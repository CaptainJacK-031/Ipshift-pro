# IPShift Pro — Kali Linux

Change your public IP address through VPNs, with leak protection and a firewall kill switch.
One project: a root daemon (`ipshiftd`), a command line (`ipshift`) and a PySide6 window (`ipshift-gui`).

> **Read this first: what "anonymous" means here.**
> No program can promise maximum anonymity, and this one does not. It does the network part as strictly as
> it can: the kill switch is fail-closed, DNS and IPv6 are locked down, every new address is verified, and
> nothing leaves your machine outside the tunnel. A VPN still only *moves* trust to its operator, and
> changing the address does nothing about your browser, your accounts or an observer who sees both ends.
> Frequent rotation can even make things worse in one way: every reconnect shows your real address to the
> VPN server you connect to. The full list is in [What this does not do](#what-this-does-not-do).

## What you get

| | |
|---|---|
| System | Kali Linux (any Debian-based system with systemd and nftables should do) |
| Language | Python 3.10+. The daemon, engine and command line use the standard library only. |
| Window | PySide6 (optional; the command line does everything the window does) |
| VPN | Free, paid and self-hosted servers, as OpenVPN (`.ovpn`) or WireGuard (`.conf`) profiles, each tagged with its tier |
| Rotation | From every 1 second. The 1-second floor is enforced in the settings, the scheduler and the command line. |
| Monitoring | Public IP (verified by independent services) and private addresses, on Wi-Fi and mobile hotspots |
| Leak tests | DNS (configuration, resolution path, escape), IPv6, tunnel, kill switch, IPv4 escape, LAN exposure, MAC address |
| Kill switch | nftables, fail-closed, armed before any tunnel comes up |
| History | SQLite, pruned after 30 days by default |

## Install

### Kali / Debian: the package

```
sudo apt install ./ipshift-pro_1.0.0_all.deb
```

It needs Python 3.10+, nftables, iproute2 and `wireguard-tools` or `openvpn`, and recommends the window's
toolkit (`python3-pyside6.qtwidgets`). The daemon is **not** started automatically.

### From the sources

```
tar xzf ipshift-pro-1.0.0.tar.gz && cd ipshift-pro-1.0.0
sudo apt install nftables iproute2 wireguard-tools openvpn python3-pyside6.qtwidgets
sudo packaging/install.sh
```

The installer copies the program to root-owned places (the daemon runs code from there, so it refuses to
install into a place other users can write to), creates the group `ipshift`, writes the launchers, the systemd
unit, the desktop entry, the completion and the manual pages. `packaging/uninstall.sh` takes it all out again
and gives you the normal network back first. `--prefix`, `--add-user NAME` and `--enable` are explained by
`--help`.

### First steps

```
sudo usermod -aG ipshift $USER          # then log out and in again
sudo systemctl enable --now ipshiftd    # start the daemon, now and at every boot
ipshift doctor                          # is this machine ready?
```

**Membership of the group `ipshift` is the right to control this machine's network** (firewall, routes,
tunnels, DNS). Add only people you would trust with that.

### Try it without root

Nothing real is touched in simulation mode: a pretend network with demo VPN profiles.

```
ipshiftd --simulate &          # as a normal user
ipshift status
ipshift-gui --demo             # the window against its own private simulated daemon
```

## Use it

```
ipshift vpn import ~/vpn/                 # every .ovpn / .conf file in a folder (asks where each server comes from)
ipshift vpn connect                       # connect, and verify the new public IP
ipshift rotate --interval 1               # change the public IP as fast as the VPNs allow
ipshift status --watch                    # live view
ipshift privacy-check                     # DNS, IPv6 and kill switch tests
ipshift stop                              # stop rotating, disconnect, give the normal network back
```

| Command | What it does |
|---|---|
| `ipshift status` | protection level, VPN, public and private IP, rotation, alerts (`--watch`, `--check` for scripts) |
| `ipshift ip` | the public and private addresses (`--public`, `--private`; `--direct` looks up your real address, only possible with no VPN and no kill switch) |
| `ipshift vpn …` | `connect`, `disconnect`, `cancel`, `list`, `import`, `remove`, `enable`, `disable`, `auth`, `set`, `reset` |
| `ipshift rotate` | `--interval SECONDS` (minimum 1), `--now`, `--stop`, `--no-immediate`, `--no-follow`, `--stop-on-exit` |
| `ipshift stop` | normal: disconnect and release the firewall. `--keep-blocking`: disconnect but keep blocking everything. `--rotation-only`: stop rotating, stay connected. |
| `ipshift privacy-check` | the ten tests with a score and a verdict (`--quick`, `--only`, `--strict`, `-v`); exit status 4 when it finds a problem |
| `ipshift killswitch` | `status`, `on`, `off`, `lockdown` (block everything, the VPN too) |
| `ipshift config` | `show`, `get`, `set`, `reload` |
| `ipshift history` | show, `--export FILE` as CSV, `--clear` |
| `ipshift harden` | DNS / IPv6 / MAC protections: `status`, `mac enable|disable|randomize|restore` |
| `ipshift restore` | undo everything IPShift changed: firewall, DNS, IPv6, MAC addresses, stray tunnels. Works without the daemon. |
| `ipshift doctor`, `events`, `version` | readiness check, recent alerts, versions |

`ipshift --json …` gives machine-readable output. Exit codes: 0 success, 1 failed, 2 wrong usage, 3 daemon not
reachable, 4 privacy check found problems, 130 interrupted. Manual pages: `man ipshift`, `man ipshiftd`,
`man ipshift-gui`.

### The window

`ipshift-gui` has five pages: **Dashboard** (public and private IP, VPN status, the protection banner, the
interval control, Start and Stop), **Privacy** (the DNS and IPv6 leak tests and the rest), **History** (every
rotation), **Profiles** (import and manage VPNs) and **Settings**. Connection failures show up as alerts in the
window and in the system tray. Anything that lowers your protection asks for confirmation first, and your
real address stays hidden until you ask to see it. Closing the window leaves the VPN and the rotation running.

## How rotation works

* The interval is a **start-to-start timer** with a hard floor of 1 second. A rotation is not a single
  instant: connecting a VPN takes time. So the tool does not report a change when the timer fires. It waits
  until the new tunnel is up, then checks the new public IP with independent services (`privacy.quorum`, two by
  default, must agree) and only then counts the change, writes it to the history and shows it.
* **Rotations never overlap.** If a connection takes longer than the interval, the next one waits for it. With
  OpenVPN, which needs several seconds to connect, "every second" means "as fast as it can". WireGuard
  profiles can be switched in a fraction of a second (`vpn.fast_switch`), so those are the ones that can follow
  a 1-second timer.
* **No leaks while switching.** The kill switch is armed before anything else happens and stays up the whole
  time. Each connection goes: arm the firewall → resolve the server name over DNS-over-HTTPS (never through
  your ISP's resolver) → allow only that server → bring the tunnel up → lock DNS and IPv6 to the tunnel →
  verify the new public IP. Until the last step succeeds, nothing but the connection attempt leaves the machine.
* A rotation that ends on the same address counts as failed (`rotation.require_change`); failures back off, and
  after `rotation.max_failures` in a row you get a critical alert. Choosing the next profile follows
  `rotation.strategy`: `diverse`, `round-robin`, `random` or `lru`.
* On Wi-Fi and mobile hotspots the daemon notices a changed network and reconnects
  (`vpn.reconnect_on_network_change`); DHCP renewals are allowed on the physical link; `vpn.mtu` and
  `vpn.wg_keepalive` are there for lossy hotspots.

## What it does for anonymity

These are the parts a network tool can do, done as strictly as it can:

* **A kill switch that fails closed.** One nftables table (`inet ipshift`), replaced atomically in a single
  transaction, so there is never a moment with half the rules. Default is drop; only the tunnel and, while
  connecting, the one VPN server are allowed. It outlives the daemon on purpose: stopping or crashing
  `ipshiftd` leaves it up, and the monitor puts it back if something else removes it.
* **DNS that cannot go around the tunnel.** Server names are resolved over DNS-over-HTTPS to fixed addresses
  (`vpn.bootstrap_doh`, Quad9 by default), plain-DNS bootstrap is off (`vpn.allow_plain_bootstrap_dns`), and
  once connected the system resolver is pinned to the tunnel (`dns.*`).
* **IPv6 closed.** It is switched off on physical interfaces (`privacy.disable_ipv6_on_physical`), and the IPv6
  test checks that nothing escapes.
* **Addresses are verified, not assumed.** The public IP is read through the tunnel from independent services
  that have to agree. The tool does not contact them *without* the VPN unless you ask for it
  (`ipshift ip --direct`, `privacy.baseline`).
* **Escape tests.** Two tests send probes pinned to your real network card (an IPv4 connection and a DNS query)
  to prove the firewall blocks them. They run inside the daemon, which is root, and they are the strongest
  evidence in `ipshift privacy-check`.
* **Quiet by default.** Logs mask addresses (`privacy.redact_logs`), history expires and can mask addresses
  (`privacy.mask_ips_in_history`), the local network is closed (`killswitch.allow_lan` is off), and nothing is
  forwarded for other devices (`killswitch.allow_forward` is off).
* **MAC addresses.** `ipshift harden mac enable` turns on NetworkManager's randomisation, so an access point or
  hotspot does not see your card's real MAC address. The privacy check warns while it is off.
* **A small privileged program.** Standard library only: no third-party code runs as root. OpenVPN drops root
  after set-up (`vpn.openvpn_user`). Profiles and keys are in root-only files (`/var/lib/ipshift`), and the
  generated tunnel configs live on tmpfs (`/run/ipshift/runtime`).

## What this does not do

* **A VPN moves trust, it does not remove it.** The operator sees where your traffic goes and, unless it is
  encrypted end to end, what it contains. Free VPNs may log, sell or alter it. A server you rent yourself is
  only as anonymous as the account you rented it with.
* **Every reconnect shows your real address to the VPN server you connect to.** Rotating through many providers
  means many operators learn it, and your ISP sees you connecting to all of them. A few providers you trust are
  better than many you do not know. A 1-second rotation is for changing the address, not for hiding.
* **Your browser is outside this tool.** WebRTC, canvas and font fingerprints, cookies, logins, time zone and
  language still identify you. Use a hardened browser profile, or Tor Browser.
* **Accounts and habits.** Signing in, paying, even your writing style tie sessions together whatever the IP.
* **An observer at both ends** can match timing and traffic volume.
* **Other devices.** The firewall protects this machine. Phones, a router, virtual machines on a bridge or
  devices sharing your hotspot are not covered, and `killswitch.allow_forward` and `killswitch.allow_ifaces`
  deliberately open holes (the privacy check warns about them).
* **Malware on this machine, or anyone with root.**

If you need anonymity rather than a different address, use Tor Browser, Tails or Whonix. The report of
`ipshift privacy-check` ends with this same "not covered" list, so a good score is never read as a guarantee.

## Security model

* **Two privilege levels.** `ipshiftd` runs as root and is the only part that touches nftables, routes, tunnels
  and DNS. `ipshift` and `ipshift-gui` are unprivileged clients of its Unix socket.
* **The socket** `/run/ipshift/ipshift.sock` is `root:ipshift`, mode 0660, in a 0750 directory, and the daemon
  checks the peer's credentials (`SO_PEERCRED`) on every connection: root, members of `ipshift`, or the user
  ids in `daemon.allowed_uids`. Membership of the group therefore equals control of the machine's network;
  treat it like `sudo` for networking.
* **The protocol** is JSON lines with typed, size-limited requests. Only a fixed list of settings can be
  changed over it, nothing goes through a shell, and external programs are started with argument lists.
* **The daemon** sets umask 077, disables core dumps and makes itself non-dumpable (it holds VPN keys in memory),
  takes a lock so only one runs, and keeps its directories private. The systemd unit adds only restrictions
  that cannot break what the daemon needs (`NoNewPrivileges`, `PrivateTmp`, `ProtectHome` and a few more); it is
  deliberately not sandboxed further because the daemon manages the firewall, routes, `/etc/resolv.conf`,
  `/proc/sys` and `/dev/net/tun`.
* **Fail-closed.** The daemon stopping or crashing leaves the kill switch up. `sudo ipshift restore` gives you the
  normal network back without the daemon, from the backup in `/var/lib/ipshift/backup`. Uninstalling does it for
  you first.
* **Not defended against:** root, members of the `ipshift` group, kernel bugs, or a hostile VPN provider.

## Settings worth knowing

`ipshift config show`, `ipshift config set rotation.interval 5`, or edit `/etc/ipshift/config.json` and run
`sudo systemctl reload ipshiftd`. Changes that lower your protection ask for confirmation.

| Setting | Default | Meaning |
|---|---|---|
| `rotation.interval` | 30 | seconds between rotation starts (minimum 1) |
| `rotation.strategy` | `diverse` | `diverse`, `round-robin`, `random`, `lru` |
| `rotation.require_change` | on | a rotation that ends on the same address counts as failed |
| `rotation.tiers`, `rotation.profiles` | all | restrict rotation to `free` / `paid` / `self-hosted`, or to named profiles |
| `killswitch.enabled` | on | arm the kill switch before any tunnel is brought up |
| `killswitch.arm_on_start` | off | block everything from the moment the daemon starts (cuts off an SSH session!) |
| `killswitch.release_on_exit` | off | release the firewall when the daemon stops (off = fail-closed) |
| `killswitch.allow_lan` | off | reach 10/8, 172.16/12, 192.168/16 outside the tunnel |
| `vpn.fast_switch` | on | WireGuard peer hot-swap when profiles are compatible |
| `vpn.auto_reconnect`, `vpn.reconnect_on_network_change` | on | recover from drops and from a new Wi-Fi or hotspot |
| `vpn.mtu`, `vpn.wg_keepalive` | auto, 25 | for lossy mobile hotspots |
| `privacy.quorum` | 2 | independent services that must agree on the public IP |
| `privacy.disable_ipv6_on_physical` | on | no IPv6 outside the tunnel |
| `privacy.history_retention_days` | 30 | how long the history is kept |

## If something goes wrong

* **The network is blocked** after a stop, a crash or an uninstall: `sudo ipshift restore`. Last resort, if
  even that does not work: `sudo nft delete table inet ipshift`.
* **`ipshift` says the daemon is not reachable** (exit status 3): is it running (`systemctl status ipshiftd`,
  `journalctl -u ipshiftd`)? Are you in the group `ipshift` (log out and in after adding yourself)?
* **Over SSH or a remote desktop**, arming the kill switch can cut your own session off. Allow that path first
  with `killswitch.allow_lan` or `killswitch.allow_ifaces`, or work at the machine.
* **Rotation is slower than the interval:** OpenVPN needs seconds to connect; use WireGuard profiles for fast
  switching.
* **DNS or IPv6 settings keep changing:** another program (NetworkManager, a VPN client) is fighting for them.
  `ipshift harden status` shows what IPShift holds; the monitor repairs and reports it.
* **Logs:** `/var/log/ipshift/ipshift.log`, `journalctl -u ipshiftd`, `ipshift events --follow`.

## What was tested, and what was not

Tested in the build environment:

* More than 1,300 automated tests (standard `unittest`) for the engine, the firewall rules, the socket protocol,
  the command line and the logic of the window, against a simulated network and fake OpenVPN / WireGuard
  programs.
* The nftables rules **in a real kernel**, inside a throw-away network namespace with fake network cards: which
  packets actually leave which interface (`sudo unshare -n python3 tests/netns_killswitch.py`).
* The installation: the staged files, the launchers, the unit file (`systemd-analyze verify`), the manifest-driven
  uninstall, the contents of the `.deb`, and install / reinstall / remove / purge of the `.deb` with the real
  `dpkg` in a throw-away namespace.
* The OpenVPN profile cleaner against thousands of generated hostile profiles (`tests/test_ovpn_fuzz.py`): only
  allow-listed options come out, never one that runs a program, reads a file or switches the encryption off.

**Not tested** (it could not be, there):

* **Real VPN servers.** No OpenVPN or WireGuard endpoint was reachable, so a real tunnel set-up, real exit
  addresses and real reconnect timings are untested. Your first `ipshift vpn connect` is the real test; run
  `ipshift privacy-check` after it.
* **Real NetworkManager, systemd-resolved and Wi-Fi roaming.** Only their command-line interfaces were simulated.
* **The window against real Qt.** PySide6 could not be installed there, so the Qt layer was tested against a
  strict stand-in that only knows the real API names. Run `ipshift-gui --selftest` once on your machine: it
  drives the same scripted scenario through real Qt (offscreen, no display needed) and exits with 0 when every
  check passed.
* **Systemd hardening** beyond what `systemd-analyze verify` checks, and installation on a live Kali system.
* **Review by someone else.** The code was written and checked by one party. The author re-read the profile
  cleaner, the socket server, the list of settings a client may change, the firewall rules and the window's calls
  into Qt; nobody else has. Have the daemon, the profile cleaner and the firewall rules reviewed before you rely
  on this on a machine that matters.

## Development

```
src/ipshift/    engine, daemon, ipc, cli, gui (the Qt-free logic and the thin PySide6 layer), vpn, firewall, privacy, net
tests/          unit tests, a stand-in for PySide6 (tests/fakeqt), the kernel kill-switch check
packaging/      install.sh, uninstall.sh, build_deb.sh, build_tarball.sh, systemd unit, desktop entry, Debian files
```

```
PYTHONPATH=src:tests python3 -m unittest discover -s tests -p "test_*.py"     # about 3 minutes
packaging/build_deb.sh        # dist/ipshift-pro_1.0.0_all.deb  (IPSHIFT_MAINTAINER="Name <mail>" names you)
packaging/build_tarball.sh    # dist/ipshift-pro-1.0.0.tar.gz
```

## Licence

Proprietary, all rights reserved. This is a placeholder: set the licence you want in `pyproject.toml` and
`packaging/debian/copyright` before you pass the program on.
