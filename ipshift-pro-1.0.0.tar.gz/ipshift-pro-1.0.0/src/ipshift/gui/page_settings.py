"""The Settings page, built from ``settings_schema.SECTIONS`` and nothing else.

Every control is one entry of that table, whose limits are checked against the daemon's own validation by
the tests, so the page cannot offer a value the daemon would refuse.  A change is sent as soon as it is made
(typing in a number or text box waits until you stop); the window asks first when the change lowers
protection, and puts the control back if the daemon says no.
"""
from __future__ import annotations

import math

from PySide6.QtCore import QTimer, Signal
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDoubleSpinBox, QFrame, QLineEdit, QScrollArea, QSpinBox,
                               QVBoxLayout, QWidget)

from .settings_schema import SECTIONS, Setting, list_text, parse_list
from .widgets import Card, hbox, label, set_text

DEBOUNCE_MS = 700


def comparable(s: Setting, value):
    """The form in which two values of one setting are compared (the order of a list does not matter)."""
    if s.kind == "list":
        return parse_list(value)
    if s.kind == "multi":
        return sorted(str(v) for v in value or [])
    return value


class SettingsPage(QWidget):
    change_requested = Signal(object, object)        # Setting, the new value

    def __init__(self):
        super().__init__()
        self.setObjectName("page")
        self._controls: dict[str, tuple[Setting, QWidget]] = {}
        self._pending: dict[str, Setting] = {}
        self._known: dict[str, object] = {}              # what the daemon has (or was last told), to skip no-op changes
        self._loading = False
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self._flush)

        self.note = label("Waiting for the daemon...", role="muted", wrap=True)
        content = QWidget()
        content.setObjectName("page")
        body = QVBoxLayout(content)
        body.setContentsMargins(22, 18, 22, 22)
        body.setSpacing(14)
        body.addWidget(label("Settings", role="h1"))
        body.addWidget(self.note)
        for section in SECTIONS:
            card = Card(section.title)
            card.add(label(section.intro, role="muted", wrap=True))
            for setting in section.settings:
                card.add(self._row(setting))
            body.addWidget(card)
        body.addStretch(1)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setWidget(content)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(scroll)
        self.load(None)

    # ---- building the controls --------------------------------------------------------------------------------
    def _row(self, s: Setting) -> QWidget:
        control = self._control(s)
        self._controls[s.key] = (s, control)
        box = QWidget()
        lay = QVBoxLayout(box)
        lay.setContentsMargins(0, 4, 0, 4)
        lay.setSpacing(2)
        if s.kind == "bool":
            lay.addWidget(control)
        else:
            lay.addLayout(hbox(label(s.label), None, control))
        help_text = s.help + (" Takes effect after the daemon restarts." if s.restart else "")
        if help_text:
            lay.addWidget(label(help_text, role="small", wrap=True))
        return box

    def _control(self, s: Setting) -> QWidget:
        if s.kind == "bool":
            w = QCheckBox(s.label)
            w.toggled.connect(lambda *_, s=s: self._commit(s))
            return w
        if s.kind == "int":
            w = QSpinBox()
            w.setRange(int(s.minimum), int(s.maximum))
            w.setSingleStep(int(s.step))
            w.setKeyboardTracking(False)
            w.valueChanged.connect(lambda *_, s=s: self._edited(s))
        elif s.kind == "float":
            w = QDoubleSpinBox()
            w.setDecimals(s.decimals)
            w.setRange(float(s.minimum), float(s.maximum))
            w.setSingleStep(float(s.step))
            w.setKeyboardTracking(False)
            w.valueChanged.connect(lambda *_, s=s: self._edited(s))
        elif s.kind == "choice":
            w = QComboBox()
            for value, text in s.choices:
                w.addItem(text, value)
            w.currentIndexChanged.connect(lambda *_, s=s: self._commit(s))
            return w
        elif s.kind == "multi":
            w = QWidget()
            w.boxes = {}
            row = hbox(spacing=12)
            for value, text in s.choices:
                box = QCheckBox(text)
                box.toggled.connect(lambda *_, s=s: self._commit(s))
                w.boxes[value] = box
                row.addWidget(box)
            w.setLayout(row)
            return w
        else:                                         # "list"
            w = QLineEdit()
            w.setMinimumWidth(280)
            w.editingFinished.connect(lambda *_, s=s: self._edited(s, now=True))
            return w
        if s.unit:
            w.setSuffix(f" {s.unit}")
        return w

    # ---- reading and writing the controls ----------------------------------------------------------------------
    @staticmethod
    def _read(s: Setting, w: QWidget):
        if s.kind == "bool":
            return w.isChecked()
        if s.kind == "int":
            return int(w.value())
        if s.kind == "float":
            return float(w.value())
        if s.kind == "choice":
            return w.currentData()
        if s.kind == "multi":
            return [value for value, box in w.boxes.items() if box.isChecked()]
        return w.text()

    @staticmethod
    def _write(s: Setting, w: QWidget, value) -> None:
        if s.kind == "bool":
            w.setChecked(bool(value))
        elif s.kind == "int":
            w.setValue(int(value))                    # an int box refuses a float, a float box takes an int
        elif s.kind == "float":
            number = float(value)
            if not math.isfinite(number):             # JSON can carry NaN and Infinity; a spin box cannot show them
                raise ValueError(f"{s.key}: {value!r} is not a usable number")
            w.setValue(number)
        elif s.kind == "choice":
            i = w.findData(value)
            if i < 0:                                 # a value set by hand that the list does not know
                w.addItem(f"{value} (current)", value)
                i = w.findData(value)
            w.setCurrentIndex(i)
        elif s.kind == "multi":
            have = set(value or [])
            for v, box in w.boxes.items():
                box.setChecked(v in have)
        else:
            w.setText(list_text(value))

    def load(self, config: dict | None, *, force: bool = False, info: str = "") -> None:
        """Show the daemon's values (``{section: {key: value}}``).  A control being edited is left alone
        unless ``force`` (used to put back a value the daemon refused)."""
        self._loading = True
        try:
            for key, (s, w) in self._controls.items():
                section, _, name = key.partition(".")
                values = (config or {}).get(section) or {}
                present = name in values
                w.setEnabled(present)
                if present and (force or not w.hasFocus()):
                    try:
                        self._write(s, w, values[name])
                    except (TypeError, ValueError, OverflowError):
                        w.setEnabled(False)           # a value this control cannot show: leave it alone
                        continue
                    self._known[key] = comparable(s, values[name])
        finally:
            self._loading = False
        set_text(self.note, info if config else "Waiting for the daemon...")

    # ---- announcing a change -----------------------------------------------------------------------------------
    def _edited(self, s: Setting, *, now: bool = False) -> None:
        if self._loading:
            return
        if now:
            self._commit(s)
            return
        self._pending[s.key] = s                      # keep typing: send when the user pauses
        self._timer.start(DEBOUNCE_MS)

    def _flush(self) -> None:
        pending, self._pending = list(self._pending.values()), {}
        for s in pending:
            self._commit(s)

    def _commit(self, s: Setting) -> None:
        if self._loading:
            return
        self._pending.pop(s.key, None)
        value = self._read(s, self._controls[s.key][1])
        if comparable(s, value) == self._known.get(s.key):
            return                                    # nothing changed (e.g. focus left a box that was not edited)
        self._known[s.key] = comparable(s, value)
        self.change_requested.emit(s, value)

    def control(self, key: str) -> QWidget:
        return self._controls[key][1]

    def value(self, key: str):
        s, w = self._controls[key]
        return self._read(s, w)
