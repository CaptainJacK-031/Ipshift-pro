"""Colours and the Qt style sheet.  A plain string: nothing here imports PySide6, so it is testable.

Widgets get their colour from a ``tone`` property (good / warn / bad / info / muted / plain), set with
``widgets.set_prop``; the style sheet below maps each tone to a colour, so the Python code never
mentions a colour at all.
"""
from __future__ import annotations

from string import Template

from .views import BAD, GOOD, INFO, MUTED, PLAIN, WARN

PALETTE = {
    "bg": "#0f1419",          # window
    "surface": "#171d25",     # cards
    "surface2": "#1f2731",    # inputs, alternate rows
    "border": "#2c3745",
    "text": "#e6edf3",
    "muted": "#8b98a8",
    "good": "#3fb950",
    "warn": "#d29922",
    "bad": "#f85149",
    "info": "#58a6ff",
    "accent": "#2f81f7",
    "accent_hover": "#4893ff",
    "mono": '"DejaVu Sans Mono", "Liberation Mono", monospace',
}
TONE_KEY = {GOOD: "good", WARN: "warn", BAD: "bad", INFO: "info", MUTED: "muted", PLAIN: "text"}
# (red, green, blue) behind a tinted background, e.g. rgba(63, 185, 80, 0.15)
TINT = {GOOD: "63, 185, 80", WARN: "210, 153, 34", BAD: "248, 81, 73", INFO: "88, 166, 255", MUTED: "139, 152, 168"}


def tone_color(tone: str, palette: dict | None = None) -> str:
    return (palette or PALETTE)[TONE_KEY.get(tone, "text")]


def _tone_rules() -> str:
    out = []
    for tone in (GOOD, WARN, BAD, INFO, MUTED):
        t = TINT[tone]
        out.append(f'''
QLabel[tone="{tone}"] {{ color: ${{{TONE_KEY[tone]}}}; }}
QLabel[pill="true"][tone="{tone}"] {{ background: rgba({t}, 0.15); border: 1px solid rgba({t}, 0.55); color: ${{{TONE_KEY[tone]}}}; }}
QFrame#banner[tone="{tone}"] {{ border-left: 5px solid ${{{TONE_KEY[tone]}}}; background: rgba({t}, 0.10); }}
QFrame#tile[tone="{tone}"] {{ border-left: 4px solid ${{{TONE_KEY[tone]}}}; }}
QFrame#toast[tone="{tone}"] {{ border: 1px solid rgba({t}, 0.7); background: rgba({t}, 0.14); }}''')
    return "".join(out)


_QSS = """
* { font-size: 13px; }
QMainWindow, QDialog, QWidget#root, QScrollArea, QWidget#page { background: ${bg}; color: ${text}; }
QWidget { color: ${text}; }
QLabel { background: transparent; }
QToolTip { background: ${surface2}; color: ${text}; border: 1px solid ${border}; padding: 4px; }

QFrame#card { background: ${surface}; border: 1px solid ${border}; border-radius: 10px; }
QFrame#banner { background: ${surface}; border: 1px solid ${border}; border-radius: 10px; }
QFrame#tile { background: ${surface}; border: 1px solid ${border}; border-radius: 8px; }
QFrame#toast { background: ${surface}; border: 1px solid ${border}; border-radius: 8px; }
QFrame#sep { background: ${border}; max-height: 1px; border: none; }

QLabel[role="muted"] { color: ${muted}; }
QLabel[role="small"] { color: ${muted}; font-size: 12px; }
QLabel[role="title"] { color: ${muted}; font-size: 11px; font-weight: 600; }
QLabel[role="h1"] { font-size: 22px; font-weight: 700; }
QLabel[role="h2"] { font-size: 15px; font-weight: 600; }
QLabel[role="big"] { font-size: 28px; font-weight: 700; font-family: ${mono}; }
QLabel[role="mono"] { font-family: ${mono}; }
QLabel[role="score"] { font-size: 44px; font-weight: 800; }
QLabel[pill="true"] { border-radius: 10px; padding: 2px 10px; font-size: 11px; font-weight: 700; border: 1px solid ${border}; }
${tone_rules}

QPushButton { background: ${surface2}; border: 1px solid ${border}; border-radius: 6px; padding: 7px 16px; }
QPushButton:hover { border-color: ${accent}; }
QPushButton:pressed { background: ${border}; }
QPushButton:disabled { color: ${muted}; background: ${surface}; border-color: ${surface2}; }
QPushButton[role="primary"] { background: ${accent}; border-color: ${accent}; color: #ffffff; font-weight: 600; }
QPushButton[role="primary"]:hover { background: ${accent_hover}; border-color: ${accent_hover}; }
QPushButton[role="primary"]:disabled { background: ${surface2}; border-color: ${surface2}; color: ${muted}; }
QPushButton[role="danger"] { background: transparent; border-color: ${bad}; color: ${bad}; }
QPushButton[role="danger"]:hover { background: rgba(248, 81, 73, 0.16); }
QPushButton[role="danger"]:disabled { border-color: ${surface2}; color: ${muted}; }
QPushButton[role="link"] { background: transparent; border: none; color: ${info}; padding: 2px 4px; text-align: left; }
QPushButton[role="link"]:hover { text-decoration: underline; }
QPushButton[role="link"]:disabled { color: ${muted}; }

QDoubleSpinBox, QSpinBox, QLineEdit, QComboBox, QPlainTextEdit { background: ${surface2}; border: 1px solid ${border}; border-radius: 6px; padding: 5px 8px; selection-background-color: ${accent}; }
QDoubleSpinBox:focus, QSpinBox:focus, QLineEdit:focus, QComboBox:focus { border-color: ${accent}; }
QDoubleSpinBox:disabled, QSpinBox:disabled, QLineEdit:disabled, QComboBox:disabled { color: ${muted}; }
QDoubleSpinBox#interval { font-size: 20px; font-weight: 700; font-family: ${mono}; padding: 6px 10px; }
QComboBox QAbstractItemView { background: ${surface2}; border: 1px solid ${border}; selection-background-color: ${accent}; }
QCheckBox, QRadioButton { spacing: 8px; }
QCheckBox::indicator { width: 16px; height: 16px; border: 1px solid ${border}; border-radius: 4px; background: ${surface2}; }
QCheckBox::indicator:checked { background: ${accent}; border-color: ${accent}; }
QRadioButton::indicator { width: 14px; height: 14px; border: 1px solid ${border}; border-radius: 8px; background: ${surface2}; }
QRadioButton::indicator:checked { background: ${accent}; border-color: ${accent}; }

QTableView { background: ${surface}; alternate-background-color: ${surface2}; gridline-color: ${border}; border: 1px solid ${border}; border-radius: 8px; selection-background-color: rgba(47, 129, 247, 0.35); selection-color: ${text}; }
QHeaderView::section { background: ${surface2}; color: ${muted}; border: none; border-bottom: 1px solid ${border}; padding: 6px 8px; font-weight: 600; }
QTabWidget::pane { border: 1px solid ${border}; border-radius: 8px; top: -1px; }
QTabBar::tab { padding: 7px 16px; color: ${muted}; border-bottom: 2px solid transparent; }
QTabBar::tab:selected { color: ${text}; border-bottom: 2px solid ${accent}; }
QProgressBar { background: ${surface2}; border: none; border-radius: 3px; max-height: 6px; text-align: center; }
QProgressBar::chunk { background: ${accent}; border-radius: 3px; }

QListWidget#nav { background: ${surface}; border: none; border-right: 1px solid ${border}; outline: 0; padding: 10px 8px; }
QListWidget#nav::item { padding: 10px 14px; border-radius: 8px; margin: 2px 0; color: ${muted}; }
QListWidget#nav::item:hover:!selected { background: ${surface2}; }
QListWidget#nav::item:selected { background: rgba(47, 129, 247, 0.18); color: ${text}; }
QStatusBar { background: ${surface}; color: ${muted}; border-top: 1px solid ${border}; }
QMenuBar { background: ${surface}; }
QMenuBar::item:selected, QMenu::item:selected { background: rgba(47, 129, 247, 0.25); }
QMenu { background: ${surface2}; border: 1px solid ${border}; }
QScrollBar:vertical { background: transparent; width: 10px; margin: 0; }
QScrollBar::handle:vertical { background: ${border}; border-radius: 5px; min-height: 30px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar:horizontal { background: transparent; height: 10px; margin: 0; }
QScrollBar::handle:horizontal { background: ${border}; border-radius: 5px; min-width: 30px; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; }
"""


def qss(palette: dict | None = None) -> str:
    """The whole style sheet, with the palette filled in."""
    p = dict(palette or PALETTE)
    p["tone_rules"] = Template(_tone_rules()).substitute(p)
    return Template(_QSS).substitute(p)
