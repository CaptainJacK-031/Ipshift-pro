"""The window's connection to the daemon, with no Qt in it.

Three kinds of thread keep the window responsive:

* a **poller** asks for the status every couple of seconds (and at once when an event arrives),
  fetches the history, profiles and last privacy report when they are wanted or have changed,
  and notices when the daemon goes away or comes back;
* an **event reader** holds the event stream open and reconnects when the daemon restarts;
* one short-lived thread per **command** (a connection can take 30 s; the window must not freeze).

Everything is reported through a ``Listener``.  Its methods are called from those threads, never
from the GUI thread; the Qt layer turns every call into a queued signal.
"""
from __future__ import annotations

import logging
import socket
import threading
import time
from dataclasses import dataclass

from ..errors import DaemonUnavailable, IPShiftError
from ..ipc.client import Client

log = logging.getLogger("ipshift.gui")

# Client methods the window may run by name; anything else is a programming error.
COMMANDS = frozenset({
    "connect", "cancel", "stop", "rotate_start", "rotate_stop", "rotate_now", "set_interval", "privacy_check",
    "profile_remove", "profile_update", "profile_auth", "profile_clear_quarantine",
    "killswitch_on", "killswitch_off", "lockdown", "config_get", "config_set",
    "history_clear", "history_export", "ip", "doctor", "restore",
})
HISTORY_EVENTS = frozenset({"connected", "unchanged", "connect_failed", "cancelled"})
PROFILE_EVENTS = frozenset({"profile_imported", "profile_removed", "connected", "connect_failed", "unchanged"})


@dataclass(frozen=True)
class Result:
    """The outcome of one command."""
    name: str
    ok: bool
    data: object = None
    error: dict | None = None

    @property
    def message(self) -> str:
        return str((self.error or {}).get("message") or (self.error or {}).get("code") or "") if self.error else ""

    @property
    def hint(self) -> str:
        return str((self.error or {}).get("hint") or "")


@dataclass(frozen=True)
class Timing:
    """How often things are asked for (seconds).  The defaults suit a person watching the window."""
    poll: float = 2.0                 # status, while nothing happens
    min_gap: float = 0.5              # never ask for the status more often than this
    profiles_every: float = 15.0
    profiles_gap: float = 2.0         # after a change, at most this often
    history_every: float = 5.0
    history_gap: float = 1.5
    reconnect: float = 1.0            # event stream: first wait before trying again
    reconnect_max: float = 5.0


class Listener:
    """Override what you need; every method may be called from a non-GUI thread."""

    def on_link(self, up: bool, error: str, hint: str) -> None: ...
    def on_status(self, status: dict) -> None: ...
    def on_event(self, event: dict) -> None: ...
    def on_data(self, name: str, data) -> None: ...          # "profiles" | "history" | "report"
    def on_busy(self, busy: frozenset) -> None: ...
    def on_result(self, result: Result) -> None: ...


class DaemonLink:
    def __init__(self, listener: Listener, client_factory=Client, *, timing: Timing | None = None,
                 history_limit: int = 300):
        self.listener = listener
        self._factory = client_factory
        self.timing = timing or Timing()
        self._poll = self.timing.poll
        self._history_limit = history_limit
        self._stop = threading.Event()
        self._wake = threading.Event()
        self._lock = threading.Lock()
        self._busy: dict[str, int] = {}
        self._want_history = False
        self._dirty = {"history": True, "profiles": True, "report": True}
        self._last = {"history": 0.0, "profiles": 0.0}
        self._events_sock = None
        self._threads: list[threading.Thread] = []
        self._last_error = None
        self.up: bool | None = None                          # None until the first answer or failure

    # ---- lifecycle ---------------------------------------------------------------------------------
    def start(self) -> "DaemonLink":
        for name, fn in (("poll", self._poll_loop), ("events", self._event_loop)):
            t = threading.Thread(target=fn, name=f"ipshift-gui-{name}", daemon=True)
            t.start()
            self._threads.append(t)
        return self

    def close(self) -> None:
        """Stop the threads.  A command that is still waiting for the daemon is simply left behind."""
        self._stop.set()
        self._wake.set()
        sock = self._events_sock
        if sock is not None:
            try:
                sock.shutdown(socket.SHUT_RDWR)             # ends a stream that is waiting for the next event
            except OSError:
                pass
        for t in self._threads:
            t.join(timeout=3.0)

    @property
    def closed(self) -> bool:
        return self._stop.is_set()

    # ---- what the window asks for -------------------------------------------------------------------
    def refresh(self, *, everything: bool = False) -> None:
        if everything:
            for k in self._dirty:
                self._dirty[k] = True
        self._wake.set()

    def want_history(self, wanted: bool) -> None:
        """The History page is on screen: keep the table fresh (it is not fetched otherwise)."""
        self._want_history = wanted
        if wanted:
            self._dirty["history"] = True
            self._wake.set()

    def set_poll(self, seconds: float) -> None:
        """Slower while the window is hidden."""
        self._poll = max(0.5, float(seconds))
        self._wake.set()

    @property
    def busy(self) -> frozenset:
        with self._lock:
            return frozenset(n for n, c in self._busy.items() if c > 0)

    def run(self, name: str, **kwargs) -> None:
        """Run ``Client.<name>(**kwargs)`` in the background; the outcome arrives as ``on_result``."""
        if name not in COMMANDS:
            raise ValueError(f"unknown command {name!r}")
        self.submit(name, lambda client: getattr(client, name)(**kwargs))

    def submit(self, name: str, job) -> None:
        """Run ``job(client)`` in the background under ``name`` (for jobs that make several calls)."""
        with self._lock:
            self._busy[name] = self._busy.get(name, 0) + 1
        self._emit("on_busy", self.busy)
        threading.Thread(target=self._run_job, args=(name, job), name=f"ipshift-gui-{name}", daemon=True).start()

    # ---- the command thread -------------------------------------------------------------------------
    def _run_job(self, name: str, job) -> None:
        try:
            result = Result(name, True, job(self._factory()))
        except IPShiftError as e:
            result = Result(name, False, None, e.to_dict())
        except Exception as e:                               # a bug in a job must be reported, not swallowed
            log.exception("command %s failed unexpectedly", name)
            result = Result(name, False, None, {"code": "internal", "message": f"{type(e).__name__}: {e}",
                                                "hint": "this is a bug in the window; the daemon is unaffected"})
        with self._lock:
            self._busy[name] = max(0, self._busy.get(name, 1) - 1)
        self._emit("on_result", result)
        self._emit("on_busy", self.busy)
        self.refresh(everything=True)

    # ---- the poller ---------------------------------------------------------------------------------
    def _poll_loop(self) -> None:
        client = self._factory()
        failures = 0
        while not self._stop.is_set():
            # Clear the wake-up *before* fetching: anything that changes from here on re-arms it, and
            # anything that changed earlier is covered by this very fetch.  (Clearing after a throttle
            # wait would swallow a wake-up that arrived during it.)
            self._wake.clear()
            began = time.monotonic()
            try:
                status = client.status()
            except IPShiftError as e:
                failures += 1
                self._set_link(False, e)
                delay = min(5.0, float(failures))
            except Exception as e:                           # never let the poller die
                log.exception("status poll failed unexpectedly")
                failures += 1
                self._set_link(False, DaemonUnavailable(f"unexpected error: {e}"))
                delay = 5.0
            else:
                failures = 0
                if self.up is not True:
                    self._mark(*self._dirty)
                self._set_link(True, None)
                self._emit("on_status", status)
                self._fetch_secondary(client)
                delay = self._poll
            self._wake.wait(delay)
            gap = self.timing.min_gap - (time.monotonic() - began)     # never ask more often than min_gap
            if gap > 0 and self._stop.wait(gap):
                break

    def _mark(self, *kinds: str) -> None:
        for k in kinds:
            self._dirty[k] = True

    def _due(self, kind: str, every: float, gap: float) -> bool:
        age = time.monotonic() - self._last[kind]
        return (self._dirty[kind] and age >= gap) or age >= every

    def _fetch_secondary(self, client) -> None:
        try:
            t = self.timing
            if self._due("profiles", t.profiles_every, t.profiles_gap):
                self._dirty["profiles"] = False
                self._last["profiles"] = time.monotonic()
                self._emit("on_data", "profiles", client.profiles())
            if self._want_history and self._due("history", t.history_every, t.history_gap):
                self._dirty["history"] = False
                self._last["history"] = time.monotonic()
                self._emit("on_data", "history", client.history(self._history_limit))
            if self._dirty["report"]:
                self._dirty["report"] = False
                self._emit("on_data", "report", client.report())
        except DaemonUnavailable:
            pass                                             # the next status poll reports it
        except IPShiftError as e:
            log.warning("could not refresh a view: %s", e)

    def _set_link(self, up: bool, error: IPShiftError | None) -> None:
        text = str(error) if error else ""
        if self.up is up and (up or text == self._last_error):
            return
        self.up, self._last_error = up, (text if not up else None)
        self._emit("on_link", up, text, (getattr(error, "hint", None) or "") if error else "")

    # ---- the event reader ---------------------------------------------------------------------------
    def _event_loop(self) -> None:
        client = self._factory()
        t = self.timing
        wait = t.reconnect
        while not self._stop.is_set():
            began = time.monotonic()
            try:
                for ev in client.events(min_level="info", replay=30, on_open=self._remember):
                    if self._stop.is_set():
                        return
                    self._note(ev)
                    self._emit("on_event", ev)
            except IPShiftError:
                pass                                         # not running, or not allowed: retry below
            except Exception:
                log.exception("the event stream failed unexpectedly")
            self._events_sock = None
            wait = t.reconnect if time.monotonic() - began > 5.0 else min(t.reconnect_max, wait * 1.5)
            if self._stop.wait(wait):
                return

    def _remember(self, sock) -> None:
        self._events_sock = sock

    def _note(self, ev: dict) -> None:
        kind = ev.get("kind")
        if kind in HISTORY_EVENTS:
            self._dirty["history"] = True
        if kind in PROFILE_EVENTS:
            self._dirty["profiles"] = True
        if kind == "leak_detected":
            self._dirty["report"] = True
        self._wake.set()                                     # anything that happened may change the status

    # ---- delivery -----------------------------------------------------------------------------------
    def _emit(self, method: str, *args) -> None:
        if self._stop.is_set():
            return
        try:
            getattr(self.listener, method)(*args)
        except Exception:                                    # a broken listener must not stop the link
            log.exception("listener.%s failed", method)
