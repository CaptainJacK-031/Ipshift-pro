"""Every button in the window as one method (no Qt).

The window calls these; so do the tests, against a real simulated daemon.  Each one hands the work to
the link, which runs it in the background, so a slow connection never freezes the window.
"""
from __future__ import annotations

from ..errors import IPShiftError
from . import tables, views
from .link import DaemonLink
from .model import AppModel
from .settings_schema import Setting, parse_list


class Actions:
    def __init__(self, link: DaemonLink, model: AppModel):
        self.link, self.model = link, model

    # ---- rotation -----------------------------------------------------------------------------------
    def start(self, interval: float) -> float:
        """Connect and rotate every ``interval`` seconds (never less than the 1 s floor)."""
        value = views.clean_interval(interval)
        self.link.run("rotate_start", interval=value)
        return value

    def stop(self, option: str = "release") -> None:
        """``option`` is one of ``views.STOP_OPTIONS``: rotation, block or release."""
        self.link.run("stop", **views.stop_kwargs(option))

    def rotate_now(self) -> None:
        self.link.run("rotate_now")

    def cancel(self) -> None:
        self.link.run("cancel")

    def apply_interval(self, value: float) -> float:
        """A change in the interval box: sent at once when the rotation is running, otherwise kept
        for the next Start."""
        v = views.clean_interval(value)
        if ((self.model.status or {}).get("rotation") or {}).get("running"):
            self.link.run("set_interval", value=v)
        return v

    # ---- privacy ------------------------------------------------------------------------------------
    def privacy_check(self, mode: str = "full") -> None:
        self.link.run("privacy_check", mode="quick" if mode == "quick" else "full")

    def lookup_real_ip(self) -> None:
        """Look up the real address on request: it is never done on its own while unprotected."""
        self.link.run("ip", direct=True)

    # ---- kill switch ----------------------------------------------------------------------------------
    def killswitch(self, action: str) -> None:
        name = {"on": "killswitch_on", "off": "killswitch_off", "lockdown": "lockdown"}.get(action)
        if name is None:
            raise ValueError(f"unknown kill switch action {action!r}")
        self.link.run(name)

    # ---- profiles -----------------------------------------------------------------------------------
    def connect_profile(self, profile_id: str) -> None:
        self.link.run("connect", profile=profile_id)

    def set_enabled(self, profile_id: str, enabled: bool) -> None:
        self.link.run("profile_update", ref=profile_id, enabled=bool(enabled))

    def remove_profile(self, profile_id: str) -> None:
        self.link.run("profile_remove", ref=profile_id)

    def set_login(self, profile_id: str, username: str, password: str) -> None:
        self.link.run("profile_auth", ref=profile_id, username=username, password=password)

    def clear_benched(self, profile_id: str | None = None) -> None:
        """Let a profile that was benched after failures be used again (all of them when no id is given)."""
        self.link.run("profile_clear_quarantine", ref=profile_id)

    def import_profiles(self, paths, *, tier: str = "unknown", username: str | None = None,
                        password: str | None = None, replace: bool = False) -> None:
        paths = list(paths)
        self.link.submit("profile_import", lambda client: tables.import_files(
            client, paths, tier=tier, username=username, password=password, replace=replace))

    # ---- history ------------------------------------------------------------------------------------
    def clear_history(self) -> None:
        self.link.run("history_clear")

    def export_history(self, path, *, overwrite: bool = False, limit: int = 100_000) -> None:
        def job(client):
            res = client.history_export(limit)
            try:
                tables.export_csv(path, res["csv"], overwrite=overwrite)
            except FileExistsError:
                raise IPShiftError(f"{path} already exists", hint="choose another name") from None
            except OSError as e:
                raise IPShiftError(f"cannot write {path}: {e.strerror or e}") from None
            return {"path": str(path), "rows": res.get("rows", 0), "truncated": bool(res.get("truncated"))}
        self.link.submit("history_export", job)

    # ---- settings -----------------------------------------------------------------------------------
    def load_settings(self) -> None:
        self.link.run("config_get")

    def change_setting(self, setting: Setting, value) -> None:
        """``value`` is what the widget holds; lists arrive as text and are split here."""
        if setting.kind == "list":
            value = parse_list(value)
        elif setting.kind == "multi":
            value = list(value)
        self.link.run("config_set", key=setting.key, value=value)
