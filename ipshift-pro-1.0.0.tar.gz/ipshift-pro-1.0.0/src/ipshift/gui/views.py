"""What the dashboard shows, as plain data (no Qt).

Each function takes the dicts the daemon sends and returns small frozen dataclasses of text plus a
*tone* (good / warn / bad / info / muted / plain).  The widgets only copy these into labels and
colour them by tone, so every word on screen and every button-enabling rule can be tested without
a display.  The wording is shared with the CLI (``ipshift.cli.render``) so both say the same thing.
"""
from __future__ import annotations

import time
from dataclasses import dataclass

from ..cli.render import event_text, interval_text, network_name
from ..cli.ui import fmt_ago, fmt_clock, fmt_duration, fmt_ms
from ..config import MIN_INTERVAL
from ..net.local import KIND_NAMES

GOOD, WARN, BAD, INFO, MUTED, PLAIN = "good", "warn", "bad", "info", "muted", "plain"
TONES = (GOOD, WARN, BAD, INFO, MUTED, PLAIN)

# GUI actions that change the VPN connection.  The daemon allows one at a time, so the window
# greys out the others while one of these is running instead of letting the user hit an error.
CONNECTION_COMMANDS = frozenset({"connect", "rotate_start", "rotate_now", "stop", "lockdown",
                                 "killswitch_on", "killswitch_off"})
MAX_INTERVAL = 86400.0


@dataclass(frozen=True)
class Row:
    label: str
    text: str
    tone: str = PLAIN


# ---- the protection banner ----------------------------------------------------------------------------
PROTECTION = {
    "protected": ("PROTECTED", GOOD),
    "connecting": ("CONNECTING", INFO),
    "blocked": ("BLOCKED", WARN),
    "no-killswitch": ("NO KILL SWITCH", WARN),
    "unprotected": ("UNPROTECTED", BAD),
}


@dataclass(frozen=True)
class Banner:
    level: str
    title: str
    detail: str
    tone: str


def banner_view(st: dict | None, link_error: str | None = None) -> Banner:
    if st is None:
        return Banner("offline", "DAEMON NOT REACHABLE",
                      link_error or "The window cannot reach the IPShift daemon.", WARN)
    prot = st.get("protection") or {}
    level = prot.get("level", "?")
    title, tone = PROTECTION.get(level, (str(level).upper(), MUTED))
    return Banner(level, title, prot.get("message", ""), tone)


# ---- the VPN card ----------------------------------------------------------------------------------------
VPN_STATES = {"connected": ("CONNECTED", GOOD), "connecting": ("CONNECTING", INFO),
              "switching": ("SWITCHING", INFO), "failed": ("FAILED", BAD)}


@dataclass(frozen=True)
class VpnView:
    badge: str
    tone: str
    profile: str
    facts: str
    server: str
    iface: str
    uptime: str
    handshake: str
    note: str
    note_tone: str
    connected: bool
    working: bool                    # connecting or switching


def vpn_view(st: dict) -> VpnView:
    vpn = st.get("vpn") or {}
    state = vpn.get("state", "?")
    badge, tone = VPN_STATES.get(state, ("DISCONNECTED", MUTED))
    p = vpn.get("profile") or {}
    facts = ", ".join(x for x in (p.get("protocol"), p.get("tier"), p.get("country") or None) if x)
    hs = (vpn.get("health") or {}).get("handshake_age")
    note, note_tone = "", PLAIN
    if vpn.get("busy"):
        note, note_tone = f"{vpn['busy']} ...", INFO
    elif vpn.get("last_error") and state != "connected":
        note, note_tone = f"Last error: {vpn['last_error']}", BAD if state == "failed" else WARN
    connected = state == "connected" and bool(p)
    return VpnView(badge=badge, tone=tone, profile=p.get("name") or "-", facts=facts or "-",
                   server=vpn.get("server") or "-", iface=(vpn.get("iface") or "-") if connected else "-",
                   uptime=fmt_duration(vpn.get("uptime")) if connected else "-",
                   handshake=f"{fmt_duration(hs)} ago" if connected and hs is not None else "-",
                   note=note, note_tone=note_tone, connected=connected,
                   working=state in ("connecting", "switching"))


# ---- public and private addresses -------------------------------------------------------------------------
@dataclass(frozen=True)
class PublicIpView:
    value: str
    note: str
    v6: str
    tone: str
    offer_direct: bool               # "look up my real address" is offered (only while unprotected)


def public_ip_view(st: dict, *, direct: dict | None = None, now: float | None = None) -> PublicIpView:
    level = (st.get("protection") or {}).get("level")
    pub = st.get("public") or {}
    if pub.get("v4"):
        note = "seen through the tunnel"
        if pub.get("verified_at"):
            note += f", verified {fmt_ago(pub['verified_at'], now)}"
        return PublicIpView(pub["v4"], note, pub.get("v6") or "none (the tunnel carries no IPv6)",
                            GOOD if level == "protected" else WARN, False)
    if level == "unprotected":
        real = (direct or {}).get("public") or {}
        if real.get("v4") and real.get("source") == "direct":
            return PublicIpView(real["v4"], "your real, unprotected address", real.get("v6") or "none", BAD, False)
        return PublicIpView("hidden", "Not looked up while you are unprotected.", "-", MUTED, True)
    if level == "blocked":
        return PublicIpView("none", "The kill switch is blocking all traffic.", "-", WARN, False)
    if level == "connecting":
        return PublicIpView("...", "Waiting for the tunnel to be verified.", "-", INFO, False)
    return PublicIpView("-", "", "-", MUTED, False)


@dataclass(frozen=True)
class PrivateIp:
    ip: str
    iface: str
    tags: str
    tunnel: bool


def private_ip_rows(st: dict) -> tuple[PrivateIp, ...]:
    ips = (st.get("network") or {}).get("private_ips") or []
    rows = [p for p in ips if p.get("family", 4) == 4] or list(ips)
    out = []
    for p in rows:
        tags = []
        if p.get("kind") == "tunnel":
            tags.append("VPN tunnel")
        elif p.get("kind"):
            tags.append(KIND_NAMES.get(p["kind"], p["kind"]))
        if p.get("primary"):
            tags.append("default route")
        out.append(PrivateIp(p.get("ip", "?"), p.get("iface", ""), ", ".join(tags), p.get("kind") == "tunnel"))
    return tuple(out)


# ---- rotation ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class RotationView:
    running: bool
    interval: float
    minimum: float
    state: str
    tone: str
    strategy: str
    counts: str
    last: str
    last_tone: str
    problem: str
    problem_tone: str


def rotation_view(st: dict) -> RotationView:
    rot = st.get("rotation") or {}
    interval = float(rot.get("interval") or MIN_INTERVAL)
    running = bool(rot.get("running"))
    state = f"Running: a new address every {interval_text(interval)}" if running else "Stopped"
    counts = ""
    if rot.get("ticks"):
        counts = (f"{rot.get('ok', 0)} changed, {rot.get('failed', 0)} failed, "
                  f"{rot.get('unchanged', 0)} unchanged, {rot.get('skipped', 0)} skipped")
    problem, problem_tone = "", PLAIN
    if rot.get("stalled"):
        problem = (f"STALLED: {rot.get('consecutive_failures', 0)} failures in a row. "
                   "Traffic stays blocked until a connection works.")
        problem_tone = BAD
    elif rot.get("consecutive_failures"):
        problem, problem_tone = f"{rot['consecutive_failures']} failure(s) in a row", WARN
    last, last_tone = "", PLAIN
    ls = rot.get("last") or {}
    if ls.get("status"):
        bits = [{"success": "changed", "unchanged": "same address", "failed": "failed"}.get(ls["status"], ls["status"]),
                ls.get("profile") or ""]
        if ls.get("ip"):
            bits.append(ls["ip"])
        if ls.get("ms") is not None:
            bits.append("in " + fmt_ms(ls["ms"]))
        last = "Last: " + " ".join(b for b in bits if b)
        if ls.get("error"):
            last += f" ({str(ls['error'])[:90]})"
        last_tone = {"success": GOOD, "unchanged": WARN, "failed": BAD}.get(ls["status"], PLAIN)
    return RotationView(running=running, interval=interval, minimum=float(rot.get("minimum_interval") or MIN_INTERVAL),
                        state=state, tone=GOOD if running else MUTED, strategy=str(rot.get("strategy", "")),
                        counts=counts, last=last, last_tone=last_tone, problem=problem, problem_tone=problem_tone)


def countdown_text(st: dict | None, received_at: float, now: float | None = None) -> str:
    """'next change in 3.4 s', counted down locally between two status updates."""
    rot = (st or {}).get("rotation") or {}
    if not rot.get("running") or rot.get("next_in") is None:
        return ""
    left = max(0.0, float(rot["next_in"]) - ((time.monotonic() if now is None else now) - received_at))
    return f"next change in {left:.1f} s"


def interval_advice(profiles: dict | None, interval: float | None) -> str:
    """OpenVPN needs seconds to bring a tunnel up; only WireGuard can change server in about a second."""
    if interval is None or interval >= 5 or not profiles:
        return ""
    rotating = set(profiles.get("in_rotation") or [])
    slow = [p for p in profiles.get("profiles", []) if p.get("id") in rotating and p.get("protocol") == "openvpn"]
    if not slow:
        return ""
    return (f"{len(slow)} OpenVPN profile(s) are in the rotation. OpenVPN needs several seconds to connect, so those "
            "changes will be slower than the interval. WireGuard profiles can switch in about a second. A cycle only "
            "counts as done once the new tunnel is up and the new public IP is verified.")


def clean_interval(value, default: float = 30.0) -> float:
    """What the daemon would accept: a number from the 1 s floor up to a day."""
    try:
        v = float(value)
    except (TypeError, ValueError):
        return default
    if v != v:                                           # NaN
        return default
    return min(MAX_INTERVAL, max(MIN_INTERVAL, v))


# ---- kill switch and hardening ------------------------------------------------------------------------------
@dataclass(frozen=True)
class KillSwitchView:
    badge: str
    tone: str
    detail: str
    endpoints: str
    armed: bool
    lockdown: bool
    enabled: bool


def killswitch_view(st: dict) -> KillSwitchView:
    ks = st.get("killswitch") or {}
    armed, enabled = bool(ks.get("armed")), ks.get("enabled") is not False
    if ks.get("error"):
        return KillSwitchView("UNKNOWN", BAD, str(ks["error"]), "", False, False, enabled)
    if not armed:
        if not enabled:
            return KillSwitchView("OFF", WARN, "Disabled in the settings (killswitch.enabled).", "", False, False, False)
        return KillSwitchView("NOT ARMED", WARN, "It arms itself when you connect.", "", False, False, True)
    bits = ["LAN blocked" if not ks.get("allow_lan") else "LAN allowed"]
    n = int(ks.get("blocked_packets") or 0)
    if n:
        bits.append(f"{n} packet{'s' if n != 1 else ''} blocked")
    if ks.get("dry_run"):
        bits.append("dry run")
    lock = bool(ks.get("lockdown"))
    eps = ks.get("endpoints") or []
    return KillSwitchView("LOCKDOWN" if lock else "ARMED", BAD if lock else GOOD,
                          "Everything is blocked, including the VPN." if lock else ", ".join(bits),
                          "" if lock or not eps else "Allowed to leave: only the VPN server " + ", ".join(eps),
                          True, lock, enabled)


def hardening_rows(st: dict) -> tuple[Row, ...]:
    h = st.get("hardening") or {}
    rows = []
    if h.get("dns_locked"):
        txt = "Locked to " + (", ".join(h.get("dns_servers") or []) or "?")
        if h.get("dns_intact") is False:
            rows.append(Row("DNS", txt + " - changed by another program!", BAD))
        else:
            rows.append(Row("DNS", txt, GOOD))
    else:
        rows.append(Row("DNS", "Not locked (locked while connected)", MUTED))
    if h.get("ipv6_guard"):
        if h.get("ipv6_intact") is False:
            rows.append(Row("IPv6", "Switched off, but changed by another program!", BAD))
        else:
            rows.append(Row("IPv6", "Switched off on the physical interfaces", GOOD))
    else:
        rows.append(Row("IPv6", "Guard off (on while connected)", MUTED))
    mac = []
    if h.get("mac_nm_policy"):
        mac.append("random MAC for each new connection")
    if h.get("mac_overrides"):
        mac.append("changed by hand on " + ", ".join(h["mac_overrides"]))
    rows.append(Row("MAC address", ", ".join(mac), GOOD) if mac else Row("MAC address", "Unchanged", MUTED))
    return tuple(rows)


# ---- problems (derived from the live state) and alerts (from the event log) ---------------------------------
@dataclass(frozen=True)
class Problem:
    text: str
    tone: str
    hint: str = ""


def problems(st: dict | None) -> tuple[Problem, ...]:
    """What is wrong right now.  They disappear by themselves once the cause is gone."""
    if st is None:
        return ()
    out: list[Problem] = []
    ks, rot, vpn = st.get("killswitch") or {}, st.get("rotation") or {}, st.get("vpn") or {}
    h, prof, level = st.get("hardening") or {}, st.get("profiles") or {}, (st.get("protection") or {}).get("level")
    if ks.get("error"):
        out.append(Problem(f"The kill switch state is unknown: {ks['error']}", BAD,
                           "Check the firewall with: sudo ipshift doctor"))
    if rot.get("stalled"):
        out.append(Problem(f"Rotation stalled after {rot.get('consecutive_failures', 0)} failures in a row. "
                           "Traffic stays blocked until a connection works.", BAD,
                           "A server may be down: check the Profiles page, or press Stop."))
    elif rot.get("consecutive_failures"):
        out.append(Problem(f"{rot['consecutive_failures']} rotation failure(s) in a row", WARN,
                           (rot.get("last") or {}).get("error") or ""))
    if vpn.get("state") == "failed":
        out.append(Problem(f"The VPN connection failed: {vpn.get('last_error') or 'unknown error'}", BAD,
                           "Try another profile, or press Start to retry."))
    if h.get("dns_intact") is False:
        out.append(Problem("Another program changed the DNS settings: DNS queries may leave outside the VPN.", BAD,
                           "Reconnect to lock DNS again."))
    if h.get("ipv6_intact") is False:
        out.append(Problem("Another program switched IPv6 back on: it can bypass the VPN.", BAD,
                           "Reconnect to switch it off again."))
    if level == "no-killswitch":
        out.append(Problem("Connected without a kill switch: traffic could leak if the VPN drops.", WARN,
                           "Arm it on the Dashboard or in Settings."))
    if not prof.get("total"):
        out.append(Problem("No VPN profiles yet.", INFO, "Import one on the Profiles page (free, paid or your own server)."))
    elif not prof.get("usable"):
        out.append(Problem("No VPN profile is usable right now.", WARN,
                           "They are disabled, benched after failures, or waiting for a username and password."))
    return tuple(out)


LEVEL_TONE = {"warning": WARN, "error": BAD, "critical": BAD}


@dataclass(frozen=True)
class AlertRow:
    ts: float
    time: str
    level: str
    tone: str
    text: str
    hint: str
    kind: str


def alert_row(ev: dict) -> AlertRow:
    d = ev.get("data") or {}
    level = ev.get("level", "info")
    return AlertRow(ts=float(ev.get("ts") or 0.0), time=fmt_clock(ev.get("ts")), level=level,
                    tone=LEVEL_TONE.get(level, INFO), text=event_text(ev), hint=str(d.get("hint") or ""),
                    kind=str(ev.get("kind", "")))


def alert_rows(events, *, limit: int = 50) -> tuple[AlertRow, ...]:
    """Warnings, errors and critical events, newest first."""
    keep = [e for e in events or [] if e.get("level") in LEVEL_TONE]
    return tuple(alert_row(e) for e in reversed(keep[-limit:]))


NOTIFY_TITLES = {"connect_failed": "VPN connection failed", "tunnel_lost": "VPN connection lost",
                 "rotation_stalled": "Rotation stalled", "reconnect_failing": "Cannot restore the VPN",
                 "leak_detected": "Leak detected", "killswitch_tampered": "Kill switch was tampered with",
                 "killswitch_failed": "Kill switch failed", "lockdown": "Lockdown"}


def notification_for(ev: dict) -> tuple[str, str] | None:
    """(title, text) for a desktop notification, or None: only errors and critical events interrupt."""
    if ev.get("level") not in ("error", "critical"):
        return None
    return NOTIFY_TITLES.get(ev.get("kind", ""), "IPShift alert"), event_text(ev)


# ---- stop ---------------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class StopOption:
    key: str
    label: str
    detail: str
    kwargs: tuple[tuple[str, bool], ...]
    risky: bool


STOP_OPTIONS = (
    StopOption("rotation", "Stop the rotation only",
               "Keep the current VPN connection and the kill switch. Your address stops changing.",
               (("keep_vpn", True),), False),
    StopOption("block", "Disconnect, but keep blocking",
               "Disconnect the VPN and leave the kill switch up: no traffic leaves this computer until you reconnect.",
               (("keep_blocking", True),), False),
    StopOption("release", "Disconnect and restore normal networking",
               "Your real IP address becomes visible again.", (), True),
)


def stop_kwargs(key: str) -> dict:
    for o in STOP_OPTIONS:
        if o.key == key:
            return dict(o.kwargs)
    raise KeyError(key)


def stop_choices(st: dict | None) -> tuple[StopOption, ...]:
    """The ways to stop that make sense right now, safest first (the first is what the dialog preselects).

    Stopping only the rotation needs a running rotation; "disconnect but keep blocking" needs something
    to disconnect.  Releasing the firewall is always possible."""
    if st is None:
        return ()
    vpn, rot = st.get("vpn") or {}, st.get("rotation") or {}
    something_up = bool(vpn.get("connected")) or vpn.get("state") in ("connecting", "switching")
    out = []
    for o in STOP_OPTIONS:
        if o.key == "rotation" and not (rot.get("running") and something_up):
            continue
        if o.key == "block" and not something_up:
            continue
        out.append(o)
    return tuple(out)


# ---- controls -----------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class Controls:
    can_start: bool
    can_stop: bool
    can_rotate_now: bool
    can_cancel: bool
    can_edit_interval: bool
    start_hint: str
    can_arm: bool = False             # block everything outside the VPN now
    can_release: bool = False         # give normal networking back
    can_lockdown: bool = False        # drop the tunnel and block everything


def controls_view(st: dict | None, busy: frozenset | set = frozenset()) -> Controls:
    if st is None:
        return Controls(False, False, False, False, False, "Waiting for the daemon.")
    vpn, rot, ks, prof = st.get("vpn") or {}, st.get("rotation") or {}, st.get("killswitch") or {}, st.get("profiles") or {}
    working = vpn.get("state") in ("connecting", "switching") or bool(vpn.get("busy"))
    in_flight = bool(set(busy) & CONNECTION_COMMANDS)
    running, usable = bool(rot.get("running")), int(prof.get("usable") or 0)
    hint = ""
    if running:
        hint = "The rotation is already running."
    elif not usable:
        hint = "No usable VPN profile: import one on the Profiles page."
    elif in_flight or working:
        hint = "Busy: wait for the current operation to finish."
    can_start = not hint
    armed, enabled = bool(ks.get("armed")), ks.get("enabled") is not False
    can_stop = "stop" not in busy and (running or bool(vpn.get("connected")) or working or armed)
    can_rotate_now = usable > 0 and not in_flight and not working
    can_cancel = working and not running
    # The kill switch buttons: arming and releasing wait for a connection attempt to finish, but the
    # panic button never does (the daemon cancels whatever is running); it is only refused when it
    # would do nothing new.
    can_arm = enabled and not armed and not in_flight and not working
    can_release = armed and not in_flight and not working
    can_lockdown = not ks.get("lockdown") and "lockdown" not in busy
    return Controls(can_start, can_stop, can_rotate_now, can_cancel, True, hint, can_arm, can_release, can_lockdown)


# ---- the whole dashboard ------------------------------------------------------------------------------------
@dataclass(frozen=True)
class Dashboard:
    banner: Banner
    simulated: bool
    daemon: str
    vpn: VpnView
    public: PublicIpView
    private: tuple[PrivateIp, ...]
    network: str
    rotation: RotationView
    killswitch: KillSwitchView
    hardening: tuple[Row, ...]
    problems: tuple[Problem, ...]
    controls: Controls
    privacy: str
    privacy_tone: str
    profiles: str


_EMPTY_VPN = VpnView("UNKNOWN", MUTED, "-", "-", "-", "-", "-", "-", "", PLAIN, False, False)
_EMPTY_PUBLIC = PublicIpView("-", "", "-", MUTED, False)
_EMPTY_ROTATION = RotationView(False, 30.0, MIN_INTERVAL, "Unknown", MUTED, "", "", "", PLAIN, "", PLAIN)
_EMPTY_KS = KillSwitchView("UNKNOWN", MUTED, "", "", False, False, True)
GRADE_TONE = {"A": GOOD, "B": GOOD, "C": WARN, "D": BAD, "F": BAD}


def privacy_line(pr: dict | None, now: float | None = None) -> tuple[str, str]:
    if not pr:
        return "Not tested yet. Run the privacy check on the Privacy page.", MUTED
    return (f"Grade {pr.get('grade', '?')} ({pr.get('score', '?')}/100): {pr.get('verdict', '')}, "
            f"checked {fmt_ago(pr.get('ts'), now)}", GRADE_TONE.get(pr.get("grade", ""), PLAIN))


def dashboard_view(st: dict | None, *, busy: frozenset | set = frozenset(), direct: dict | None = None,
                   link_error: str | None = None, now: float | None = None) -> Dashboard:
    banner = banner_view(st, link_error)
    if st is None:
        return Dashboard(banner, False, "", _EMPTY_VPN, _EMPTY_PUBLIC, (), "unknown", _EMPTY_ROTATION, _EMPTY_KS, (),
                         (), controls_view(None, busy), "-", MUTED, "-")
    d, prof = st.get("daemon") or {}, st.get("profiles") or {}
    text, tone = privacy_line(st.get("privacy"), now)
    return Dashboard(
        banner=banner, simulated=bool(d.get("simulated")),
        daemon=f"IPShift Pro {d.get('version', '?')}, daemon pid {d.get('pid', '?')}, up {fmt_duration(d.get('uptime'))}",
        vpn=vpn_view(st), public=public_ip_view(st, direct=direct, now=now), private=private_ip_rows(st),
        network=network_name(st.get("network") or {}), rotation=rotation_view(st),
        killswitch=killswitch_view(st), hardening=hardening_rows(st), problems=problems(st),
        controls=controls_view(st, busy), privacy=text, privacy_tone=tone,
        profiles=(f"{prof.get('usable', 0)} usable of {prof['total']}" if prof.get("total") else "none imported"))
