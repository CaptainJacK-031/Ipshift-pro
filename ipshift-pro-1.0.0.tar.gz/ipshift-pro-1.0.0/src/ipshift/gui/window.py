"""The main window: navigation, the pages, and what every button means.

The window owns no state of its own.  Everything the daemon says goes into the ``AppModel``; every
button calls an ``Actions`` method; the pages only draw.  What lives here is the glue: which page is
shown, which questions are asked first (anything that lowers protection), the desktop notification
for a serious alert, and the tray icon.
"""
from __future__ import annotations

from PySide6.QtCore import QEvent, Qt, QTimer, Signal
from PySide6.QtWidgets import (QApplication, QListWidget, QMainWindow, QMenu, QStackedWidget, QSystemTrayIcon,
                               QVBoxLayout, QWidget)

from .. import __version__
from ..privacy.report import NOT_COVERED
from . import dialogs, tables, views
from .actions import Actions
from .model import AppModel
from .page_dashboard import DashboardPage
from .page_history import HistoryPage
from .page_privacy import PrivacyPage
from .page_profiles import ProfilesPage
from .page_settings import SettingsPage
from .qtbridge import Bridge
from .settings_schema import needs_confirmation
from .widgets import Toast, button, hbox, holder, label, set_text, set_tone, status_icon, vbox

NAV = ("Dashboard", "Privacy", "History", "Profiles", "Settings")
FAST_POLL, SLOW_POLL = 2.0, 10.0
QUIET = frozenset({"config_get", "ip"})            # commands whose success needs no message (the page shows it)
DASHBOARD_ALERTS = 6


class OfflinePanel(QWidget):
    """Shown instead of the pages while the daemon cannot be reached."""
    retry_requested = Signal()

    def __init__(self, demo: bool = False):
        super().__init__()
        self.setObjectName("page")
        self.title = label("Connecting to the IPShift daemon...", role="h1", wrap=True)
        self.error = label("", tone=views.WARN, wrap=True, selectable=True)
        self.hint = label("", role="muted", wrap=True, selectable=True)
        self.retry = button("Try again", role="primary", on_click=self.retry_requested.emit)
        steps = ["Start it:   sudo systemctl start ipshiftd",
                 "Not allowed?   sudo usermod -aG ipshift $USER   (then log out and in again)",
                 "Look around without a daemon:   ipshift-gui --demo"]
        self.steps = vbox(*[label(s, role="mono", selectable=True, wrap=True) for s in steps], spacing=6)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(40, 40, 40, 40)
        lay.setSpacing(12)
        lay.addWidget(self.title)
        lay.addWidget(self.error)
        lay.addWidget(self.hint)
        lay.addLayout(hbox(self.retry, None))
        lay.addSpacing(10)
        self.steps_title = label("WHAT TO TRY", role="title")
        lay.addWidget(self.steps_title)
        lay.addLayout(self.steps)
        lay.addStretch(1)
        self.set_demo(demo)

    def set_demo(self, demo: bool) -> None:
        self.steps_title.setVisible(not demo)
        for i in range(self.steps.count()):
            self.steps.itemAt(i).widget().setVisible(not demo)

    def show_state(self, up, error: str, hint: str) -> None:
        if up is None:
            set_text(self.title, "Connecting to the IPShift daemon...")
            set_text(self.error, "")
            set_text(self.hint, "")
        else:
            set_text(self.title, "The IPShift daemon is not reachable")
            set_text(self.error, error)
            set_text(self.hint, hint)
        self.error.setVisible(bool(error) and up is not None)
        self.hint.setVisible(bool(hint) and up is not None)
        self.retry.setVisible(up is not None)


class MainWindow(QMainWindow):
    def __init__(self, bridge: Bridge, model: AppModel, actions: Actions, *, demo: bool = False):
        super().__init__()
        self.bridge, self.model, self.commands, self.demo = bridge, model, actions, demo
        self._tray_tone = None
        self.setWindowTitle("IPShift Pro" + (" (demo)" if demo else ""))
        self.setWindowIcon(status_icon(views.MUTED))
        self.resize(1120, 780)
        self.setMinimumSize(840, 560)

        self.dashboard = DashboardPage()
        self.privacy = PrivacyPage()
        self.history = HistoryPage()
        self.profiles = ProfilesPage()
        self.settings = SettingsPage()
        self.dashboard.advice_fn = model.advice
        self.pages = dict(zip(NAV, (self.dashboard, self.privacy, self.history, self.profiles, self.settings)))
        self.stack = QStackedWidget()
        for page in self.pages.values():
            self.stack.addWidget(page)
        self.offline = OfflinePanel(demo)
        self.outer = QStackedWidget()
        self.outer.addWidget(self.stack)                 # 0: the pages
        self.outer.addWidget(self.offline)               # 1: no daemon
        self.toast = Toast()

        self.nav = QListWidget()
        self.nav.setObjectName("nav")
        for name in NAV:
            self.nav.addItem(name)
        self.nav.setCurrentRow(0)
        left = vbox(label("IPShift Pro", role="h2"), (self.nav, 1),
                    label("Closing this window does not stop the VPN or the rotation.", role="small", wrap=True),
                    margins=(14, 14, 10, 12), spacing=10)
        left_box = holder(left)
        left_box.setFixedWidth(210)
        right = vbox(self.toast, (self.outer, 1), margins=(0, 0, 0, 0), spacing=0)
        root = holder(hbox(left_box, (holder(right), 1), spacing=0), "root")
        self.setCentralWidget(root)

        self.link_label = label("", role="small")
        self.statusBar().addPermanentWidget(self.link_label)
        self._build_menu()
        self._build_tray()
        self._wire_pages()
        self._wire_bridge()
        self.nav.currentRowChanged.connect(self._page_changed)

        self.countdown_timer = QTimer(self)
        self.countdown_timer.setInterval(250)
        self.countdown_timer.timeout.connect(self._tick)
        self.countdown_timer.start()
        self.redraw()

    # ---- wiring ----------------------------------------------------------------------------------------------
    def _wire_bridge(self) -> None:
        queued = Qt.ConnectionType.QueuedConnection      # the link's threads send these; Qt delivers them here
        b = self.bridge
        b.link_changed.connect(self.on_link, queued)
        b.status_received.connect(self.on_status, queued)
        b.event_received.connect(self.on_event, queued)
        b.data_received.connect(self.on_data, queued)
        b.busy_changed.connect(self.on_busy, queued)
        b.result_ready.connect(self.on_result, queued)

    def _wire_pages(self) -> None:
        d = self.dashboard
        d.start_requested.connect(self.commands.start)
        d.stop_requested.connect(self.on_stop)
        d.rotate_now_requested.connect(self.commands.rotate_now)
        d.cancel_requested.connect(self.commands.cancel)
        d.interval_changed.connect(self.commands.apply_interval)
        d.killswitch_requested.connect(self.on_killswitch)
        d.privacy_requested.connect(self.commands.privacy_check)
        d.lookup_requested.connect(self.commands.lookup_real_ip)
        d.goto.connect(self.select_page)
        self.privacy.run_requested.connect(self.commands.privacy_check)
        h = self.history
        h.filter_changed.connect(self.redraw)
        h.export_requested.connect(self.on_export)
        h.clear_requested.connect(self.on_clear_history)
        p = self.profiles
        p.import_requested.connect(self.on_import)
        p.connect_requested.connect(self.commands.connect_profile)
        p.toggle_requested.connect(self.commands.set_enabled)
        p.login_requested.connect(self.on_login)
        p.reuse_requested.connect(self.commands.clear_benched)
        p.remove_requested.connect(self.on_remove)
        self.settings.change_requested.connect(self.on_setting)
        self.offline.retry_requested.connect(lambda: self.bridge.link.refresh(everything=True))

    def _build_menu(self) -> None:
        file_menu = self.menuBar().addMenu("&File")
        act = file_menu.addAction("&Close window")
        act.triggered.connect(self.close)
        help_menu = self.menuBar().addMenu("&Help")
        act = help_menu.addAction("What this tool cannot do")
        act.triggered.connect(self.show_limits)
        act = help_menu.addAction("&About IPShift Pro")
        act.triggered.connect(self.show_about)

    def _build_tray(self) -> None:
        self.tray = None
        self._tray_menu = None
        if not QSystemTrayIcon.isSystemTrayAvailable():
            return
        self.tray = QSystemTrayIcon(status_icon(views.MUTED), self)
        self._tray_menu = QMenu()
        act = self._tray_menu.addAction("Show window")
        act.triggered.connect(self.show_normal)
        act = self._tray_menu.addAction("Close window")
        act.triggered.connect(self.close)
        self.tray.setContextMenu(self._tray_menu)
        self.tray.setToolTip("IPShift Pro")
        self.tray.show()

    # ---- pages -----------------------------------------------------------------------------------------------
    @property
    def page_name(self) -> str:
        return NAV[max(0, self.stack.currentIndex())]

    def select_page(self, name: str) -> None:
        self.nav.setCurrentRow(NAV.index(name))

    def _page_changed(self, row: int) -> None:
        if not 0 <= row < len(NAV):
            return
        self.stack.setCurrentIndex(row)
        name = NAV[row]
        self.bridge.link.want_history(name == "History")
        if name in ("Settings", "Profiles"):
            self.bridge.link.refresh(everything=True)
        if name == "Settings":
            self.commands.load_settings()
        self.redraw()

    # ---- drawing ---------------------------------------------------------------------------------------------
    def redraw(self) -> None:
        m = self.model
        up = m.link_up
        self.outer.setCurrentIndex(0 if up else 1)
        self.offline.show_state(up, m.link_error, m.link_hint)
        d = m.dashboard()
        set_text(self.link_label, "Daemon connected" if up else "Daemon not reachable")
        set_tone(self.link_label, views.GOOD if up else views.WARN)
        title = (f"IPShift Pro - {d.banner.title}" if up else "IPShift Pro") + (" (demo)" if self.demo else "")
        if self.windowTitle() != title:
            self.setWindowTitle(title)
        self._show_tray(d)
        if not up:
            return
        name = self.page_name
        if name == "Dashboard":
            self.dashboard.update_view(d, m.alerts()[:DASHBOARD_ALERTS])
            self.dashboard.set_countdown(m.countdown())
        elif name == "Privacy":
            self.privacy.update_view(m.leaks(), "privacy_check" in m.busy)
        elif name == "History":
            self._render_history()
        elif name == "Profiles":
            self.profiles.update_view(m.profile_rows(), can_connect=d.controls.can_rotate_now)

    def _render_history(self) -> None:
        m = self.model
        rows = m.history_rows(self.history.current_filter())
        data = m.history or {}
        shown = len(data.get("rotations") or [])
        stats = tables.history_stats(data)
        if shown and (data.get("stats") or {}).get("total", 0) > shown:
            stats += f". Showing the newest {shown}."
        self.history.update_view(rows, tables.event_rows(data), stats, can_export=bool(shown))

    def _show_tray(self, d: views.Dashboard) -> None:
        tone = d.banner.tone if self.model.link_up else views.MUTED
        if tone == self._tray_tone:
            return
        self._tray_tone = tone
        icon = status_icon(tone)
        self.setWindowIcon(icon)
        if self.tray is not None:
            self.tray.setIcon(icon)
            self.tray.setToolTip(f"IPShift Pro: {d.banner.title.title()}" if self.model.link_up else "IPShift Pro")

    def _tick(self) -> None:
        if self.model.link_up and self.page_name == "Dashboard":
            self.dashboard.set_countdown(self.model.countdown())

    # ---- what the daemon says (slots; delivered in this thread) ----------------------------------------------
    def on_link(self, up: bool, error: str, hint: str) -> None:
        self.model.apply_link(up, error, hint)
        if up:
            self.commands.load_settings()
        else:
            self.dashboard.forget_interval()
        self.redraw()

    def on_status(self, status) -> None:
        self.model.apply_status(status)
        self.redraw()

    def on_event(self, event) -> None:
        note = self.model.apply_event(event)
        if note and self.tray is not None:
            self.tray.showMessage(note[0], note[1], QSystemTrayIcon.MessageIcon.Critical, 10000)
        self.redraw()

    def on_data(self, name: str, data) -> None:
        self.model.apply_data(name, data)
        self.redraw()

    def on_busy(self, busy) -> None:
        self.model.apply_busy(busy)
        self.redraw()

    def on_result(self, res) -> None:
        outcome = self.model.apply_result(res)
        if res.ok and res.name == "config_get":
            self._load_settings()
        elif not res.ok and res.name == "config_set":
            self._load_settings(force=True)               # the daemon said no: put the control back
        if not res.ok or res.name not in QUIET:
            self.toast.show_message(outcome.text, outcome.tone, outcome.hint)
        if res.ok and res.name == "profile_import" and isinstance(res.data, list):
            dialogs.inform(self, "Import finished", tables.import_summary(res.data))
        self.redraw()

    def _load_settings(self, force: bool = False) -> None:
        cfg = self.model.config or {}
        info = ""
        if cfg:
            info = ("Changes apply at once and are saved to " + str(cfg.get("file") or "the configuration file")
                    + ". Program paths and daemon options are changed only in that file.")
            if cfg.get("simulated"):
                info = "SIMULATION: changes are not saved to disk. " + info
        self.settings.load(cfg.get("config"), force=force, info=info)

    # ---- what the buttons mean ---------------------------------------------------------------------------------
    def on_stop(self) -> None:
        choices = views.stop_choices(self.model.status)
        if not choices:
            self.toast.show_message("There is nothing to stop.", views.INFO)
            return
        if len(choices) == 1:
            only = choices[0]
            key = only.key if dialogs.confirm(self, "Stop", only.label + "?", detail=only.detail, accept="Stop",
                                              danger=only.risky) else None
        else:
            key = dialogs.ask_stop(self, choices)
        if key:
            self.commands.stop(key)

    def on_killswitch(self, action: str) -> None:
        if action == "off":
            ok = dialogs.confirm(self, "Release the kill switch?",
                                 "Traffic will be able to leave this computer outside the VPN.",
                                 detail="If the VPN drops, your real IP address will be exposed.",
                                 accept="Release", danger=True)
        elif action == "lockdown":
            ok = dialogs.confirm(self, "Lock everything down?",
                                 "The VPN is disconnected, the rotation stops and ALL network traffic is blocked.",
                                 detail="Use Release or Start to get connected again.", accept="Lock down", danger=True)
        else:
            ok = True
        if ok:
            self.commands.killswitch(action)

    def on_setting(self, setting, value) -> None:
        warning = needs_confirmation(setting, value)
        if warning and not dialogs.confirm(self, "Lower your protection?", warning,
                                           detail="You can change it back at any time.", accept="Change it",
                                           danger=True):
            self._load_settings(force=True)
            return
        self.commands.change_setting(setting, value)

    def on_import(self) -> None:
        request = dialogs.ask_import(self)
        if request is not None:
            self.commands.import_profiles(request.paths, tier=request.tier, username=request.username or None,
                                         password=request.password or None, replace=request.replace)
            self.toast.show_message("Importing...", views.INFO)

    def _profile(self, profile_id: str):
        return next((r for r in self.model.profile_rows() if r.id == profile_id), None)

    def on_login(self, profile_id: str) -> None:
        row = self._profile(profile_id)
        login = dialogs.ask_login(self, row.name if row else profile_id)
        if login is not None:
            self.commands.set_login(profile_id, *login)

    def on_remove(self, profile_id: str) -> None:
        row = self._profile(profile_id)
        if dialogs.confirm(self, "Remove profile?", f"Remove {row.name if row else profile_id}?",
                           detail="Its stored login is deleted too. The file you imported it from is not touched.",
                           accept="Remove", danger=True):
            self.commands.remove_profile(profile_id)

    def on_export(self) -> None:
        answer = dialogs.ask_save_csv(self, tables.default_export_name())
        if answer is not None:
            path, overwrite = answer
            self.commands.export_history(path, overwrite=overwrite)

    def on_clear_history(self) -> None:
        if dialogs.confirm(self, "Delete the history?", "Delete every recorded rotation and alert?",
                           detail="This cannot be undone. Export it first if you want to keep a copy.",
                           accept="Delete", danger=True):
            self.commands.clear_history()

    # ---- help ---------------------------------------------------------------------------------------------------
    def show_about(self) -> None:
        dialogs.inform(self, "About IPShift Pro",
                       f"IPShift Pro {__version__}\n\nRotates a VPN connection and watches for leaks, with a "
                       "firewall kill switch that keeps your traffic from leaving outside the VPN.\n\n"
                       "The window is only a remote control: the work is done by the ipshiftd daemon, and "
                       "everything here can also be done with the ipshift command.")

    def show_limits(self) -> None:
        dialogs.inform(self, "What this tool cannot do",
                       "No software can promise anonymity. A VPN moves your trust from your internet provider to "
                       "the VPN provider; free VPNs may log or sell your traffic. Changing the address often does "
                       "not hide who you are once you sign in, and a distinctive browser can be recognised without "
                       "any address at all.\n\nThe privacy check cannot see:\n- "
                       + "\n- ".join(NOT_COVERED))

    # ---- window behaviour --------------------------------------------------------------------------------------
    def show_normal(self) -> None:
        self.showNormal()
        self.raise_()
        self.activateWindow()

    def _apply_poll(self) -> None:
        slow = self.isMinimized() or not self.isVisible()
        self.bridge.link.set_poll(SLOW_POLL if slow else FAST_POLL)

    def showEvent(self, event) -> None:
        super().showEvent(event)
        self._apply_poll()

    def hideEvent(self, event) -> None:
        super().hideEvent(event)
        self._apply_poll()

    def changeEvent(self, event) -> None:
        super().changeEvent(event)
        if event.type() == QEvent.Type.WindowStateChange:
            self._apply_poll()

    def closeEvent(self, event) -> None:
        self.countdown_timer.stop()
        if self.tray is not None:
            self.tray.hide()
        self.bridge.close()
        event.accept()
        QApplication.quit()
