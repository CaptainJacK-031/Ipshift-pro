"""The Settings page as a table (no Qt): one entry per setting a client may change over the socket.

The page is built from this table and nothing else.  ``tests/test_gui_logic.py`` checks every
entry against the daemon's own rules (the settable-key allowlist and the validation bounds), so the
page can never offer a value the daemon would refuse or a key it does not allow.
"""
from __future__ import annotations

from dataclasses import dataclass

from ..cli.reports import APPLIES
from ..config import MIN_INTERVAL


@dataclass(frozen=True)
class Setting:
    key: str
    label: str
    kind: str                                   # bool | int | float | choice | multi | list
    help: str
    minimum: float | None = None
    maximum: float | None = None
    step: float = 1.0
    decimals: int = 0
    unit: str = ""
    choices: tuple[tuple[object, str], ...] = ()   # (value, label) for choice and multi
    risky_value: bool | None = None             # the value that lowers protection: ask first
    risk: str = ""                              # what to tell the user before they pick it
    restart: bool = False


@dataclass(frozen=True)
class Section:
    title: str
    intro: str
    settings: tuple[Setting, ...]


TIER_CHOICES = (("free", "Free"), ("paid", "Paid"), ("self-hosted", "Self-hosted"))

SECTIONS: tuple[Section, ...] = (
    Section("Rotation", "How often the address changes, and through which servers.", (
        Setting("rotation.interval", "Interval", "float",
                "Time between the start of two rotations. The smallest value is 1 second. OpenVPN needs several "
                "seconds to reconnect; WireGuard can switch in about one.",
                MIN_INTERVAL, 86400.0, 1.0, 1, "s"),
        Setting("rotation.strategy", "Order", "choice", "How the next server is picked.",
                choices=(("diverse", "Diverse: prefer a different server each time"), ("round-robin", "In turn"),
                         ("random", "Random"), ("lru", "Least recently used"))),
        Setting("rotation.jitter_pct", "Randomise the interval", "float",
                "Vary each wait by up to this many percent, so the pattern is harder to recognise.",
                0.0, 100.0, 5.0, 0, "%"),
        Setting("rotation.tiers", "Only use", "multi",
                "Limit the rotation to these kinds of servers. Tick none to use all of them.", choices=TIER_CHOICES),
        Setting("rotation.require_change", "Same address counts as a failure", "bool",
                "A server that gives the same public address as before is skipped and retried."),
        Setting("rotation.max_failures", "Alert after failures", "int",
                "Raise a critical alert after this many failed rotations in a row.", 1, 100, 1, 0, "failures"),
        Setting("rotation.backoff_max", "Longest retry wait", "float",
                "After failures the wait grows up to this limit.", 1.0, 3600.0, 5.0, 0, "s"),
    )),
    Section("Kill switch", "The firewall rules that stop traffic leaving outside the VPN.", (
        Setting("killswitch.enabled", "Kill switch", "bool",
                "Block all traffic except the VPN while connected, connecting or reconnecting.",
                risky_value=False, risk="Without the kill switch your real address is exposed if the VPN drops."),
        Setting("killswitch.allow_lan", "Allow the local network", "bool",
                "Let this computer reach printers and other devices on your LAN outside the tunnel.",
                risky_value=True, risk="Other devices on this network can see this computer and its traffic to them."),
        Setting("killswitch.allow_dhcp", "Allow DHCP renewals", "bool",
                "Needed on Wi-Fi and phone hotspots so the network can renew your local address."),
        Setting("killswitch.allow_forward", "Allow forwarding", "bool",
                "Needed to share this connection with a VM or another device.",
                risky_value=True, risk="Forwarded traffic is not covered by the kill switch."),
        Setting("killswitch.log_drops", "Log blocked packets", "bool", "Write blocked packets to the system log."),
        Setting("killswitch.release_on_exit", "Release when the daemon stops", "bool",
                "Off (recommended): if the daemon stops or crashes, traffic stays blocked until you run "
                "'ipshift restore'.", risky_value=True,
                risk="If the daemon crashes, traffic would flow outside the VPN."),
        Setting("killswitch.arm_on_start", "Block everything at start-up", "bool",
                "Block all traffic as soon as the daemon starts, before any VPN is up.", restart=True),
    )),
    Section("VPN", "Connection behaviour.", (
        Setting("vpn.auto_reconnect", "Reconnect automatically", "bool", "Bring the VPN back when it drops."),
        Setting("vpn.reconnect_on_network_change", "Reconnect when the network changes", "bool",
                "For example when you move from Wi-Fi to a phone hotspot."),
        Setting("vpn.fast_switch", "Fast switching (WireGuard)", "bool",
                "Switch WireGuard servers without taking the tunnel down."),
        Setting("vpn.pin_endpoints", "Resolve server names privately", "bool",
                "Look up VPN server names through an encrypted channel so your ISP cannot see them."),
        Setting("vpn.connect_timeout", "Connection timeout", "float",
                "How long to wait for a tunnel before giving up.", 3.0, 300.0, 5.0, 0, "s"),
        Setting("vpn.verify_timeout", "Address check timeout", "float",
                "How long to wait for the new public address to be confirmed.", 3.0, 300.0, 5.0, 0, "s"),
        Setting("vpn.mtu", "Packet size (MTU)", "choice",
                "Lower it if pages stall on a mobile hotspot.",
                choices=((0, "Automatic"), (1280, "1280 (very lossy links)"), (1380, "1380"),
                         (1420, "1420 (common for WireGuard)"), (1500, "1500"))),
        Setting("vpn.wg_keepalive", "WireGuard keep-alive", "int",
                "Keeps the connection alive through the NAT of a hotspot. 0 switches it off.", 0, 600, 5, 0, "s"),
        Setting("vpn.allow_plain_bootstrap_dns", "Allow plain DNS to find VPN servers", "bool",
                "Fallback when the private lookup fails.", risky_value=True,
                risk="Your ISP can see which VPN servers you connect to."),
    )),
    Section("DNS", "Name lookups.", (
        Setting("dns.manage", "Lock DNS while connected", "bool",
                "Point this computer's DNS at the VPN only.", risky_value=False,
                risk="DNS queries may then go to your ISP while the VPN is up."),
        Setting("dns.use_vpn_pushed", "Use the VPN's DNS servers", "bool", "Use the servers the VPN provides."),
        Setting("dns.servers", "Always use these servers", "list",
                "Addresses separated by commas. Leave empty to use the VPN's own."),
        Setting("dns.fallback", "Fallback servers", "list", "Used when the VPN provides none."),
    )),
    Section("Privacy", "What is remembered, and what the tests do.", (
        Setting("privacy.check_ipv6", "Test for IPv6 leaks", "bool", "Include IPv6 in the leak tests."),
        Setting("privacy.disable_ipv6_on_physical", "Switch IPv6 off while connected", "bool",
                "IPv6 can bypass a VPN that only carries IPv4.", risky_value=False,
                risk="IPv6 traffic could leave outside the VPN."),
        Setting("privacy.history", "Keep a rotation history", "bool",
                "Stored on this computer only, readable by root.", restart=True),
        Setting("privacy.history_retention_days", "Keep history for", "int",
                "Older entries are deleted.", 1, 3650, 1, 0, "days"),
        Setting("privacy.history_max_rows", "History size limit", "int",
                "Keep at most this many entries (a 1-second rotation writes about 86,000 a day).",
                1000, 50_000_000, 1000, 0, "entries"),
        Setting("privacy.mask_ips_in_history", "Hide the last part of addresses", "bool",
                "Store 203.0.113.x instead of the full address."),
        Setting("privacy.redact_logs", "Hide addresses in logs", "bool",
                "Replace IP addresses in the log file.", risky_value=False,
                risk="The log file would then contain your addresses."),
        Setting("privacy.baseline", "Learn my real address first", "bool",
                "Ask an address-echo service for your real address once, before the VPN is up, so a tunnel that "
                "carries no traffic can be recognised.", risky_value=True,
                risk="This contacts an outside service WITHOUT the VPN, once, and reveals your real address to it."),
        Setting("privacy.quorum", "Echo services that must agree", "int",
                "How many independent address-echo services must report the same address.", 1, 5, 1, 0, "services"),
        Setting("privacy.http_timeout", "Echo service timeout", "float", "", 1.0, 60.0, 1.0, 0, "s"),
    )),
)


def all_settings() -> tuple[Setting, ...]:
    return tuple(s for sec in SECTIONS for s in sec.settings)


def find(key: str) -> Setting:
    for s in all_settings():
        if s.key == key:
            return s
    raise KeyError(key)


def parse_list(text) -> list[str]:
    if isinstance(text, (list, tuple)):
        return [str(x).strip() for x in text if str(x).strip()]
    return [p.strip() for p in str(text or "").replace(";", ",").split(",") if p.strip()]


def list_text(values) -> str:
    return ", ".join(str(v) for v in values or [])


def clamp(setting: Setting, value: float) -> float:
    lo = setting.minimum if setting.minimum is not None else float("-inf")
    hi = setting.maximum if setting.maximum is not None else float("inf")
    return min(hi, max(lo, value))


def needs_confirmation(setting: Setting, new_value) -> str:
    """Text to show before a change that lowers protection; '' when it is safe to apply at once."""
    if setting.risky_value is not None and new_value is setting.risky_value:
        return f"{setting.label}: {setting.risk}" if setting.risk else ""
    return ""


def applies_text(res: dict | None) -> str:
    res = res or {}
    when = APPLIES.get(res.get("applies", ""), "")
    saved = "saved" if res.get("saved") else "not saved to the config file"
    return f"{when}; {saved}" if when else saved
