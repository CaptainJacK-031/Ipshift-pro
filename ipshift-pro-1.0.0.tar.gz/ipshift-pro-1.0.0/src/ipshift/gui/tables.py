"""Contents of the History and Profiles tables as plain data (no Qt), plus the file helpers they need."""
from __future__ import annotations

import os
import time
from dataclasses import dataclass
from pathlib import Path

from ..cli.ui import fmt_datetime, fmt_duration, fmt_ms
from ..errors import DaemonUnavailable, IPShiftError
from ..vpn.importer import read_bundle
from .views import BAD, GOOD, INFO, MUTED, PLAIN, WARN

# ---- rotation history -----------------------------------------------------------------------------------
HISTORY_COLUMNS = ("Time", "Result", "Profile", "From", "To", "Took", "Note")
RESULTS = {"success": ("Changed", GOOD), "failed": ("Failed", BAD), "unchanged": ("Same address", WARN),
           "cancelled": ("Cancelled", MUTED)}
HISTORY_FILTERS = (("all", "All results"), ("success", "Changed"), ("failed", "Failed"),
                   ("unchanged", "Same address"))


@dataclass(frozen=True)
class HistoryRow:
    ts: float
    status: str
    result: str
    tone: str
    time: str
    profile: str
    old_ip: str
    new_ip: str
    took: str
    note: str

    def cells(self) -> tuple[str, ...]:
        return (self.time, self.result, self.profile, self.old_ip, self.new_ip, self.took, self.note)


def history_row(r: dict) -> HistoryRow:
    status = str(r.get("status", "?"))
    result, tone = RESULTS.get(status, (status, PLAIN))
    return HistoryRow(ts=float(r.get("ts") or 0.0), status=status, result=result, tone=tone,
                      time=fmt_datetime(r.get("ts")), profile=r.get("profile_name") or "-",
                      old_ip=r.get("old_ip") or "-", new_ip=r.get("new_ip") or "-",
                      took=fmt_ms(r.get("duration_ms")) if r.get("duration_ms") is not None else "-",
                      note=str(r.get("error") or r.get("reason") or ""))


def history_rows(data: dict | None, flt: str = "all", limit: int = 1000) -> tuple[HistoryRow, ...]:
    """Newest first (the order the daemon sends them in), optionally only one kind of result."""
    rows = [history_row(r) for r in (data or {}).get("rotations", [])]
    if flt != "all":
        rows = [r for r in rows if r.status == flt]
    return tuple(rows[:max(1, limit)])


def history_stats(data: dict | None) -> str:
    st = (data or {}).get("stats") or {}
    if not st.get("total"):
        return "No rotations recorded yet."
    avg = f", average {fmt_ms(st['avg_duration_ms'])}" if st.get("avg_duration_ms") is not None else ""
    return (f"{st['total']} recorded: {st.get('success', 0)} changed the address, {st.get('failed', 0)} failed, "
            f"{st.get('unchanged', 0)} kept the same address; {st.get('unique_ips', 0)} different addresses{avg}")


EVENT_COLUMNS = ("Time", "Level", "Event")
EVENT_TONE = {"warning": WARN, "error": BAD, "critical": BAD}


@dataclass(frozen=True)
class EventRow:
    ts: float
    time: str
    level: str
    tone: str
    text: str

    def cells(self) -> tuple[str, ...]:
        return (self.time, self.level, self.text)


def event_rows(data: dict | None) -> tuple[EventRow, ...]:
    """The alerts stored with the history (newest first)."""
    out = []
    for e in (data or {}).get("events", []):
        out.append(EventRow(float(e.get("ts") or 0.0), fmt_datetime(e.get("ts")), str(e.get("level", "")),
                            EVENT_TONE.get(e.get("level"), INFO), str(e.get("message") or e.get("kind") or "")))
    return tuple(out)


def default_export_name(now: float | None = None) -> str:
    return "ipshift-history-" + time.strftime("%Y%m%d-%H%M%S", time.localtime(now)) + ".csv"


def export_csv(path: str | Path, text: str, *, overwrite: bool = False) -> None:
    """Write the export readable only by its owner (it shows when you used which server).

    Never follows a symlink; an existing file is replaced only when ``overwrite`` is set."""
    flags = os.O_WRONLY | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0) | (os.O_TRUNC if overwrite else os.O_EXCL)
    fd = os.open(os.fspath(path), flags, 0o600)
    try:
        os.fchmod(fd, 0o600)
    except OSError:
        pass
    with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
        f.write(text)


# ---- profiles ---------------------------------------------------------------------------------------------
PROFILE_COLUMNS = ("Name", "Protocol", "Tier", "Country", "State", "In rotation", "OK / failed", "Last address")
TIER_CHOICES = (("paid", "A paid provider"), ("free", "A free provider"), ("self-hosted", "My own server"),
                ("unknown", "Not sure"))
FREE_VPN_WARNING = ("Free VPNs can log your traffic, inject ads or sell your data. "
                    "For anything sensitive, use a paid provider or your own server.")


@dataclass(frozen=True)
class ProfileRow:
    id: str
    name: str
    protocol: str
    tier: str
    country: str
    state: str
    tone: str
    rotating: bool
    record: str
    last_ip: str
    endpoints: int
    active: bool
    enabled: bool
    quarantined: bool
    needs_login: bool
    usable: bool
    error: str

    def cells(self) -> tuple[str, ...]:
        return (self.name, self.protocol, self.tier, self.country, self.state, "yes" if self.rotating else "-",
                self.record, self.last_ip)

    @property
    def can_connect(self) -> bool:
        return self.usable and not self.active


def profile_state(p: dict, current: str | None, now: float) -> tuple[str, str]:
    if p.get("id") == current:
        return "Active", GOOD
    if not p.get("enabled", True):
        return "Disabled", MUTED
    if p.get("quarantined"):
        left = max(0.0, float(p.get("quarantined_until") or 0) - now)
        return f"Benched for {fmt_duration(left)}", BAD
    if p.get("needs_auth") and not p.get("has_auth"):
        return "Needs login", WARN
    return "Ready", GOOD


def profile_rows(data: dict | None, now: float | None = None) -> tuple[ProfileRow, ...]:
    now = time.time() if now is None else now
    data = data or {}
    rotating, current = set(data.get("in_rotation") or []), data.get("current")
    out = []
    for p in data.get("profiles", []):
        state, tone = profile_state(p, current, now)
        out.append(ProfileRow(
            id=str(p.get("id", "")), name=str(p.get("name", "?")), protocol=str(p.get("protocol", "?")),
            tier=str(p.get("tier", "?")), country=p.get("country") or "-", state=state, tone=tone,
            rotating=p.get("id") in rotating, record=f"{p.get('ok_count', 0)} / {p.get('fail_count', 0)}",
            last_ip=p.get("last_ip") or "-", endpoints=len(p.get("endpoints") or []),
            active=p.get("id") == current, enabled=bool(p.get("enabled", True)),
            quarantined=bool(p.get("quarantined")), needs_login=bool(p.get("needs_auth") and not p.get("has_auth")),
            usable=bool(p.get("usable")), error=str(p.get("last_error") or "")))
    return tuple(out)


def has_free_profiles(rows) -> bool:
    return any(r.tier == "free" for r in rows)


# ---- importing --------------------------------------------------------------------------------------------
IMPORT_SUFFIXES = (".ovpn", ".conf")
MAX_IMPORT_FILES = 2000


def expand_import_paths(paths) -> list[Path]:
    """Files as given; a folder contributes the .ovpn and .conf files directly inside it."""
    out: list[Path] = []
    for raw in paths:
        p = Path(raw).expanduser()
        if p.is_dir():
            out.extend(sorted(f for f in p.iterdir() if f.is_file() and f.suffix.lower() in IMPORT_SUFFIXES))
        elif p.is_file():
            out.append(p)
    return out[:MAX_IMPORT_FILES]


@dataclass(frozen=True)
class ImportOutcome:
    file: str
    ok: bool
    name: str = ""
    message: str = ""
    needs_login: bool = False


def import_files(client, paths, *, tier: str = "unknown", username: str | None = None, password: str | None = None,
                 replace: bool = False) -> list[ImportOutcome]:
    """Read each file here (the daemon never opens a path it was given) and send its contents.

    One bad file does not stop the others; a lost daemon does."""
    out: list[ImportOutcome] = []
    for path in expand_import_paths(paths):
        try:
            bundle = read_bundle(path)
            kw = {"text": bundle["text"], "name": bundle["name"], "tier": tier, "replace": replace,
                  "files": bundle["files"] or None, "username": username or None, "password": password or None}
            res = client.profile_import(**{k: v for k, v in kw.items() if v not in (None, "")})
            p = res.get("profile") or {}
            warn = (res.get("warnings") or [""])[0]
            out.append(ImportOutcome(str(path), True, p.get("name", bundle["name"]), warn,
                                     bool(p.get("needs_auth") and not p.get("has_auth"))))
        except DaemonUnavailable:
            raise
        except IPShiftError as e:
            out.append(ImportOutcome(str(path), False, Path(path).stem, e.message or str(e)))
    return out


def import_summary(outcomes: list[ImportOutcome]) -> str:
    if not outcomes:
        return "No .ovpn or .conf files were found."
    done = sum(1 for o in outcomes if o.ok)
    text = f"Imported {done} of {len(outcomes)} profile(s)."
    failed = [o for o in outcomes if not o.ok]
    if failed:
        text += "\n" + "\n".join(f"  {Path(o.file).name}: {o.message}" for o in failed[:8])
        if len(failed) > 8:
            text += f"\n  ... and {len(failed) - 8} more"
    needy = sum(1 for o in outcomes if o.ok and o.needs_login)
    if needy:
        text += f"\n{needy} profile(s) still need a username and password (select them and press Set login)."
    return text
