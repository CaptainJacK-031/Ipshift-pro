"""The questions the window asks.  Each one is a plain function that returns the answer, or ``None`` /
``False`` when the user backs out, so the window's code reads as a series of decisions (and a test can
replace any of them)."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFileDialog, QLineEdit, QListWidget,
                               QMessageBox, QRadioButton, QVBoxLayout)

from . import tables, views
from .widgets import button, hbox, label


# ---- yes / no -----------------------------------------------------------------------------------------------
def confirm(parent, title: str, text: str, *, accept: str = "OK", detail: str = "", danger: bool = False) -> bool:
    """Ask before something that lowers protection.  Cancel is the default and Escape means Cancel."""
    box = QMessageBox(parent)
    box.setIcon(QMessageBox.Icon.Warning if danger else QMessageBox.Icon.Question)
    box.setWindowTitle(title)
    box.setText(text)
    if detail:
        box.setInformativeText(detail)
    yes = box.addButton(accept, QMessageBox.ButtonRole.AcceptRole)
    cancel = box.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)
    box.setDefaultButton(cancel)
    box.setEscapeButton(cancel)
    box.exec()
    return box.clickedButton() == yes


def inform(parent, title: str, text: str) -> None:
    QMessageBox.information(parent, title, text)


# ---- Stop ---------------------------------------------------------------------------------------------------
class StopDialog(QDialog):
    """Stop means three different things; say which."""

    def __init__(self, parent, options):
        super().__init__(parent)
        self.setWindowTitle("Stop")
        self.setModal(True)
        self.setMinimumWidth(480)
        self.radios: dict[str, QRadioButton] = {}
        lay = QVBoxLayout(self)
        lay.setSpacing(8)
        lay.addWidget(label("What should Stop do?", role="h2"))
        for i, option in enumerate(options):
            radio = QRadioButton(option.label)
            radio.setChecked(i == 0)                        # the first one never exposes the real address
            self.radios[option.key] = radio
            lay.addWidget(radio)
            lay.addLayout(hbox(24, (label(option.detail, role="small", wrap=True, tone=views.WARN if option.risky else None), 1)))
        self.buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        self.buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Stop")
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        lay.addWidget(self.buttons)

    def choice(self) -> str | None:
        for key, radio in self.radios.items():
            if radio.isChecked():
                return key
        return None


def ask_stop(parent, options) -> str | None:
    """The key of the chosen ``views.StopOption``; None when cancelled."""
    options = tuple(options)
    if not options:
        return None
    dialog = StopDialog(parent, options)
    return dialog.choice() if dialog.exec() else None


# ---- importing profiles -------------------------------------------------------------------------------------
@dataclass(frozen=True)
class ImportRequest:
    paths: tuple[str, ...]
    tier: str
    username: str
    password: str = field(repr=False)                  # never shown by a log line or a traceback
    replace: bool = False


class ImportDialog(QDialog):
    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle("Import VPN profiles")
        self.setModal(True)
        self.setMinimumWidth(520)
        self.files = QListWidget()
        self.files.setMaximumHeight(110)
        self.tier = QComboBox()
        for value, text in tables.TIER_CHOICES:
            self.tier.addItem(text, value)
        self.tier.setCurrentIndex(self.tier.findData("unknown"))
        self.username = QLineEdit()
        self.username.setPlaceholderText("Username (only if the provider gave you one)")
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.EchoMode.Password)
        self.password.setPlaceholderText("Password")
        self.replace = QCheckBox("Replace profiles that already exist")
        self.warning = label(tables.FREE_VPN_WARNING, role="small", wrap=True, tone=views.WARN)
        self.warning.setVisible(False)
        self.buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        self.ok = self.buttons.button(QDialogButtonBox.StandardButton.Ok)
        self.ok.setText("Import")
        self.ok.setEnabled(False)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        self.add_files_button = button("Add files...", on_click=self.add_files)
        self.add_folder_button = button("Add a folder...", on_click=self.add_folder)

        lay = QVBoxLayout(self)
        lay.setSpacing(8)
        lay.addWidget(label("Choose the .ovpn (OpenVPN) or .conf (WireGuard) files from your VPN provider, "
                            "or a folder that contains them.", wrap=True))
        lay.addWidget(self.files)
        lay.addLayout(hbox(self.add_files_button, self.add_folder_button, None))
        lay.addWidget(label("Where do these servers come from?", role="muted"))
        lay.addWidget(self.tier)
        lay.addWidget(self.warning)
        lay.addWidget(self.username)
        lay.addWidget(self.password)
        lay.addWidget(self.replace)
        lay.addWidget(self.buttons)
        self.tier.currentIndexChanged.connect(lambda *_: self._tier_changed())

    # ---- what the buttons do ----------------------------------------------------------------------------
    def add_paths(self, paths) -> None:
        have = set(self.paths())
        for p in paths:
            if p and p not in have:
                self.files.addItem(p)
                have.add(p)
        self.ok.setEnabled(self.files.count() > 0)

    def add_files(self) -> None:
        picked, _ = QFileDialog.getOpenFileNames(self, "Choose VPN files", str(Path.home()),
                                                 "VPN configurations (*.ovpn *.conf);;All files (*)")
        self.add_paths(picked)

    def add_folder(self) -> None:
        picked = QFileDialog.getExistingDirectory(self, "Choose a folder with VPN files", str(Path.home()))
        self.add_paths([picked] if picked else [])

    def _tier_changed(self) -> None:
        self.warning.setVisible(self.tier.currentData() == "free")

    def paths(self) -> list[str]:
        return [self.files.item(i).text() for i in range(self.files.count())]

    def request(self) -> ImportRequest:
        return ImportRequest(tuple(self.paths()), str(self.tier.currentData()), self.username.text().strip(),
                             self.password.text(), self.replace.isChecked())


def ask_import(parent) -> ImportRequest | None:
    dialog = ImportDialog(parent)
    return dialog.request() if dialog.exec() else None


# ---- login for one profile ----------------------------------------------------------------------------------
class LoginDialog(QDialog):
    def __init__(self, parent, name: str):
        super().__init__(parent)
        self.setWindowTitle("Set login")
        self.setModal(True)
        self.setMinimumWidth(380)
        self.username = QLineEdit()
        self.username.setPlaceholderText("Username")
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.EchoMode.Password)
        self.password.setPlaceholderText("Password")
        self.buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        lay = QVBoxLayout(self)
        lay.setSpacing(8)
        lay.addWidget(label(f"Username and password for {name}", role="h2", wrap=True))
        lay.addWidget(label("They are stored on this computer, readable only by root.", role="small", wrap=True))
        lay.addWidget(self.username)
        lay.addWidget(self.password)
        lay.addWidget(self.buttons)


def ask_login(parent, name: str) -> tuple[str, str] | None:
    dialog = LoginDialog(parent, name)
    if not dialog.exec():
        return None
    user, password = dialog.username.text().strip(), dialog.password.text()
    return (user, password) if user and password else None


# ---- saving the history -------------------------------------------------------------------------------------
def ask_save_csv(parent, default_name: str) -> tuple[str, bool] | None:
    """(path, overwrite) for the history export; None when cancelled.

    The file dialog's own "replace?" question is switched off so that the answer is asked once, here,
    the same way on every desktop."""
    start = str(Path.home() / default_name)
    path, _ = QFileDialog.getSaveFileName(parent, "Export the rotation history", start,
                                          "CSV files (*.csv);;All files (*)",
                                          options=QFileDialog.Option.DontConfirmOverwrite)
    if not path:
        return None
    if os.path.lexists(path):
        if not confirm(parent, "Replace file?", f"{Path(path).name} already exists. Replace it?", accept="Replace"):
            return None
        return path, True
    return path, False
