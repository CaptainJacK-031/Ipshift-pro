"""The Privacy page as plain data (no Qt): the DNS and IPv6 leak results up front, then every check."""
from __future__ import annotations

from dataclasses import dataclass

from ..cli.ui import fmt_ago, fmt_ms
from ..privacy.leaks import FULL, TITLES
from ..privacy.report import NOT_COVERED
from .views import BAD, GOOD, MUTED, PLAIN, WARN

GLYPH = {"pass": "✔", "warn": "!", "fail": "✖", "skip": "–", "pending": "…"}
WORD = {"pass": "PASS", "warn": "WARNING", "fail": "FAIL", "skip": "NOT TESTED", "pending": "NOT RUN YET"}
TONE = {"pass": GOOD, "warn": WARN, "fail": BAD, "skip": MUTED, "pending": MUTED}
VERDICT_TONE = {"protected": GOOD, "protected-with-warnings": WARN, "blocked": WARN,
                "at-risk": BAD, "unprotected": BAD, "exposed": BAD}
DNS_IDS = ("dns_config", "dns_path", "dns_escape")
_SEVERITY = {"fail": 3, "warn": 2, "pass": 1, "skip": 0}


@dataclass(frozen=True)
class Tile:
    id: str
    title: str
    status: str                      # pass | warn | fail | skip | pending
    word: str
    glyph: str
    tone: str
    detail: str
    hint: str
    leak: bool


def make_tile(id_: str, title: str, status: str, detail: str = "", hint: str = "", leak: bool = False) -> Tile:
    return Tile(id_, title, status, WORD.get(status, status.upper()), GLYPH.get(status, "?"),
                TONE.get(status, MUTED), detail, hint or "", bool(leak and status == "fail"))


def _from_finding(f: dict) -> Tile:
    return make_tile(f.get("id", "?"), f.get("title") or TITLES.get(f.get("id", ""), f.get("id", "?")),
                     f.get("status", "skip"), f.get("detail") or "",
                     f.get("hint") if f.get("status") in ("fail", "warn") else "", bool(f.get("leak")))


def pending_tile(id_: str, title: str | None = None) -> Tile:
    return make_tile(id_, title or TITLES.get(id_, id_), "pending", "Run the privacy check to see this result.")


def dns_tile(findings: dict[str, dict]) -> Tile:
    """One result for DNS: the worst of the configuration, resolution-path and escape checks."""
    have = [findings[i] for i in DNS_IDS if i in findings]
    title = "DNS leak test"
    if not have:
        return make_tile("dns", title, "pending", "Run the privacy check to see this result.")
    worst = max((f.get("status", "skip") for f in have), key=lambda s: _SEVERITY.get(s, 0))
    pick = next(f for f in have if f.get("status") == worst)
    if worst in ("fail", "warn"):
        return make_tile("dns", title, worst, f"{pick.get('title', '')}: {pick.get('detail', '')}",
                         pick.get("hint") or "", any(f.get("leak") and f.get("status") == "fail" for f in have))
    if worst == "pass":
        names = ", ".join(f.get("title", "") for f in have if f.get("status") == "pass")
        return make_tile("dns", title, "pass", f"No DNS leak found ({names}).")
    return make_tile("dns", title, "skip", pick.get("detail") or "These checks could not run.")


@dataclass(frozen=True)
class LeakView:
    has_report: bool
    verdict: str
    headline: str
    tone: str
    score: str
    grade: str
    meta: str
    simulated: bool
    dns: Tile
    ipv6: Tile
    tiles: tuple[Tile, ...]
    counts: str
    not_covered: tuple[str, ...]


def leak_view(rep: dict | None, now: float | None = None) -> LeakView:
    if not rep:
        pend = tuple(pending_tile(i) for i in FULL)
        return LeakView(False, "", "No test has been run yet", MUTED, "-", "-",
                        "Press “Run test” to check for DNS, IPv6 and other leaks.", False,
                        make_tile("dns", "DNS leak test", "pending", "Run the privacy check to see this result."),
                        pending_tile("ipv6", "IPv6 leak test"), pend, "", tuple(NOT_COVERED))
    findings = {f.get("id"): f for f in rep.get("findings", []) if f.get("id")}
    order = [i for i in FULL if i in findings] + [i for i in findings if i not in FULL]
    tiles = tuple(_from_finding(findings[i]) for i in order)
    ipv6 = _from_finding(findings["ipv6"]) if "ipv6" in findings else pending_tile("ipv6", "IPv6 leak test")
    c = rep.get("counts") or {}
    verdict = rep.get("verdict", "")
    meta = f"{rep.get('mode', 'full')} test, {fmt_ms(rep.get('duration_ms'))}, checked {fmt_ago(rep.get('ts'), now)}"
    return LeakView(True, verdict, rep.get("headline") or verdict, VERDICT_TONE.get(verdict, PLAIN),
                    str(rep.get("score", "-")), str(rep.get("grade", "-")), meta, bool(rep.get("simulated")),
                    dns_tile(findings), ipv6, tiles,
                    f"{c.get('pass', 0)} passed, {c.get('warn', 0)} warnings, {c.get('fail', 0)} failed, "
                    f"{c.get('skip', 0)} not tested",
                    tuple(rep.get("not_covered") or NOT_COVERED))
