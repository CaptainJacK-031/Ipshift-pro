"""The Profiles page: the VPN servers the rotation chooses from."""
from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtWidgets import QVBoxLayout, QWidget

from . import tables, views
from .widgets import (Card, TableModel, button, hbox, label, make_table, selected_row, set_table_rows, set_text)


class ProfilesPage(QWidget):
    import_requested = Signal()
    connect_requested = Signal(str)                # profile id
    toggle_requested = Signal(str, bool)           # profile id, enable?
    login_requested = Signal(str)
    reuse_requested = Signal(str)                  # bring a benched profile back
    remove_requested = Signal(str)

    def __init__(self):
        super().__init__()
        self.setObjectName("page")
        self._can_connect = False

        self.model = TableModel(tables.PROFILE_COLUMNS, tone_column=4)
        self.view = make_table(self.model)
        self.view.selectionModel().selectionChanged.connect(lambda *_: self._update_buttons())

        self.import_button = button("Import...", role="primary", on_click=self.import_requested.emit,
                                    tip="Add .ovpn (OpenVPN) or .conf (WireGuard) files, or a whole folder")
        self.connect_button = button("Connect", tip="Connect to the selected server now",
                                     on_click=lambda: self._send(self.connect_requested))
        self.toggle_button = button("Disable", tip="Keep the profile but leave it out of the rotation",
                                    on_click=self._toggle)
        self.login_button = button("Set login...", tip="Username and password for this profile",
                                   on_click=lambda: self._send(self.login_requested))
        self.reuse_button = button("Use again", tip="This profile was benched after failures: try it again",
                                   on_click=lambda: self._send(self.reuse_requested))
        self.remove_button = button("Remove", role="danger", on_click=lambda: self._send(self.remove_requested))

        self.empty = Card()
        self.empty.add(label("No VPN profiles yet", role="h2"),
                       label("Import the configuration files your VPN provider gave you (.ovpn for OpenVPN, .conf "
                             "for WireGuard), or the files of your own server. Paid, free and self-hosted servers "
                             "all work; the rotation switches between the ones you add.", role="muted", wrap=True))
        self.warning = label(tables.FREE_VPN_WARNING, tone=views.WARN, wrap=True)
        self.warning.setVisible(False)
        self.detail = label("", role="muted", wrap=True, selectable=True)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(22, 18, 22, 22)
        lay.setSpacing(12)
        lay.addWidget(label("VPN profiles", role="h1"))
        lay.addWidget(self.empty)
        lay.addWidget(self.warning)
        lay.addLayout(hbox(self.import_button, None, self.connect_button, self.toggle_button, self.login_button,
                           self.reuse_button, self.remove_button))
        lay.addWidget(self.view, 1)
        lay.addWidget(self.detail)

    # ---- what the user picked -------------------------------------------------------------------------------
    def selected(self):
        return selected_row(self.view, self.model)

    def _send(self, signal) -> None:
        row = self.selected()
        if row is not None:
            signal.emit(row.id)

    def _toggle(self) -> None:
        row = self.selected()
        if row is not None:
            self.toggle_requested.emit(row.id, not row.enabled)

    def _update_buttons(self) -> None:
        row = self.selected()
        self.connect_button.setEnabled(bool(row and row.can_connect and self._can_connect))
        self.toggle_button.setEnabled(row is not None)
        set_text(self.toggle_button, "Disable" if row is None or row.enabled else "Enable")
        self.login_button.setEnabled(row is not None)
        self.reuse_button.setEnabled(bool(row and row.quarantined))
        self.remove_button.setEnabled(row is not None)
        if row is None:
            text = ""
        elif row.error:
            text = f"{row.name}: {row.error}"
        elif row.needs_login:
            text = f"{row.name} needs a username and password: press Set login."
        else:
            text = f"{row.name}: {row.endpoints} server address(es)" if row.endpoints else row.name
        set_text(self.detail, text)

    # ---- showing a view ---------------------------------------------------------------------------------------
    def update_view(self, rows, *, can_connect: bool) -> None:
        rows = tuple(rows)
        self._can_connect = can_connect
        set_table_rows(self.view, self.model, rows, key=lambda r: r.id)
        self.empty.setVisible(not rows)
        self.view.setVisible(bool(rows))
        self.warning.setVisible(tables.has_free_profiles(rows))
        self._update_buttons()
