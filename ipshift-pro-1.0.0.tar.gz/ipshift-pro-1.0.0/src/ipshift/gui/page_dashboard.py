"""The Dashboard page: protection status, addresses, VPN, kill switch and the rotation controls.

The page only shows what ``views.Dashboard`` says and reports what the user presses (as signals);
the window decides what a press means and asks before anything that lowers protection.
"""
from __future__ import annotations

from PySide6.QtCore import QTimer, Signal
from PySide6.QtWidgets import QDoubleSpinBox, QFrame, QGridLayout, QScrollArea, QVBoxLayout, QWidget

from ..config import MIN_INTERVAL
from . import views
from .model import IntervalSync
from .widgets import (Banner, Card, KeyValue, RowList, build_alert, build_private_ip, build_problem, button, hbox,
                      label, set_text, set_tone)

INTERVAL_DEBOUNCE_MS = 500            # wait for the typing to stop before changing a running rotation


class DashboardPage(QWidget):
    start_requested = Signal(float)
    stop_requested = Signal()
    rotate_now_requested = Signal()
    cancel_requested = Signal()
    interval_changed = Signal(float)
    killswitch_requested = Signal(str)             # "on" | "lockdown" | "off"
    privacy_requested = Signal(str)                # "full" | "quick"
    lookup_requested = Signal()
    goto = Signal(str)                             # the title of a page

    def __init__(self):
        super().__init__()
        self.setObjectName("page")
        self.advice_fn = lambda interval: ""       # the window sets this to ``model.advice``
        self._sync = IntervalSync()
        self._interval_timer = QTimer(self)
        self._interval_timer.setSingleShot(True)
        self._interval_timer.timeout.connect(self._commit_interval)

        self.banner = Banner()
        self.problems = RowList(build_problem, spacing=10)
        self.problems_card = Card("Needs attention")
        self.problems_card.add(self.problems)
        self.problems_card.setVisible(False)

        content = QWidget()
        content.setObjectName("page")
        body = QVBoxLayout(content)
        body.setContentsMargins(22, 18, 22, 22)
        body.setSpacing(14)
        body.addWidget(self.banner)
        body.addWidget(self.problems_card)
        grid = QGridLayout()
        grid.setHorizontalSpacing(14)
        grid.setVerticalSpacing(14)
        grid.setColumnStretch(0, 1)
        grid.setColumnStretch(1, 1)
        grid.addWidget(self._build_vpn_card(), 0, 0)
        grid.addWidget(self._build_public_card(), 0, 1)
        grid.addWidget(self._build_private_card(), 1, 0)
        grid.addWidget(self._build_killswitch_card(), 1, 1)
        body.addLayout(grid)
        body.addWidget(self._build_rotation_card())
        lower = QGridLayout()
        lower.setHorizontalSpacing(14)
        lower.setColumnStretch(0, 1)
        lower.setColumnStretch(1, 1)
        lower.addWidget(self._build_privacy_card(), 0, 0)
        lower.addWidget(self._build_alerts_card(), 0, 1)
        body.addLayout(lower)
        body.addStretch(1)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setWidget(content)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(scroll)

    # ---- the cards ---------------------------------------------------------------------------------------
    def _build_vpn_card(self) -> Card:
        self.vpn_badge = label("", pill=True)
        self.vpn_profile = label("-", role="h2", selectable=True)
        self.vpn_facts = KeyValue(("Type", "Server", "Interface", "Connected for", "Last handshake"))
        self.vpn_note = label("", wrap=True)
        card = Card("VPN connection")
        card.add(hbox(self.vpn_profile, None, self.vpn_badge), self.vpn_facts, self.vpn_note)
        return card

    def _build_public_card(self) -> Card:
        self.public_value = label("-", role="big", selectable=True)
        self.public_note = label("", role="muted", wrap=True)
        self.public_v6 = KeyValue(("IPv6",))
        self.lookup_button = button("Look up my real address", role="link", on_click=self.lookup_requested.emit,
                                    tip="Asks an outside service for your address without the VPN. Only offered "
                                        "while you are unprotected, and only when you press it.")
        self.lookup_button.setVisible(False)
        card = Card("Public IP address")
        card.add(self.public_value, self.public_note, self.public_v6, self.lookup_button)
        return card

    def _build_private_card(self) -> Card:
        self.private_ips = RowList(build_private_ip, empty="No network address found.", spacing=4)
        self.network = label("", role="muted", wrap=True)
        card = Card("This computer (private IP)")
        card.add(self.private_ips, self.network)
        return card

    def _build_killswitch_card(self) -> Card:
        self.ks_badge = label("", pill=True)
        self.ks_detail = label("", wrap=True)
        self.ks_endpoints = label("", role="small", wrap=True)
        self.arm_button = button("Arm", tip="Block all traffic except the VPN now",
                                 on_click=lambda: self.killswitch_requested.emit("on"))
        self.lockdown_button = button("Lockdown", role="danger", tip="Drop the VPN and block everything",
                                      on_click=lambda: self.killswitch_requested.emit("lockdown"))
        self.release_button = button("Release", tip="Give normal networking back (your real address is exposed)",
                                     on_click=lambda: self.killswitch_requested.emit("off"))
        self.hardening = KeyValue(("DNS", "IPv6", "MAC address"))
        card = Card("Kill switch")
        card.add(hbox(self.ks_badge, None), self.ks_detail, self.ks_endpoints,
                 hbox(self.arm_button, self.lockdown_button, self.release_button, None), self.hardening)
        return card

    def _build_rotation_card(self) -> Card:
        self.interval = QDoubleSpinBox()
        self.interval.setObjectName("interval")
        self.interval.setRange(MIN_INTERVAL, views.MAX_INTERVAL)
        self.interval.setDecimals(1)
        self.interval.setSingleStep(1.0)
        self.interval.setSuffix(" s")
        self.interval.setValue(30.0)
        self.interval.setKeyboardTracking(False)
        self.interval.setAccelerated(True)
        self.interval.setToolTip("Time between the start of two address changes. The smallest value is 1 second.")
        self.interval.valueChanged.connect(lambda *_: self._interval_edited())

        self.start_button = button("Start", role="primary", tip="Connect and change the address every interval",
                                   on_click=lambda: self.start_requested.emit(self.interval.value()))
        self.now_button = button("Rotate now", tip="Switch to another server once, now",
                                 on_click=self.rotate_now_requested.emit)
        self.stop_button = button("Stop", role="danger", on_click=self.stop_requested.emit)
        self.cancel_button = button("Cancel", tip="Abandon the connection attempt in progress",
                                    on_click=self.cancel_requested.emit)
        self.rotation_state = label("", role="h2", wrap=True)
        self.countdown = label("", role="mono")
        self.rotation_counts = label("", role="muted", wrap=True)
        self.rotation_last = label("", wrap=True)
        self.rotation_problem = label("", wrap=True)
        self.rotation_hint = label("", role="muted", wrap=True)
        self.rotation_advice = label("", role="small", wrap=True, tone=views.INFO)

        card = Card("IP rotation")
        card.add(hbox(label("Change my address every", role="muted"), self.interval, 8, self.start_button,
                      self.now_button, self.stop_button, self.cancel_button, None, spacing=8),
                 hbox(self.rotation_state, None, self.countdown),
                 self.rotation_counts, self.rotation_last, self.rotation_problem, self.rotation_hint,
                 self.rotation_advice)
        for w in (self.rotation_counts, self.rotation_last, self.rotation_problem, self.rotation_hint,
                  self.rotation_advice):
            w.setVisible(False)
        return card

    def _build_privacy_card(self) -> Card:
        self.privacy_line = label("", wrap=True)
        self.check_button = button("Run privacy check", on_click=lambda: self.privacy_requested.emit("full"))
        self.open_privacy = button("See the details", role="link", on_click=lambda: self.goto.emit("Privacy"))
        card = Card("Privacy")
        card.add(self.privacy_line, hbox(self.check_button, self.open_privacy, None))
        return card

    def _build_alerts_card(self) -> Card:
        self.alerts = RowList(build_alert, empty="No warnings or errors.", spacing=8)
        card = Card("Recent alerts")
        card.add(self.alerts)
        return card

    # ---- the interval box -------------------------------------------------------------------------------
    def _interval_edited(self) -> None:
        self._show_advice()
        self._interval_timer.start(INTERVAL_DEBOUNCE_MS)

    def _commit_interval(self) -> None:
        self.interval_changed.emit(self.interval.value())

    def _show_advice(self) -> None:
        text = self.advice_fn(self.interval.value())
        set_text(self.rotation_advice, text)
        self.rotation_advice.setVisible(bool(text))

    def set_interval(self, value: float) -> None:
        """Show ``value`` in the box without announcing it as an edit."""
        self.interval.blockSignals(True)
        self.interval.setValue(value)
        self.interval.blockSignals(False)

    # ---- showing a view ---------------------------------------------------------------------------------
    def update_view(self, d: views.Dashboard, alerts=()) -> None:
        extra = d.daemon + ("   -   SIMULATION: no real network is touched" if d.simulated else "")
        self.banner.show_view(d.banner, extra)
        self.problems.set_items(d.problems)
        self.problems_card.setVisible(bool(d.problems))
        self._show_vpn(d.vpn)
        self._show_public(d.public)
        self.private_ips.set_items(d.private)
        set_text(self.network, d.network)
        self._show_killswitch(d)
        self._show_rotation(d)
        set_text(self.privacy_line, d.privacy)
        set_tone(self.privacy_line, d.privacy_tone)
        self.alerts.set_items(alerts)

    def _show_vpn(self, v: views.VpnView) -> None:
        set_text(self.vpn_badge, v.badge)
        set_tone(self.vpn_badge, v.tone)
        set_text(self.vpn_profile, v.profile)
        for key, text in (("Type", v.facts), ("Server", v.server), ("Interface", v.iface),
                          ("Connected for", v.uptime), ("Last handshake", v.handshake)):
            self.vpn_facts.set(key, text)
        set_text(self.vpn_note, v.note)
        set_tone(self.vpn_note, v.note_tone)
        self.vpn_note.setVisible(bool(v.note))

    def _show_public(self, p: views.PublicIpView) -> None:
        set_text(self.public_value, p.value)
        set_tone(self.public_value, p.tone)
        set_text(self.public_note, p.note)
        self.public_note.setVisible(bool(p.note))
        self.public_v6.set("IPv6", p.v6)
        self.lookup_button.setVisible(p.offer_direct)

    def _show_killswitch(self, d: views.Dashboard) -> None:
        k, c = d.killswitch, d.controls
        set_text(self.ks_badge, k.badge)
        set_tone(self.ks_badge, k.tone)
        set_text(self.ks_detail, k.detail)
        set_text(self.ks_endpoints, k.endpoints)
        self.ks_endpoints.setVisible(bool(k.endpoints))
        self.arm_button.setEnabled(c.can_arm)
        self.release_button.setEnabled(c.can_release)
        self.lockdown_button.setEnabled(c.can_lockdown)
        for row in d.hardening:
            self.hardening.set(row.label, row.text, row.tone)

    def _show_rotation(self, d: views.Dashboard) -> None:
        r, c = d.rotation, d.controls
        shown = self._sync.on_daemon(r.interval, editing=self.interval.hasFocus())
        if shown is not None:
            self.set_interval(shown)
        self.start_button.setEnabled(c.can_start)
        self.now_button.setEnabled(c.can_rotate_now)
        self.stop_button.setEnabled(c.can_stop)
        self.cancel_button.setEnabled(c.can_cancel)
        set_text(self.rotation_state, r.state)
        set_tone(self.rotation_state, r.tone)
        for lab, text, tone in ((self.rotation_counts, r.counts, views.MUTED),
                                (self.rotation_last, r.last, r.last_tone),
                                (self.rotation_problem, r.problem, r.problem_tone),
                                (self.rotation_hint, "" if c.can_start or r.running else c.start_hint, views.MUTED)):
            set_text(lab, text)
            set_tone(lab, tone)
            lab.setVisible(bool(text))
        self._show_advice()

    def set_countdown(self, text: str) -> None:
        """Called four times a second; only the countdown label changes."""
        set_text(self.countdown, text)

    def forget_interval(self) -> None:
        """The daemon went away: take its interval again when it comes back."""
        self._sync.reset()
