"""What the window knows right now (no Qt): the latest data from the daemon and what it adds up to.

The window feeds every signal from the link into ``apply_*`` and redraws from the getters, so the
rules about what is shown (which data is stale, when a real-IP lookup is forgotten, which events
deserve a desktop notification, what a command's outcome is called) are all tested without a display.
"""
from __future__ import annotations

import time
from dataclasses import dataclass

from ..cli.render import interval_text
from . import leakviews, tables, views
from .link import Result
from .settings_schema import applies_text

MAX_EVENTS = 300
DIRECT_LOOKUP_TTL = 120.0               # a looked-up real address is forgotten after this many seconds


@dataclass(frozen=True)
class Outcome:
    text: str
    tone: str
    hint: str = ""


class IntervalSync:
    """Keeps the interval box and the daemon in step without fighting the user.

    The box is the user's until the *daemon's* value changes (the CLI changed it, or the window just
    connected); only then is the box overwritten."""

    def __init__(self):
        self._seen: float | None = None

    def on_daemon(self, value: float, editing: bool = False) -> float | None:
        if self._seen is not None and abs(value - self._seen) < 1e-9:
            return None
        if editing and self._seen is not None:
            self._seen = value                                # the user is typing: leave the box alone
            return None
        self._seen = value
        return value

    def reset(self) -> None:
        self._seen = None


class AppModel:
    def __init__(self, *, clock=time.time, mono=time.monotonic):
        self._clock, self._mono = clock, mono
        self.started_at = clock()
        self.link_up: bool | None = None
        self.link_error = ""
        self.link_hint = ""
        self.status: dict | None = None
        self.status_at = 0.0
        self.profiles: dict | None = None
        self.history: dict | None = None
        self.report: dict | None = None
        self.events: list[dict] = []
        self.busy: frozenset = frozenset()
        self.direct: dict | None = None
        self._direct_at = 0.0
        self.config: dict | None = None                       # the answer to config.get: {"config": {section: {key: value}}, ...}

    # ---- feeding it ------------------------------------------------------------------------------------
    def apply_link(self, up: bool, error: str = "", hint: str = "") -> None:
        self.link_up, self.link_error, self.link_hint = up, error, hint
        if not up:
            self.status = None                                # an old status would look like a live one

    def apply_status(self, st: dict) -> None:
        self.status, self.status_at = st, self._mono()
        if (st.get("protection") or {}).get("level") != "unprotected":
            self.direct = None                                # the real address is only shown while unprotected

    def apply_event(self, ev: dict) -> tuple[str, str] | None:
        """Record the event; returns (title, text) when it deserves a desktop notification."""
        self.events.append(ev)
        del self.events[:-MAX_EVENTS]
        if float(ev.get("ts") or 0) < self.started_at - 1.0:
            return None                                       # replayed from before the window opened
        return views.notification_for(ev)

    def apply_data(self, name: str, data) -> None:
        if name in ("profiles", "history", "report"):
            setattr(self, name, data)

    def apply_busy(self, busy) -> None:
        self.busy = frozenset(busy)

    def apply_result(self, res: Result) -> Outcome:
        """Keep what the result carries and say what happened, in words for the status line."""
        if res.ok and res.name == "privacy_check" and isinstance(res.data, dict):
            self.report = res.data
        if res.ok and res.name == "ip" and isinstance(res.data, dict):
            self.direct, self._direct_at = res.data, self._mono()
        if res.ok and res.name == "config_get" and isinstance(res.data, dict) and "config" in res.data:
            self.config = res.data
        if res.ok and res.name == "config_set" and isinstance(res.data, dict) and self.config:
            sec, _, key = str(res.data.get("key", "")).partition(".")
            if sec in self.config["config"] and key in self.config["config"][sec]:
                self.config["config"][sec][key] = res.data.get("value")
        return describe_result(res)

    # ---- reading it ------------------------------------------------------------------------------------
    def _direct(self) -> dict | None:
        if self.direct and self._mono() - self._direct_at > DIRECT_LOOKUP_TTL:
            self.direct = None
        return self.direct

    def dashboard(self) -> views.Dashboard:
        return views.dashboard_view(self.status, busy=self.busy, direct=self._direct(),
                                    link_error=self.link_error or None, now=self._clock())

    def leaks(self) -> leakviews.LeakView:
        return leakviews.leak_view(self.report, self._clock())

    def history_rows(self, flt: str = "all"):
        return tables.history_rows(self.history, flt)

    def profile_rows(self):
        return tables.profile_rows(self.profiles, self._clock())

    def alerts(self):
        return views.alert_rows(self.events)

    def advice(self, interval: float | None) -> str:
        return views.interval_advice(self.profiles, interval)

    def countdown(self) -> str:
        return views.countdown_text(self.status, self.status_at, self._mono())

    @property
    def level(self) -> str:
        return (self.status or {}).get("protection", {}).get("level", "offline")


# ---- the words for a command's outcome ----------------------------------------------------------------------
def describe_result(res: Result) -> Outcome:
    if not res.ok:
        text = res.message or "The command failed."
        if (res.error or {}).get("code") == "busy":
            text = "Another operation is still running. Try again in a moment."
        return Outcome(text, views.BAD, res.hint)
    d = res.data if isinstance(res.data, dict) else {}
    name = res.name
    if name in ("connect", "rotate_now"):
        text = f"Connected to {d.get('profile_name', '?')}: {d.get('exit_ip', '?')}"
        if d.get("previous_ip") and d.get("changed") is False:
            return Outcome(text + " (the same address as before)", views.WARN)
        return Outcome(text, views.GOOD)
    if name == "rotate_start":
        return Outcome(f"Rotation started: a new address every {interval_text(d.get('interval'))}", views.GOOD,
                       str(d.get("warning") or ""))
    if name == "rotate_stop":
        return Outcome("Rotation stopped", views.INFO)
    if name == "stop":
        if d.get("stopped") == "rotation":
            return Outcome("Rotation stopped; the VPN stays connected", views.INFO)
        if d.get("released"):
            return Outcome("Stopped. Normal networking is back and your real address is visible.", views.WARN)
        return Outcome("Stopped. The kill switch keeps blocking all traffic.", views.INFO)
    if name == "cancel":
        return Outcome("Cancelling the connection attempt", views.INFO)
    if name == "privacy_check":
        return Outcome(f"Privacy check finished: grade {d.get('grade', '?')} ({d.get('score', '?')}/100)",
                       leakviews.VERDICT_TONE.get(d.get("verdict", ""), views.PLAIN))
    if name == "set_interval":
        return Outcome(f"Interval is now {interval_text(d.get('interval'))}", views.GOOD)
    if name == "killswitch_on":
        return Outcome("Kill switch armed: nothing leaves this computer except through the VPN", views.GOOD)
    if name == "killswitch_off":
        return Outcome("Kill switch released: traffic can leave outside the VPN", views.WARN)
    if name == "lockdown":
        return Outcome("Lockdown: all network traffic is blocked", views.BAD)
    if name == "config_set":
        return Outcome(f"{d.get('key', 'Setting')} changed ({applies_text(d)})", views.GOOD)
    if name == "history_clear":
        return Outcome("History deleted", views.INFO)
    if name == "history_export":
        text = f"Wrote {d.get('rows', 0)} row(s) to {d.get('path', 'the file')} (readable only by you)"
        return Outcome(text, views.WARN if d.get("truncated") else views.GOOD,
                       "The export was cut at its size limit: the oldest rows are missing." if d.get("truncated") else "")
    if name == "profile_import":
        outcomes = res.data if isinstance(res.data, list) else []
        failed = sum(1 for o in outcomes if not o.ok)
        text = f"Imported {len(outcomes) - failed} of {len(outcomes)} profile(s)" if outcomes else "No profile files found"
        return Outcome(text, views.WARN if failed or not outcomes else views.GOOD)
    if name in ("profile_remove", "profile_update", "profile_auth", "profile_clear_quarantine"):
        return Outcome({"profile_remove": "Profile removed", "profile_update": "Profile updated",
                        "profile_auth": "Login saved", "profile_clear_quarantine": "Profiles can be used again"}[name],
                       views.GOOD)
    return Outcome("Done", views.INFO)
