"""A private, simulated daemon for trying the window without root, a VPN or any network change.

``ipshift-gui --demo`` and ``--selftest`` start one inside the GUI process.  Nothing real is touched:
the network, the VPN servers and the firewall are all fake, and everything it creates lives in a
temporary directory that is deleted when it stops.
"""
from __future__ import annotations

import tempfile
from pathlib import Path

from ..config import Config
from ..daemon import Daemon
from ..paths import Paths


class DemoDaemon:
    def __init__(self, speed: float = 1.0):
        self.speed = speed
        self.daemon: Daemon | None = None
        self.socket: Path | None = None
        self._tmp: tempfile.TemporaryDirectory | None = None

    def start(self) -> Path:
        if self.daemon is not None and self.socket is not None:
            return self.socket
        self._tmp = tempfile.TemporaryDirectory(prefix="ipshift-demo-")
        root = Path(self._tmp.name)
        paths = Paths(root / "etc" / "config.json", root / "var", root / "run", root / "log")
        cfg = Config()
        cfg.vpn.connect_timeout = 20.0
        cfg.vpn.verify_timeout = 10.0
        self.socket = root / "run" / "ipshift.sock"
        daemon = Daemon(cfg, paths, simulate=True, sim_speed=self.speed, demo=True, socket_path=self.socket)
        try:
            daemon.start()
        except BaseException:
            self._cleanup()
            raise
        self.daemon = daemon
        return self.socket

    def stop(self) -> None:
        daemon, self.daemon = self.daemon, None
        try:
            if daemon is not None:
                daemon.stop()
        finally:
            self._cleanup()

    def _cleanup(self) -> None:
        tmp, self._tmp = self._tmp, None
        if tmp is not None:
            tmp.cleanup()

    def __enter__(self) -> "DemoDaemon":
        self.start()
        return self

    def __exit__(self, *exc) -> None:
        self.stop()
