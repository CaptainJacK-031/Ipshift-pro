"""The Privacy page: the DNS and IPv6 leak results first, then every other check, then what no check can see."""
from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtWidgets import QFrame, QGridLayout, QProgressBar, QScrollArea, QVBoxLayout, QWidget

from . import leakviews, views
from .widgets import Card, RowList, TileCard, button, clear_layout, hbox, label, set_text, set_tone, vbox


class PrivacyPage(QWidget):
    run_requested = Signal(str)                    # "full" | "quick"

    def __init__(self):
        super().__init__()
        self.setObjectName("page")
        self._ids: tuple[str, ...] = ()
        self._tiles: list[TileCard] = []

        self.grade = label("-", role="score")
        self.score = label("", role="muted")
        self.headline = label("", role="h2", wrap=True)
        self.meta = label("", role="muted", wrap=True)
        self.counts = label("", role="small", wrap=True)
        self.simulated = label("SIMULATION: these results are made up; no real network was tested.",
                               tone=views.WARN, wrap=True)
        self.simulated.setVisible(False)
        self.run_full = button("Run full test", role="primary",
                               tip="Tests DNS, IPv6, the tunnel, the kill switch and more (about 10 seconds)",
                               on_click=lambda: self.run_requested.emit("full"))
        self.run_quick = button("Quick test", tip="Only the checks that need no network traffic",
                                on_click=lambda: self.run_requested.emit("quick"))
        self.progress = QProgressBar()
        self.progress.setRange(0, 0)                # no end in sight: a moving bar
        self.progress.setTextVisible(False)
        self.progress.setVisible(False)

        summary = Card()
        summary.add(hbox(vbox(self.grade, self.score, spacing=0),
                         (vbox(self.headline, self.meta, self.counts, spacing=3), 1),
                         vbox(self.run_full, self.run_quick, None, spacing=6), spacing=18),
                    self.progress, self.simulated)

        self.dns_tile = TileCard(big=True)
        self.ipv6_tile = TileCard(big=True)
        self.grid = QGridLayout()
        self.grid.setHorizontalSpacing(12)
        self.grid.setVerticalSpacing(12)
        self.grid.setColumnStretch(0, 1)
        self.grid.setColumnStretch(1, 1)
        self.not_covered = RowList(lambda text: label("•  " + text, role="muted", wrap=True), spacing=4)

        content = QWidget()
        content.setObjectName("page")
        body = QVBoxLayout(content)
        body.setContentsMargins(22, 18, 22, 22)
        body.setSpacing(14)
        body.addWidget(summary)
        body.addLayout(hbox(self.dns_tile, self.ipv6_tile, spacing=14))
        body.addWidget(label("ALL CHECKS", role="title"))
        body.addLayout(self.grid)
        body.addWidget(Card("What this check cannot see").add(
            label("A privacy test can only look at this computer's network. Some things need a different tool:",
                  role="muted", wrap=True), self.not_covered))
        body.addStretch(1)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setWidget(content)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(scroll)

    def update_view(self, lv: leakviews.LeakView, running: bool = False) -> None:
        set_text(self.grade, lv.grade)
        set_tone(self.grade, lv.tone)
        set_text(self.score, f"{lv.score} / 100" if lv.has_report else "")
        set_text(self.headline, lv.headline)
        set_tone(self.headline, lv.tone)
        set_text(self.meta, lv.meta)
        set_text(self.counts, lv.counts)
        self.counts.setVisible(bool(lv.counts))
        self.simulated.setVisible(lv.simulated)
        self.progress.setVisible(running)
        self.run_full.setEnabled(not running)
        self.run_quick.setEnabled(not running)
        self.dns_tile.show_tile(lv.dns)
        self.ipv6_tile.show_tile(lv.ipv6)
        self._show_tiles(lv.tiles)
        self.not_covered.set_items(lv.not_covered)

    def _show_tiles(self, tiles) -> None:
        ids = tuple(t.id for t in tiles)
        if ids != self._ids:                           # a different set of checks: build the grid again
            clear_layout(self.grid)
            self._tiles = []
            for i, _ in enumerate(tiles):
                card = TileCard()
                self._tiles.append(card)
                self.grid.addWidget(card, i // 2, i % 2)
            self._ids = ids
        for card, tile in zip(self._tiles, tiles):
            card.show_tile(tile)
