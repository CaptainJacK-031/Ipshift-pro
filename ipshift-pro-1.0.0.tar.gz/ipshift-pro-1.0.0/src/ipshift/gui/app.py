"""``ipshift-gui``: the graphical dashboard.

    ipshift-gui                 talk to the running daemon (needs membership of the 'ipshift' group)
    ipshift-gui --demo          try the window against a private simulated daemon (no root, nothing real touched)
    ipshift-gui --selftest      drive the window through a scripted run against the simulator and report

The window is a remote control: it needs no root, and closing it leaves the VPN and the rotation running.
"""
from __future__ import annotations

import argparse
import os
import signal
import sys

from .. import __version__
from . import qt_available

MISSING_QT = """\
The graphical window needs PySide6 (Qt for Python), which is not installed.

    Kali / Debian:   sudo apt install python3-pyside6.qtwidgets
    anywhere else:   python3 -m pip install --user 'PySide6>=6.5'

The command line needs nothing extra and does the same things:  ipshift status
"""


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="ipshift-gui", description="IPShift Pro: graphical dashboard")
    p.add_argument("--demo", action="store_true",
                   help="use a private simulated daemon: needs no root and touches no real network")
    p.add_argument("--selftest", action="store_true",
                   help="run a scripted check of the window against the simulator, then exit (0 = all passed)")
    p.add_argument("--screenshots", metavar="DIR", help="with --selftest: save a picture of every page into DIR")
    p.add_argument("--socket", metavar="PATH", help="the daemon's socket (default: found automatically)")
    p.add_argument("--version", action="store_true", help="print the version and exit")
    return p


def parse_args(argv=None) -> argparse.Namespace:
    return build_parser().parse_args(argv)


def build(app, socket_path=None, *, demo: bool = False):
    """The window with everything wired to a daemon: returns (window, bridge, model, actions)."""
    from ..ipc.client import Client
    from .actions import Actions
    from .model import AppModel
    from .qtbridge import Bridge
    from .window import MainWindow

    model = AppModel()
    bridge = Bridge(lambda: Client(socket_path))
    actions = Actions(bridge.link, model)
    window = MainWindow(bridge, model, actions, demo=demo)
    return window, bridge, model, actions


def main(argv=None) -> int:
    args = parse_args(argv)
    if args.version:
        print(f"ipshift-gui {__version__}")
        return 0
    if not qt_available():
        sys.stderr.write(MISSING_QT)
        return 2
    if args.selftest:
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")      # no display needed

    from PySide6.QtCore import QTimer
    from PySide6.QtWidgets import QApplication

    from ..logging_setup import setup_logging
    from . import theme

    setup_logging("WARNING", None, redact=True)
    app = QApplication.instance() or QApplication([sys.argv[0]])
    app.setApplicationName("IPShift Pro")
    app.setDesktopFileName("ipshift-pro")                           # ties the window to ipshift-pro.desktop (icon, grouping)
    app.setStyle("Fusion")                                          # the style sheet looks the same everywhere
    app.setStyleSheet(theme.qss())

    demo = None
    socket_path = args.socket
    if args.demo or args.selftest:
        from .demo import DemoDaemon
        demo = DemoDaemon(speed=0.0 if args.selftest else 1.0)
        socket_path = str(demo.start())

    window = bridge = None
    try:
        window, bridge, model, actions = build(app, socket_path, demo=demo is not None)
        window.show()
        bridge.start()
        if args.selftest:
            from . import selftest
            return selftest.run(app, window, model, actions, shots=args.screenshots)
        # Let Ctrl+C in the terminal close the window cleanly: Python only sees the signal when it runs,
        # so a timer wakes it up now and then.
        signal.signal(signal.SIGINT, lambda *_: app.quit())
        signal.signal(signal.SIGTERM, lambda *_: app.quit())
        wake = QTimer()
        wake.start(500)
        wake.timeout.connect(lambda: None)
        return app.exec()
    finally:
        if bridge is not None:
            bridge.close()
        if demo is not None:
            demo.stop()


if __name__ == "__main__":
    sys.exit(main())
