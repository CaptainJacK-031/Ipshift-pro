"""The IPShift Pro desktop app (PySide6).

The window is a client of the daemon, exactly like the CLI: it holds no privileges and talks to
``ipshiftd`` over the same socket.  The code is layered so that nearly all of it can be tested
without Qt or a display:

    views.py, leakviews.py, tables.py, settings_schema.py, link.py, demo.py     no Qt at all
    theme.py, qtbridge.py, widgets.py, dialogs.py, page_*.py, window.py, app.py  PySide6, kept thin
"""
from __future__ import annotations

import importlib.util


def qt_available() -> bool:
    """True when PySide6 can be imported (it is an optional extra: ``pip install ipshift-pro[gui]``)."""
    try:
        return importlib.util.find_spec("PySide6") is not None
    except (ImportError, ValueError):
        return False
