"""``ipshift-gui --selftest``: drive the real window through a scripted run against the simulator.

It presses the same buttons a person would (``button.click()`` does nothing on a disabled button, so
the enabling rules are tested too), waits for the daemon's answers, and checks what the pages show.
Nothing real is touched: the daemon is the in-process simulator.  The questions the window would ask
are answered by the script.  Exit status 0 means every check passed.
"""
from __future__ import annotations

import time
import traceback
from pathlib import Path

from . import dialogs
from .settings_schema import find

SIM_REAL_IP = "192.0.2.77"                       # the made-up real address of the simulator


class Run:
    def __init__(self, app, window, model, actions, shots=None, echo=print):
        self.app, self.win, self.model, self.actions = app, window, model, actions
        self.shots = Path(shots) if shots else None
        self.echo = echo
        self.results: list[tuple[str, bool, str]] = []

    # ---- plumbing ---------------------------------------------------------------------------------------------
    def pump(self, until=None, limit: float = 15.0) -> bool:
        """Let Qt deliver events until ``until()`` is true (or ``limit`` seconds pass)."""
        deadline = time.monotonic() + limit
        while True:
            self.app.processEvents()
            if until is not None and until():
                return True
            if time.monotonic() >= deadline:
                return until is None
            time.sleep(0.01)

    def check(self, name: str, ok: bool, detail: str = "") -> bool:
        ok = bool(ok)
        self.results.append((name, ok, detail))
        self.echo(f"  [{'ok' if ok else 'FAIL'}] {name}" + ("" if ok or not detail else f"   ({detail})"))
        return ok

    def wait_for(self, name: str, cond, limit: float = 15.0, detail=lambda: "") -> bool:
        ok = self.pump(cond, limit)
        return self.check(name, ok, "" if ok else "timed out: " + str(detail()))

    def section(self, title: str) -> None:
        self.echo(title)

    def go(self, page: str) -> None:
        self.win.select_page(page)
        self.pump(limit=0.05)

    def shot(self, name: str) -> None:
        if self.shots is None:
            return
        self.shots.mkdir(parents=True, exist_ok=True)
        self.win.grab().save(str(self.shots / f"{name}.png"))

    # ---- the script --------------------------------------------------------------------------------------------
    def run(self) -> int:
        saved = (dialogs.confirm, dialogs.ask_stop, dialogs.inform)
        self.answers = {"confirm": True, "stop": "block"}
        dialogs.confirm = lambda *a, **k: self.answers["confirm"]
        dialogs.ask_stop = lambda parent, options: self.answers["stop"] if any(
            o.key == self.answers["stop"] for o in options) else None
        dialogs.inform = lambda *a, **k: None
        try:
            for step in (self.connect, self.interval_floor, self.rotation, self.history, self.privacy,
                         self.profiles, self.settings, self.stopping, self.lookup, self.finish):
                try:
                    step()
                except Exception as e:                      # a crash in one step must not hide the others
                    self.check(step.__name__ + " ran without an error", False,
                               f"{type(e).__name__}: {e}\n{traceback.format_exc(limit=4)}")
        finally:
            dialogs.confirm, dialogs.ask_stop, dialogs.inform = saved
        failed = [r for r in self.results if not r[1]]
        self.echo(f"\n{len(self.results) - len(failed)} of {len(self.results)} checks passed"
                  + ("" if not failed else "; failed: " + ", ".join(r[0] for r in failed)))
        return 1 if failed else 0

    def connect(self) -> None:
        self.section("Connecting to the daemon")
        d, m = self.win.dashboard, self.model
        self.wait_for("the window reaches the daemon", lambda: m.link_up and m.status is not None,
                      detail=lambda: m.link_error)
        self.wait_for("the profiles arrive", lambda: bool(m.profile_rows()))
        title = d.banner.title.text()
        self.check("the banner shows a protection level", title in views_titles(), title)
        self.check("the daemon line and the simulation notice are shown", "SIMULATION" in d.banner.extra.text(),
                   d.banner.extra.text())
        self.shot("dashboard-start")

    def interval_floor(self) -> None:
        self.section("Rotation interval")
        spin = self.win.dashboard.interval
        self.check("the smallest interval is 1 second", spin.minimum() == 1.0, str(spin.minimum()))
        spin.setValue(0.2)
        self.check("an interval below 1 second is not accepted", spin.value() >= 1.0, str(spin.value()))
        spin.setValue(1.0)
        self.check("1 second can be chosen", spin.value() == 1.0, str(spin.value()))

    def rotation(self) -> None:
        self.section("Start and rotate")
        d, m = self.win.dashboard, self.model
        self.go("Dashboard")
        self.check("Start is enabled", d.start_button.isEnabled())
        d.start_button.click()
        self.wait_for("the VPN connects and the banner says PROTECTED",
                      lambda: m.level == "protected" and d.banner.title.text() == "PROTECTED",
                      limit=40, detail=lambda: f"{m.level} / {d.banner.title.text()}")
        self.check("the rotation is running and Start is disabled",
                   ((m.status or {}).get("rotation") or {}).get("running") and not d.start_button.isEnabled())
        self.check("Stop is enabled", d.stop_button.isEnabled())
        self.check("the public address is shown", d.public_value.text() not in ("-", "hidden", "none", "..."),
                   d.public_value.text())
        self.check("the kill switch shows ARMED", d.ks_badge.text() == "ARMED", d.ks_badge.text())
        self.wait_for("the address changes at the 1-second interval (two changes)",
                      lambda: (((m.status or {}).get("rotation") or {}).get("ok", 0) >= 2),
                      limit=40, detail=lambda: str((m.status or {}).get("rotation")))
        self.check("the countdown is shown while rotating", d.countdown.text().startswith("next change"),
                   d.countdown.text())
        self.shot("dashboard-rotating")

    def history(self) -> None:
        self.section("History")
        h = self.win.history
        self.go("History")
        self.wait_for("rotations appear in the table", lambda: h.rotations_model.rowCount() > 0)
        self.check("at least one row is a change of address",
                   any(r.status == "success" for r in h.rotations_model.rows))
        self.shot("history")

    def privacy(self) -> None:
        self.section("Privacy check")
        p = self.win.privacy
        self.go("Privacy")
        self.check("Run test is enabled", p.run_full.isEnabled())
        p.run_full.click()
        done = ("PASS", "WARNING", "FAIL", "LEAK", "NOT TESTED")
        self.wait_for("the DNS leak test shows a result", lambda: p.dns_tile.word.text() in done, limit=60,
                      detail=lambda: p.dns_tile.word.text())
        self.check("the IPv6 leak test shows a result", p.ipv6_tile.word.text() in done, p.ipv6_tile.word.text())
        self.check("a grade is shown", p.grade.text() in ("A", "B", "C", "D", "F"), p.grade.text())
        self.check("every check has a tile", len(p._tiles) >= 8, str(len(p._tiles)))
        self.shot("privacy")

    def profiles(self) -> None:
        self.section("Profiles")
        pr = self.win.profiles
        self.go("Profiles")
        self.check("the profiles are listed", pr.model.rowCount() >= 2, str(pr.model.rowCount()))
        self.check("the Import button is there and enabled", pr.import_button.isEnabled())
        pr.view.selectRow(0)
        self.pump(limit=0.05)
        self.check("selecting a row enables Remove", pr.remove_button.isEnabled())
        self.shot("profiles")

    def settings(self) -> None:
        self.section("Settings")
        s, m = self.win.settings, self.model
        self.go("Settings")
        self.wait_for("the settings load", lambda: s.control("rotation.jitter_pct").isEnabled())
        cfg = m.config["config"]
        self.check("the interval shown is the daemon's", abs(s.value("rotation.interval") - cfg["rotation"]["interval"]) < 0.05,
                   f"{s.value('rotation.interval')} vs {cfg['rotation']['interval']}")
        before = cfg["rotation"]["jitter_pct"]
        wanted = 20.0 if before != 20.0 else 10.0
        s.control("rotation.jitter_pct").setValue(wanted)
        self.wait_for("a harmless change reaches the daemon",
                      lambda: m.config["config"]["rotation"]["jitter_pct"] == wanted, limit=10,
                      detail=lambda: str(m.config["config"]["rotation"]["jitter_pct"]))
        # A setting whose risky value is not the one it has now: switching it needs a confirmation.
        key = next(k for k in ("killswitch.allow_lan", "killswitch.allow_forward", "killswitch.release_on_exit")
                   if cfg[k.split(".")[0]][k.split(".")[1]] is not find(k).risky_value)
        section, name = key.split(".")
        self.answers["confirm"] = False
        box = s.control(key)
        was = box.isChecked()
        box.setChecked(find(key).risky_value)
        self.pump(limit=0.3)
        self.check("a risky change that is not confirmed is put back", box.isChecked() == was, key)
        self.check("and the daemon never heard of it", m.config["config"][section][name] == was, key)
        self.answers["confirm"] = True
        self.shot("settings")

    def stopping(self) -> None:
        self.section("Stop")
        d, m = self.win.dashboard, self.model
        self.go("Dashboard")
        self.answers["stop"] = "block"
        d.stop_button.click()
        self.wait_for("'disconnect but keep blocking' stops the rotation and leaves the firewall up",
                      lambda: m.level == "blocked" and not ((m.status or {}).get("rotation") or {}).get("running"),
                      limit=40, detail=lambda: m.level)
        self.check("the banner says BLOCKED", d.banner.title.text() == "BLOCKED", d.banner.title.text())
        self.check("the kill switch still shows ARMED", d.ks_badge.text() == "ARMED", d.ks_badge.text())
        self.check("Release is enabled and Arm is not", d.release_button.isEnabled() and not d.arm_button.isEnabled())
        d.stop_button.click()
        self.wait_for("Stop then restores normal networking",
                      lambda: m.level == "unprotected", limit=40, detail=lambda: m.level)
        self.check("the banner says UNPROTECTED", d.banner.title.text() == "UNPROTECTED", d.banner.title.text())
        self.shot("dashboard-stopped")

    def lookup(self) -> None:
        self.section("Real address")
        d, m = self.win.dashboard, self.model
        self.check("the real address is hidden until asked for", d.public_value.text() == "hidden",
                   d.public_value.text())
        self.check("'Look up my real address' is offered", not d.lookup_button.isHidden())
        d.lookup_button.click()
        self.wait_for("the real address is shown after the lookup", lambda: d.public_value.text() == SIM_REAL_IP,
                      limit=20, detail=lambda: d.public_value.text())

    def finish(self) -> None:
        self.section("Closing")
        bridge = self.win.bridge
        self.win.close()
        self.pump(limit=0.1)
        self.check("closing the window stops its connection to the daemon", bridge.link.closed)


def views_titles() -> set[str]:
    from .views import PROTECTION
    return {t for t, _ in PROTECTION.values()}


def run(app, window, model, actions, shots=None) -> int:
    print("IPShift GUI self-test (simulated daemon; nothing real is touched)")
    return Run(app, window, model, actions, shots).run()
