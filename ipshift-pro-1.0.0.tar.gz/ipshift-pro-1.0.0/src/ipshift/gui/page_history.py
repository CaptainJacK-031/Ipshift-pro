"""The History page: every rotation the daemon recorded, and the alerts stored with it."""
from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtWidgets import QComboBox, QTabWidget, QVBoxLayout, QWidget

from . import tables
from .widgets import TableModel, button, hbox, label, make_table, set_table_rows, set_text


class HistoryPage(QWidget):
    filter_changed = Signal()
    export_requested = Signal()
    clear_requested = Signal()

    def __init__(self):
        super().__init__()
        self.setObjectName("page")
        self.filter = QComboBox()
        for key, text in tables.HISTORY_FILTERS:
            self.filter.addItem(text, key)
        self.filter.currentIndexChanged.connect(lambda *_: self.filter_changed.emit())
        self.stats = label("", role="muted", wrap=True)
        self.export_button = button("Export CSV...", tip="Save the whole history as a file only you can read",
                                    on_click=self.export_requested.emit)
        self.clear_button = button("Clear history", role="danger", on_click=self.clear_requested.emit)

        self.rotations_model = TableModel(tables.HISTORY_COLUMNS, tone_column=1)
        self.rotations_view = make_table(self.rotations_model)
        self.events_model = TableModel(tables.EVENT_COLUMNS, tone_column=1)
        self.events_view = make_table(self.events_model)
        self.tabs = QTabWidget()
        self.tabs.addTab(self.rotations_view, "Rotations")
        self.tabs.addTab(self.events_view, "Alerts")
        self.tabs.currentChanged.connect(lambda i: self.filter.setEnabled(i == 0))

        lay = QVBoxLayout(self)
        lay.setContentsMargins(22, 18, 22, 22)
        lay.setSpacing(12)
        lay.addWidget(label("Rotation history", role="h1"))
        lay.addWidget(self.stats)
        lay.addLayout(hbox(label("Show", role="muted"), self.filter, None, self.export_button, self.clear_button))
        lay.addWidget(self.tabs, 1)
        lay.addWidget(label("The history is stored on this computer only, readable by root. "
                            "It can be switched off or shortened in Settings.", role="small", wrap=True))

    def current_filter(self) -> str:
        return str(self.filter.currentData() or "all")

    def update_view(self, rows, events, stats: str, can_export: bool) -> None:
        set_table_rows(self.rotations_view, self.rotations_model, rows)
        set_table_rows(self.events_view, self.events_model, events)
        set_text(self.stats, stats)
        self.export_button.setEnabled(can_export)
        self.clear_button.setEnabled(can_export or bool(events))
