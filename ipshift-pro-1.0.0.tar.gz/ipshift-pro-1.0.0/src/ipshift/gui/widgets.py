"""A small kit of widgets.  Every page is built from these, so the Qt calls are concentrated here.

Colour never appears in Python: a widget gets a ``tone`` (good / warn / bad / info / muted / plain) with
``set_tone`` and the style sheet in ``theme.py`` paints it.  Text that came from the daemon (profile
names, event messages, addresses) is always shown as *plain text*: a label that guesses "rich text"
would render markup that a server operator or a profile file put there.
"""
from __future__ import annotations

from PySide6.QtCore import QAbstractTableModel, QModelIndex, Qt, QTimer
from PySide6.QtGui import QBrush, QColor, QIcon, QPainter, QPixmap
from PySide6.QtWidgets import (QAbstractItemView, QFrame, QGridLayout, QHBoxLayout, QHeaderView, QLabel, QLayout,
                               QPushButton, QSizePolicy, QTableView, QVBoxLayout, QWidget)

from . import views
from .theme import PALETTE, tone_color


# ---- styling ------------------------------------------------------------------------------------------------
def set_prop(widget, name: str, value) -> None:
    """Set a dynamic property and apply the style sheet again (Qt does not do that by itself)."""
    if widget.property(name) == value:
        return
    widget.setProperty(name, value)
    style = widget.style()
    style.unpolish(widget)
    style.polish(widget)
    widget.update()


def set_tone(widget, tone: str) -> None:
    set_prop(widget, "tone", tone)


def set_text(lab, text: str) -> None:
    """Only touch the label when the text changed: no flicker, no needless layout work."""
    if lab.text() != text:
        lab.setText(text)


# ---- building blocks ----------------------------------------------------------------------------------------
def label(text: str = "", *, role: str | None = None, tone: str | None = None, wrap: bool = False,
          selectable: bool = False, pill: bool = False) -> QLabel:
    w = QLabel(text)
    w.setTextFormat(Qt.TextFormat.PlainText)
    if wrap:
        w.setWordWrap(True)
    if selectable:
        w.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
    if pill:
        w.setProperty("pill", "true")
        w.setAlignment(Qt.AlignmentFlag.AlignCenter)
        w.setSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed)
    if role:
        w.setProperty("role", role)
    if tone:
        w.setProperty("tone", tone)
    return w


def button(text: str, *, role: str | None = None, tip: str = "", on_click=None) -> QPushButton:
    b = QPushButton(text)
    if role:
        b.setProperty("role", role)
    if tip:
        b.setToolTip(tip)
    if on_click is not None:
        b.clicked.connect(lambda *_: on_click())
    return b


def separator() -> QFrame:
    line = QFrame()
    line.setObjectName("sep")
    line.setFixedHeight(1)
    return line


def _fill(layout, items) -> None:
    """Add widgets, layouts, ``None`` (a stretch), an int (a fixed gap) or ``(item, stretch)`` pairs."""
    for item in items:
        stretch = 0
        if isinstance(item, tuple):
            item, stretch = item
        if item is None:
            layout.addStretch(max(1, stretch))
        elif isinstance(item, int):
            layout.addSpacing(item)
        elif isinstance(item, QLayout):
            layout.addLayout(item, stretch)
        else:
            layout.addWidget(item, stretch)


def vbox(*items, margins=(0, 0, 0, 0), spacing: int = 8) -> QVBoxLayout:
    lay = QVBoxLayout()
    lay.setContentsMargins(*margins)
    lay.setSpacing(spacing)
    _fill(lay, items)
    return lay


def hbox(*items, margins=(0, 0, 0, 0), spacing: int = 8) -> QHBoxLayout:
    lay = QHBoxLayout()
    lay.setContentsMargins(*margins)
    lay.setSpacing(spacing)
    _fill(lay, items)
    return lay


def holder(layout, name: str | None = None) -> QWidget:
    """A plain widget that carries a layout."""
    w = QWidget()
    if name:
        w.setObjectName(name)
    w.setLayout(layout)
    return w


def clear_layout(layout) -> None:
    while layout.count():
        item = layout.takeAt(0)
        w = item.widget()
        if w is not None:
            w.setParent(None)
            w.deleteLater()
            continue
        sub = item.layout()
        if sub is not None:
            clear_layout(sub)


# ---- cards and rows -----------------------------------------------------------------------------------------
class Card(QFrame):
    """A titled panel."""

    def __init__(self, title: str = ""):
        super().__init__()
        self.setObjectName("card")
        self.body = QVBoxLayout(self)
        self.body.setContentsMargins(16, 14, 16, 16)
        self.body.setSpacing(8)
        if title:
            self.body.addWidget(label(title.upper(), role="title"))

    def add(self, *items) -> "Card":
        _fill(self.body, items)
        return self


class KeyValue(QWidget):
    """Fixed captions in one column, values in the other."""

    def __init__(self, keys, *, mono: bool = False):
        super().__init__()
        grid = QGridLayout(self)
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setHorizontalSpacing(14)
        grid.setVerticalSpacing(5)
        grid.setColumnStretch(1, 1)
        self._values: dict[str, QLabel] = {}
        for i, key in enumerate(keys):
            grid.addWidget(label(key, role="muted"), i, 0, Qt.AlignmentFlag.AlignTop)
            value = label("-", role="mono" if mono else None, selectable=True, wrap=True)
            grid.addWidget(value, i, 1)
            self._values[key] = value

    def set(self, key: str, text: str, tone: str = views.PLAIN) -> None:
        value = self._values[key]
        set_text(value, text)
        set_tone(value, tone)

    def text(self, key: str) -> str:
        return self._values[key].text()


class RowList(QWidget):
    """A column of rows, rebuilt only when its content changes (so a refresh every two seconds never flickers)."""

    def __init__(self, build, empty: str = "", spacing: int = 8):
        super().__init__()
        self._build, self._empty = build, empty
        self._shown = None
        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(0, 0, 0, 0)
        self._layout.setSpacing(spacing)

    def set_items(self, items) -> None:
        items = tuple(items)
        if items == self._shown:
            return
        self._shown = items
        clear_layout(self._layout)
        if not items and self._empty:
            self._layout.addWidget(label(self._empty, role="muted", wrap=True))
        for item in items:
            self._layout.addWidget(self._build(item))

    @property
    def count(self) -> int:
        return len(self._shown or ())


def build_alert(a: views.AlertRow) -> QWidget:
    box = QWidget()
    grid = QGridLayout(box)
    grid.setContentsMargins(0, 0, 0, 0)
    grid.setHorizontalSpacing(10)
    grid.setVerticalSpacing(1)
    grid.setColumnStretch(1, 1)
    grid.addWidget(label(a.time, role="small"), 0, 0, Qt.AlignmentFlag.AlignTop)
    grid.addWidget(label(a.text, tone=a.tone, wrap=True, selectable=True), 0, 1)
    if a.hint:
        grid.addWidget(label(a.hint, role="small", wrap=True), 1, 1)
    return box


def build_problem(p: views.Problem) -> QWidget:
    box = QWidget()
    grid = QGridLayout(box)
    grid.setContentsMargins(0, 0, 0, 0)
    grid.setHorizontalSpacing(8)
    grid.setVerticalSpacing(1)
    grid.setColumnStretch(1, 1)
    grid.addWidget(label("●", tone=p.tone), 0, 0, Qt.AlignmentFlag.AlignTop)
    grid.addWidget(label(p.text, tone=p.tone, wrap=True, selectable=True), 0, 1)
    if p.hint:
        grid.addWidget(label(p.hint, role="small", wrap=True), 1, 1)
    return box


def build_private_ip(p: views.PrivateIp) -> QWidget:
    box = QWidget()
    lay = hbox(label(p.ip, role="mono", selectable=True, tone=views.INFO if p.tunnel else None),
               label(p.iface, role="muted"), label(p.tags, role="small"), None, spacing=12)
    box.setLayout(lay)
    return box


class Banner(QFrame):
    """The big protection status at the top of the dashboard."""

    def __init__(self):
        super().__init__()
        self.setObjectName("banner")
        self.title = label("", role="h1")
        self.detail = label("", role="muted", wrap=True)
        self.extra = label("", role="small", wrap=True)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(18, 14, 18, 14)
        lay.setSpacing(2)
        for w in (self.title, self.detail, self.extra):
            lay.addWidget(w)

    def show_view(self, b: views.Banner, extra: str = "") -> None:
        set_text(self.title, b.title)
        set_text(self.detail, b.detail)
        set_text(self.extra, extra)
        self.extra.setVisible(bool(extra))
        set_tone(self.title, b.tone)
        set_prop(self, "tone", b.tone)


class TileCard(QFrame):
    """One leak-test result: a symbol, the name of the test, PASS / WARNING / FAIL, and what it found."""

    def __init__(self, *, big: bool = False):
        super().__init__()
        self.setObjectName("tile")
        self.tile_id = ""
        self.glyph = label("", role="h1" if big else "h2")
        self.title = label("", role="h1" if big else "h2")
        self.word = label("", pill=True)
        self.detail = label("", role="muted", wrap=True, selectable=True)
        self.hint = label("", role="small", wrap=True, selectable=True)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 12, 14, 12)
        lay.setSpacing(6)
        lay.addLayout(hbox(self.glyph, self.title, None, self.word, spacing=10))
        lay.addWidget(self.detail)
        lay.addWidget(self.hint)

    def show_tile(self, t) -> None:
        self.tile_id = t.id
        set_text(self.glyph, t.glyph)
        set_text(self.title, t.title)
        set_text(self.word, "LEAK" if t.leak else t.word)
        set_text(self.detail, t.detail)
        set_text(self.hint, ("How to fix it: " + t.hint) if t.hint else "")
        self.detail.setVisible(bool(t.detail))
        self.hint.setVisible(bool(t.hint))
        set_tone(self.glyph, t.tone)
        set_tone(self.word, t.tone)
        set_prop(self, "tone", t.tone)


class Toast(QWidget):
    """A message that shows up above the page for a few seconds (longer for an error).

    The outer widget only carries the margins, so that a hidden toast takes no room at all."""

    def __init__(self):
        super().__init__()
        self.frame = QFrame()
        self.frame.setObjectName("toast")
        self.text = label("", wrap=True, selectable=True)
        self.hint = label("", role="small", wrap=True)
        inner = QHBoxLayout(self.frame)
        inner.setContentsMargins(14, 10, 8, 10)
        inner.setSpacing(10)
        inner.addLayout(vbox(self.text, self.hint, spacing=2), 1)
        inner.addWidget(button("✕", role="link", tip="Dismiss", on_click=self.hide), 0, Qt.AlignmentFlag.AlignTop)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(22, 12, 22, 0)
        outer.addWidget(self.frame)
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self.hide)
        self.hide()

    def show_message(self, text: str, tone: str = views.INFO, hint: str = "", seconds: float | None = None) -> None:
        set_text(self.text, text)
        set_text(self.hint, hint)
        self.hint.setVisible(bool(hint))
        set_tone(self.text, tone)
        set_prop(self.frame, "tone", tone)
        self.show()
        self._timer.start(int((seconds if seconds is not None else (25.0 if tone == views.BAD else 8.0)) * 1000))


# ---- tables -------------------------------------------------------------------------------------------------
class TableModel(QAbstractTableModel):
    """Rows are the frozen dataclasses from ``tables``: ``cells()`` gives the text, ``tone`` the colour."""

    def __init__(self, columns, *, tone_column: int = -1, parent=None):
        super().__init__(parent)
        self._columns = tuple(columns)
        self._tone_column = tone_column
        self._rows: tuple = ()

    def set_rows(self, rows) -> bool:
        """Replace the rows; False (and no redraw) when nothing changed."""
        rows = tuple(rows)
        if rows == self._rows:
            return False
        self.beginResetModel()
        self._rows = rows
        self.endResetModel()
        return True

    def row_at(self, i: int):
        return self._rows[i] if 0 <= i < len(self._rows) else None

    @property
    def rows(self) -> tuple:
        return self._rows

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self._rows)

    def columnCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self._columns)

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if (role == Qt.ItemDataRole.DisplayRole and orientation == Qt.Orientation.Horizontal
                and 0 <= section < len(self._columns)):
            return self._columns[section]
        return None

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid() or not 0 <= index.row() < len(self._rows):
            return None
        row, col = self._rows[index.row()], index.column()
        if role in (Qt.ItemDataRole.DisplayRole, Qt.ItemDataRole.ToolTipRole):
            cells = row.cells()
            return cells[col] if 0 <= col < len(cells) else None
        if role == Qt.ItemDataRole.ForegroundRole and col == self._tone_column:
            tone = getattr(row, "tone", views.PLAIN)
            if tone != views.PLAIN:
                return QBrush(QColor(tone_color(tone)))
        return None


def make_table(model: TableModel) -> QTableView:
    view = QTableView()
    view.setModel(model)
    view.setAlternatingRowColors(True)
    view.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
    view.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
    view.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
    view.setShowGrid(False)
    view.setWordWrap(False)
    view.verticalHeader().setVisible(False)
    header = view.horizontalHeader()
    last = model.columnCount() - 1
    for i in range(last):
        header.setSectionResizeMode(i, QHeaderView.ResizeMode.ResizeToContents)
    header.setSectionResizeMode(last, QHeaderView.ResizeMode.Stretch)
    return view


def selected_row(view: QTableView, model: TableModel):
    selection = view.selectionModel()
    indexes = selection.selectedIndexes() if selection is not None else []
    return model.row_at(indexes[0].row()) if indexes else None


def set_table_rows(view: QTableView, model: TableModel, rows, key=None) -> bool:
    """Replace the rows but keep the scroll position and, when ``key`` is given, the selected row."""
    bar = view.verticalScrollBar()
    position = bar.value()
    chosen = None
    if key is not None:
        current = selected_row(view, model)
        chosen = key(current) if current is not None else None
    if not model.set_rows(rows):
        return False
    bar.setValue(position)
    if chosen is not None:
        for i, row in enumerate(model.rows):
            if key(row) == chosen:
                view.selectRow(i)
                break
    return True


# ---- icons --------------------------------------------------------------------------------------------------
_ICONS: dict[str, QIcon] = {}


def status_icon(tone: str) -> QIcon:
    """A ring in the colour of the protection level (window and tray icon)."""
    icon = _ICONS.get(tone)
    if icon is None:
        size = 64
        pixmap = QPixmap(size, size)
        pixmap.fill(Qt.GlobalColor.transparent)
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QBrush(QColor(tone_color(tone))))
        painter.drawEllipse(4, 4, size - 8, size - 8)
        painter.setBrush(QBrush(QColor(PALETTE["bg"])))
        painter.drawEllipse(22, 22, size - 44, size - 44)
        painter.end()
        icon = _ICONS[tone] = QIcon(pixmap)
    return icon
