"""The one place where the link's threads meet Qt.

``DaemonLink`` calls its listener from background threads.  A Qt widget may only be touched from the
GUI thread, so every call is turned into a signal here.  The window connects to these signals with a
*queued* connection, which makes Qt deliver each one later, in the GUI thread, whichever thread sent it.
"""
from __future__ import annotations

from PySide6.QtCore import QObject, Signal

from ..ipc.client import Client
from .link import DaemonLink, Listener, Timing


class _Forward(Listener):
    """Runs in the link's threads: does nothing but emit."""

    def __init__(self, bridge: "Bridge"):
        self._bridge = bridge

    def on_link(self, up, error, hint):
        self._bridge.link_changed.emit(bool(up), str(error or ""), str(hint or ""))

    def on_status(self, status):
        self._bridge.status_received.emit(status)

    def on_event(self, event):
        self._bridge.event_received.emit(event)

    def on_data(self, name, data):
        self._bridge.data_received.emit(str(name), data)

    def on_busy(self, busy):
        self._bridge.busy_changed.emit(frozenset(busy))

    def on_result(self, result):
        self._bridge.result_ready.emit(result)


class Bridge(QObject):
    link_changed = Signal(bool, str, str)         # up, error text, hint
    status_received = Signal(object)              # dict
    event_received = Signal(object)               # dict
    data_received = Signal(str, object)           # "profiles" | "history" | "report", dict
    busy_changed = Signal(object)                 # frozenset of command names
    result_ready = Signal(object)                 # link.Result

    def __init__(self, client_factory=Client, *, timing: Timing | None = None, parent=None):
        super().__init__(parent)
        self.link = DaemonLink(_Forward(self), client_factory, timing=timing)

    def start(self) -> None:
        self.link.start()

    def close(self) -> None:
        self.link.close()
