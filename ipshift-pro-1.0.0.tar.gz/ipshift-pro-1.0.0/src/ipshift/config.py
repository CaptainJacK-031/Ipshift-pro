"""Configuration: typed sections, validation, dotted get/set, atomic JSON save.

Design notes
------------
* The 1-second rotation floor is enforced here (``validate``) *and* again in the
  scheduler, so no entry point (file edit, CLI, GUI, RPC) can bypass it.
* Defaults are privacy-first: kill switch on, LAN blocked, no real-IP baseline
  probe, history masked/pruned, IPv6 disabled on physical interfaces.
"""
from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass, field, fields, asdict
from pathlib import Path
from urllib.parse import urlsplit

from .errors import ConfigError
from .sysutil import atomic_write, parse_ip

MIN_INTERVAL = 1.0
STRATEGIES = ("diverse", "round-robin", "random", "lru")
LOG_LEVELS = ("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL")

DEFAULT_ECHO_V4 = [
    "https://api.ipify.org",
    "https://ipv4.icanhazip.com",
    "https://checkip.amazonaws.com",
    "https://v4.ident.me",
]
DEFAULT_ECHO_V6 = [
    "https://api6.ipify.org",
    "https://ipv6.icanhazip.com",
    "https://v6.ident.me",
]

_IFACE_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_.-]{0,14}$")
_IFACE_PATTERN_RE = re.compile(r"^[A-Za-z0-9_.-]{1,14}\*?$")
_GROUP_RE = re.compile(r"^[a-z_][a-z0-9_-]{0,31}$")


@dataclass
class RotationConfig:
    interval: float = 30.0            # seconds between rotation starts (>= 1)
    strategy: str = "diverse"         # diverse | round-robin | random | lru
    jitter_pct: float = 0.0           # +/- percent randomisation of the interval
    tiers: list[str] = field(default_factory=list)      # restrict to free/paid/self-hosted
    profiles: list[str] = field(default_factory=list)   # restrict to these profile ids/names
    require_change: bool = True       # a rotation that yields the same exit IP counts as failed
    max_failures: int = 3             # consecutive failures before a critical alert
    backoff_max: float = 60.0         # cap for the retry back-off (seconds)


@dataclass
class VpnConfig:
    interface: str = "ipshift0"
    connect_timeout: float = 30.0
    verify_timeout: float = 20.0
    auto_reconnect: bool = True
    reconnect_on_network_change: bool = True
    fast_switch: bool = True          # WireGuard peer hot-swap when profiles are compatible
    pin_endpoints: bool = True        # resolve server names without leaking them to the ISP
    allow_plain_bootstrap_dns: bool = False
    bootstrap_doh: list[str] = field(
        default_factory=lambda: ["https://9.9.9.9/dns-query", "https://149.112.112.112/dns-query"])
    mtu: int = 0                      # 0 = automatic; set 1280-1420 on lossy mobile hotspots
    wg_keepalive: int = 25            # keeps NAT mappings alive on mobile networks
    openvpn_bin: str = "openvpn"
    openvpn_user: str = "nobody"      # OpenVPN drops root after set-up; "" keeps it root
    wg_bin: str = "wg"
    ip_bin: str = "ip"


@dataclass
class KillSwitchConfig:
    enabled: bool = True              # arm the kill switch before any tunnel is brought up
    # Always-on lockdown: block everything the moment the daemon starts.  Off by
    # default because on a remote (SSH) box it would cut your own session off.
    arm_on_start: bool = False
    release_on_exit: bool = False     # False = stay armed (fail-closed) when the daemon stops
    allow_lan: bool = False           # reach 10/8, 172.16/12, 192.168/16 outside the tunnel
    allow_ifaces: list[str] = field(default_factory=list)  # e.g. ["virbr*", "tun0"] lab networks
    allow_forward: bool = False       # let this host forward traffic (VM / hotspot sharing)
    allow_dhcp: bool = True           # DHCPv4 renewals on the physical link (needed on Wi-Fi/hotspots)
    log_drops: bool = False
    nft_bin: str = "nft"


@dataclass
class DnsConfig:
    manage: bool = True
    servers: list[str] = field(default_factory=list)       # forced servers (override VPN DNS)
    fallback: list[str] = field(default_factory=lambda: ["9.9.9.9", "149.112.112.112"])
    use_vpn_pushed: bool = True


@dataclass
class PrivacyConfig:
    ip_echo_v4: list[str] = field(default_factory=lambda: list(DEFAULT_ECHO_V4))
    ip_echo_v6: list[str] = field(default_factory=lambda: list(DEFAULT_ECHO_V6))
    quorum: int = 2                   # independent echo services that must agree
    http_timeout: float = 6.0
    baseline: bool = False            # contact echo services WITHOUT the VPN to learn the real IP
    check_ipv6: bool = True
    disable_ipv6_on_physical: bool = True
    history: bool = True
    history_retention_days: int = 30
    history_max_rows: int = 200_000   # newest rotations kept; a 1-second rotation writes ~86,000 rows a day
    mask_ips_in_history: bool = False
    redact_logs: bool = True


@dataclass
class DaemonConfig:
    group: str = "ipshift"
    allowed_uids: list[int] = field(default_factory=list)
    monitor_interval: float = 5.0
    ip_refresh_interval: float = 20.0
    log_level: str = "INFO"


_SECTIONS = {
    "rotation": RotationConfig,
    "vpn": VpnConfig,
    "killswitch": KillSwitchConfig,
    "dns": DnsConfig,
    "privacy": PrivacyConfig,
    "daemon": DaemonConfig,
}

_TRUE = {"1", "true", "yes", "on", "y"}
_FALSE = {"0", "false", "no", "off", "n"}


def _coerce(value, ann: str, where: str):
    try:
        if ann == "bool":
            if isinstance(value, bool):
                return value
            if isinstance(value, str) and value.strip().lower() in _TRUE:
                return True
            if isinstance(value, str) and value.strip().lower() in _FALSE:
                return False
            raise ValueError
        if ann == "int":
            if isinstance(value, bool) or (isinstance(value, float) and not value.is_integer()):
                raise ValueError
            return int(value)
        if ann == "float":
            if isinstance(value, bool):
                raise ValueError
            return float(value)
        if ann == "str":
            if not isinstance(value, str):
                raise ValueError
            return value
        if ann in ("list[str]", "list[int]"):
            if isinstance(value, str):
                value = [p.strip() for p in value.split(",") if p.strip()]
            if not isinstance(value, (list, tuple)):
                raise ValueError
            return [str(v) for v in value] if ann == "list[str]" else [int(v) for v in value]
    except (ValueError, TypeError):
        raise ConfigError(f"{where}: expected {ann}, got {value!r}") from None
    raise ConfigError(f"{where}: unsupported type {ann}")


def _is_loopback_host(host: str | None) -> bool:
    return host in ("127.0.0.1", "localhost", "::1")


@dataclass
class Config:
    rotation: RotationConfig = field(default_factory=RotationConfig)
    vpn: VpnConfig = field(default_factory=VpnConfig)
    killswitch: KillSwitchConfig = field(default_factory=KillSwitchConfig)
    dns: DnsConfig = field(default_factory=DnsConfig)
    privacy: PrivacyConfig = field(default_factory=PrivacyConfig)
    daemon: DaemonConfig = field(default_factory=DaemonConfig)
    warnings: list[str] = field(default_factory=list, repr=False, compare=False)

    # ---- (de)serialisation -------------------------------------------------
    def to_dict(self) -> dict:
        return {name: asdict(getattr(self, name)) for name in _SECTIONS}

    @classmethod
    def from_dict(cls, data: dict) -> "Config":
        if not isinstance(data, dict):
            raise ConfigError("config root must be a JSON object")
        cfg = cls()
        for sec_name, sec_data in data.items():
            if sec_name not in _SECTIONS:
                cfg.warnings.append(f"unknown section ignored: {sec_name}")
                continue
            if not isinstance(sec_data, dict):
                raise ConfigError(f"{sec_name}: must be an object")
            sect = getattr(cfg, sec_name)
            ann = {f.name: f.type for f in fields(sect)}
            for key, val in sec_data.items():
                if key not in ann:
                    cfg.warnings.append(f"unknown key ignored: {sec_name}.{key}")
                    continue
                setattr(sect, key, _coerce(val, ann[key], f"{sec_name}.{key}"))
        cfg.validate()
        return cfg

    @classmethod
    def load(cls, path: Path) -> "Config":
        path = Path(path)
        if not path.exists():
            return cls()
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as e:
            raise ConfigError(f"cannot read {path}: {e}") from None
        return cls.from_dict(raw)

    def save(self, path: Path) -> None:
        # No secrets live in the config, so it is world-readable (0644): the
        # unprivileged GUI/CLI may show it.
        atomic_write(Path(path), json.dumps(self.to_dict(), indent=2, sort_keys=True) + "\n", 0o644)

    @staticmethod
    def section_names() -> tuple[str, ...]:
        return tuple(_SECTIONS)

    def update_from(self, other: "Config", *, skip: tuple[str, ...] = ()) -> list[str]:
        """Copy values from ``other`` into this object's *existing* section objects (running
        components hold references to them).  Returns the dotted keys that changed."""
        changed: list[str] = []
        for sec in _SECTIONS:
            mine, theirs = getattr(self, sec), getattr(other, sec)
            for f in fields(mine):
                key = f"{sec}.{f.name}"
                if key in skip:
                    continue
                new = getattr(theirs, f.name)
                if getattr(mine, f.name) != new:
                    setattr(mine, f.name, list(new) if isinstance(new, list) else new)
                    changed.append(key)
        self.warnings = list(other.warnings)
        return changed

    # ---- dotted access -----------------------------------------------------
    @staticmethod
    def _split(path: str) -> tuple[str, str]:
        if path.count(".") != 1:
            raise ConfigError(f"expected <section>.<key>, got {path!r}")
        return tuple(path.split("."))  # type: ignore[return-value]

    def _locate(self, path: str):
        sec, key = self._split(path)
        if sec not in _SECTIONS:
            raise ConfigError(f"unknown section {sec!r} (have: {', '.join(_SECTIONS)})")
        sect = getattr(self, sec)
        ann = {f.name: f.type for f in fields(sect)}
        if key not in ann:
            raise ConfigError(f"unknown key {path!r} (have: {', '.join(ann)})")
        return sect, key, ann[key]

    def get(self, path: str):
        sect, key, _ = self._locate(path)
        return getattr(sect, key)

    def set(self, path: str, raw):
        sect, key, ann = self._locate(path)
        new = _coerce(raw, ann, path)
        old = getattr(sect, key)
        setattr(sect, key, new)
        try:
            self.validate()
        except ConfigError:
            setattr(sect, key, old)
            raise
        return new

    # ---- validation --------------------------------------------------------
    def validate(self) -> None:
        problems: list[str] = []
        r, v, k, d, p, dm = (self.rotation, self.vpn, self.killswitch, self.dns,
                             self.privacy, self.daemon)

        def finite(name: str, val: float) -> bool:
            if not math.isfinite(val):
                problems.append(f"{name} must be a finite number")
                return False
            return True

        if finite("rotation.interval", r.interval) and not (MIN_INTERVAL <= r.interval <= 86400):
            problems.append(f"rotation.interval must be between {MIN_INTERVAL:g} and 86400 seconds")
        if r.strategy not in STRATEGIES:
            problems.append(f"rotation.strategy must be one of {', '.join(STRATEGIES)}")
        if finite("rotation.jitter_pct", r.jitter_pct) and not (0 <= r.jitter_pct <= 100):
            problems.append("rotation.jitter_pct must be between 0 and 100")
        if r.max_failures < 1:
            problems.append("rotation.max_failures must be >= 1")
        if finite("rotation.backoff_max", r.backoff_max) and r.backoff_max < 1:
            problems.append("rotation.backoff_max must be >= 1")
        for t in r.tiers:
            if t not in ("free", "paid", "self-hosted", "unknown"):
                problems.append(f"rotation.tiers: unknown tier {t!r}")

        if not _IFACE_RE.match(v.interface):
            problems.append("vpn.interface must be a valid interface name (<= 15 chars)")
        if v.openvpn_user and not _GROUP_RE.match(v.openvpn_user):
            problems.append("vpn.openvpn_user must be a valid user name (or empty to stay root)")
        for name in ("connect_timeout", "verify_timeout"):
            val = getattr(v, name)
            if finite(f"vpn.{name}", val) and not (3 <= val <= 300):
                problems.append(f"vpn.{name} must be between 3 and 300 seconds")
        if v.mtu != 0 and not (1280 <= v.mtu <= 1500):
            problems.append("vpn.mtu must be 0 (auto) or between 1280 and 1500")
        if not (0 <= v.wg_keepalive <= 600):
            problems.append("vpn.wg_keepalive must be between 0 and 600")
        for u in v.bootstrap_doh:
            if not u.startswith("https://"):
                problems.append(f"vpn.bootstrap_doh must be https:// URLs, got {u!r}")

        for pat in k.allow_ifaces:
            if not _IFACE_PATTERN_RE.match(pat):
                problems.append(f"killswitch.allow_ifaces: bad interface pattern {pat!r} "
                                "(letters/digits/_.- with an optional trailing *)")

        for name in ("servers", "fallback"):
            for s in getattr(d, name):
                if parse_ip(s) is None:
                    problems.append(f"dns.{name}: {s!r} is not an IP address")

        for name in ("ip_echo_v4", "ip_echo_v6"):
            for u in getattr(p, name):
                try:
                    parts = urlsplit(u)
                except ValueError:
                    problems.append(f"privacy.{name}: bad URL {u!r}")
                    continue
                ok = parts.scheme == "https" or (parts.scheme == "http" and _is_loopback_host(parts.hostname))
                if not ok or not parts.hostname:
                    problems.append(f"privacy.{name}: {u!r} must be https:// (http only for loopback)")
        if not (1 <= p.quorum <= 5):
            problems.append("privacy.quorum must be between 1 and 5")
        if finite("privacy.http_timeout", p.http_timeout) and not (1 <= p.http_timeout <= 60):
            problems.append("privacy.http_timeout must be between 1 and 60 seconds")
        if not (1 <= p.history_retention_days <= 3650):
            problems.append("privacy.history_retention_days must be between 1 and 3650 "
                            "(disable history entirely with privacy.history=false)")
        if not (1000 <= p.history_max_rows <= 50_000_000):
            problems.append("privacy.history_max_rows must be between 1000 and 50000000")

        if not _GROUP_RE.match(dm.group):
            problems.append("daemon.group is not a valid group name")
        if any(u < 0 for u in dm.allowed_uids):
            problems.append("daemon.allowed_uids must be >= 0")
        if finite("daemon.monitor_interval", dm.monitor_interval) and not (1 <= dm.monitor_interval <= 300):
            problems.append("daemon.monitor_interval must be between 1 and 300 seconds")
        if finite("daemon.ip_refresh_interval", dm.ip_refresh_interval) and dm.ip_refresh_interval < 5:
            problems.append("daemon.ip_refresh_interval must be >= 5 seconds")
        if dm.log_level.upper() not in LOG_LEVELS:
            problems.append(f"daemon.log_level must be one of {', '.join(LOG_LEVELS)}")

        if problems:
            raise ConfigError("; ".join(problems))
