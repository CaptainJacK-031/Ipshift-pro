"""The daemon's Unix-socket server.

Who may talk to the daemon is decided three times, so that one mistake is not enough:

1. the socket lives in a directory that only root and the ``ipshift`` group can enter,
   and is itself mode 0660 root:ipshift (0600 when not running as root);
2. every connection's real identity is read from the kernel (SO_PEERCRED) and checked
   against root / the daemon's own user / ``daemon.allowed_uids`` / the group;
3. every request is validated against the command table before it reaches the engine.

Membership of the group is equivalent to the right to control the machine's network (the
daemon can open and close the firewall for you), so give it only to people you trust.
"""
from __future__ import annotations

import grp
import logging
import os
import pwd
import queue
import socket
import struct
import threading
import time
from pathlib import Path

from .. import __version__
from ..errors import IPShiftError, ProtocolError
from ..events import LEVELS
from .protocol import (ADMIN, COMMANDS, MAX_REQUEST, READ, decode, encode, error_reply, ok_reply, validate)

log = logging.getLogger(__name__)

PEERCRED = struct.Struct("3i")                 # pid, uid, gid


class IpcServer:
    def __init__(self, engine, socket_path: str | Path, *, group: str = "ipshift", allowed_uids=(),
                 max_clients: int = 32, idle_timeout: float = 300.0, heartbeat: float = 10.0):
        self.engine = engine
        self.path = Path(socket_path)
        self.group = group
        self.allowed_uids = frozenset(int(u) for u in allowed_uids)
        self.max_clients = max_clients
        self.idle_timeout = idle_timeout
        self.heartbeat = heartbeat
        self._listener: socket.socket | None = None
        self._thread: threading.Thread | None = None
        self._stopping = threading.Event()
        self._lock = threading.Lock()
        self._conns: dict[int, socket.socket] = {}
        self._next = 0
        self._gid: int | None = None
        self._bound = False
        self.served = 0

    # ---- setup ----------------------------------------------------------------------------
    def _group_gid(self) -> int | None:
        try:
            return grp.getgrnam(self.group).gr_gid
        except KeyError:
            return None

    @staticmethod
    def _listening(path: Path) -> bool:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(1.0)
        try:
            s.connect(str(path))
            return True
        except OSError:
            return False
        finally:
            s.close()

    def start(self) -> None:
        root = os.geteuid() == 0
        self._gid = self._group_gid()
        d = self.path.parent
        d.mkdir(parents=True, exist_ok=True)
        if root and self._gid is not None:
            os.chown(d, 0, self._gid)
            os.chmod(d, 0o750)
        else:
            os.chmod(d, 0o700)
            if root:
                log.warning("group %r does not exist: only root can use the daemon "
                            "(create it with 'groupadd %s' and add your user to it)", self.group, self.group)
        if self.path.is_symlink() or self.path.exists():
            if self._listening(self.path):
                raise IPShiftError(f"another IPShift daemon is already listening on {self.path}")
            self.path.unlink()
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        old = os.umask(0o177)                     # born 0600: never reachable by anyone who should not
        try:
            sock.bind(str(self.path))
        finally:
            os.umask(old)
        if root and self._gid is not None:
            os.chown(self.path, 0, self._gid)
            os.chmod(self.path, 0o660)
        self._bound = True
        sock.listen(16)
        sock.settimeout(0.5)
        self._listener = sock
        self._stopping.clear()
        self._thread = threading.Thread(target=self._accept_loop, daemon=True, name="ipc-accept")
        self._thread.start()
        log.info("listening on %s", self.path)

    def stop(self) -> None:
        self._stopping.set()
        if self._thread:
            self._thread.join(3)
        if self._listener:
            try:
                self._listener.close()
            except OSError:
                pass
        with self._lock:
            conns = list(self._conns.values())
        for c in conns:
            try:
                c.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
        deadline = time.monotonic() + 3
        while time.monotonic() < deadline:
            with self._lock:
                if not self._conns:
                    break
            time.sleep(0.02)
        if self._bound:                          # never remove a socket that belongs to somebody else
            try:
                self.path.unlink()
            except OSError:
                pass
            self._bound = False
        self._listener = self._thread = None

    # ---- who may connect --------------------------------------------------------------------
    def authorized(self, uid: int, gid: int) -> bool:
        if uid == 0 or uid == os.geteuid():
            return True
        if self.allowed_uids:                     # an explicit allow-list narrows access further
            return uid in self.allowed_uids
        if self._gid is None:
            return False
        if gid == self._gid:
            return True
        try:
            name = pwd.getpwuid(uid).pw_name
            return self._gid in os.getgrouplist(name, gid)
        except (KeyError, OSError):
            return False

    # ---- serving --------------------------------------------------------------------------------
    def _accept_loop(self) -> None:
        assert self._listener is not None
        while not self._stopping.is_set():
            try:
                conn, _ = self._listener.accept()
            except socket.timeout:
                continue
            except OSError:
                if self._stopping.is_set():
                    return
                log.exception("accept failed")
                time.sleep(0.2)
                continue
            try:
                pid, uid, gid = PEERCRED.unpack(conn.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, PEERCRED.size))
            except OSError:
                conn.close()
                continue
            if not self.authorized(uid, gid):
                log.warning("refused a connection from uid %d (pid %d): not allowed to use the daemon", uid, pid)
                self._send(conn, error_reply(None, {"code": "auth", "message": "you are not allowed to use the daemon",
                                                    "hint": f"ask the administrator to add you to the {self.group!r} group"}))
                conn.close()
                continue
            with self._lock:
                if len(self._conns) >= self.max_clients:
                    full = True
                else:
                    full = False
                    cid = self._next = self._next + 1
                    self._conns[cid] = conn
            if full:
                self._send(conn, error_reply(None, {"code": "busy", "message": "too many connections to the daemon",
                                                    "hint": None}))
                conn.close()
                continue
            threading.Thread(target=self._serve, args=(cid, conn, (pid, uid, gid)), daemon=True,
                             name=f"ipc-{cid}").start()

    @staticmethod
    def _send(conn: socket.socket, obj: dict) -> bool:
        try:
            conn.settimeout(10.0)
            conn.sendall(encode(obj))
            return True
        except OSError:
            return False

    def _serve(self, cid: int, conn: socket.socket, creds: tuple[int, int, int]) -> None:
        reader = conn.makefile("rb")
        try:
            while not self._stopping.is_set():
                conn.settimeout(self.idle_timeout)
                try:
                    line = reader.readline(MAX_REQUEST + 2)
                except (socket.timeout, OSError):
                    return
                if not line:
                    return
                if len(line) > MAX_REQUEST + 1 or not line.endswith(b"\n"):
                    self._send(conn, error_reply(None, {"code": "protocol", "message": "the request is too large",
                                                        "hint": None}))
                    return                                          # cannot resynchronise after a cut-off line
                self.served += 1
                try:
                    req = decode(line)
                except ProtocolError as e:
                    if not self._send(conn, error_reply(None, e.to_dict())):
                        return
                    continue
                if req.get("cmd") == "subscribe":
                    self._stream(conn, req, creds)
                    return
                if not self._send(conn, self.handle(req, creds)):
                    return
        except Exception:
            log.exception("connection handler failed")
        finally:
            with self._lock:
                self._conns.pop(cid, None)
            try:
                reader.close()
                conn.close()
            except OSError:
                pass

    # ---- one request ------------------------------------------------------------------------------
    def handle(self, req: dict, creds: tuple[int, int, int] = (0, 0, 0)) -> dict:
        rid = req.get("id")
        if not isinstance(rid, (int, str, type(None))):
            rid = None
        try:
            name = req.get("cmd")
            cmd = COMMANDS.get(name) if isinstance(name, str) else None
            if cmd is None:
                raise ProtocolError(f"unknown command: {str(name)[:60]!r}")
            args = validate(cmd, req.get("args"))
            if cmd.name == "ping":
                return ok_reply(rid, {"pong": time.time(), "version": __version__})
            if cmd.level != READ:
                pid, uid, _ = creds
                log.info("%s requested by uid %d (pid %d)", cmd.name, uid, pid)
            return ok_reply(rid, getattr(self.engine, cmd.method)(**args))
        except IPShiftError as e:
            return error_reply(rid, e.to_dict())
        except Exception:
            log.exception("command %r failed", req.get("cmd"))
            return error_reply(rid, {"code": "internal", "message": "internal error (see the daemon log)",
                                     "hint": None})

    # ---- event stream -------------------------------------------------------------------------------
    def _stream(self, conn: socket.socket, req: dict, creds) -> None:
        rid = req.get("id")
        try:
            args = validate(COMMANDS["subscribe"], req.get("args"))
        except ProtocolError as e:
            self._send(conn, error_reply(rid, e.to_dict()))
            return
        floor = LEVELS.get(args.get("min_level", "info"), 20)
        replay = max(0, min(int(args.get("replay", 0)), 300))
        q: queue.Queue = queue.Queue(maxsize=1000)

        def on_event(ev) -> None:
            if LEVELS.get(ev.level, 20) >= floor:
                try:
                    q.put_nowait(ev)
                except queue.Full:                                  # a slow reader loses events, never blocks the engine
                    pass

        unsubscribe = self.engine.bus.subscribe(on_event)
        try:
            if not self._send(conn, ok_reply(rid, {"subscribed": True})):
                return
            if replay:
                for ev in self.engine.bus.recent(replay, args.get("min_level", "info")):
                    if not self._send(conn, {"event": ev.to_dict()}):
                        return
            last = time.monotonic()
            while not self._stopping.is_set():
                try:
                    # Wait in short slices so that stop() is noticed at once (not after a whole heartbeat);
                    # a heartbeat is still sent after ``self.heartbeat`` seconds of silence.
                    ev = q.get(timeout=min(0.25, self.heartbeat))
                    msg = {"event": ev.to_dict()}
                except queue.Empty:
                    if time.monotonic() - last < self.heartbeat:
                        continue
                    msg = {"hb": time.time()}
                last = time.monotonic()
                if not self._send(conn, msg):
                    return
        finally:
            unsubscribe()
