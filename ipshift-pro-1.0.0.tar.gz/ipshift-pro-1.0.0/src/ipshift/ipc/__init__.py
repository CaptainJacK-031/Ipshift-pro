"""Daemon <-> client communication (JSON lines over a Unix socket)."""
