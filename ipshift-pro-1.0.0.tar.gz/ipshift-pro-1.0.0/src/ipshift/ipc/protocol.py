"""Wire protocol between the daemon and its clients (CLI, GUI).

JSON lines over a Unix socket.  A request is one line::

    {"id": 7, "cmd": "connect", "args": {"profile": "frankfurt"}}

and gets exactly one line back::

    {"id": 7, "ok": true,  "data": {...}}
    {"id": 7, "ok": false, "error": {"code": "vpn", "message": "...", "hint": "..."}}

``subscribe`` turns the connection into an event stream: after the acknowledgement the
daemon pushes ``{"event": {...}}`` lines (and ``{"hb": <time>}`` heartbeats) until either
side closes the connection.

The daemon never trusts a request: every command has a declared argument list, each
argument has a type and a size limit, and anything else is refused before it reaches
the engine.  Argument *values* are never logged (they can contain passwords).
"""
from __future__ import annotations

import json
import math
from dataclasses import dataclass, field

from ..errors import ProtocolError

MAX_REQUEST = 1 << 20          # one request line: 1 MiB (a profile bundle is far smaller)
MAX_RESPONSE = 16 << 20        # replies can carry history exports
DEFAULT_TIMEOUT = 30.0

READ, WRITE, ADMIN = "read", "write", "admin"

# Argument types.  A trailing "?" makes the argument optional (it may also be null).
#   str    short text (<= 4096 characters)      text   long text (<= 1 MiB: a configuration file)
#   name   one-line label (<= 200, no control characters)
#   int / float / bool                          (floats must be finite)
#   strs   list of up to 64 short strings       files  {name: text}, up to 20 entries
#   scalar a setting value: str, number, bool or list of strings
TYPES = ("str", "text", "name", "int", "float", "bool", "strs", "files", "scalar")


@dataclass(frozen=True)
class Command:
    name: str
    level: str                           # read | write | admin (write/admin are logged with the caller's identity)
    method: str                          # Engine method that runs it ("" = handled by the server itself)
    args: dict = field(default_factory=dict)
    timeout: float = DEFAULT_TIMEOUT     # how long a client should wait for the answer


def _c(name, level, method, args=None, timeout=DEFAULT_TIMEOUT) -> tuple[str, Command]:
    return name, Command(name, level, method, args or {}, timeout)


PROFILE_FIELDS = {"name": "name?", "tier": "str?", "provider": "name?", "country": "str?", "enabled": "bool?",
                  "notes": "str?"}

COMMANDS: dict[str, Command] = dict([
    # ---- read -----------------------------------------------------------------------------
    _c("ping", READ, ""),
    _c("status", READ, "status", {"fresh": "bool?"}),
    _c("ip", READ, "ip_info", {"refresh": "bool?", "direct": "bool?"}, 60),
    _c("profiles", READ, "profiles"),
    _c("history", READ, "history_get", {"limit": "int?"}),
    _c("history.export", READ, "history_export", {"limit": "int?"}, 120),
    _c("events", READ, "events", {"n": "int?", "min_level": "str?"}),
    _c("report", READ, "last_report"),
    _c("config.get", READ, "config_get", {"key": "str?"}),
    _c("killswitch.status", READ, "killswitch_status"),
    _c("harden.status", READ, "harden_status"),
    _c("doctor", READ, "doctor", {}, 60),
    _c("subscribe", READ, "", {"min_level": "str?", "replay": "int?"}),
    # ---- write ----------------------------------------------------------------------------
    _c("connect", WRITE, "connect", {"profile": "str?", "keep_rotation": "bool?"}, 240),
    _c("cancel", WRITE, "cancel"),
    _c("stop", WRITE, "stop", {"keep_blocking": "bool?", "keep_vpn": "bool?"}, 90),
    _c("rotate.start", WRITE, "rotate_start", {"interval": "float?", "immediate": "bool?"}, 60),
    _c("rotate.stop", WRITE, "rotate_stop", {}, 60),
    _c("rotate.now", WRITE, "rotate_now", {}, 240),
    _c("rotate.interval", WRITE, "set_interval", {"value": "float"}),
    _c("privacy.check", WRITE, "privacy_check", {"mode": "str?", "only": "strs?"}, 90),
    _c("profile.import", WRITE, "profile_import",
       {"text": "text", "name": "name", "files": "files?", "protocol": "str?", "tier": "str?", "provider": "name?",
        "country": "str?", "username": "str?", "password": "str?", "replace": "bool?", "notes": "str?"}, 90),
    _c("profile.remove", WRITE, "profile_remove", {"ref": "str"}),
    _c("profile.update", WRITE, "profile_update", {"ref": "str", **PROFILE_FIELDS}),
    _c("profile.auth", WRITE, "profile_auth", {"ref": "str", "username": "str", "password": "str"}),
    _c("profile.clear_quarantine", WRITE, "profile_clear_quarantine", {"ref": "str?"}),
    _c("history.clear", WRITE, "history_clear"),
    # ---- admin ----------------------------------------------------------------------------
    _c("config.set", ADMIN, "config_set", {"key": "str", "value": "scalar"}),
    _c("config.reload", ADMIN, "config_reload"),
    _c("killswitch.on", ADMIN, "killswitch_on"),
    _c("killswitch.off", ADMIN, "killswitch_off"),
    _c("killswitch.lockdown", ADMIN, "lockdown", {}, 90),
    _c("harden.mac", ADMIN, "mac_policy", {"action": "str", "iface": "str?", "mac": "str?"}, 60),
    _c("restore", ADMIN, "restore_network", {"include_mac": "bool?"}, 90),
])

_STR_MAX, _NAME_MAX, _TEXT_MAX = 4096, 200, MAX_REQUEST


def _bad(cmd: str, arg: str, why: str) -> ProtocolError:
    return ProtocolError(f"{cmd}: argument {arg!r} {why}")


def _is_str(v) -> bool:
    return isinstance(v, str)


def check_value(cmd: str, arg: str, tag: str, value):
    """Validate one argument against its type tag; returns the value (unchanged)."""
    optional = tag.endswith("?")
    base = tag.rstrip("?")
    if value is None:
        if optional:
            return None
        raise _bad(cmd, arg, "is required")
    if base == "str":
        if not _is_str(value) or len(value) > _STR_MAX:
            raise _bad(cmd, arg, f"must be text of at most {_STR_MAX} characters")
    elif base == "text":
        if not _is_str(value) or len(value) > _TEXT_MAX:
            raise _bad(cmd, arg, "must be text of at most 1 MiB")
    elif base == "name":
        if not _is_str(value) or len(value) > _NAME_MAX or any(ord(ch) < 32 for ch in value):
            raise _bad(cmd, arg, f"must be one line of at most {_NAME_MAX} characters")
    elif base == "int":
        if isinstance(value, bool) or not isinstance(value, int) or abs(value) > 10 ** 12:
            raise _bad(cmd, arg, "must be an integer")
    elif base == "float":
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
            raise _bad(cmd, arg, "must be a finite number")
    elif base == "bool":
        if not isinstance(value, bool):
            raise _bad(cmd, arg, "must be true or false")
    elif base == "strs":
        if (not isinstance(value, list) or len(value) > 64
                or not all(_is_str(v) and len(v) <= _NAME_MAX for v in value)):
            raise _bad(cmd, arg, "must be a list of at most 64 short strings")
    elif base == "files":
        if (not isinstance(value, dict) or len(value) > 20
                or not all(_is_str(k) and len(k) <= _STR_MAX and _is_str(v) and len(v) <= _TEXT_MAX
                           for k, v in value.items())):
            raise _bad(cmd, arg, "must be an object of at most 20 named texts")
    elif base == "scalar":
        ok = (isinstance(value, bool) or (isinstance(value, (int, float)) and math.isfinite(value))
              or (_is_str(value) and len(value) <= _STR_MAX)
              or (isinstance(value, list) and len(value) <= 64 and all(_is_str(v) and len(v) <= _NAME_MAX for v in value)))
        if not ok:
            raise _bad(cmd, arg, "must be text, a number, true/false or a list of strings")
    else:  # pragma: no cover - a typo in the table above
        raise AssertionError(f"unknown argument type {tag!r}")
    return value


def validate(cmd: Command, args) -> dict:
    """Check ``args`` against the command's declaration; returns the cleaned dict (nulls dropped)."""
    if args is None:
        args = {}
    if not isinstance(args, dict):
        raise ProtocolError(f"{cmd.name}: 'args' must be an object")
    unknown = sorted(set(args) - set(cmd.args))
    if unknown:
        raise ProtocolError(f"{cmd.name}: unexpected argument(s): {', '.join(map(str, unknown))}")
    out = {}
    for name, tag in cmd.args.items():
        value = check_value(cmd.name, name, tag, args.get(name))
        if value is not None:
            out[name] = value
    return out


# ---- encoding -------------------------------------------------------------------------------------
def encode(obj: dict) -> bytes:
    return json.dumps(obj, separators=(",", ":"), default=str).encode("utf-8") + b"\n"


def decode(line: bytes) -> dict:
    try:
        obj = json.loads(line.decode("utf-8"))
    except (UnicodeDecodeError, ValueError):
        raise ProtocolError("the message is not valid JSON") from None
    if not isinstance(obj, dict):
        raise ProtocolError("the message must be a JSON object")
    return obj


def ok_reply(rid, data) -> dict:
    return {"id": rid, "ok": True, "data": data}


def error_reply(rid, err: dict) -> dict:
    return {"id": rid, "ok": False, "error": err}
