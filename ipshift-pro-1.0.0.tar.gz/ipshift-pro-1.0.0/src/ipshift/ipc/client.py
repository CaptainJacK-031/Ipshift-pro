"""Client side of the daemon protocol, used by the CLI and the GUI.

``Client`` opens one short connection per call, so there is no stale-connection
state to manage; ``events()`` keeps one connection open for the event stream.
"""
from __future__ import annotations

import itertools
import socket
from pathlib import Path
from typing import Iterator

from ..errors import DaemonUnavailable, ProtocolError, from_dict
from ..paths import client_socket_candidates
from .protocol import COMMANDS, DEFAULT_TIMEOUT, MAX_RESPONSE, decode, encode


def diagnose(candidates: list[Path], errors: dict[Path, OSError]) -> DaemonUnavailable:
    """The most useful explanation for 'cannot reach the daemon'."""
    denied = [p for p, e in errors.items() if isinstance(e, PermissionError)]
    refused = [p for p, e in errors.items() if isinstance(e, ConnectionRefusedError)]
    if denied:
        return DaemonUnavailable(
            f"permission denied on {denied[0]}",
            hint="join the 'ipshift' group (sudo usermod -aG ipshift $USER, then log out and in again), "
                 "or run this command with sudo")
    if refused:
        return DaemonUnavailable(
            f"the daemon does not answer on {refused[0]} (the socket is left over from a run that ended)",
            hint="start it with: sudo systemctl restart ipshiftd")
    where = ", ".join(str(p) for p in candidates)
    return DaemonUnavailable(
        f"the IPShift daemon is not running (looked for {where})",
        hint="start it with: sudo systemctl start ipshiftd   -   or try the simulator: ipshiftd --simulate")


def _connect_to(path: Path, timeout: float | None) -> socket.socket:
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(5.0)
    try:
        s.connect(str(path))
    except OSError:
        s.close()
        raise
    s.settimeout(timeout)
    return s


def open_socket(explicit: str | Path | None = None, timeout: float | None = None) -> tuple[socket.socket, Path]:
    """Connect to the first daemon socket that answers, or raise DaemonUnavailable with a hint."""
    candidates = [Path(explicit)] if explicit else client_socket_candidates()
    errors: dict[Path, OSError] = {}
    for path in candidates:
        try:
            return _connect_to(path, timeout), path
        except OSError as e:
            errors[path] = e
    raise diagnose(candidates, errors)


def find_socket(explicit: str | Path | None = None) -> Path:
    s, path = open_socket(explicit)
    s.close()
    return path


class Client:
    def __init__(self, socket_path: str | Path | None = None):
        self._explicit = socket_path
        self._path: Path | None = None
        self._ids = itertools.count(1)

    @property
    def path(self) -> Path:
        if self._path is None:
            self._path = find_socket(self._explicit)
        return self._path

    # ---- plumbing ---------------------------------------------------------------------------
    def _connect(self, timeout: float | None) -> socket.socket:
        if self._path is not None:                         # the last socket that worked
            try:
                return _connect_to(self._path, timeout)
            except OSError:
                self._path = None                          # the daemon may have moved: discover again
        s, self._path = open_socket(self._explicit, timeout)
        return s

    @staticmethod
    def _readline(f) -> bytes:
        line = f.readline(MAX_RESPONSE + 2)
        if not line:
            raise DaemonUnavailable("the daemon closed the connection",
                                    hint="it may have been restarted; try again")
        if not line.endswith(b"\n"):
            raise ProtocolError("the daemon's reply was cut off")
        return line

    def call(self, cmd: str, args: dict | None = None, *, timeout: float | None = None):
        """Run one command; returns its data or raises the matching IPShiftError."""
        spec = COMMANDS.get(cmd)
        wait = timeout if timeout is not None else (spec.timeout if spec else DEFAULT_TIMEOUT)
        s = self._connect(wait)
        f = None
        try:
            try:
                s.sendall(encode({"id": next(self._ids), "cmd": cmd, "args": args or {}}))
            except (BrokenPipeError, ConnectionResetError):
                pass                                       # the daemon may have refused us and hung up: read why
            f = s.makefile("rb")
            reply = decode(self._readline(f))
        except socket.timeout:
            raise DaemonUnavailable(
                f"the daemon did not answer '{cmd}' within {wait:.0f} s",
                hint="the operation may still be running; check with: ipshift status") from None
        except OSError as e:
            raise DaemonUnavailable(f"lost the connection to the daemon ({e.strerror or e})") from None
        finally:
            if f is not None:
                f.close()
            s.close()
        if reply.get("ok"):
            return reply.get("data")
        raise from_dict(reply.get("error") or {"code": "error", "message": "the daemon reported an error"})

    def events(self, min_level: str = "info", replay: int = 0, *, on_open=None) -> Iterator[dict]:
        """Yield events as they happen (heartbeats are swallowed).  Close the generator to disconnect.

        ``on_open(sock)`` receives the connected socket, so another thread can ``shutdown()`` it to end a
        stream that is blocked waiting for the next event (the GUI does this when its window closes)."""
        s = self._connect(None)
        f = None
        try:
            if on_open is not None:
                on_open(s)
            try:
                s.sendall(encode({"id": 0, "cmd": "subscribe", "args": {"min_level": min_level, "replay": replay}}))
            except (BrokenPipeError, ConnectionResetError):
                pass
            f = s.makefile("rb")
            first = decode(self._readline(f))
            if not first.get("ok"):
                raise from_dict(first.get("error") or {"code": "error", "message": "subscribe failed"})
            while True:
                try:
                    msg = decode(self._readline(f))
                except (DaemonUnavailable, OSError):
                    return
                if "event" in msg:
                    yield msg["event"]
        finally:
            if f is not None:
                f.close()
            s.close()

    # ---- the commands ----------------------------------------------------------------------------
    def ping(self) -> dict:
        return self.call("ping")

    def status(self, fresh: bool = False) -> dict:
        return self.call("status", {"fresh": fresh})

    def ip(self, refresh: bool = False, direct: bool = False) -> dict:
        return self.call("ip", {"refresh": refresh, "direct": direct})

    def profiles(self) -> dict:
        return self.call("profiles")

    def history(self, limit: int = 100) -> dict:
        return self.call("history", {"limit": limit})

    def history_export(self, limit: int = 100_000) -> dict:
        return self.call("history.export", {"limit": limit})

    def history_clear(self) -> dict:
        return self.call("history.clear")

    def recent_events(self, n: int = 50, min_level: str = "info") -> list:
        return self.call("events", {"n": n, "min_level": min_level})

    def report(self):
        return self.call("report")

    def config_get(self, key: str | None = None) -> dict:
        return self.call("config.get", {"key": key} if key else {})

    def config_set(self, key: str, value) -> dict:
        return self.call("config.set", {"key": key, "value": value})

    def config_reload(self) -> dict:
        return self.call("config.reload")

    def connect(self, profile: str | None = None, keep_rotation: bool = False) -> dict:
        args: dict = {"keep_rotation": keep_rotation}
        if profile:
            args["profile"] = profile
        return self.call("connect", args)

    def cancel(self) -> dict:
        return self.call("cancel")

    def stop(self, keep_blocking: bool = False, keep_vpn: bool = False) -> dict:
        return self.call("stop", {"keep_blocking": keep_blocking, "keep_vpn": keep_vpn})

    def rotate_start(self, interval: float | None = None, immediate: bool = True) -> dict:
        args: dict = {"immediate": immediate}
        if interval is not None:
            args["interval"] = interval
        return self.call("rotate.start", args)

    def rotate_stop(self) -> dict:
        return self.call("rotate.stop")

    def rotate_now(self) -> dict:
        return self.call("rotate.now")

    def set_interval(self, value: float) -> dict:
        return self.call("rotate.interval", {"value": value})

    def privacy_check(self, mode: str = "full", only: list[str] | None = None) -> dict:
        args: dict = {"mode": mode}
        if only:
            args["only"] = only
        return self.call("privacy.check", args)

    def profile_import(self, **kw) -> dict:
        return self.call("profile.import", kw)

    def profile_remove(self, ref: str) -> dict:
        return self.call("profile.remove", {"ref": ref})

    def profile_update(self, ref: str, **changes) -> dict:
        return self.call("profile.update", {"ref": ref, **changes})

    def profile_auth(self, ref: str, username: str, password: str) -> dict:
        return self.call("profile.auth", {"ref": ref, "username": username, "password": password})

    def profile_clear_quarantine(self, ref: str | None = None) -> dict:
        return self.call("profile.clear_quarantine", {"ref": ref} if ref else {})

    def killswitch_status(self) -> dict:
        return self.call("killswitch.status")

    def killswitch_on(self) -> dict:
        return self.call("killswitch.on")

    def killswitch_off(self) -> dict:
        return self.call("killswitch.off")

    def lockdown(self) -> dict:
        return self.call("killswitch.lockdown")

    def harden_status(self) -> dict:
        return self.call("harden.status")

    def mac(self, action: str, iface: str | None = None, mac: str | None = None) -> dict:
        args: dict = {"action": action}
        if iface:
            args["iface"] = iface
        if mac:
            args["mac"] = mac
        return self.call("harden.mac", args)

    def restore(self, include_mac: bool = True) -> dict:
        return self.call("restore", {"include_mac": include_mac})

    def doctor(self) -> dict:
        return self.call("doctor")
