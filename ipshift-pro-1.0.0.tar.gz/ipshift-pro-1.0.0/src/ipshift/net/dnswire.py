"""Minimal DNS wire-format client (RFC 1035 + EDNS0).

Just enough for the leak tests and for the DoH bootstrap resolver: build a
query, send it over UDP/TCP (optionally pinned to a network *device*), parse
A / AAAA / TXT / CNAME / NS answers.  Responses are only accepted from the
server we asked (connected UDP socket) with a matching transaction id.
"""
from __future__ import annotations

import ipaddress
import secrets
import socket
import struct
from dataclasses import dataclass, field

from .http import SO_BINDTODEVICE

QTYPE = {"A": 1, "NS": 2, "CNAME": 5, "TXT": 16, "AAAA": 28}
_QNAME = {v: k for k, v in QTYPE.items()}


class DnsError(OSError):
    pass


@dataclass
class Record:
    name: str
    rtype: str
    ttl: int
    data: str


@dataclass
class Message:
    id: int
    rcode: int
    truncated: bool
    answers: list[Record] = field(default_factory=list)

    def values(self, rtype: str) -> list[str]:
        return [r.data for r in self.answers if r.rtype == rtype]


def encode_name(name: str) -> bytes:
    name = name.rstrip(".")
    if len(name) > 253:
        raise DnsError("name too long")
    out = b""
    for label in name.split(".") if name else []:
        raw = label.encode("idna") if not label.isascii() else label.encode("ascii")
        if not 0 < len(raw) <= 63:
            raise DnsError("bad label length")
        out += bytes([len(raw)]) + raw
    return out + b"\0"


def build_query(name: str, qtype: str = "A", *, txid: int | None = None, edns: bool = True) -> bytes:
    txid = secrets.randbelow(65536) if txid is None else txid
    header = struct.pack("!HHHHHH", txid, 0x0100, 1, 0, 0, 1 if edns else 0)   # RD set
    q = encode_name(name) + struct.pack("!HH", QTYPE[qtype], 1)
    opt = b"\0" + struct.pack("!HHIH", 41, 1232, 0, 0) if edns else b""
    return header + q + opt


def _read_name(buf: bytes, pos: int) -> tuple[str, int]:
    labels, jumped, end, hops = [], False, pos, 0
    while True:
        if pos >= len(buf):
            raise DnsError("truncated name")
        n = buf[pos]
        if n & 0xC0 == 0xC0:
            if pos + 1 >= len(buf):
                raise DnsError("truncated pointer")
            ptr = ((n & 0x3F) << 8) | buf[pos + 1]
            if not jumped:
                end = pos + 2
            pos, jumped, hops = ptr, True, hops + 1
            if hops > 20:
                raise DnsError("compression loop")
            continue
        if n == 0:
            if not jumped:
                end = pos + 1
            return ".".join(labels), end
        pos += 1
        if pos + n > len(buf):
            raise DnsError("truncated label")
        labels.append(buf[pos:pos + n].decode("ascii", "replace"))
        pos += n


def parse_response(buf: bytes) -> Message:
    if len(buf) < 12:
        raise DnsError("short response")
    txid, flags, qd, an, _ns, _ar = struct.unpack("!HHHHHH", buf[:12])
    msg = Message(txid, flags & 0xF, bool(flags & 0x200))
    pos = 12
    for _ in range(qd):
        _, pos = _read_name(buf, pos)
        pos += 4
    for _ in range(an):
        name, pos = _read_name(buf, pos)
        if pos + 10 > len(buf):
            raise DnsError("truncated record")
        rtype, _cls, ttl, rdlen = struct.unpack("!HHIH", buf[pos:pos + 10])
        pos += 10
        rdata, rstart = buf[pos:pos + rdlen], pos
        if len(rdata) < rdlen:
            raise DnsError("truncated rdata")
        pos += rdlen
        t = _QNAME.get(rtype)
        if t == "A" and rdlen == 4:
            data = str(ipaddress.IPv4Address(rdata))
        elif t == "AAAA" and rdlen == 16:
            data = str(ipaddress.IPv6Address(rdata))
        elif t == "TXT":
            parts, i = [], 0
            while i < rdlen:
                ln = rdata[i]
                parts.append(rdata[i + 1:i + 1 + ln].decode("utf-8", "replace"))
                i += 1 + ln
            data = "".join(parts)
        elif t in ("CNAME", "NS"):
            data = _read_name(buf, rstart)[0]
        else:
            continue
        msg.answers.append(Record(name, t, ttl, data))
    return msg


def _sock(server: str, kind: int, device, source_ip, timeout) -> socket.socket:
    fam = socket.AF_INET6 if ":" in server else socket.AF_INET
    s = socket.socket(fam, kind)
    s.settimeout(timeout)
    if device:
        s.setsockopt(socket.SOL_SOCKET, SO_BINDTODEVICE, device.encode() + b"\0")
    if source_ip:
        s.bind((source_ip, 0))
    return s


def udp_query(server: str, name: str, qtype: str = "A", *, port: int = 53, timeout: float = 3.0,
              device: str | None = None, source_ip: str | None = None) -> Message:
    query = build_query(name, qtype)
    txid = struct.unpack("!H", query[:2])[0]
    s = _sock(server, socket.SOCK_DGRAM, device, source_ip, timeout)
    try:
        s.connect((server, port))          # the kernel now drops datagrams from anyone else
        s.send(query)
        while True:
            try:
                data = s.recv(4096)
            except socket.timeout:
                raise DnsError(f"timeout querying {server}") from None
            except OSError as e:
                raise DnsError(f"{server}: {e}") from None
            msg = parse_response(data)
            if msg.id == txid:
                break
        if msg.truncated:
            return tcp_query(server, name, qtype, port=port, timeout=timeout, device=device, source_ip=source_ip)
        return msg
    finally:
        s.close()


def tcp_query(server: str, name: str, qtype: str = "A", *, port: int = 53, timeout: float = 3.0,
              device: str | None = None, source_ip: str | None = None) -> Message:
    query = build_query(name, qtype)
    s = _sock(server, socket.SOCK_STREAM, device, source_ip, timeout)
    try:
        s.connect((server, port))
        s.sendall(struct.pack("!H", len(query)) + query)
        hdr = _recv_exact(s, 2)
        data = _recv_exact(s, struct.unpack("!H", hdr)[0])
        return parse_response(data)
    except (OSError, struct.error) as e:
        raise DnsError(f"{server}: {e}") from None
    finally:
        s.close()


def _recv_exact(s: socket.socket, n: int) -> bytes:
    buf = b""
    while len(buf) < n:
        chunk = s.recv(n - len(buf))
        if not chunk:
            raise DnsError("connection closed")
        buf += chunk
    return buf
