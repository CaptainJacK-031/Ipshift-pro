"""Local network facts: interfaces, private addresses, routes and link kind.

Uses ``ip -j`` when iproute2 is present and falls back to procfs/sysfs/ioctl, so
it also works on a minimal system (and in the test sandbox).  Nothing here
touches the network.
"""
from __future__ import annotations

import fcntl
import ipaddress
import json
import os
import socket
import struct
from dataclasses import dataclass, field, asdict
from pathlib import Path

from ..sysutil import Runner

SIOCGIFADDR, SIOCGIFNETMASK = 0x8915, 0x891B
_USB_TETHER = {"rndis_host", "cdc_ether", "cdc_ncm", "ipheth", "usbnet"}
_MOBILE = {"qmi_wwan", "cdc_mbim", "huawei_cdc_ncm", "option", "cdc_wdm"}
_TUN_PREFIX = ("tun", "tap", "wg", "ppp", "ipshift", "vpn", "proton", "mullvad", "nordlynx")
_CGNAT = ipaddress.ip_network("100.64.0.0/10")
# Well-known hotspot gateways: a hint for the UI, never used for security decisions.
_HOTSPOT_GW = {"172.20.10.1": "iPhone hotspot", "192.168.43.1": "Android hotspot",
               "192.168.49.1": "Android Wi-Fi Direct"}



# Human names for the interface kinds above (shown by the CLI, the GUI and in alerts)
KIND_NAMES = {"wifi": "Wi-Fi", "ethernet": "Ethernet", "usb-tether": "USB tethering", "mobile": "Mobile data",
              "tunnel": "VPN tunnel", "bridge": "bridge", "virtual": "virtual"}


@dataclass
class Iface:
    name: str
    kind: str                       # ethernet wifi usb-tether mobile tunnel bridge virtual loopback
    up: bool
    mac: str | None = None
    ipv4: list[str] = field(default_factory=list)     # "192.168.1.5/24"
    ipv6: list[str] = field(default_factory=list)
    physical: bool = False

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Route:
    iface: str
    gateway: str | None = None
    src: str | None = None
    metric: int | None = None

    def to_dict(self) -> dict:
        return asdict(self)


def scope_of(addr: str) -> str:
    """loopback | link-local | private | cgnat | global"""
    try:
        ip = ipaddress.ip_address(addr.split("/")[0].split("%")[0])
    except ValueError:
        return "unknown"
    if ip.is_loopback:
        return "loopback"
    if ip.is_link_local:
        return "link-local"
    if ip.version == 4 and ip in _CGNAT:
        return "cgnat"
    if ip.is_private:
        return "private"
    return "global"


def _hex_ip4(h: str) -> str:
    return socket.inet_ntoa(struct.pack("<I", int(h, 16)))


class NetInfo:
    def __init__(self, runner: Runner | None = None, ip_bin: str = "ip",
                 sysroot: str | Path = "/sys/class/net", procroot: str | Path = "/proc/net"):
        self.runner = runner or Runner()
        self.ip_bin = ip_bin
        self.sys = Path(sysroot)
        self.proc = Path(procroot)

    # ---- helpers -----------------------------------------------------------
    def _ip_json(self, *args: str):
        r = self.runner.run([self.ip_bin, "-j", *args], timeout=5)
        if not r.ok or not r.stdout.strip():
            return None
        try:
            return json.loads(r.stdout)
        except ValueError:
            return None

    def _read(self, p: Path) -> str:
        try:
            return p.read_text().strip()
        except OSError:
            return ""

    def classify(self, name: str) -> tuple[str, bool]:
        """(kind, physical) from sysfs hints; names are the last resort."""
        if name == "lo":
            return "loopback", False
        base = self.sys / name
        if (base / "tun_flags").exists() or name.startswith(_TUN_PREFIX) or self._read(base / "type") == "65534":
            return "tunnel", False
        if (base / "bridge").exists():
            return "bridge", False
        real = os.path.realpath(base) if base.exists() else ""
        driver = ""
        try:
            driver = os.path.basename(os.readlink(base / "device" / "driver"))
        except OSError:
            pass
        if (base / "wireless").exists() or (base / "phy80211").exists():
            return "wifi", True
        if driver in _USB_TETHER:
            return "usb-tether", True
        if driver in _MOBILE or name.startswith("wwan"):
            return "mobile", True
        if "/devices/virtual/" in real or (base.exists() and not (base / "device").exists()):
            return "virtual", False
        return "ethernet", True

    # ---- interfaces --------------------------------------------------------
    def interfaces(self) -> list[Iface]:
        data = self._ip_json("addr", "show")
        out: list[Iface] = []
        if data is not None:
            for d in data:
                name = d.get("ifname", "")
                kind, phys = self.classify(name)
                up = "UP" in d.get("flags", []) and d.get("operstate", "UNKNOWN") != "DOWN"
                ifc = Iface(name, kind, up, d.get("address"), [], [], phys)
                for a in d.get("addr_info", []):
                    cidr = f"{a.get('local')}/{a.get('prefixlen')}"
                    (ifc.ipv4 if a.get("family") == "inet" else ifc.ipv6).append(cidr)
                out.append(ifc)
            return out
        return self._interfaces_fallback()

    def _interfaces_fallback(self) -> list[Iface]:
        v6: dict[str, list[str]] = {}
        try:
            for line in (self.proc / "if_inet6").read_text().splitlines():
                addr, _idx, plen, _scope, _fl, name = line.split()
                a = ipaddress.IPv6Address(int(addr, 16))
                v6.setdefault(name, []).append(f"{a}/{int(plen, 16)}")
        except (OSError, ValueError):
            pass
        names = sorted(n for _i, n in socket.if_nameindex())
        out = []
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            for name in names:
                kind, phys = self.classify(name)
                flags = self._read(self.sys / name / "flags")
                up = bool(int(flags, 16) & 1) if flags else True
                ifc = Iface(name, kind, up, self._read(self.sys / name / "address") or None,
                            [], v6.get(name, []), phys)
                req = struct.pack("256s", name.encode()[:15])
                try:
                    addr = socket.inet_ntoa(fcntl.ioctl(sock, SIOCGIFADDR, req)[20:24])
                    mask = socket.inet_ntoa(fcntl.ioctl(sock, SIOCGIFNETMASK, req)[20:24])
                    plen = ipaddress.ip_network(f"0.0.0.0/{mask}").prefixlen
                    ifc.ipv4.append(f"{addr}/{plen}")
                except OSError:
                    pass
                out.append(ifc)
        finally:
            sock.close()
        return out

    def physical_ifaces(self) -> list[str]:
        return [i.name for i in self.interfaces() if i.physical]

    # ---- routes ------------------------------------------------------------
    def default_route(self, family: int = 4) -> Route | None:
        data = self._ip_json(f"-{family}", "route", "show", "default")
        if data:
            best = min(data, key=lambda r: r.get("metric", 0))
            return Route(best.get("dev", ""), best.get("gateway"), best.get("prefsrc"), best.get("metric"))
        if data is not None:
            return None
        return self._default_route_fallback(family)

    def _default_route_fallback(self, family: int) -> Route | None:
        best: Route | None = None
        try:
            if family == 4:
                for line in (self.proc / "route").read_text().splitlines()[1:]:
                    f = line.split()
                    if f[1] == "00000000" and f[7] == "00000000" and int(f[3], 16) & 1:
                        r = Route(f[0], _hex_ip4(f[2]) if int(f[3], 16) & 2 else None, None, int(f[6]))
                        if best is None or (r.metric or 0) < (best.metric or 0):
                            best = r
            else:
                for line in (self.proc / "ipv6_route").read_text().splitlines():
                    f = line.split()
                    if f[0] == "0" * 32 and f[1] == "00":
                        gw = str(ipaddress.IPv6Address(int(f[4], 16))) if int(f[4], 16) else None
                        r = Route(f[9], gw, None, int(f[5], 16))
                        if best is None or (r.metric or 0) < (best.metric or 0):
                            best = r
        except (OSError, ValueError, IndexError):
            return None
        return best

    def route_get(self, dest: str) -> Route | None:
        """Which interface would a packet to ``dest`` leave through?"""
        ip = ipaddress.ip_address(dest)
        data = self._ip_json(f"-{ip.version}", "route", "get", str(ip))
        if data:
            d = data[0]
            return Route(d.get("dev", ""), d.get("gateway"), d.get("prefsrc"), d.get("metric"))
        if data is not None or ip.version != 4:
            return None
        best, best_len = None, -1
        try:
            for line in (self.proc / "route").read_text().splitlines()[1:]:
                f = line.split()
                if not int(f[3], 16) & 1:
                    continue
                net = ipaddress.ip_network(f"{_hex_ip4(f[1])}/{_hex_ip4(f[7])}", strict=False)
                if ip in net and net.prefixlen > best_len:
                    best, best_len = Route(f[0], _hex_ip4(f[2]) if int(f[3], 16) & 2 else None, None, int(f[6])), net.prefixlen
        except (OSError, ValueError, IndexError):
            return None
        return best

    # ---- summaries ---------------------------------------------------------
    def private_ips(self, ifaces: list[Iface] | None = None) -> list[dict]:
        ifaces = self.interfaces() if ifaces is None else ifaces
        r4 = self.default_route(4)
        out = []
        for i in ifaces:
            if i.kind == "loopback":
                continue
            for cidr in i.ipv4 + i.ipv6:
                addr, _, plen = cidr.partition("/")
                sc = scope_of(addr)
                if sc in ("loopback", "link-local"):
                    continue
                out.append({"iface": i.name, "ip": addr, "prefix": int(plen or 0),
                            "family": 6 if ":" in addr else 4, "scope": sc, "kind": i.kind,
                            "primary": bool(r4 and r4.iface == i.name and ":" not in addr)})
        return out

    @staticmethod
    def hotspot_hint(kind: str, gateway: str | None) -> str | None:
        if gateway in _HOTSPOT_GW:
            return _HOTSPOT_GW[gateway]
        return "USB tethering" if kind == "usb-tether" else None

    def summary(self) -> dict:
        """Everything the UI shows about the physical link, plus a change-detection key."""
        ifaces = self.interfaces()
        r4, r6 = self.default_route(4), self.default_route(6)
        by = {i.name: i for i in ifaces}
        kind = by[r4.iface].kind if r4 and r4.iface in by else None
        return {
            "default_iface": r4.iface if r4 else None,
            "gateway": r4.gateway if r4 else None,
            "kind": kind,
            "hotspot": self.hotspot_hint(kind or "", r4.gateway if r4 else None),
            "has_ipv6_route": r6 is not None,
            "private_ips": self.private_ips(ifaces),
            "ifaces": [i.to_dict() for i in ifaces],
        }

    @staticmethod
    def change_key(summary: dict) -> tuple:
        """Stable value that changes when the physical network changes."""
        ips = tuple(sorted((p["iface"], p["ip"]) for p in summary["private_ips"] if p["kind"] != "tunnel"))
        return (summary["default_iface"], summary["gateway"], ips)
