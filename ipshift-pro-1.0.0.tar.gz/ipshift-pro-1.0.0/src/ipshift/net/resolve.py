"""Resolve VPN server names without asking the local (ISP / hotspot) resolver.

A VPN profile usually names its server by hostname.  Looking that name up
through the normal resolver tells the network operator which VPN you use, and
under a kill switch it would simply fail.  Instead we ask public DoH servers
addressed by IP literal (certificate-checked against their IP SANs), so the
operator sees only an HTTPS session to a well-known resolver.

Plain-DNS fallback via the system resolver exists but is OFF unless
``vpn.allow_plain_bootstrap_dns`` is set.
"""
from __future__ import annotations

import ipaddress
import logging
import socket
import time

from .dnswire import DnsError, build_query, parse_response
from .http import HttpError, http_post

log = logging.getLogger(__name__)
CACHE_TTL = 300.0


class ResolveError(OSError):
    pass


class BootstrapResolver:
    """``vpn`` is the live VpnConfig section."""

    def __init__(self, vpn, *, post=http_post, system_resolver=socket.getaddrinfo):
        self.vpn = vpn
        self._post = post
        self._system = system_resolver
        self._cache: dict[tuple[str, int], tuple[float, list[str]]] = {}

    @staticmethod
    def doh_hosts(urls) -> list[str]:
        """IPs the firewall must let through (tcp/443) while a lookup is in flight."""
        out = []
        for u in urls:
            host = u.split("//", 1)[-1].split("/", 1)[0].split(":")[0]
            try:
                ipaddress.ip_address(host)
                out.append(host)
            except ValueError:
                continue
        return out

    def resolve(self, host: str, family: int = 4, *, use_cache: bool = True) -> list[str]:
        """IPs of ``host`` (A records for family 4, AAAA for 6).  Raises ResolveError."""
        try:
            ipaddress.ip_address(host)
            return [host]
        except ValueError:
            pass
        key = (host.lower(), family)
        hit = self._cache.get(key)
        if use_cache and hit and hit[0] > time.monotonic():
            return list(hit[1])
        ips, ttl = self._doh(host, family)
        if not ips and self.vpn.allow_plain_bootstrap_dns:
            log.warning("falling back to the system resolver for %s (plain DNS: the local network sees this name)", host)
            ips, ttl = self._plain(host, family), 60
        if not ips:
            raise ResolveError(f"could not resolve {host}")
        self._cache[key] = (time.monotonic() + min(ttl, CACHE_TTL), ips)
        return list(ips)

    def _doh(self, host: str, family: int) -> tuple[list[str], int]:
        qtype = "A" if family == 4 else "AAAA"
        query = build_query(host, qtype, txid=0)           # RFC 8484: id 0 for cache friendliness
        for url in self.vpn.bootstrap_doh:
            try:
                resp = self._post(url, query, "application/dns-message",
                                  headers={"Accept": "application/dns-message"}, timeout=6, max_bytes=8192)
                if resp.status != 200:
                    continue
                msg = parse_response(resp.body)
            except (HttpError, DnsError) as e:
                log.debug("DoH %s failed: %s", url, e)
                continue
            vals = msg.values(qtype)
            if vals:
                ttl = min((r.ttl for r in msg.answers if r.rtype == qtype), default=60)
                return list(dict.fromkeys(vals)), ttl
        return [], 0

    def _plain(self, host: str, family: int) -> list[str]:
        try:
            infos = self._system(host, None, socket.AF_INET if family == 4 else socket.AF_INET6, socket.SOCK_STREAM)
        except OSError:
            return []
        return list(dict.fromkeys(i[4][0] for i in infos))
