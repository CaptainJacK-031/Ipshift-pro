"""Minimal HTTP(S) client built on ``http.client``.

Why not urllib?  The leak tests need three things it cannot do:

* force the address family, so IPv4 and IPv6 reachability are tested separately;
* bind the socket to a network *device* (``SO_BINDTODEVICE``, needs root) or a
  source address, to prove traffic cannot leave outside the tunnel;
* hard caps on response size so a hostile echo service cannot exhaust memory.

TLS verification is always on.  ``cafile`` exists only so the tests can trust a
throw-away certificate.  Plain ``http://`` is accepted only for loopback hosts.
"""
from __future__ import annotations

import http.client
import socket
import ssl
from dataclasses import dataclass, field
from urllib.parse import urlsplit

SO_BINDTODEVICE = getattr(socket, "SO_BINDTODEVICE", 25)
USER_AGENT = "ipshift/1"
_LOOPBACK = {"127.0.0.1", "localhost", "::1"}


class HttpError(OSError):
    """Any transport or protocol failure; the message never contains payload data."""


@dataclass
class HttpResponse:
    status: int
    headers: dict[str, str] = field(default_factory=dict)
    body: bytes = b""

    @property
    def text(self) -> str:
        return self.body.decode("utf-8", "replace")


def open_socket(host: str, port: int, *, family: int = 0, device: str | None = None,
                source_ip: str | None = None, timeout: float = 6.0) -> socket.socket:
    """Connect a TCP socket, optionally pinned to a family / device / source IP."""
    try:
        infos = socket.getaddrinfo(host, port, family, socket.SOCK_STREAM)
    except socket.gaierror as e:
        raise HttpError(f"cannot resolve {host}: {e}") from None
    last: Exception | None = None
    for fam, typ, proto, _canon, addr in infos:
        sock = socket.socket(fam, typ, proto)
        try:
            sock.settimeout(timeout)
            if device:
                sock.setsockopt(socket.SOL_SOCKET, SO_BINDTODEVICE, device.encode() + b"\0")
            if source_ip:
                sock.bind((source_ip, 0))
            sock.connect(addr)
            return sock
        except OSError as e:
            last = e
            sock.close()
    raise HttpError(f"cannot connect to {host}:{port}: {last}") from None


class _PlainConn(http.client.HTTPConnection):
    def __init__(self, host, port, *, opts, timeout):
        super().__init__(host, port, timeout=timeout)
        self._opts = opts

    def connect(self):
        self.sock = open_socket(self.host, self.port, timeout=self.timeout, **self._opts)


class _TlsConn(http.client.HTTPSConnection):
    def __init__(self, host, port, *, opts, timeout, context):
        super().__init__(host, port, timeout=timeout, context=context)
        self._opts = opts

    def connect(self):
        raw = open_socket(self.host, self.port, timeout=self.timeout, **self._opts)
        try:
            self.sock = self._context.wrap_socket(raw, server_hostname=self.host)
        except (ssl.SSLError, OSError):
            raw.close()
            raise


def request(method: str, url: str, *, body: bytes | None = None, headers: dict | None = None,
            family: int = 0, device: str | None = None, source_ip: str | None = None,
            timeout: float = 6.0, max_bytes: int = 65536, cafile: str | None = None) -> HttpResponse:
    try:
        parts = urlsplit(url)
    except ValueError:
        raise HttpError("malformed URL") from None
    host = parts.hostname
    if not host or parts.scheme not in ("https", "http"):
        raise HttpError("unsupported URL")
    if parts.scheme == "http" and host not in _LOOPBACK:
        raise HttpError("plain http is only allowed for loopback hosts")
    port = parts.port or (443 if parts.scheme == "https" else 80)
    path = (parts.path or "/") + (f"?{parts.query}" if parts.query else "")
    opts = {"family": family, "device": device, "source_ip": source_ip}
    hdrs = {"User-Agent": USER_AGENT, "Accept": "*/*", "Connection": "close"}
    hdrs.update(headers or {})
    conn: http.client.HTTPConnection
    try:
        if parts.scheme == "https":
            ctx = ssl.create_default_context(cafile=cafile)
            conn = _TlsConn(host, port, opts=opts, timeout=timeout, context=ctx)
        else:
            conn = _PlainConn(host, port, opts=opts, timeout=timeout)
        try:
            conn.request(method, path, body=body, headers=hdrs)
            resp = conn.getresponse()
            data = resp.read(max_bytes + 1)
            if len(data) > max_bytes:
                raise HttpError("response too large")
            return HttpResponse(resp.status, {k.lower(): v for k, v in resp.getheaders()}, data)
        finally:
            conn.close()
    except HttpError:
        raise
    except (OSError, http.client.HTTPException, ssl.SSLError) as e:
        raise HttpError(f"{type(e).__name__}: {e}") from None


def http_get(url: str, **kw) -> HttpResponse:
    return request("GET", url, **kw)


def http_post(url: str, body: bytes, content_type: str, **kw) -> HttpResponse:
    headers = dict(kw.pop("headers", None) or {})
    headers["Content-Type"] = content_type
    return request("POST", url, body=body, headers=headers, **kw)
