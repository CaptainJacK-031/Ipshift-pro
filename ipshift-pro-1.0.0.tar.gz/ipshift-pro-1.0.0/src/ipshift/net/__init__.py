"""Network probing: public-IP echo lookups, local interface/route inspection,
a DNS wire client and a DoH bootstrap resolver.  Standard library only."""
