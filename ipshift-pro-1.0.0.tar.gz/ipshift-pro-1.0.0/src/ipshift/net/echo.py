"""Public-IP detection with quorum.

A single echo service can be down, wrong, or hostile.  We ask a small random
subset first (``quorum`` services, in parallel) and only widen the question when
they disagree or fail.  That keeps the number of third parties who learn the
exit address small, while still never trusting one voice.

An address is reported as ``ip`` only when at least ``quorum`` services agree;
otherwise ``ip`` is None and the best guess is exposed as ``candidate`` so a UI
can show it as *unverified*.
"""
from __future__ import annotations

import concurrent.futures as cf
import ipaddress
import random
import socket
import time
from collections import Counter
from dataclasses import dataclass, field
from urllib.parse import urlsplit

from .http import HttpError, http_get

FAMILY = {4: socket.AF_INET, 6: socket.AF_INET6}


@dataclass
class EchoResult:
    family: int
    ip: str | None = None             # verified by quorum
    candidate: str | None = None      # most common answer even without quorum
    agree: int = 0
    asked: int = 0
    answers: dict[str, str] = field(default_factory=dict)  # service host -> ip | "error: ..."
    error: str | None = None
    ts: float = field(default_factory=time.time)
    elapsed_ms: int = 0

    @property
    def ok(self) -> bool:
        return self.ip is not None

    def to_dict(self) -> dict:
        return {"family": self.family, "ip": self.ip, "candidate": self.candidate,
                "agree": self.agree, "asked": self.asked, "answers": dict(self.answers),
                "error": self.error, "ts": self.ts, "elapsed_ms": self.elapsed_ms}


def parse_echo_body(text: str, family: int) -> str | None:
    """First non-empty line of the body, if it is an IP of the wanted family."""
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            ip = ipaddress.ip_address(line)
        except ValueError:
            return None
        return str(ip) if ip.version == family else None
    return None


class EchoResolver:
    """``privacy`` is the live PrivacyConfig section, so config changes apply at once."""

    def __init__(self, privacy, *, fetch=http_get, rng: random.Random | None = None):
        self.privacy = privacy
        self._fetch = fetch
        self._rng = rng or random.SystemRandom()

    def services(self, family: int) -> list[str]:
        return list(self.privacy.ip_echo_v4 if family == 4 else self.privacy.ip_echo_v6)

    def _ask_one(self, url: str, family: int, device, source_ip, timeout, cafile) -> str:
        try:
            resp = self._fetch(url, family=FAMILY[family], device=device, source_ip=source_ip,
                               timeout=timeout, max_bytes=512, cafile=cafile)
        except HttpError as e:
            return "error: " + str(e)[:120]
        if resp.status != 200:
            return f"error: HTTP {resp.status}"
        ip = parse_echo_body(resp.text, family)
        return ip or "error: unparseable answer"

    def _ask_many(self, urls: list[str], family: int, device, source_ip, timeout, cafile) -> dict[str, str]:
        out: dict[str, str] = {}
        if not urls:
            return out
        ex = cf.ThreadPoolExecutor(max_workers=len(urls), thread_name_prefix="echo")
        futs = {ex.submit(self._ask_one, u, family, device, source_ip, timeout, cafile): u for u in urls}
        done, pending = cf.wait(futs, timeout=timeout + 2)
        for f in done:
            out[urlsplit(futs[f]).hostname or futs[f]] = f.result()
        for f in pending:
            out[urlsplit(futs[f]).hostname or futs[f]] = "error: timeout"
        ex.shutdown(wait=False, cancel_futures=True)
        return out

    def lookup(self, family: int = 4, *, device: str | None = None, source_ip: str | None = None,
               timeout: float | None = None, quorum: int | None = None,
               cafile: str | None = None) -> EchoResult:
        t0 = time.monotonic()
        res = EchoResult(family=family)
        urls = self.services(family)
        if not urls:
            res.error = "no echo services configured"
            return res
        timeout = float(timeout or self.privacy.http_timeout)
        need = max(1, min(int(quorum or self.privacy.quorum), len(urls)))
        self._rng.shuffle(urls)
        batches = [urls[:need], urls[need:]]          # ask few first, widen only if needed
        answers: dict[str, str] = {}
        for batch in batches:
            answers.update(self._ask_many(batch, family, device, source_ip, timeout, cafile))
            votes = Counter(v for v in answers.values() if not v.startswith("error:"))
            if votes:
                top, n = votes.most_common(1)[0]
                res.candidate, res.agree = top, n
                if n >= need:
                    res.ip = top
                    break
        res.answers, res.asked = answers, len(answers)
        if res.ip is None:
            if res.candidate is None:
                res.error = "no echo service answered (" + _summarise(answers) + ")"
            else:
                res.error = f"no consensus: {res.agree}/{need} agree"
        res.elapsed_ms = int((time.monotonic() - t0) * 1000)
        res.ts = time.time()
        return res

    def lookup_both(self, **kw) -> dict[int, EchoResult]:
        with cf.ThreadPoolExecutor(max_workers=2, thread_name_prefix="echo2") as ex:
            f4 = ex.submit(self.lookup, 4, **kw)
            f6 = ex.submit(self.lookup, 6, **kw)
            return {4: f4.result(), 6: f6.result()}


def _reason(answer: str) -> str:
    """A short, plain cause for one failed echo-service answer."""
    if not answer.startswith("error:"):
        return "ok"
    text = answer.split(":", 1)[1].strip().lower()
    if text.startswith("cannot resolve"):
        return "name lookup failed"
    if text.startswith("cannot connect") or "refused" in text or "unreachable" in text:
        return "connection failed"
    if "timeout" in text or "timed out" in text:
        return "timed out"
    if text.startswith("http "):
        return text.upper().replace("HTTP ", "HTTP ", 1)
    return " ".join(text.split(" ")[:3]) or "failed"


def _summarise(answers: dict[str, str]) -> str:
    kinds = Counter(_reason(v) for v in answers.values())
    return ", ".join(f"{k} x{n}" for k, n in kinds.most_common(3)) or "no attempts"
