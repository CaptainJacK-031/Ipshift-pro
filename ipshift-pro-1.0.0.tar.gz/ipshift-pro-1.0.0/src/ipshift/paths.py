"""Filesystem layout.

As root (the daemon) everything lives in the usual system locations.  An
unprivileged process (CLI/GUI, or a developer run) gets XDG locations.  The
``IPSHIFT_ROOT`` environment variable relocates the whole tree, which the test
suite uses to stay out of the real system.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

SYSTEM_SOCKET = Path("/run/ipshift/ipshift.sock")


@dataclass(frozen=True)
class Paths:
    config_file: Path
    state_dir: Path
    run_dir: Path
    log_dir: Path

    @property
    def profiles_dir(self) -> Path:
        return self.state_dir / "profiles"

    @property
    def history_db(self) -> Path:
        return self.state_dir / "history.db"

    @property
    def backup_dir(self) -> Path:
        return self.state_dir / "backup"

    @property
    def socket(self) -> Path:
        return self.run_dir / "ipshift.sock"

    @property
    def pidfile(self) -> Path:
        return self.run_dir / "ipshiftd.pid"

    @property
    def runtime_dir(self) -> Path:
        """Generated tunnel configs (contain private keys) - tmpfs on real systems."""
        return self.run_dir / "runtime"

    @property
    def log_file(self) -> Path:
        return self.log_dir / "ipshift.log"


def default_paths(env: Mapping[str, str] | None = None, euid: int | None = None) -> Paths:
    env = os.environ if env is None else env
    euid = os.geteuid() if euid is None else euid
    root = env.get("IPSHIFT_ROOT")
    if root:
        r = Path(root)
        return Paths(r / "etc" / "config.json", r / "var", r / "run", r / "log")
    if euid == 0:
        return Paths(
            Path("/etc/ipshift/config.json"),
            Path("/var/lib/ipshift"),
            Path("/run/ipshift"),
            Path("/var/log/ipshift"),
        )
    home = Path(env.get("HOME") or "~").expanduser()
    cfg = Path(env.get("XDG_CONFIG_HOME") or home / ".config") / "ipshift" / "config.json"
    data = Path(env.get("XDG_DATA_HOME") or home / ".local" / "share") / "ipshift"
    state = Path(env.get("XDG_STATE_HOME") or home / ".local" / "state") / "ipshift"
    runtime = env.get("XDG_RUNTIME_DIR")
    run = Path(runtime) / "ipshift" if runtime else Path(f"/tmp/ipshift-{euid}")
    return Paths(cfg, data, run, state / "log")


def client_socket_candidates(env: Mapping[str, str] | None = None) -> list[Path]:
    """Where a client should look for the daemon socket, most specific first."""
    env = os.environ if env is None else env
    out: list[Path] = []
    explicit = env.get("IPSHIFT_SOCKET")
    if explicit:
        out.append(Path(explicit))
    if env.get("IPSHIFT_ROOT"):
        out.append(default_paths(env).socket)
    else:
        out.append(SYSTEM_SOCKET)
        user_sock = default_paths(env, euid=max(os.geteuid(), 1)).socket
        if user_sock not in out:
            out.append(user_sock)
    seen: set[Path] = set()
    uniq = []
    for p in out:
        if p not in seen:
            seen.add(p)
            uniq.append(p)
    return uniq
