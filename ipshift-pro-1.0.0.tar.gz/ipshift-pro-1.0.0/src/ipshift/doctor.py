"""``ipshift doctor``: is this machine ready to run IPShift, and if not, what is missing?

Read-only: it looks at programs, kernel features, files and permissions and never changes
anything (it does not even start a tunnel).  It works with or without the daemon.
"""
from __future__ import annotations

import grp
import os
import platform
import pwd
import stat
import sys
import time
from pathlib import Path

from .sysutil import Runner, which

STATUSES = ("ok", "info", "warn", "fail")


def _c(cid: str, title: str, status: str, detail: str, hint: str | None = None) -> dict:
    return {"id": cid, "title": title, "status": status, "detail": detail, "hint": hint}


def _read(path: str | Path) -> str:
    try:
        return Path(path).read_text(errors="replace")
    except OSError:
        return ""


def os_name(os_release: str | Path) -> tuple[str, str]:
    """(pretty name, id) from os-release."""
    fields = {}
    for line in _read(os_release).splitlines():
        if "=" in line and not line.startswith("#"):
            k, _, v = line.partition("=")
            fields[k.strip()] = v.strip().strip('"')
    return fields.get("PRETTY_NAME") or fields.get("NAME") or platform.system(), fields.get("ID", "").lower()


def run_doctor(cfg, paths, *, runner=None, net=None, store=None, simulate: bool = False,
               os_release: str | Path = "/etc/os-release", dev_tun: str | Path = "/dev/net/tun",
               proc_sys: str | Path = "/proc/sys", resolv: str | Path = "/etc/resolv.conf",
               sys_module: str | Path = "/sys/module", clock=time.time, find=which) -> dict:
    runner = runner or Runner()
    out: list[dict] = []
    add = out.append
    real = not simulate

    if simulate:
        add(_c("simulation", "Simulation mode", "info",
               "The daemon is running against a simulated network: the checks about programs, kernel features "
               "and system files are skipped because nothing real is touched"))
    else:
        # ---- who we are ----------------------------------------------------------------------
        if os.geteuid() == 0:
            add(_c("root", "Privileges", "ok", "Running as root"))
        else:
            add(_c("root", "Privileges", "warn", "Not running as root: some checks need it and the daemon must be root",
                   "run: sudo ipshift doctor"))
        name, ident = os_name(os_release)
        if ident == "kali":
            add(_c("os", "Operating system", "ok", name))
        elif ident in ("debian", "ubuntu", "parrot", "linuxmint") or "debian" in _read(os_release).lower():
            add(_c("os", "Operating system", "info", f"{name} (built for Kali Linux; Debian-based systems work the same way)"))
        else:
            add(_c("os", "Operating system", "warn", f"{name}: IPShift is built and tested for Kali Linux",
                   "package names in the hints below may differ"))
        if sys.version_info >= (3, 10):
            add(_c("python", "Python", "ok", platform.python_version()))
        else:
            add(_c("python", "Python", "fail", f"{platform.python_version()} is too old (3.10 or newer is needed)"))
        clock_year = time.gmtime(clock()).tm_year
        if clock_year >= 2024:
            add(_c("clock", "System clock", "ok", f"year {clock_year}"))
        else:
            add(_c("clock", "System clock", "fail", f"the clock says year {clock_year}: VPN certificates will be rejected",
                   "set the time: sudo timedatectl set-ntp true"))

        # ---- programs ----------------------------------------------------------------------------
        nft = find(cfg.killswitch.nft_bin)
        if not nft:
            add(_c("nft", "nftables (kill switch)", "fail", f"{cfg.killswitch.nft_bin!r} was not found: no kill switch is possible",
                   "sudo apt install nftables"))
        else:
            res = runner.run([cfg.killswitch.nft_bin, "list", "tables"], timeout=10) if os.geteuid() == 0 else None
            if res is None:
                add(_c("nft", "nftables (kill switch)", "info", f"{nft} is installed (not tested without root)"))
            elif res.ok:
                add(_c("nft", "nftables (kill switch)", "ok", f"{nft}; the kernel firewall answers"))
            else:
                add(_c("nft", "nftables (kill switch)", "fail",
                       "nft is installed but the kernel did not accept it: " + (res.text.strip()[:120] or "no output"),
                       "load the module: sudo modprobe nf_tables"))
        add(_c("ip", "iproute2", "ok", find(cfg.vpn.ip_bin)) if find(cfg.vpn.ip_bin)
            else _c("ip", "iproute2", "fail", f"{cfg.vpn.ip_bin!r} was not found", "sudo apt install iproute2"))

        protos = {p.protocol for p in store.list()} if store else set()
        ovpn = find(cfg.vpn.openvpn_bin)
        if ovpn:
            add(_c("openvpn", "OpenVPN", "ok", ovpn))
        else:
            add(_c("openvpn", "OpenVPN", "warn" if "openvpn" in protos else "info",
                   f"{cfg.vpn.openvpn_bin!r} was not found: OpenVPN profiles cannot connect",
                   "sudo apt install openvpn"))
        wg = find(cfg.vpn.wg_bin)
        has_module = (Path(sys_module) / "wireguard").exists()
        if not has_module and find("modinfo"):
            has_module = runner.run(["modinfo", "wireguard"], timeout=5).ok
        if wg and has_module:
            add(_c("wireguard", "WireGuard", "ok", f"{wg}; kernel support present"))
        elif wg:
            add(_c("wireguard", "WireGuard", "warn" if "wireguard" in protos else "info",
                   "the 'wg' tool is installed but kernel WireGuard support was not found",
                   "sudo apt install wireguard (needs a kernel with WireGuard, 5.6 or newer)"))
        else:
            add(_c("wireguard", "WireGuard", "warn" if "wireguard" in protos else "info",
                   f"{cfg.vpn.wg_bin!r} was not found: WireGuard profiles cannot connect "
                   "(WireGuard is the only protocol that can switch servers in about a second)",
                   "sudo apt install wireguard-tools"))
        if Path(dev_tun).exists():
            add(_c("tun", "TUN device", "ok", str(dev_tun)))
        else:
            add(_c("tun", "TUN device", "warn", f"{dev_tun} is missing: OpenVPN cannot create its tunnel",
                   "sudo modprobe tun"))
        user = cfg.vpn.openvpn_user
        if user:
            try:
                pwd.getpwnam(user)
                add(_c("openvpn_user", "OpenVPN unprivileged user", "ok", f"OpenVPN drops root to {user!r} after set-up"))
            except KeyError:
                add(_c("openvpn_user", "OpenVPN unprivileged user", "warn",
                       f"user {user!r} does not exist: OpenVPN would keep running as root",
                       "set vpn.openvpn_user to an existing unprivileged user such as 'nobody'"))
        else:
            add(_c("openvpn_user", "OpenVPN unprivileged user", "warn", "vpn.openvpn_user is empty: OpenVPN keeps running as root"))

        # ---- DNS, IPv6, MAC --------------------------------------------------------------------------
        rp = Path(resolv)
        if rp.is_symlink():
            add(_c("resolv", "DNS configuration file", "info",
                   f"{rp} is a symlink to {os.readlink(rp)}: IPShift replaces it while connected and puts it back afterwards"))
        elif rp.exists() and os.access(rp.parent, os.W_OK):
            add(_c("resolv", "DNS configuration file", "ok", f"{rp} can be managed"))
        else:
            add(_c("resolv", "DNS configuration file", "warn", f"{rp} cannot be written: DNS leak protection will not work",
                   "run as root; check that the file is not immutable (lsattr)"))
        v6 = Path(proc_sys) / "net" / "ipv6"
        if not v6.exists():
            add(_c("ipv6", "IPv6", "info", "IPv6 is not enabled in this kernel: nothing to leak"))
        elif os.access(v6 / "conf" / "all" / "disable_ipv6", os.W_OK):
            add(_c("ipv6", "IPv6", "ok", "IPv6 can be switched off on physical interfaces while connected"))
        else:
            add(_c("ipv6", "IPv6", "warn", "the IPv6 switches are not writable: IPv6 leaks cannot be prevented here",
                   "run as root"))
        nm = find("nmcli")
        add(_c("networkmanager", "NetworkManager", "ok", f"{nm}: MAC randomisation can be enabled with 'ipshift harden mac enable'")
            if nm else _c("networkmanager", "NetworkManager", "info",
                          "nmcli was not found: MAC addresses can only be changed by hand ('ipshift harden mac randomize IFACE')"))

        # ---- access control ----------------------------------------------------------------------------
        try:
            g = grp.getgrnam(cfg.daemon.group)
            members = ", ".join(g.gr_mem) or "nobody yet"
            add(_c("group", "Access group", "ok", f"group {g.gr_name!r} exists (members: {members})",
                   None if g.gr_mem else f"add yourself: sudo usermod -aG {g.gr_name} $USER  (then log in again)"))
        except KeyError:
            add(_c("group", "Access group", "warn",
                   f"group {cfg.daemon.group!r} does not exist: only root can use the daemon",
                   f"sudo groupadd {cfg.daemon.group} && sudo usermod -aG {cfg.daemon.group} $USER"))

    # ---- things that matter in simulation too -------------------------------------------------------------
    for label, path, want in (("State directory", paths.state_dir, 0o700), ("Profile store", paths.profiles_dir, 0o700)):
        try:
            mode = stat.S_IMODE(path.stat().st_mode)
        except OSError:
            continue
        if mode & 0o077:
            add(_c("perm_" + path.name, label, "warn", f"{path} is accessible to others (mode {mode:o}): it holds VPN keys",
                   f"chmod {want:o} {path}"))
        else:
            add(_c("perm_" + path.name, label, "ok", f"{path} is private (mode {mode:o})"))
    db = paths.history_db
    if db.exists():
        mode = stat.S_IMODE(db.stat().st_mode)
        add(_c("perm_history", "History database", "ok" if not mode & 0o077 else "warn",
               f"{db} mode {mode:o}", None if not mode & 0o077 else f"chmod 600 {db}"))

    if store is not None:
        profiles = store.list()
        if not profiles:
            add(_c("profiles", "VPN profiles", "warn", "no VPN profile has been imported yet",
                   "import one: ipshift vpn import FILE.conf  (free, paid or your own server)"))
        else:
            usable = [p for p in profiles if p.usable]
            tiers = sorted({p.tier for p in profiles})
            needs = [p.name for p in profiles if p.needs_auth and not p.has_auth]
            detail = f"{len(profiles)} profile(s), {len(usable)} usable now; tiers: {', '.join(tiers)}"
            if needs:
                add(_c("profiles", "VPN profiles", "warn", detail + f"; waiting for credentials: {', '.join(needs[:3])}",
                       "add them: ipshift vpn auth NAME"))
            elif len(usable) < 2:
                add(_c("profiles", "VPN profiles", "info", detail + "; rotation needs at least two usable profiles to change the address"))
            else:
                add(_c("profiles", "VPN profiles", "ok", detail))
    for w in cfg.warnings:
        add(_c("config_warning", "Configuration", "warn", w))
    if store is not None and any(p.tier == "free" for p in store.list()):
        add(_c("free_vpn", "Free VPN profiles", "info",
               "free VPNs can log, inject ads or sell data: prefer paid or self-hosted ones for anything sensitive"))

    summary = {s: sum(1 for c in out if c["status"] == s) for s in STATUSES}
    return {"checks": out, "summary": summary, "simulated": simulate, "ready": summary["fail"] == 0}
