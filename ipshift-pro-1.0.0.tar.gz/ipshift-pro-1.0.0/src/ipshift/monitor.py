"""Background monitor: the part that notices things while nobody is looking.

Every ``daemon.monitor_interval`` seconds it checks

* the physical network (Wi-Fi roam, hotspot switch, cable) and tells the VPN;
* that the firewall rules are still there - and puts them back if not;
* that the tunnel is alive - and brings it back (same server, then another);
* that DNS / IPv6 settings were not undone by NetworkManager or dhclient;
* that the public IP seen through the tunnel is still the one we verified.

Everything that is worth a person's attention is published as an event; events
at level ``warning`` or above are the "alerts" the GUI and CLI show.
"""
from __future__ import annotations

import logging
import threading
import time

from .errors import BusyError, IPShiftError
from .net.local import KIND_NAMES

log = logging.getLogger(__name__)


def describe_network(summary: dict) -> str:
    raw = summary.get("kind")
    kind = summary.get("hotspot") or KIND_NAMES.get(raw or "", raw) or "no connection"
    iface = summary.get("default_iface") or "-"
    primary = next((p["ip"] for p in summary.get("private_ips", []) if p.get("primary")), None)
    return f"{kind} ({iface}" + (f", {primary})" if primary else ")")


class Monitor:
    def __init__(self, cfg, manager, killswitch, hardening, net, bus, hooks):
        """``hooks`` is the engine: protect_wanted(), vpn_wanted(), rotating(), recover_tunnel()."""
        self.cfg = cfg
        self.mgr = manager
        self.ks = killswitch
        self.h = hardening
        self.net = net
        self.bus = bus
        self.hooks = hooks
        self.summary: dict = {}
        self._key = None
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._poke = threading.Event()
        self._worker: threading.Thread | None = None
        self._lost = False
        self._recover_failures = 0
        self._next_recover = 0.0
        self._ip_fail = 0
        self._last_ip_probe = 0.0
        self.last_ip_check: float | None = None         # wall-clock time of the last confirmed exit address
        self._ks_alerted = False

    # ---- lifecycle ---------------------------------------------------------
    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True, name="monitor")
        self._thread.start()

    def stop(self) -> None:
        """Stop checking.  A reconnect that is already running is waited for (callers that
        are shutting down cancel the VPN manager first, which makes that quick)."""
        self._stop.set()
        self._poke.set()
        me = threading.current_thread()
        if self._thread and self._thread is not me:
            self._thread.join(5)
        worker = self._worker
        if worker and worker is not me and worker.is_alive():
            worker.join(15)
            if worker.is_alive():
                log.warning("a reconnect attempt was still running when the monitor stopped")
        self._thread = None

    def poke(self) -> None:
        """Run a cycle now instead of waiting for the next one."""
        self._poke.set()

    def _loop(self) -> None:
        while not self._stop.is_set():
            self.tick()
            self._poke.wait(max(1.0, float(self.cfg.daemon.monitor_interval)))
            self._poke.clear()

    def tick(self) -> None:
        for step in (self._check_network, self._check_firewall, self._check_tunnel,
                     self._check_hardening, self._check_public_ip):
            if self._stop.is_set():
                return
            try:
                step()
            except Exception:
                log.exception("monitor step %s failed", step.__name__)

    def _spawn(self, fn) -> None:
        """Run slow work (reconnecting) off the monitor thread; never two at once."""
        if self._worker and self._worker.is_alive():
            return
        self._worker = threading.Thread(target=fn, daemon=True, name="monitor-worker")
        self._worker.start()

    # ---- network -----------------------------------------------------------
    def _check_network(self) -> None:
        summary = self.net.summary()
        key = self.net.change_key(summary)
        old_key, self._key, self.summary = self._key, key, summary
        if old_key is None or key == old_key:
            return
        where = describe_network(summary)
        self.bus.publish("network_changed", "warning" if self.mgr.conn else "info", network=where,
                         message=f"Network changed: now on {where}")
        action = self.mgr.on_network_change()
        if action == "reconnect" and self.hooks.vpn_wanted():
            self.bus.publish("network_reconnect", "info", message="Reconnecting the VPN on the new network")
            self._spawn(self._recover_now)

    # ---- firewall ----------------------------------------------------------
    def _check_firewall(self) -> None:
        if not (self.cfg.killswitch.enabled and self.hooks.protect_wanted()):
            self._ks_alerted = False
            return
        if self.ks.is_armed():
            if self._ks_alerted:
                self._ks_alerted = False
            return
        if not self._ks_alerted:
            self._ks_alerted = True
            self.bus.publish("killswitch_tampered", "critical",
                             message="The firewall rules were removed by something else; re-arming the kill switch")
        try:
            self.ks.arm()
        except IPShiftError as e:
            self.bus.publish("killswitch_failed", "critical", message=f"Could not re-arm the kill switch: {e}", hint=e.hint)
        else:
            self._ks_alerted = False
            self.bus.publish("killswitch_restored", "warning", message="The kill switch was re-armed")

    # ---- tunnel ------------------------------------------------------------
    def _check_tunnel(self) -> None:
        state = self.mgr.state
        if not self.hooks.vpn_wanted():
            self._lost, self._recover_failures = False, 0
            return
        if state == "connected":
            if self.mgr.tunnel_alive():
                if self._lost:
                    self._lost, self._recover_failures = False, 0
                    self.bus.publish("tunnel_restored", "info", message="The VPN connection is back")
                return
            if not self._lost:
                self._lost = True
                self._next_recover = 0.0
                conn = self.mgr.conn
                self.bus.publish("tunnel_lost", "critical", profile=conn.profile.name if conn else None,
                                 message="The VPN connection dropped; traffic stays blocked until it is restored")
        elif state == "failed" and not self.hooks.rotating():
            self._lost = True                           # the scheduler is not retrying: we do
        else:
            return
        if self.cfg.vpn.auto_reconnect and time.monotonic() >= self._next_recover:
            self._spawn(self._recover_now)

    def _recover_now(self) -> None:
        try:
            self.hooks.recover_tunnel()
        except BusyError:
            return                                      # somebody else is already reconnecting
        except Exception as e:
            self._recover_failures += 1
            delay = min(float(self.cfg.rotation.backoff_max), 2.0 ** self._recover_failures)
            self._next_recover = time.monotonic() + delay
            if not isinstance(e, IPShiftError):
                log.exception("unexpected error while reconnecting")
            if self._recover_failures in (3, 10):
                self.bus.publish("reconnect_failing", "critical", attempts=self._recover_failures,
                                 message=f"Still cannot restore the VPN after {self._recover_failures} attempts: {e}",
                                 hint=getattr(e, "hint", None))
        else:
            self._lost, self._recover_failures = False, 0
            self.bus.publish("tunnel_restored", "info", message="The VPN connection is back")

    # ---- hardening & public IP ---------------------------------------------
    def _check_hardening(self) -> None:
        if self.mgr.state != "connected":
            return
        fixed = self.h.refresh()
        if fixed:
            self.bus.publish("hardening_repaired", "info", message="DNS/IPv6 settings were changed by another program; restored",
                             **{k: v for k, v in fixed.items()})

    def _check_public_ip(self) -> None:
        conn = self.mgr.conn
        every = float(self.cfg.daemon.ip_refresh_interval)
        if self.mgr.state != "connected" or conn is None or time.monotonic() - self._last_ip_probe < every:
            return
        if time.time() - conn.since < 5 or self.mgr.status().get("busy"):
            return                                      # a rotation just verified it / is verifying it
        self._last_ip_probe = time.monotonic()
        res = self.mgr.probe_exit_ip(4)
        if res.ok:
            self._ip_fail = 0
            self.last_ip_check = time.time()
            if res.ip != conn.exit_ip:
                self.bus.publish("ip_changed", "warning", old=conn.exit_ip, new=res.ip,
                                 message=f"The public IP changed without a rotation: {conn.exit_ip} -> {res.ip}")
                conn.exit_ip = res.ip
            return
        self._ip_fail += 1
        if self._ip_fail == 3:
            self.bus.publish("ip_unverifiable", "warning",
                             message="The public IP could not be confirmed three times in a row; the tunnel may not be passing traffic")
