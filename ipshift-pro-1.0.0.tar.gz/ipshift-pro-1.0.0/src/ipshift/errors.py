"""Exception hierarchy.

Every error carries a short machine-readable ``code`` that the IPC layer sends
to clients, and an optional human ``hint`` telling the user how to fix it.
"""
from __future__ import annotations


class IPShiftError(Exception):
    code = "error"

    def __init__(self, message: str = "", *, hint: str | None = None):
        super().__init__(message)
        self.message = message
        self.hint = hint

    def __str__(self) -> str:  # pragma: no cover - trivial
        return self.message or self.__class__.__name__

    def to_dict(self) -> dict:
        return {"code": self.code, "message": self.message, "hint": self.hint}


class ConfigError(IPShiftError):
    code = "config"


class PrivilegeError(IPShiftError):
    code = "privilege"


class DependencyError(IPShiftError):
    code = "dependency"


class ProfileError(IPShiftError):
    code = "profile"


class VpnError(IPShiftError):
    code = "vpn"


class VpnTimeout(VpnError):
    code = "vpn_timeout"


class VerificationError(VpnError):
    code = "verify"


class IPUnchanged(VerificationError):
    """The tunnel works but the exit address is the same as before."""
    code = "unchanged"


class LeakDetected(VerificationError):
    """Traffic is not leaving through the tunnel (e.g. exit IP equals the real IP)."""
    code = "leak"


class KillSwitchError(IPShiftError):
    code = "killswitch"


class HardeningError(IPShiftError):
    code = "hardening"


class BusyError(IPShiftError):
    code = "busy"


class NotFound(IPShiftError):
    code = "not_found"


class DaemonUnavailable(IPShiftError):
    code = "daemon_unavailable"


class ProtocolError(IPShiftError):
    code = "protocol"


class AuthError(IPShiftError):
    code = "auth"


class InternalError(IPShiftError):
    """A bug in the daemon: the details are in its log, never sent to the client."""
    code = "internal"


_BY_CODE = {
    cls.code: cls
    for cls in (
        IPShiftError, ConfigError, PrivilegeError, DependencyError, ProfileError,
        VpnError, VpnTimeout, VerificationError, IPUnchanged, LeakDetected, KillSwitchError, HardeningError, BusyError,
        NotFound, DaemonUnavailable, ProtocolError, AuthError, InternalError,
    )
}


def from_dict(d: dict) -> IPShiftError:
    """Rebuild an exception from :meth:`IPShiftError.to_dict` output."""
    cls = _BY_CODE.get(d.get("code", "error"), IPShiftError)
    return cls(d.get("message", ""), hint=d.get("hint"))
