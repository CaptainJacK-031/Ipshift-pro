"""Rotation scheduler.

* The interval is the time between the *starts* of two rotations and can never
  be below one second - checked here, in the configuration and at the IPC layer.
* A rotation is not "done" when the timer fires; it is done when the new tunnel
  is up *and* the new public IP has been verified (the manager does that).  If
  that takes longer than the interval, the ticks that passed meanwhile are
  skipped and counted - rotations never overlap or queue up.
* A failed rotation is retried quickly (1 s, 2 s, 4 s ... up to the interval)
  with a different profile, because while it fails the kill switch keeps you
  offline.  After ``max_failures`` in a row a critical alert is raised.
"""
from __future__ import annotations

import logging
import math
import random
import threading
import time

from .config import MIN_INTERVAL, STRATEGIES
from .errors import BusyError, ConfigError, IPShiftError, IPUnchanged, NotFound, ProfileError

log = logging.getLogger(__name__)


def check_interval(value, floor: float = MIN_INTERVAL) -> float:
    try:
        v = float(value)
    except (TypeError, ValueError):
        raise ConfigError("the rotation interval must be a number of seconds") from None
    if not math.isfinite(v):
        raise ConfigError("the rotation interval must be a finite number")
    if v < floor:
        raise ConfigError(f"the minimum rotation interval is {floor:g} second",
                          hint="a VPN needs time to reconnect and the new IP has to be verified")
    return v


class NothingToRotate(ProfileError):
    """Only the current profile (or none) is usable: there is nowhere to rotate to."""


class Selector:
    """Chooses the next profile according to the configured strategy."""

    def __init__(self, store, rotation_cfg, rng: random.Random | None = None):
        self.store = store
        self.cfg = rotation_cfg
        self._rng = rng or random.SystemRandom()
        self._cursor: str | None = None            # round-robin position

    def _allowed_ids(self) -> set[str] | None:
        if not self.cfg.profiles:
            return None
        ids: set[str] = set()
        for ref in self.cfg.profiles:
            try:
                ids.add(self.store.get(ref).id)
            except (NotFound, ProfileError) as e:
                log.warning("rotation.profiles entry %r ignored: %s", ref, e)
        return ids

    def candidates(self) -> list:
        allowed = self._allowed_ids()
        out = self.store.list(tiers=self.cfg.tiers or None, usable=True)
        return [p for p in out if allowed is None or p.id in allowed]

    def pick(self, current, tried: set[str] | None = None):
        """Next profile, or None when there is nothing sensible to switch to."""
        cands = self.candidates()
        others = [p for p in cands if not current or p.id != current.id]
        if not others:
            return None
        pool = [p for p in others if p.id not in (tried or set())] or others
        strategy = self.cfg.strategy if self.cfg.strategy in STRATEGIES else "diverse"
        if strategy == "round-robin":
            ordered = sorted(pool, key=lambda p: p.id)
            after = [p for p in ordered if self._cursor is None or p.id > self._cursor]
            choice = (after or ordered)[0]
        elif strategy == "random":
            choice = self._rng.choice(pool)
        elif strategy == "lru":
            choice = min(pool, key=lambda p: (p.last_used or 0.0, self._rng.random()))
        else:                                       # diverse: change provider/country, then least recently used
            def score(p):
                s = 0
                if current is not None:
                    s += 1 if p.provider and p.provider == current.provider else 0
                    s += 2 if p.country and p.country == current.country else 0
                return (s, p.last_used or 0.0, self._rng.random())
            choice = min(pool, key=score)
        self._cursor = choice.id
        return choice


class RotationScheduler:
    def __init__(self, cfg, manager, store, bus, *, clock=time.monotonic, rng: random.Random | None = None):
        self.cfg = cfg
        self.mgr = manager
        self.bus = bus
        self.store = store
        self._clock = clock
        self._rng = rng or random.SystemRandom()
        self.selector = Selector(store, cfg.rotation, self._rng)
        self.floor = MIN_INTERVAL
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._cv = threading.Condition()
        self._rearm = False
        self._attempt_lock = threading.Lock()
        self._next_due: float | None = None
        self._last_start: float | None = None
        self._tried: set[str] = set()
        self._stalled = False
        self._warned_single = False
        self.ticks = self.ok = self.failed = self.unchanged = self.skipped = 0
        self.consecutive_failures = self.consecutive_unchanged = 0
        self.last: dict = {}

    # ---- control -----------------------------------------------------------
    @property
    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    @property
    def interval(self) -> float:
        return float(self.cfg.rotation.interval)

    def start(self, interval: float | None = None, *, immediate: bool = True) -> None:
        if interval is not None:
            self.cfg.rotation.interval = check_interval(interval, self.floor)
        else:
            check_interval(self.cfg.rotation.interval, self.floor)
        if self.running:
            self.set_interval(self.cfg.rotation.interval)
            return
        self._stop.clear()
        self._rearm = False
        self._tried.clear()
        self._stalled = False
        self.consecutive_failures = self.consecutive_unchanged = 0
        self._thread = threading.Thread(target=self._loop, args=(immediate,), daemon=True, name="rotation")
        self._thread.start()
        self.bus.publish("rotation_started", interval=self.interval, strategy=self.cfg.rotation.strategy)

    def stop(self, timeout: float = 35.0, *, cancel: bool = True) -> None:
        """Stop rotating.  ``cancel``: also abort a connection attempt that is under way (the right thing
        when the person is leaving or connecting somewhere else); without it the attempt finishes first,
        so that stopping only the rotation does not take away the connection."""
        t = self._thread
        if t is None:
            return
        self._stop.set()
        if cancel:
            self.mgr.cancel()
        with self._cv:
            self._cv.notify_all()
        if t is not threading.current_thread():
            t.join(timeout)
        self._thread = None
        self._next_due = None
        self.bus.publish("rotation_stopped")

    def set_interval(self, value: float) -> None:
        self.cfg.rotation.interval = check_interval(value, self.floor)
        with self._cv:
            self._rearm = True
            self._cv.notify_all()
        self.bus.publish("interval_changed", interval=self.interval)

    def rotate_now(self) -> object:
        """Rotate immediately (also works while the scheduler is stopped)."""
        if not self._attempt_lock.acquire(blocking=False):
            raise BusyError("a rotation is already in progress")
        try:
            res = self._rotate()
        finally:
            self._attempt_lock.release()
        self._last_start = self._clock()
        if self.running:
            with self._cv:
                self._rearm = True
                self._cv.notify_all()
        return res

    # ---- one rotation ------------------------------------------------------
    def _reason(self, current) -> str:
        if current is not None:
            return "rotate"
        return "retry" if self.consecutive_failures else "start"

    def _rotate(self):
        current = self.mgr.conn.profile if self.mgr.conn else None
        nxt = self.selector.pick(current, self._tried)
        if nxt is None:
            raise NothingToRotate("no other usable VPN profile to rotate to",
                                  hint="import more profiles (ipshift vpn import) or relax rotation.tiers / rotation.profiles")
        return self.mgr.activate(nxt.id, reason=self._reason(current))

    def _attempt(self) -> str:
        """One rotation attempt; returns ok | unchanged | failed | busy | idle."""
        if not self._attempt_lock.acquire(blocking=False):
            self.skipped += 1
            return "busy"
        try:
            t0 = time.time()
            try:
                res = self._rotate()
            except BusyError:
                self.skipped += 1
                return "busy"
            except NothingToRotate as e:
                if not self._warned_single:
                    self._warned_single = True
                    self.bus.publish("rotation_idle", "warning", message=str(e), hint=e.hint)
                return "idle"
            except IPUnchanged as e:
                self.ticks += 1
                return self._on_unchanged(e)
            except Exception as e:                       # includes bugs: they must not kill the rotation thread
                if not isinstance(e, (IPShiftError, OSError)):
                    log.exception("unexpected error during rotation")
                self.ticks += 1
                return self._on_failure(e)
            self.ticks += 1
            self._warned_single = False
            self._on_success(res, t0)
            return "ok"
        finally:
            self._attempt_lock.release()

    def _on_success(self, res, t0: float) -> None:
        self.ok += 1
        self.consecutive_unchanged = 0
        self._tried.clear()
        if self._stalled:
            self._stalled = False
            self.bus.publish("rotation_recovered", after_failures=self.consecutive_failures)
        self.consecutive_failures = 0
        self.last = {"status": "success", "profile": res.profile_name, "ip": res.exit_ip, "ms": res.duration_ms,
                     "via": res.via, "at": t0, "error": None}

    def _name(self, pid: str | None) -> str | None:
        if not pid:
            return None
        try:
            return self.store.get(pid).name
        except (NotFound, ProfileError):
            return pid

    def _on_unchanged(self, e: Exception) -> str:
        self.unchanged += 1
        self.consecutive_unchanged += 1
        conn = self.mgr.conn
        if conn is not None:
            self._tried.add(conn.profile.id)
        self.last = {"status": "unchanged", "profile": conn.profile.name if conn else None,
                     "ip": conn.exit_ip if conn else None, "ms": None, "at": time.time(), "error": str(e)}
        if self.consecutive_unchanged == 3:
            self.bus.publish("rotation_unchanged_streak", "warning", count=3,
                             message="three rotations in a row ended on the same IP address",
                             hint="your profiles may share exit addresses; add servers from other providers")
        return "unchanged"

    def _on_failure(self, e: Exception) -> str:
        self.failed += 1
        self.consecutive_failures += 1
        cur = self.mgr.last_profile_id
        if cur:
            self._tried.add(cur)
        self.last = {"status": "failed", "profile": self._name(cur), "ip": None, "ms": None, "at": time.time(),
                     "error": str(e) or e.__class__.__name__}
        if self.consecutive_failures >= max(1, int(self.cfg.rotation.max_failures)) and not self._stalled:
            self._stalled = True
            self.bus.publish("rotation_stalled", "critical", failures=self.consecutive_failures,
                             message=f"{self.consecutive_failures} rotations in a row failed: {e}",
                             hint=getattr(e, "hint", None))
        return "failed"

    # ---- timing ------------------------------------------------------------
    def _cycle_interval(self) -> float:
        base = self.interval
        j = float(self.cfg.rotation.jitter_pct or 0.0)
        if j > 0:
            base *= 1 + self._rng.uniform(-j, j) / 100.0
        return max(self.floor, base)

    def step(self) -> float:
        """Run one rotation and return how long to wait before the next one starts."""
        start = self._clock()
        self._last_start = start
        interval = self._cycle_interval()
        outcome = self._attempt()
        end = self._clock()
        if outcome == "failed":
            backoff = min(float(self.cfg.rotation.backoff_max), 2.0 ** (self.consecutive_failures - 1))
            return max(0.0, min(interval, backoff))
        due = start + interval
        if end > due:                                   # the rotation outlasted one or more ticks
            missed = int((end - due) // interval) + 1
            self.skipped += missed
            due += missed * interval
            self.bus.publish("rotation_overrun", "info", skipped=missed, took=round(end - start, 3))
        return max(0.0, due - end)

    def _loop(self, immediate: bool) -> None:
        delay = 0.0 if immediate else self._cycle_interval()
        while not self._stop.is_set():
            deadline = self._clock() + delay
            self._next_due = deadline
            with self._cv:
                while not self._stop.is_set() and not self._rearm:
                    left = deadline - self._clock()
                    if left <= 0:
                        break
                    self._cv.wait(left)
                rearmed, self._rearm = self._rearm, False
            if self._stop.is_set():
                return
            if rearmed:                                  # interval changed or a manual rotation happened
                base = self._last_start if self._last_start is not None else self._clock()
                delay = max(0.0, base + self._cycle_interval() - self._clock())
                continue
            delay = self.step()

    # ---- inspection --------------------------------------------------------
    def status(self) -> dict:
        nd = self._next_due
        return {"running": self.running, "interval": self.interval, "strategy": self.cfg.rotation.strategy,
                "next_in": round(max(0.0, nd - self._clock()), 3) if (self.running and nd is not None) else None,
                "ticks": self.ticks, "ok": self.ok, "failed": self.failed, "unchanged": self.unchanged,
                "skipped": self.skipped, "consecutive_failures": self.consecutive_failures,
                "stalled": self._stalled, "last": dict(self.last), "minimum_interval": self.floor}
