"""Thread-safe publish/subscribe bus used by the engine, the daemon (to stream
events to clients) and the rotation scheduler."""
from __future__ import annotations

import logging
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Callable

log = logging.getLogger(__name__)

LEVELS = {"debug": 10, "info": 20, "warning": 30, "error": 40, "critical": 50}


@dataclass
class Event:
    kind: str
    level: str = "info"
    data: dict = field(default_factory=dict)
    ts: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return {"kind": self.kind, "level": self.level, "data": self.data, "ts": self.ts}

    @property
    def is_alert(self) -> bool:
        return LEVELS.get(self.level, 20) >= LEVELS["warning"]


class EventBus:
    def __init__(self, backlog: int = 200):
        self._subs: list[Callable[[Event], None]] = []
        self._lock = threading.Lock()
        self._recent: deque[Event] = deque(maxlen=backlog)

    def subscribe(self, fn: Callable[[Event], None]) -> Callable[[], None]:
        with self._lock:
            self._subs.append(fn)

        def unsubscribe() -> None:
            with self._lock:
                if fn in self._subs:
                    self._subs.remove(fn)

        return unsubscribe

    def publish(self, kind: str, level: str = "info", **data) -> Event:
        ev = Event(kind=kind, level=level, data=data)
        with self._lock:
            self._recent.append(ev)
            subs = list(self._subs)
        for fn in subs:
            try:
                fn(ev)
            except Exception:  # a broken subscriber must never break the engine
                log.exception("event subscriber failed")
        return ev

    def recent(self, n: int = 50, min_level: str = "debug") -> list[Event]:
        floor = LEVELS.get(min_level, 10)
        with self._lock:
            items = [e for e in self._recent if LEVELS.get(e.level, 20) >= floor]
        return items[-n:]
