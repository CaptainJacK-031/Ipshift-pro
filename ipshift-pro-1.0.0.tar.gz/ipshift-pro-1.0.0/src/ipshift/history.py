"""SQLite history of IP rotations and alerts.

Privacy properties
------------------
* The database file is created 0600 inside a 0700 directory.
* ``secure_delete`` is ON, so pruned/cleared rows are overwritten, not just unlinked.
* ``path=None`` keeps everything in memory (nothing ever touches the disk).
* Optional IP masking stores ``203.0.113.x`` instead of the full address.
* Rows older than the retention period are removed on open and every hour.
"""
from __future__ import annotations

import csv
import os
import sqlite3
import threading
import time
from pathlib import Path
from typing import IO

from .logging_setup import mask_ip
from .sysutil import ensure_private_dir

SCHEMA_VERSION = 1
_SCHEMA = """
CREATE TABLE IF NOT EXISTS rotations(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts REAL NOT NULL,
  profile_id TEXT, profile_name TEXT, kind TEXT, tier TEXT,
  old_ip TEXT, new_ip TEXT,
  duration_ms INTEGER,
  status TEXT NOT NULL,
  reason TEXT,
  error TEXT
);
CREATE INDEX IF NOT EXISTS idx_rot_ts ON rotations(ts);
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts REAL NOT NULL,
  level TEXT NOT NULL,
  kind TEXT NOT NULL,
  message TEXT
);
CREATE INDEX IF NOT EXISTS idx_evt_ts ON events(ts);
"""

ROTATION_COLUMNS = ("id", "ts", "profile_id", "profile_name", "kind", "tier", "old_ip",
                    "new_ip", "duration_ms", "status", "reason", "error")


class History:
    def __init__(self, path: Path | None, *, retention_days: int = 30, mask_ips: bool = False,
                 max_rows: int = 200_000):
        self.path = Path(path) if path else None
        self.retention_days = retention_days
        self.max_rows = max_rows
        self.mask_ips = mask_ips
        self._lock = threading.RLock()
        self._last_prune = 0.0
        if self.path is None:
            self._db = sqlite3.connect(":memory:", check_same_thread=False)
        else:
            ensure_private_dir(self.path.parent)
            self._db = sqlite3.connect(str(self.path), check_same_thread=False)
            try:
                os.chmod(self.path, 0o600)
            except OSError:
                pass
        self._db.row_factory = sqlite3.Row
        with self._lock:
            self._db.execute("PRAGMA secure_delete = ON")
            self._db.executescript(_SCHEMA)
            self._db.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
            self._db.commit()
        self.prune()

    # ---- writing -----------------------------------------------------------
    def _m(self, ip: str | None) -> str | None:
        return mask_ip(ip) if (self.mask_ips and ip) else ip

    def add_rotation(self, *, status: str, profile_id: str | None = None,
                     profile_name: str | None = None, kind: str | None = None,
                     tier: str | None = None, old_ip: str | None = None,
                     new_ip: str | None = None, duration_ms: int | None = None,
                     reason: str | None = None, error: str | None = None,
                     ts: float | None = None) -> int:
        with self._lock:
            cur = self._db.execute(
                "INSERT INTO rotations(ts, profile_id, profile_name, kind, tier, old_ip, new_ip,"
                " duration_ms, status, reason, error) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (ts or time.time(), profile_id, profile_name, kind, tier, self._m(old_ip),
                 self._m(new_ip), duration_ms, status, reason, error))
            self._db.commit()
            row_id = int(cur.lastrowid)
        self._maybe_prune()
        return row_id

    def add_event(self, level: str, kind: str, message: str, ts: float | None = None) -> None:
        with self._lock:
            self._db.execute("INSERT INTO events(ts, level, kind, message) VALUES (?,?,?,?)",
                             (ts or time.time(), level, kind, message))
            self._db.commit()

    # ---- reading -----------------------------------------------------------
    def recent_rotations(self, limit: int = 100) -> list[dict]:
        with self._lock:
            rows = self._db.execute(
                "SELECT * FROM rotations ORDER BY id DESC LIMIT ?", (max(1, int(limit)),)).fetchall()
        return [dict(r) for r in rows]

    def recent_events(self, limit: int = 100) -> list[dict]:
        with self._lock:
            rows = self._db.execute(
                "SELECT * FROM events ORDER BY id DESC LIMIT ?", (max(1, int(limit)),)).fetchall()
        return [dict(r) for r in rows]

    def stats(self) -> dict:
        with self._lock:
            by_status = {r["status"]: r["n"] for r in self._db.execute(
                "SELECT status, COUNT(*) AS n FROM rotations GROUP BY status")}
            uniq = self._db.execute(
                "SELECT COUNT(DISTINCT new_ip) AS n FROM rotations WHERE status='success'").fetchone()["n"]
            avg = self._db.execute(
                "SELECT AVG(duration_ms) AS a FROM rotations WHERE status='success'").fetchone()["a"]
        return {
            "total": sum(by_status.values()),
            "success": by_status.get("success", 0),
            "failed": by_status.get("failed", 0),
            "unchanged": by_status.get("unchanged", 0),
            "unique_ips": uniq,
            "avg_duration_ms": int(avg) if avg is not None else None,
        }

    # ---- maintenance -------------------------------------------------------
    def _maybe_prune(self) -> None:
        if time.time() - self._last_prune > 3600:
            self.prune()

    def prune(self) -> int:
        """Drop rows older than the retention period, then the oldest ones beyond the row cap."""
        cutoff = time.time() - self.retention_days * 86400
        with self._lock:
            n = self._db.execute("DELETE FROM rotations WHERE ts < ?", (cutoff,)).rowcount
            n += self._db.execute("DELETE FROM events WHERE ts < ?", (cutoff,)).rowcount
            for table, cap in (("rotations", self.max_rows), ("events", max(1000, self.max_rows // 10))):
                top = self._db.execute(f"SELECT MAX(id) AS m FROM {table}").fetchone()["m"]
                if top is not None and top > cap:
                    n += self._db.execute(f"DELETE FROM {table} WHERE id <= ?", (top - cap,)).rowcount
            self._db.commit()
        self._last_prune = time.time()
        return n

    def clear(self) -> None:
        """Delete everything and compact the file so nothing lingers on disk."""
        with self._lock:
            self._db.execute("DELETE FROM rotations")
            self._db.execute("DELETE FROM events")
            self._db.commit()
            self._db.execute("VACUUM")

    def export_csv(self, fh: IO[str]) -> int:
        rows = self.recent_rotations(limit=10_000_000)
        w = csv.writer(fh)
        w.writerow(ROTATION_COLUMNS)
        for r in reversed(rows):
            w.writerow([r[c] for c in ROTATION_COLUMNS])
        return len(rows)

    def close(self) -> None:
        with self._lock:
            try:
                self._db.close()
            except sqlite3.Error:
                pass
