"""Small system helpers.  All external commands go through :class:`Runner` so
tests can substitute a fake and nothing else in the code base calls
``subprocess`` directly (except the long-running OpenVPN process)."""
from __future__ import annotations

import ipaddress
import os
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence


@dataclass
class CmdResult:
    args: tuple
    returncode: int
    stdout: str = ""
    stderr: str = ""

    @property
    def ok(self) -> bool:
        return self.returncode == 0

    @property
    def text(self) -> str:
        return (self.stdout or "") + (self.stderr or "")


def _to_text(v) -> str:
    if v is None:
        return ""
    if isinstance(v, bytes):
        return v.decode("utf-8", "replace")
    return v


class Runner:
    """Runs external commands.  Never raises for a missing binary: returns 127."""

    def run(self, args: Sequence[str], *, timeout: float = 15.0, input: str | None = None,
            env: dict | None = None) -> CmdResult:
        args = tuple(str(a) for a in args)
        try:
            p = subprocess.run(args, input=input, capture_output=True, text=True,
                               timeout=timeout, env=env)
        except FileNotFoundError:
            return CmdResult(args, 127, "", f"{args[0]}: command not found")
        except subprocess.TimeoutExpired as e:
            return CmdResult(args, 124, _to_text(e.stdout), "timeout after %.0fs" % timeout)
        except OSError as e:
            return CmdResult(args, 126, "", str(e))
        return CmdResult(args, p.returncode, p.stdout, p.stderr)

    def popen(self, args: Sequence[str], **kw) -> subprocess.Popen:
        return subprocess.Popen([str(a) for a in args], **kw)


def which(name: str) -> str | None:
    return shutil.which(name)


def is_root() -> bool:
    return os.geteuid() == 0


def ensure_private_dir(path: Path, mode: int = 0o700) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(path, mode)
    except OSError:
        pass
    return path


def atomic_write(path: Path, data: str | bytes, mode: int = 0o600) -> None:
    """Write ``data`` to ``path`` atomically with the given permissions.

    The temp file is created in the destination directory (same filesystem, so
    ``os.replace`` is atomic) with the final mode from the start, so secrets are
    never briefly world-readable.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        os.fchmod(fd, mode)
        with os.fdopen(fd, "wb") as fh:
            fh.write(data.encode() if isinstance(data, str) else data)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def parse_ip(value: str):
    """Return an ipaddress object or None (never raises)."""
    try:
        return ipaddress.ip_address(value.strip().split("%")[0])
    except (ValueError, AttributeError):
        return None


def is_ipv6(value: str) -> bool:
    ip = parse_ip(value)
    return ip is not None and ip.version == 6
