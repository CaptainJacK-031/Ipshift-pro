"""Housekeeping commands: VPN profiles, configuration, history, hardening, restore, doctor, version."""
from __future__ import annotations

import json
import os
from pathlib import Path

from .. import __version__
from ..errors import DaemonUnavailable, IPShiftError, PrivilegeError
from ..sysutil import is_root
from ..vpn.importer import read_bundle
from .context import FAILED, NO_DAEMON, OK, Context, UsageError
from .render import render_hardening
from .reports import (fmt_value, render_config, render_config_set, render_doctor, render_history, render_import,
                      render_profiles, render_restore)
from .standalone import load_config, standalone_doctor, standalone_restore

TIERS = ("free", "paid", "self-hosted", "unknown")
IMPORT_SUFFIXES = (".ovpn", ".conf")
MAX_IMPORT_FILES = 2000


# ---- vpn list / import -----------------------------------------------------------------------------------
def cmd_vpn_list(ctx: Context, args) -> int:
    data = ctx.client.profiles()
    ctx.emit(data, lambda: render_profiles(data, ctx.style))
    return OK


def expand_import_paths(paths: list[str]) -> list[Path]:
    """Files as given; a folder contributes the .ovpn / .conf files directly inside it."""
    out: list[Path] = []
    for raw in paths:
        p = Path(raw).expanduser()
        if p.is_dir():
            found = sorted(f for f in p.iterdir() if f.is_file() and f.suffix.lower() in IMPORT_SUFFIXES)
            if not found:
                raise UsageError(f"no .ovpn or .conf files in {p}")
            out.extend(found)
        elif p.is_file():
            out.append(p)
        else:
            raise UsageError(f"{p}: no such file or folder")
    if len(out) > MAX_IMPORT_FILES:
        raise UsageError(f"{len(out)} files is too many at once (the limit is {MAX_IMPORT_FILES}); import a folder at a time")
    return out


def ask_tier(ctx: Context, many: bool) -> str:
    """Free, paid or self-hosted decides how much to trust a server, so ask rather than guess."""
    if not ctx.interactive:
        return "unknown"
    ctx.warn(f"Where {'do these VPN servers' if many else 'does this VPN server'} come from?\n"
             "  1) a paid provider    2) a free provider    3) my own server    4) not sure")
    answer = ctx.ask("Choose 1-4:", "4").lower()
    return {"1": "paid", "2": "free", "3": "self-hosted", "4": "unknown", "paid": "paid", "free": "free",
            "self-hosted": "self-hosted", "own": "self-hosted", "unknown": "unknown"}.get(answer, "unknown")


def cmd_vpn_import(ctx: Context, args) -> int:
    paths = expand_import_paths(args.paths)
    if args.name and len(paths) > 1:
        raise UsageError("--name works with a single file; with several files each profile is named after its file")
    password = None
    if args.username:
        password = ctx.secret(f"Password for {args.username}: ", from_stdin=args.password_stdin)
    tier = args.tier or ask_tier(ctx, len(paths) > 1)
    results, failed = [], 0
    for path in paths:
        try:
            bundle = read_bundle(path)
            kw = {"text": bundle["text"], "name": args.name or bundle["name"], "tier": tier, "replace": args.replace,
                  "files": bundle["files"] or None, "protocol": args.protocol, "provider": args.provider,
                  "country": args.country, "username": args.username, "password": password, "notes": args.notes}
            res = ctx.client.profile_import(**{k: v for k, v in kw.items() if v not in (None, "")})
            results.append({"file": str(path), "ok": True, **res})
        except DaemonUnavailable:
            raise
        except IPShiftError as e:
            failed += 1
            results.append({"file": str(path), "ok": False, "error": e.to_dict()})
    if ctx.json:
        ctx.say(json.dumps(results, indent=2))
    elif len(results) == 1 and results[0]["ok"]:
        ctx.say(render_import(results[0], ctx.style, width=ctx.width))
    else:
        st = ctx.style
        for r in results:
            if r["ok"]:
                p = r["profile"]
                ctx.say(f"{st.ok} {p['name']} ({p['protocol']}, {p.get('country') or '-'})"
                        + (f"  {st.dim(r['warnings'][0])}" if r.get("warnings") else ""))
            else:
                ctx.say(f"{st.fail} {Path(r['file']).name}: {r['error']['message']}")
        done = len(results) - failed
        ctx.say("")
        ctx.say(f"Imported {done} of {len(results)} profile(s)." + (f" {failed} failed." if failed else ""))
        needy = [r["profile"]["id"] for r in results
                 if r["ok"] and r["profile"].get("needs_auth") and not r["profile"].get("has_auth")]
        if needy:
            ctx.say(f"{st.warn} {len(needy)} profile(s) still need a login: ipshift vpn auth PROFILE"
                    f"   {st.dim('(or import them with --username to set it for all at once)')}")
        if tier == "free" and done:
            ctx.say(st.dim("Free VPNs can log, inject ads or sell your data; prefer paid or self-hosted servers "
                           "for anything sensitive."))
    return FAILED if failed and not any(r["ok"] for r in results) else OK


# ---- vpn remove / enable / disable / auth / set / reset --------------------------------------------------
def cmd_vpn_remove(ctx: Context, args) -> int:
    if not ctx.confirm(f"Remove {', '.join(args.profiles)}? Its stored keys and settings are deleted.",
                       assume_yes=args.yes):
        ctx.warn("ipshift: nothing removed")
        return FAILED
    out = [ctx.client.profile_remove(ref) for ref in args.profiles]
    ctx.emit(out, lambda: "\n".join(f"{ctx.style.ok} Removed {r['name']}" for r in out))
    return OK


def _toggle(ctx: Context, refs: list[str], enabled: bool) -> int:
    out = [ctx.client.profile_update(ref, enabled=enabled)["profile"] for ref in refs]
    ctx.emit(out, lambda: "\n".join(f"{ctx.style.ok} {p['name']} is now {'enabled' if enabled else 'disabled'}" for p in out))
    return OK


def cmd_vpn_enable(ctx: Context, args) -> int:
    return _toggle(ctx, args.profiles, True)


def cmd_vpn_disable(ctx: Context, args) -> int:
    return _toggle(ctx, args.profiles, False)


def cmd_vpn_auth(ctx: Context, args) -> int:
    user = args.username or ctx.ask("Username:", flag="--username")
    if not user:
        raise UsageError("a username is needed")
    password = ctx.secret(f"Password for {user}: ", from_stdin=args.password_stdin)
    if not password:
        raise UsageError("a password is needed")
    res = ctx.client.profile_auth(args.profile, user, password)
    ctx.emit(res, lambda: f"{ctx.style.ok} Saved the login for {res['profile']['name']}")
    return OK


def cmd_vpn_set(ctx: Context, args) -> int:
    changes = {k: getattr(args, k) for k in ("name", "tier", "provider", "country", "notes") if getattr(args, k) is not None}
    if not changes:
        raise UsageError("nothing to change: give at least one of --name, --tier, --provider, --country, --notes")
    res = ctx.client.profile_update(args.profile, **changes)
    ctx.emit(res, lambda: f"{ctx.style.ok} Updated {res['profile']['name']}: " + ", ".join(f"{k}={v}" for k, v in changes.items()))
    return OK


def cmd_vpn_reset(ctx: Context, args) -> int:
    res = ctx.client.profile_clear_quarantine(args.profile)
    n = res.get("cleared", 0)
    n = len(n) if isinstance(n, (list, tuple)) else n
    ctx.emit(res, lambda: f"{ctx.style.ok} {n} profile(s) are available again")
    return OK


# ---- config ----------------------------------------------------------------------------------------------------
def cmd_config(ctx: Context, args) -> int:
    action = args.action or "show"
    if action == "show":
        data = ctx.client.config_get()
        ctx.emit(data, lambda: render_config(data, ctx.style, section=args.key))
    elif action == "get":
        if not args.key:
            raise UsageError("config get needs a setting name, for example: ipshift config get rotation.interval")
        res = ctx.client.config_get(args.key)
        ctx.emit(res, lambda: fmt_value(res["value"]))
    elif action == "set":
        if not args.key or args.value is None:
            raise UsageError("config set needs a name and a value, for example: ipshift config set rotation.interval 5")
        res = ctx.client.config_set(args.key, args.value)
        ctx.emit(res, lambda: render_config_set(res, ctx.style))
    else:                                                   # reload
        res = ctx.client.config_reload()
        def text() -> str:
            st = ctx.style
            out = [f"{st.ok} Settings reloaded: {len(res['changed'])} changed"
                   + (f" ({', '.join(res['changed'])})" if res["changed"] else "")]
            if res.get("restart_required"):
                out.append(f"{st.warn} Needs a daemon restart: {', '.join(res['restart_required'])}")
            out += [f"{st.warn} {w}" for w in res.get("warnings", [])]
            return "\n".join(out)
        ctx.emit(res, text)
    return OK


# ---- history ---------------------------------------------------------------------------------------------------
def write_private(path: str, text: str) -> None:
    """Create a new file readable only by its owner (the history shows when you used which server)."""
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
        f.write(text)


def cmd_history(ctx: Context, args) -> int:
    if args.clear:
        if not ctx.confirm("Delete the whole rotation history? This cannot be undone.", assume_yes=args.yes):
            ctx.warn("ipshift: history kept")
            return FAILED
        res = ctx.client.history_clear()
        ctx.emit(res, lambda: f"{ctx.style.ok} History deleted")
        return OK
    if args.export:
        res = ctx.client.history_export(args.limit)
        if args.export == "-":
            ctx.out.write(res["csv"])
            ctx.out.flush()
            return OK
        try:
            write_private(args.export, res["csv"])
        except FileExistsError:
            raise UsageError(f"{args.export} already exists; choose another name (nothing is overwritten)") from None
        except OSError as e:
            raise UsageError(f"cannot write {args.export}: {e.strerror or e}") from None
        msg = f"{ctx.style.ok} Wrote {res['rows']} row(s) to {args.export} (readable only by you)"
        if res.get("truncated"):
            msg += f"\n{ctx.style.warn} The export was cut at its size limit: the oldest rows are missing"
        ctx.emit(res | {"csv": None, "file": args.export}, lambda: msg)
        return OK
    data = ctx.client.history(args.limit)
    ctx.emit(data, lambda: render_history(data, ctx.style, width=ctx.width))
    return OK


# ---- hardening ---------------------------------------------------------------------------------------------------
def cmd_harden(ctx: Context, args) -> int:
    st = ctx.style
    if args.action in (None, "status"):
        res = ctx.client.harden_status()
        ctx.emit(res, lambda: render_hardening(res, st))
        return OK
    action = args.mac_action                                # args.action == "mac"
    if action in ("randomize",) and not args.iface:
        raise UsageError("randomize needs an interface name, for example: ipshift harden mac randomize wlan0")
    res = ctx.client.mac(action, args.iface, args.mac)

    def text() -> str:
        if action == "enable":
            return f"{st.ok} {res.get('note', 'MAC randomisation enabled')}"
        if action == "disable":
            return f"{st.ok} MAC randomisation " + ("switched off" if res.get("was_enabled") else "was not on")
        if action == "randomize":
            return f"{st.ok} {res['iface']} now uses {res['mac']}   {st.dim('(the link drops for a moment)')}"
        done = res.get("restored") or []
        return f"{st.ok} " + (f"Original MAC address put back on {', '.join(done)}" if done else "Nothing to restore")
    ctx.emit(res, text)
    return OK


# ---- restore / doctor / version ------------------------------------------------------------------------------------
def cmd_restore(ctx: Context, args) -> int:
    include_mac = not args.keep_mac
    try:
        rep = ctx.client.restore(include_mac=include_mac)
    except DaemonUnavailable as e:
        if not is_root():
            if "permission denied" in str(e):
                raise
            raise PrivilegeError("the daemon is not running, so restoring the network needs root",
                                 hint="run: sudo ipshift restore") from None
        cfg, paths = load_config(ctx.config)
        ctx.warn("ipshift: the daemon is not running; restoring directly")
        rep = standalone_restore(cfg, paths, include_mac=include_mac)
    ctx.emit(rep, lambda: render_restore(rep, ctx.style))
    return FAILED if str(rep.get("killswitch", "")).startswith("FAILED") else OK


def cmd_doctor(ctx: Context, args) -> int:
    try:
        rep = ctx.client.doctor()
    except DaemonUnavailable:
        cfg, paths = load_config(ctx.config)
        rep = standalone_doctor(cfg, paths)
    ctx.emit(rep, lambda: render_doctor(rep, ctx.style, width=ctx.width))
    return OK if rep.get("ready") else FAILED


def cmd_version(ctx: Context, args) -> int:
    daemon = None
    try:
        daemon = ctx.client.ping().get("version")
    except IPShiftError:
        pass
    data = {"ipshift": __version__, "daemon": daemon}
    if ctx.json:
        ctx.say(json.dumps(data, indent=2))
        return OK
    ctx.say(f"ipshift {__version__}")
    if daemon is None:
        ctx.say(ctx.style.dim("daemon: not reachable"))
        return OK
    ctx.say(f"ipshiftd {daemon}" + ("" if daemon == __version__ else ctx.style.paint("   (differs from the client)", "yellow")))
    return OK
