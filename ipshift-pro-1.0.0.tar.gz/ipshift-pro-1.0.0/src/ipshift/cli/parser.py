"""The command line grammar of ``ipshift``."""
from __future__ import annotations

import argparse
import math

from .. import APP_NAME, __version__
from ..config import MIN_INTERVAL
from . import commands as c
from . import manage as m

EPILOG = """\
examples:
  ipshift vpn import ~/vpn/                 import every .ovpn / .conf file in a folder
  ipshift vpn connect                       connect and verify the new public IP
  ipshift rotate --interval 1               change the public IP as fast as the VPNs allow
  ipshift status --watch                    live dashboard
  ipshift privacy-check                     DNS, IPv6 and kill-switch leak tests
  ipshift stop                              stop rotating, disconnect, give the normal network back

exit codes:
  0 success   1 failed   2 wrong usage   3 daemon not reachable   4 privacy check found problems   130 interrupted

A VPN changes who can see your traffic; it does not make you anonymous. See: ipshift privacy-check
"""

LEVELS = ("debug", "info", "warning", "error", "critical")


class Parser(argparse.ArgumentParser):
    """argparse that keeps its own wording: errors are 'ipshift: ...' and exit with 2."""


def interval_arg(text: str) -> float:
    try:
        value = float(text)
    except ValueError:
        raise argparse.ArgumentTypeError(f"{text!r} is not a number of seconds") from None
    if not math.isfinite(value):
        raise argparse.ArgumentTypeError(f"{text!r} is not a usable number of seconds")
    if value < MIN_INTERVAL:
        raise argparse.ArgumentTypeError(f"the shortest interval is {MIN_INTERVAL:g} second (got {value:g})")
    return value


def positive_int(text: str) -> int:
    try:
        value = int(text)
    except ValueError:
        raise argparse.ArgumentTypeError(f"{text!r} is not a whole number") from None
    if value < 1:
        raise argparse.ArgumentTypeError("must be at least 1")
    return value


def _common() -> argparse.ArgumentParser:
    """A fresh copy per parser: argparse shares action objects between parents and children, and
    set_defaults() on the root would otherwise overwrite the sub-commands' 'not given' marker."""
    p = argparse.ArgumentParser(add_help=False)
    g = p.add_argument_group("global options")
    S = argparse.SUPPRESS            # a value given before the command must survive the sub-parser's defaults
    g.add_argument("--json", action="store_true", default=S, help="machine-readable JSON output")
    g.add_argument("--socket", metavar="PATH", default=S, help="daemon socket (default: /run/ipshift/ipshift.sock)")
    g.add_argument("--config", metavar="FILE", default=S,
                   help="configuration file, only used when the daemon is not running")
    g.add_argument("--no-color", action="store_true", default=S, help="no colours (also: NO_COLOR=1)")
    g.add_argument("--ascii", action="store_true", default=S, help="plain ASCII symbols only")
    return p


def _add(sub, name, func, help_, *, aliases=(), **kw) -> argparse.ArgumentParser:
    p = sub.add_parser(name, parents=[_common()], aliases=list(aliases), help=help_, description=help_,
                       formatter_class=argparse.RawDescriptionHelpFormatter, **kw)
    p.set_defaults(func=func)
    return p


def build_parser() -> argparse.ArgumentParser:
    root = Parser(prog="ipshift", parents=[_common()], formatter_class=argparse.RawDescriptionHelpFormatter,
                  description=f"{APP_NAME}: change your public IP address through VPNs, with leak protection and a "
                              "firewall kill switch.",
                  epilog=EPILOG)
    root.add_argument("--version", action="version", version=f"ipshift {__version__}")
    root.set_defaults(json=False, socket=None, config=None, no_color=False, ascii=False, func=None)
    sub = root.add_subparsers(dest="command", metavar="COMMAND", parser_class=Parser)

    # ---- everyday ---------------------------------------------------------------------------------------
    p = _add(sub, "status", c.cmd_status, "show protection, VPN, public and private IP, rotation and alerts")
    p.add_argument("-w", "--watch", nargs="?", const=2.0, default=None, type=float, metavar="SECONDS",
                   help="keep refreshing (every 2 s unless given)")
    p.add_argument("--count", type=positive_int, metavar="N", help="with --watch: stop after N refreshes")
    p.add_argument("--fresh", action="store_true", help="re-read the network now instead of using the last look")
    p.add_argument("--check", action="store_true", help="exit with 1 unless fully protected (for scripts)")

    p = _add(sub, "ip", c.cmd_ip, "show the public and private IP addresses")
    p.add_argument("--direct", action="store_true",
                   help="look up your real public address (only possible with no VPN and no kill switch)")
    p.add_argument("--refresh", action="store_true", help="ask the echo services again instead of using the verified address")
    g = p.add_mutually_exclusive_group()
    g.add_argument("--public", action="store_true", help="print only the public IPv4 address")
    g.add_argument("--private", action="store_true", help="print only the private addresses, one per line")

    vpn = _add(sub, "vpn", None, "connect, disconnect and manage VPN profiles")
    vsub = vpn.add_subparsers(dest="vpn_command", metavar="ACTION", required=True, parser_class=Parser)
    q = _add(vsub, "connect", c.cmd_connect, "connect to a profile (default: the last used or best one)")
    q.add_argument("profile", nargs="?", help="profile id or name")
    q.add_argument("--keep-rotation", action="store_true", help="do not pause a running rotation")
    q = _add(vsub, "disconnect", c.cmd_stop, "same as 'ipshift stop'")
    q.add_argument("--keep-blocking", action="store_true", help="keep the kill switch up: nothing leaves the machine")
    q.set_defaults(rotation_only=False)
    _add(vsub, "cancel", c.cmd_cancel, "cancel a connection attempt that is still running")
    _add(vsub, "list", m.cmd_vpn_list, "list the imported profiles", aliases=("ls",))
    q = _add(vsub, "import", m.cmd_vpn_import, "import .ovpn / .conf files, or every one in a folder")
    q.add_argument("paths", nargs="+", metavar="FILE_OR_FOLDER")
    q.add_argument("--name", help="profile name (single file only; default: the file name)")
    q.add_argument("--tier", choices=m.TIERS, help="where the server comes from (asked for when omitted)")
    q.add_argument("--provider", help="provider name, for your own overview")
    q.add_argument("--country", metavar="CC", help="2-letter country code (guessed from the name when omitted)")
    q.add_argument("--protocol", choices=("openvpn", "wireguard"), help="only needed when it cannot be detected")
    q.add_argument("--username", help="login for providers that need one (the password is asked for)")
    q.add_argument("--password-stdin", action="store_true", help="read the password from standard input")
    q.add_argument("--replace", action="store_true", help="replace a profile with the same name")
    q.add_argument("--notes", help="a note stored with the profile")
    q = _add(vsub, "remove", m.cmd_vpn_remove, "delete profiles", aliases=("rm",))
    q.add_argument("profiles", nargs="+", metavar="PROFILE")
    q.add_argument("-y", "--yes", action="store_true", help="do not ask")
    for name, func, text in (("enable", m.cmd_vpn_enable, "include profiles in rotation again"),
                             ("disable", m.cmd_vpn_disable, "keep profiles out of the rotation")):
        q = _add(vsub, name, func, text)
        q.add_argument("profiles", nargs="+", metavar="PROFILE")
    q = _add(vsub, "auth", m.cmd_vpn_auth, "store the username and password of a profile")
    q.add_argument("profile", metavar="PROFILE")
    q.add_argument("--username", help="the login (asked for when omitted)")
    q.add_argument("--password-stdin", action="store_true", help="read the password from standard input")
    q = _add(vsub, "set", m.cmd_vpn_set, "change a profile's name, tier, provider, country or notes")
    q.add_argument("profile", metavar="PROFILE")
    q.add_argument("--name", help="a new name for the profile")
    q.add_argument("--tier", choices=m.TIERS, help="where the server comes from")
    q.add_argument("--provider", help="provider name, for your own overview")
    q.add_argument("--country", metavar="CC", help="2-letter country code")
    q.add_argument("--notes", help="a note stored with the profile")
    q = _add(vsub, "reset", m.cmd_vpn_reset, "let benched (failing) profiles be used again")
    q.add_argument("profile", nargs="?", metavar="PROFILE", help="default: all")

    p = _add(sub, "rotate", c.cmd_rotate,
             "change the public IP over and over (the interval is a start-to-start timer, minimum "
             f"{MIN_INTERVAL:g} s; a change only counts once the new tunnel is up and the new IP is verified)")
    p.add_argument("-i", "--interval", type=interval_arg, metavar="SECONDS",
                   help="seconds between rotations for this run (default: the rotation.interval setting)")
    p.add_argument("--now", action="store_true", help="rotate once, right now")
    p.add_argument("--stop", action="store_true", help="stop rotating but stay connected")
    p.add_argument("--no-immediate", action="store_true", help="wait one interval before the first rotation")
    p.add_argument("--no-follow", action="store_true", help="return at once instead of showing the rotation live")
    p.add_argument("--stop-on-exit", action="store_true", help="stop everything when you press Ctrl-C")

    p = _add(sub, "stop", c.cmd_stop,
             "stop rotating, disconnect the VPN and give the normal network back")
    p.add_argument("--keep-blocking", action="store_true", help="disconnect but keep the kill switch up (nothing leaves)")
    p.add_argument("--rotation-only", action="store_true", help="only stop the rotation, stay connected")

    p = _add(sub, "privacy-check", c.cmd_privacy_check,
             "test for DNS, IPv6 and traffic leaks, and check the kill switch", aliases=("check",))
    p.add_argument("--quick", action="store_true", help="skip the slow tests")
    p.add_argument("--only", action="append", metavar="IDS", help="run only these checks (comma separated)")
    p.add_argument("--strict", action="store_true", help="exit with 4 on warnings too")
    p.add_argument("-v", "--verbose", action="store_true", help="show the evidence behind each result")

    p = _add(sub, "killswitch", c.cmd_killswitch, "show or change the firewall kill switch")
    p.add_argument("action", nargs="?", choices=("status", "on", "off", "lockdown"),
                   help="on: arm it   off: release it   lockdown: block everything, VPN included")
    p.add_argument("-y", "--yes", action="store_true", help="do not ask before releasing it")

    # ---- housekeeping -------------------------------------------------------------------------------
    p = _add(sub, "config", m.cmd_config, "show or change settings")
    p.add_argument("action", nargs="?", choices=("show", "get", "set", "reload"))
    p.add_argument("key", nargs="?", help="setting name such as rotation.interval (for 'show': a section)")
    p.add_argument("value", nargs="?")

    p = _add(sub, "history", m.cmd_history, "show, export or delete the rotation history")
    p.add_argument("-n", "--limit", type=positive_int, default=50, metavar="N", help="how many rows (default 50)")
    p.add_argument("--export", metavar="FILE", help="write the history as CSV ('-' for the terminal)")
    p.add_argument("--clear", action="store_true", help="delete the history")
    p.add_argument("-y", "--yes", action="store_true", help="do not ask")

    p = _add(sub, "harden", m.cmd_harden, "show DNS / IPv6 / MAC protections, or change MAC randomisation")
    p.add_argument("action", nargs="?", choices=("status", "mac"))
    p.add_argument("mac_action", nargs="?", choices=("enable", "disable", "randomize", "restore"),
                   help="mac: enable/disable NetworkManager randomisation, randomize one interface, or restore")
    p.add_argument("iface", nargs="?", help="interface for 'randomize'")
    p.add_argument("mac", nargs="?", help="a specific address for 'randomize' (default: random)")

    p = _add(sub, "restore", m.cmd_restore,
             "undo everything IPShift changed: firewall, DNS, IPv6, MAC addresses, stray tunnels")
    p.add_argument("--keep-mac", action="store_true", help="leave MAC addresses alone")
    _add(sub, "doctor", m.cmd_doctor, "check that this machine is ready (works without the daemon)")
    p = _add(sub, "events", c.cmd_events, "show recent events and alerts")
    p.add_argument("-n", "--number", type=positive_int, default=30, metavar="N", help="how many (default 30)")
    p.add_argument("--level", choices=LEVELS, default="info", help="lowest level to show (default info)")
    p.add_argument("-f", "--follow", action="store_true", help="keep showing new events")
    _add(sub, "version", m.cmd_version, "show the client and daemon versions")
    return root
