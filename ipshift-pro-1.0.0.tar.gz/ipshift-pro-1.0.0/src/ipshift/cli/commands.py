"""The everyday commands: status, ip, connect, rotate, stop, privacy-check, killswitch, events."""
from __future__ import annotations

import contextlib
import json

from ..errors import DaemonUnavailable, IPShiftError
from .context import FAILED, NO_DAEMON, OK, PRIVACY, Context
from .render import (kv, render_connect, render_event, render_ip, render_killswitch, render_rotation_started,
                     render_status)
from .reports import render_report, render_stop
from .standalone import load_config, local_facts, local_ip_info
from .ui import wrap

BAD_VERDICTS = ("exposed", "at-risk", "unprotected")
WATCH_DEFAULT = 2.0


# ---- status -------------------------------------------------------------------------------------------------
def _no_daemon(ctx: Context, err: DaemonUnavailable) -> int:
    """The daemon cannot be reached: say so, and show what can be seen without it."""
    cfg, _ = load_config(ctx.config)
    facts = local_facts(cfg)
    if ctx.json:
        ctx.say(json.dumps({"daemon": None, "error": err.to_dict(), "local": facts}, indent=2))
        return NO_DAEMON
    st = ctx.style
    ctx.warn(f"ipshift: {err}" + (f"\n  hint: {err.hint}" if err.hint else ""))
    ctx.say("")
    ctx.say(kv("Daemon", st.paint("not reachable", "red"), st))
    ctx.say(kv("Network", facts["network"], st))
    armed = facts.get("killswitch_armed")
    if armed:
        ctx.say(kv("Kill switch", st.paint("armed", "yellow") + "   firewall rules from IPShift are blocking traffic.\n"
                                  "Release them with: sudo ipshift restore", st))
    elif armed is None and not facts["root"]:
        ctx.say(kv("Kill switch", st.dim("unknown (run as root to look)"), st))
    else:
        ctx.say(kv("Kill switch", st.dim("not armed"), st))
    return NO_DAEMON


def _status_once(ctx: Context, args) -> tuple[dict | None, int]:
    try:
        return ctx.client.status(fresh=args.fresh), OK
    except DaemonUnavailable as e:
        return None, _no_daemon(ctx, e)


def cmd_status(ctx: Context, args) -> int:
    if args.watch is not None:
        return _watch_status(ctx, args)
    st, code = _status_once(ctx, args)
    if st is None:
        return code
    ctx.emit(st, lambda: render_status(st, ctx.style))
    if args.check and st["protection"]["level"] != "protected":
        return FAILED
    return OK


def _watch_status(ctx: Context, args) -> int:
    interval = max(0.5, float(args.watch))
    n = 0
    try:
        while True:
            try:
                st = ctx.client.status(fresh=args.fresh)
            except DaemonUnavailable as e:
                st = None
                lost = str(e)
            n += 1
            if ctx.json:
                ctx.emit_line(st if st is not None else {"daemon": None, "error": lost})
            else:
                if ctx.tty:
                    ctx.out.write("\x1b[H\x1b[2J")
                elif n > 1:
                    ctx.say("")
                if st is not None:
                    ctx.say(render_status(st, ctx.style))
                else:
                    ctx.say(ctx.style.paint(f"daemon not reachable: {lost}", "red"))
                ctx.say("")
                ctx.say(ctx.style.dim(f"Refreshing every {interval:g} s. Press Ctrl-C to quit."))
            if args.count and n >= args.count:
                return OK
            ctx.sleep(interval)
    except KeyboardInterrupt:
        ctx.say("")
        return OK


# ---- ip -----------------------------------------------------------------------------------------------------
def cmd_ip(ctx: Context, args) -> int:
    try:
        info = ctx.client.ip(refresh=args.refresh, direct=args.direct)
    except DaemonUnavailable:
        cfg, _ = load_config(ctx.config)
        info = local_ip_info(cfg, direct=args.direct)
    if args.public:
        v4 = (info.get("public") or {}).get("v4")
        if not v4:
            ctx.warn("ipshift: no public address to show" + (f": {info['note']}" if info.get("note") else ""))
            return FAILED
        ctx.say(v4)
        return OK
    if args.private:
        mine = [p["ip"] for p in info.get("private", []) if p.get("kind") != "tunnel"]
        if not mine:
            ctx.warn("ipshift: no private address found")
            return FAILED
        for ip in mine:
            ctx.say(ip)
        return OK
    ctx.emit(info, lambda: render_ip(info, ctx.style))
    return OK


# ---- connect / stop -----------------------------------------------------------------------------------------
def cmd_connect(ctx: Context, args) -> int:
    ctx.progress(f"Connecting to {args.profile or 'the best available profile'} ... "
                 "(traffic stays blocked until the tunnel is verified; Ctrl-C cancels)")
    try:
        res = ctx.client.connect(args.profile, keep_rotation=args.keep_rotation)
    except KeyboardInterrupt:
        with contextlib.suppress(IPShiftError):
            ctx.client_factory(ctx.socket).cancel()
        ctx.warn("ipshift: cancelled; traffic stays blocked. Use 'ipshift stop' to get the normal network back.")
        return 130
    ctx.emit(res, lambda: render_connect(res, ctx.style))
    return OK


def cmd_cancel(ctx: Context, args) -> int:
    res = ctx.client.cancel()
    ctx.emit(res, lambda: f"{ctx.style.ok} Asked the daemon to cancel the connection attempt")
    return OK


def cmd_stop(ctx: Context, args) -> int:
    res = ctx.client.stop(keep_blocking=args.keep_blocking, keep_vpn=args.rotation_only)
    ctx.emit(res, lambda: render_stop(res, ctx.style))
    return OK


# ---- rotate -------------------------------------------------------------------------------------------------
def _slow_protocol_note(ctx: Context, interval: float | None) -> str | None:
    """OpenVPN needs seconds to bring a tunnel up; only WireGuard can change server in about a second."""
    if interval is None or interval >= 5:
        return None
    try:
        data = ctx.client.profiles()
    except IPShiftError:
        return None
    rotating = set(data.get("in_rotation") or [])
    slow = [p for p in data.get("profiles", []) if p["id"] in rotating and p.get("protocol") == "openvpn"]
    if not slow:
        return None
    return (f"{len(slow)} OpenVPN profile(s) are in the rotation: OpenVPN needs several seconds to connect, so those "
            "changes will be slower than the interval. WireGuard profiles can switch in about a second.")


def cmd_rotate(ctx: Context, args) -> int:
    if args.stop:
        res = ctx.client.rotate_stop()
        ctx.emit(res, lambda: f"{ctx.style.ok} Rotation stopped")
        return OK
    if args.now:
        ctx.progress("Rotating now ...")
        res = ctx.client.rotate_now()
        ctx.emit(res, lambda: render_connect(res, ctx.style))
        return OK
    res = ctx.client.rotate_start(args.interval, immediate=not args.no_immediate)
    if ctx.json and not args.no_follow:
        ctx.emit_line(res)                                   # the whole output is then JSON Lines
    else:
        ctx.emit(res, lambda: render_rotation_started(res, ctx.style))
    note = _slow_protocol_note(ctx, res.get("interval"))
    if note and not ctx.json:
        ctx.say(ctx.style.dim(wrap(note, ctx.width, "  ")))
    if args.no_follow:
        return OK
    banner = ("Following the rotation. Press Ctrl-C to stop it and give the normal network back."
              if args.stop_on_exit else
              "Following the rotation. Press Ctrl-C to stop watching "
              "(the rotation keeps running in the background; 'ipshift stop' ends it).")
    return follow_events(ctx, skip=("connecting",), stop_on_exit=args.stop_on_exit, banner=banner)


def follow_events(ctx: Context, *, min_level: str = "info", replay: int = 0, skip: tuple[str, ...] = (),
                  stop_on_exit: bool = False, banner: str | None = None) -> int:
    if banner and not ctx.json:
        ctx.say("")
        ctx.say(ctx.style.dim(banner))
    try:
        for ev in ctx.client.events(min_level=min_level, replay=replay):
            if ev.get("kind") in skip:
                continue
            if ctx.json:
                ctx.emit_line(ev)
            else:
                ctx.say(render_event(ev, ctx.style))
        ctx.warn("ipshift: lost the connection to the daemon")
        return NO_DAEMON
    except KeyboardInterrupt:
        ctx.say("")
        if stop_on_exit:
            res = ctx.client_factory(ctx.socket).stop()
            ctx.say(render_stop(res, ctx.style))
        elif not ctx.json:
            ctx.say("Stopped watching. The rotation keeps running in the background; stop it with: ipshift stop")
        return OK


# ---- privacy check ------------------------------------------------------------------------------------------
def split_ids(values: list[str] | None) -> list[str] | None:
    out = [p.strip() for v in values or [] for p in v.split(",") if p.strip()]
    return out or None


def cmd_privacy_check(ctx: Context, args) -> int:
    ctx.progress("Running the privacy checks (up to a minute) ...")
    rep = ctx.client.privacy_check("quick" if args.quick else "full", split_ids(args.only))
    ctx.emit(rep, lambda: render_report(rep, ctx.style, width=ctx.width, verbose=args.verbose))
    verdict = rep.get("verdict")
    if verdict in BAD_VERDICTS or (args.strict and verdict != "protected"):
        return PRIVACY
    return OK


# ---- kill switch --------------------------------------------------------------------------------------------
def cmd_killswitch(ctx: Context, args) -> int:
    action = args.action or "status"
    st = ctx.style
    if action == "status":
        res = ctx.client.killswitch_status()
        ctx.emit(res, lambda: render_killswitch(res, st))
    elif action == "on":
        res = ctx.client.killswitch_on()
        ctx.emit(res, lambda: f"{st.ok} Kill switch armed: nothing can leave this machine except through the VPN "
                              f"(all traffic is blocked until one is connected)\n{render_killswitch(res, st)}")
    elif action == "off":
        if not ctx.confirm("Releasing the kill switch lets traffic leave outside the VPN if it drops. Release it?",
                           assume_yes=args.yes, required=False):
            ctx.warn("ipshift: left as it was")
            return FAILED
        res = ctx.client.killswitch_off()
        ctx.emit(res, lambda: f"{st.warn} Kill switch released: traffic can leave outside the VPN")
    else:                                                   # lockdown
        res = ctx.client.lockdown()
        ctx.emit(res, lambda: f"{st.fail} LOCKDOWN: all network traffic is blocked, including the VPN\n"
                              f"  Leave it with: ipshift vpn connect   (or: ipshift stop)")
    return OK


# ---- events -------------------------------------------------------------------------------------------------
def cmd_events(ctx: Context, args) -> int:
    if args.follow:
        return follow_events(ctx, min_level=args.level, replay=args.number,
                             banner="Following events. Press Ctrl-C to stop.")
    events = ctx.client.recent_events(args.number, args.level)
    if ctx.json:
        ctx.say(json.dumps(events, indent=2))
    elif not events:
        ctx.say(ctx.style.dim("  No events yet."))
    else:
        for ev in events:
            ctx.say(render_event(ev, ctx.style))
    return OK

