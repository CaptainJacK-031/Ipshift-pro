"""State shared by one CLI run: streams, colours, the daemon client, prompts, exit codes."""
from __future__ import annotations

import getpass
import json
import sys
import time
from dataclasses import dataclass, field
from typing import Callable, TextIO

from ..ipc.client import Client
from .ui import Style, make_style, term_width

# Exit codes (also listed in `ipshift --help`)
OK, FAILED, USAGE, NO_DAEMON, PRIVACY, INTERRUPTED = 0, 1, 2, 3, 4, 130


class UsageError(Exception):
    """The command line asks for something that cannot be done as written."""


@dataclass
class Context:
    out: TextIO = field(default_factory=lambda: sys.stdout)
    err: TextIO = field(default_factory=lambda: sys.stderr)
    inp: TextIO = field(default_factory=lambda: sys.stdin)
    json: bool = False
    socket: str | None = None
    config: str | None = None
    no_color: bool = False
    ascii_only: bool = False
    sleep: Callable[[float], None] = time.sleep
    client_factory: Callable[[str | None], Client] = Client
    secret_reader: Callable[[str], str] = getpass.getpass
    _client: Client | None = field(default=None, init=False, repr=False)

    # ---- environment ----------------------------------------------------------------------------------
    @property
    def style(self) -> Style:
        return make_style(self.out, no_color=self.no_color, ascii_only=self.ascii_only)

    @property
    def err_style(self) -> Style:
        return make_style(self.err, no_color=self.no_color, ascii_only=self.ascii_only)

    @staticmethod
    def _tty(stream) -> bool:
        try:
            return bool(stream.isatty())
        except (AttributeError, ValueError):
            return False

    @property
    def tty(self) -> bool:
        return self._tty(self.out)

    @property
    def interactive(self) -> bool:
        return self._tty(self.inp) and self._tty(self.err)

    @property
    def width(self) -> int:
        return term_width() if self.tty else 100

    @property
    def client(self) -> Client:
        if self._client is None:
            self._client = self.client_factory(self.socket)
        return self._client

    # ---- output ---------------------------------------------------------------------------------------
    def say(self, text: str = "") -> None:
        self.out.write(text + "\n")
        self.out.flush()

    def warn(self, text: str) -> None:
        self.err.write(text + "\n")
        self.err.flush()

    def progress(self, text: str) -> None:
        """A 'working on it' line: only for a person watching a terminal, never in pipes or logs."""
        if self._tty(self.err) and not self.json:
            self.err.write(self.err_style.dim(text) + "\n")
            self.err.flush()

    def emit(self, data, render: Callable[[], str]) -> None:
        """The result of a command: JSON for scripts, readable text for people."""
        self.say(json.dumps(data, indent=2) if self.json else render())

    def emit_line(self, data) -> None:
        """One JSON object per line (streams)."""
        self.say(json.dumps(data, separators=(",", ":")))

    # ---- input ----------------------------------------------------------------------------------------
    def confirm(self, question: str, *, assume_yes: bool = False, required: bool = True) -> bool:
        """Ask before something drastic.  ``required``: with no person to ask (a script), refuse unless
        ``--yes`` was given; otherwise go ahead (for things a script legitimately does)."""
        if assume_yes:
            return True
        if not self.interactive:
            if required:
                raise UsageError(f"{question} Nobody to ask: add --yes to go ahead.")
            return True
        self.err.write(f"{question} [y/N] ")
        self.err.flush()
        return self.inp.readline().strip().lower() in ("y", "yes")

    def ask(self, prompt: str, default: str | None = None, *, flag: str | None = None) -> str:
        if not self.interactive:
            what = prompt.strip().rstrip(":").lower()
            raise UsageError(f"{what} is needed and there is no terminal to ask on" + (f": use {flag}" if flag else ""))
        self.err.write(prompt + (f" [{default}] " if default else " "))
        self.err.flush()
        answer = self.inp.readline().strip()
        return answer or (default or "")

    def secret(self, prompt: str, *, from_stdin: bool = False) -> str:
        if from_stdin:
            return self.inp.readline().rstrip("\r\n")
        if not self.interactive:
            raise UsageError("a password is needed: use --password-stdin when there is no terminal")
        return self.secret_reader(prompt)
