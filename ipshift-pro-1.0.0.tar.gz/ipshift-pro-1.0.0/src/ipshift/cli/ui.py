"""Terminal output helpers: colour, symbols and tables, all optional.

Colour is used only on a terminal (and never when NO_COLOR is set), and every symbol has a
plain-ASCII fallback, so the output is just as readable in a log file or over a bad SSH link.
"""
from __future__ import annotations

import os
import re
import sys
import time
from dataclasses import dataclass

_CODES = {"red": "31", "green": "32", "yellow": "33", "blue": "34", "magenta": "35", "cyan": "36",
          "dim": "2", "bold": "1"}


@dataclass
class Style:
    color: bool = False
    unicode: bool = False

    def paint(self, text: str, *names: str) -> str:
        if not self.color or not names:
            return text
        codes = ";".join(_CODES[n] for n in names if n in _CODES)
        return f"\x1b[{codes}m{text}\x1b[0m" if codes else text

    def dim(self, t: str) -> str:
        return self.paint(t, "dim")

    def bold(self, t: str) -> str:
        return self.paint(t, "bold")

    # symbols ----------------------------------------------------------------------------------
    @property
    def ok(self) -> str:
        return self.paint("✔" if self.unicode else "[ok]", "green")

    @property
    def warn(self) -> str:
        return self.paint("!" if self.unicode else "[!!]", "yellow")

    @property
    def fail(self) -> str:
        return self.paint("✖" if self.unicode else "[XX]", "red")

    @property
    def skip(self) -> str:
        return self.paint("–" if self.unicode else "[--]", "dim")

    @property
    def info(self) -> str:
        return self.paint("i" if self.unicode else "[i]", "cyan")

    @property
    def arrow(self) -> str:
        return "→" if self.unicode else "->"

    @property
    def bullet(self) -> str:
        return "•" if self.unicode else "*"

    @property
    def dot(self) -> str:
        return "●" if self.unicode else "*"

    @property
    def ellipsis(self) -> str:
        return "…" if self.unicode else "..."

    def status_symbol(self, status: str) -> str:
        return {"pass": self.ok, "ok": self.ok, "warn": self.warn, "fail": self.fail, "skip": self.skip,
                "info": self.info}.get(status, self.skip)


def make_style(stream=None, *, no_color: bool = False, ascii_only: bool = False) -> Style:
    stream = stream or sys.stdout
    tty = bool(getattr(stream, "isatty", lambda: False)())
    enc = (getattr(stream, "encoding", None) or "").lower().replace("-", "")
    color = tty and not no_color and not os.environ.get("NO_COLOR") and os.environ.get("TERM") != "dumb"
    return Style(color=color, unicode=("utf8" in enc) and not ascii_only)


_ANSI = re.compile(r"\x1b\[[0-9;]*m")


def strip_ansi(text: str) -> str:
    return _ANSI.sub("", text)


def visible_len(text: str) -> int:
    """Length as seen on screen (colour codes take no room)."""
    return len(strip_ansi(text))


# ---- numbers and times --------------------------------------------------------------------------
def fmt_duration(seconds: float | None) -> str:
    if seconds is None:
        return "-"
    s = int(round(seconds))
    if s < 60:
        return f"{s} s"
    m, s = divmod(s, 60)
    if m < 60:
        return f"{m} min {s:02d} s"
    h, m = divmod(m, 60)
    if h < 48:
        return f"{h} h {m:02d} min"
    d, h = divmod(h, 24)
    return f"{d} d {h} h"


def fmt_ms(ms: float | None) -> str:
    if ms is None:
        return "-"
    return f"{ms} ms" if ms < 1000 else f"{ms / 1000:.1f} s"


def fmt_ago(ts: float | None, now: float | None = None) -> str:
    if not ts:
        return "never"
    d = (now if now is not None else time.time()) - ts
    if d < 1.5:
        return "just now"
    return fmt_duration(d) + " ago"


def fmt_clock(ts: float | None) -> str:
    return time.strftime("%H:%M:%S", time.localtime(ts)) if ts else "--:--:--"


def fmt_datetime(ts: float | None) -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts)) if ts else "-"


# ---- tables ---------------------------------------------------------------------------------------
Cell = "str | tuple[str, str]"          # text, or (text, colour)


def table(rows: list[list], headers: list[str], style: Style, *, indent: str = "") -> str:
    """Aligned columns; a cell is ``"text"`` or ``("text", "red")``.  Padding ignores colour codes."""
    def text(c) -> str:
        return c[0] if isinstance(c, tuple) else str(c)

    widths = [len(h) for h in headers]
    for r in rows:
        for i, c in enumerate(r):
            widths[i] = max(widths[i], len(text(c)))
    lines = [indent + style.dim("  ".join(h.ljust(widths[i]) for i, h in enumerate(headers)).rstrip())]
    for r in rows:
        cells = []
        for i, c in enumerate(r):
            t = text(c).ljust(widths[i])
            cells.append(style.paint(t, c[1]) if isinstance(c, tuple) else t)
        lines.append(indent + "  ".join(cells).rstrip())
    return "\n".join(lines)


def wrap(text: str, width: int, indent: str = "", first: str | None = None) -> str:
    """Wrap to ``width``; ``first`` is the prefix of the first line (a bullet), ``indent`` of the others.
    Long words (paths, addresses) are never split."""
    import textwrap
    return "\n".join(textwrap.wrap(text, width=max(20, width), initial_indent=indent if first is None else first,
                                   subsequent_indent=indent, break_long_words=False, break_on_hyphens=False)) or indent


def term_width(default: int = 100) -> int:
    try:
        return max(40, min(os.get_terminal_size().columns, 140))
    except OSError:
        return default
