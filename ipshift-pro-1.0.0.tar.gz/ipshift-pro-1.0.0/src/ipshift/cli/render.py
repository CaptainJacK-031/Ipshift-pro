"""Live-state views: turn the daemon's data into terminal text.

Everything here is a pure function (data in, string out, the clock passed in), so the exact
output can be tested without a terminal, a daemon or a network.
"""
from __future__ import annotations

from ..net.local import KIND_NAMES
from .ui import Style, fmt_ago, fmt_clock, fmt_duration, fmt_ms

LABEL = 14

PROTECTION = {
    "protected": ("PROTECTED", "green"),
    "connecting": ("CONNECTING", "cyan"),
    "blocked": ("BLOCKED", "yellow"),
    "no-killswitch": ("NO KILL SWITCH", "yellow"),
    "unprotected": ("UNPROTECTED", "red"),
}


def badge(level: str, style: Style) -> str:
    text, colour = PROTECTION.get(level, (str(level).upper(), "dim"))
    return style.paint(text, colour, "bold")


def kv(label: str, text, style: Style, *, width: int = LABEL) -> str:
    """``Label    text`` with continuation lines aligned under the text."""
    lines = str(text).split("\n")
    pad = " " * (2 + width)
    head = f"  {style.bold(label.ljust(width))}{lines[0]}"
    return "\n".join([head] + [pad + line for line in lines[1:]])


def interval_text(value) -> str:
    try:
        return f"{float(value):g} s"
    except (TypeError, ValueError):
        return "-"


def network_name(net: dict) -> str:
    kind = net.get("hotspot") or KIND_NAMES.get(net.get("kind") or "", net.get("kind")) or "no connection"
    iface = net.get("default_iface")
    out = f"{kind} on {iface}" if iface else str(kind)
    if net.get("gateway"):
        out += f", gateway {net['gateway']}"
    return out


# ---- the pieces of the status view ---------------------------------------------------------------------
def vpn_text(vpn: dict, style: Style) -> str:
    state = vpn.get("state", "?")
    p = vpn.get("profile") or {}
    if state == "connected" and p:
        facts = ", ".join(x for x in (p.get("protocol"), p.get("tier"), p.get("country") or None) if x)
        lines = [f"{style.paint('connected', 'green')} to {p.get('name', '?')} ({facts}) for "
                 f"{fmt_duration(vpn.get('uptime'))}"]
        more = []
        if vpn.get("server"):
            more.append(f"server {vpn['server']}")
        if vpn.get("iface"):
            more.append(f"interface {vpn['iface']}")
        hs = (vpn.get("health") or {}).get("handshake_age")
        if hs is not None:
            more.append(f"handshake {fmt_duration(hs)} ago")
        if more:
            lines.append(style.dim(", ".join(more)))
        return "\n".join(lines)
    if state in ("connecting", "switching"):
        what = f" ({vpn['busy']})" if vpn.get("busy") else ""
        return style.paint(f"{state}{what}", "cyan") + " ..."
    if state == "failed":
        err = vpn.get("last_error") or "unknown error"
        return f"{style.paint('failed', 'red')}: {err}"
    return "not connected" + (f"  {style.dim('(last error: ' + vpn['last_error'] + ')')}" if vpn.get("last_error") else "")


def public_text(pub: dict, level: str, style: Style, now: float | None = None) -> str:
    if pub.get("v4"):
        out = style.bold(pub["v4"])
        if pub.get("verified_at"):
            out += style.dim(f"   seen through the tunnel, verified {fmt_ago(pub['verified_at'], now)}")
        return out
    if level == "blocked":
        return style.paint("none", "yellow") + style.dim("   the kill switch is blocking all traffic")
    if level == "unprotected":
        return style.dim("not looked up while unprotected   (to see your real address: ipshift ip --direct)")
    return style.dim("-")


def private_lines(ips: list[dict], style: Style) -> str:
    rows = [p for p in ips or [] if p.get("family", 4) == 4] or list(ips or [])
    if not rows:
        return style.dim("-")
    out = []
    for p in rows:
        tags = []
        if p.get("kind") == "tunnel":
            tags.append("VPN tunnel")
        elif p.get("kind"):
            tags.append(KIND_NAMES.get(p["kind"], p["kind"]))
        if p.get("primary"):
            tags.append("default route")
        out.append(f"{p.get('ip', '?')}  {style.dim(p.get('iface', '') + (' - ' + ', '.join(tags) if tags else ''))}")
    return "\n".join(out)


def killswitch_text(ks: dict, style: Style) -> str:
    if ks.get("error"):
        return f"{style.paint('unknown', 'red')}: {ks['error']}"
    if not ks.get("armed"):
        if ks.get("enabled") is False:
            return style.paint("off", "yellow") + style.dim("   (disabled in the settings: killswitch.enabled)")
        return style.paint("not armed", "yellow") + style.dim("   (it arms itself when you connect)")
    bits = [style.paint("LOCKDOWN: everything is blocked", "red", "bold") if ks.get("lockdown")
            else style.paint("armed", "green")]
    bits.append("LAN blocked" if not ks.get("allow_lan") else "LAN allowed")
    n = int(ks.get("blocked_packets") or 0)
    if n:
        bits.append(f"{n} packet{'s' if n != 1 else ''} blocked")
    if ks.get("dry_run"):
        bits.append("dry run")
    out = " - ".join(bits)
    eps = ks.get("endpoints") or []
    if eps and not ks.get("lockdown"):
        out += "\n" + style.dim("allowed to leave: only the VPN server " + ", ".join(eps))
    return out


def hardening_lines(h: dict, style: Style) -> list[tuple[str, str]]:
    """(label, text) rows for DNS, IPv6 and MAC."""
    rows = []
    if h.get("dns_locked"):
        txt = f"locked to {', '.join(h.get('dns_servers') or []) or '?'}"
        if h.get("dns_intact") is False:
            txt += "  " + style.paint("(changed by another program!)", "red")
        rows.append(("DNS", txt))
    else:
        rows.append(("DNS", style.dim("not locked (locked while connected)")))
    if h.get("ipv6_guard"):
        txt = "switched off on the physical interfaces"
        if h.get("ipv6_intact") is False:
            txt += "  " + style.paint("(changed by another program!)", "red")
        rows.append(("IPv6", txt))
    else:
        rows.append(("IPv6", style.dim("guard off (on while connected)")))
    mac = []
    if h.get("mac_nm_policy"):
        mac.append("random MAC for each new connection (NetworkManager)")
    if h.get("mac_overrides"):
        mac.append("changed by hand on " + ", ".join(h["mac_overrides"]))
    rows.append(("MAC address", ", ".join(mac) if mac else style.dim("unchanged")))
    return rows


def rotation_text(rot: dict, style: Style, now: float | None = None) -> str:
    interval = interval_text(rot.get("interval"))
    if not rot.get("running"):
        out = f"stopped   {style.dim('(interval ' + interval + ', minimum ' + interval_text(rot.get('minimum_interval', 1)) + ')')}"
    else:
        head = f"{style.paint('running', 'green')}: every {interval} ({rot.get('strategy', '?')})"
        if rot.get("next_in") is not None:
            head += f", next in {rot['next_in']:.1f} s"
        out = head
    if rot.get("ticks"):
        counts = (f"{rot.get('ok', 0)} changed, {rot.get('failed', 0)} failed, "
                  f"{rot.get('unchanged', 0)} unchanged, {rot.get('skipped', 0)} skipped")
        out += "\n" + style.dim(counts)
    if rot.get("stalled"):
        out += "\n" + style.paint(f"STALLED: {rot.get('consecutive_failures', 0)} failures in a row; "
                                  "traffic stays blocked until a connection works", "red", "bold")
    elif rot.get("consecutive_failures"):
        out += "\n" + style.paint(f"{rot['consecutive_failures']} failure(s) in a row", "yellow")
    last = rot.get("last") or {}
    if last.get("status"):
        sym = {"success": style.ok, "unchanged": style.warn, "failed": style.fail}.get(last["status"], style.skip)
        bits = [last["status"], last.get("profile") or ""]
        if last.get("ip"):
            bits.append(last["ip"])
        if last.get("ms") is not None:
            bits.append("in " + fmt_ms(last["ms"]))
        line = f"last: {sym} " + " ".join(b for b in bits if b)
        if last.get("error"):
            line += style.dim(f" ({str(last['error'])[:90]})")
        out += "\n" + line
    return out


def privacy_text(pr: dict | None, style: Style, now: float | None = None) -> str:
    if not pr:
        return style.dim("not tested yet   (run: ipshift privacy-check)")
    colour = {"A": "green", "B": "green", "C": "yellow", "D": "red", "F": "red"}.get(pr.get("grade", ""), None)
    head = style.paint(f"grade {pr.get('grade', '?')} ({pr.get('score', '?')}/100)", colour, "bold") if colour else \
        f"grade {pr.get('grade', '?')}"
    return f"{head}  {pr.get('verdict', '')}   {style.dim('checked ' + fmt_ago(pr.get('ts'), now))}"


# ---- events -----------------------------------------------------------------------------------
def event_text(ev: dict) -> str:
    kind, d = ev.get("kind", "?"), ev.get("data") or {}
    if d.get("message"):
        return str(d["message"])
    name = d.get("name") or d.get("profile") or "?"
    if kind == "connecting":
        return f"Connecting to {name}"
    if kind == "connected":
        out = f"Connected to {name}: public IP {d.get('ip', '?')}"
        if d.get("previous"):
            out += f" (was {d['previous']})"
        if d.get("ms") is not None:
            out += f" in {fmt_ms(d['ms'])}"
        if d.get("via") == "hot-swap":
            out += " [hot-swap]"
        return out
    if kind == "unchanged":
        return f"{name} gave the same public IP as before ({d.get('ip', '?')})"
    if kind == "cancelled":
        return f"Connecting to {name} was cancelled"
    if kind == "connect_failed":
        return f"Could not connect to {name}: {d.get('error', 'unknown error')}"
    if kind == "disconnected":
        return f"Disconnected from {name}" + ("" if d.get("released") else " (the kill switch is still blocking)")
    if kind == "recovering":
        return f"Reconnecting to {d.get('profile', '?')}"
    if kind == "rotation_started":
        return f"Rotation started: every {interval_text(d.get('interval'))}, strategy {d.get('strategy', '?')}"
    if kind == "rotation_stopped":
        return "Rotation stopped"
    if kind == "interval_changed":
        return f"Rotation interval is now {interval_text(d.get('interval'))}"
    if kind == "rotation_recovered":
        return f"Rotation recovered after {d.get('after_failures', '?')} failed attempt(s)"
    if kind == "rotation_overrun":
        return f"A rotation took {d.get('took', '?')} s; skipped {d.get('skipped', '?')} tick(s)"
    return kind.replace("_", " ")


def event_symbol(level: str, style: Style) -> str:
    if level in ("error", "critical"):
        return style.fail
    if level == "warning":
        return style.warn
    return style.info


def render_event(ev: dict, style: Style) -> str:
    text = event_text(ev)
    if ev.get("level") == "critical":
        text = style.paint(text, "red", "bold")
    line = f"{fmt_clock(ev.get('ts'))}  {event_symbol(ev.get('level', 'info'), style)} {text}"
    hint = (ev.get("data") or {}).get("hint")
    if hint:
        line += "\n" + " " * 10 + style.dim("hint: " + str(hint))
    return line


# ---- the views ------------------------------------------------------------------------------------
def render_status(st: dict, style: Style, *, now: float | None = None) -> str:
    d, prot = st.get("daemon", {}), st.get("protection", {})
    level = prot.get("level", "?")
    out = [style.bold(f"IPShift Pro {d.get('version', '?')}") +
           style.dim(f"   daemon pid {d.get('pid', '?')}, up {fmt_duration(d.get('uptime'))}")]
    if d.get("simulated"):
        out.append(style.paint("  SIMULATION: nothing on this machine is touched; the network and the VPNs are fake",
                               "magenta"))
    out.append("")
    out.append(kv("Protection", f"{badge(level, style)}  {prot.get('message', '')}", style))
    out.append(kv("VPN", vpn_text(st.get("vpn", {}), style), style))
    pub = st.get("public") or {}
    out.append(kv("Public IP", public_text(pub, level, style, now), style))
    if st.get("vpn", {}).get("connected"):
        out.append(kv("Public IPv6", pub.get("v6") or style.dim("none (the tunnel carries no IPv6)"), style))
    net = st.get("network") or {}
    out.append(kv("Private IP", private_lines(net.get("private_ips"), style), style))
    out.append(kv("Network", network_name(net), style))
    out.append(kv("Kill switch", killswitch_text(st.get("killswitch") or {}, style), style))
    h = st.get("hardening") or {}
    for label, text in hardening_lines(h, style):
        if label == "MAC address" and not (h.get("mac_nm_policy") or h.get("mac_overrides")):
            continue
        out.append(kv(label, text, style))
    out.append(kv("Rotation", rotation_text(st.get("rotation") or {}, style, now), style))
    out.append(kv("Privacy check", privacy_text(st.get("privacy"), style, now), style))
    pf = st.get("profiles") or {}
    if pf.get("total"):
        out.append(kv("Profiles", f"{pf.get('usable', 0)} usable of {pf['total']}", style))
    else:
        out.append(kv("Profiles", style.paint("none imported", "yellow") + style.dim("   (ipshift vpn import FILE)"), style))
    alerts = (st.get("alerts") or [])[-5:]
    if alerts:
        out += ["", style.bold("  Recent alerts")]
        out += ["    " + render_event(a, style).replace("\n", "\n    ") for a in alerts]
    return "\n".join(out)


def render_ip(info: dict, style: Style, *, now: float | None = None) -> str:
    level = info.get("protection", "?")
    pub = info.get("public") or {}
    out = [kv("Public IP", public_text(pub, level, style, now), style)]
    if pub.get("source") == "direct":
        out[0] = kv("Public IP", style.bold(pub["v4"]) + "   " + style.paint("your real, unprotected address", "yellow"), style) \
            if pub.get("v4") else out[0]
    if pub.get("source") == "tunnel" or pub.get("v6"):
        out.append(kv("Public IPv6", pub.get("v6") or style.dim("none"), style))
    out.append(kv("Private IP", private_lines(info.get("private"), style), style))
    out.append(kv("Network", info.get("network", "unknown"), style))
    out.append(kv("Protection", badge(level, style), style))
    if info.get("note"):
        out.append(kv("Note", style.dim(info["note"]), style))
    return "\n".join(out)


def render_connect(res: dict, style: Style) -> str:
    out = [f"{style.ok} Connected to {style.bold(res.get('profile_name', '?'))} ({res.get('backend', '?')}) "
           f"in {fmt_ms(res.get('duration_ms'))}"]
    ip = style.bold(res.get("exit_ip", "?"))
    if res.get("previous_ip"):
        ip += style.dim(f"   (was {res['previous_ip']})")
    out.append(kv("Public IP", ip, style))
    if res.get("exit_ipv6"):
        out.append(kv("Public IPv6", res["exit_ipv6"], style))
    out.append(kv("Server", res.get("server", "?") + (style.dim("   hot-swapped") if res.get("via") == "hot-swap" else ""),
                  style))
    if res.get("dns"):
        out.append(kv("DNS", f"{', '.join(res['dns'])} {style.dim('(only the tunnel answers)')}", style))
    if res.get("previous_ip") and not res.get("changed", True):
        out.append(f"{style.warn} The public IP did not change: this server exits at the same address as the last one")
    if res.get("rotation_stopped"):
        out.append(style.dim("  Rotation was running and has been paused (an explicit choice stays put). "
                             "Resume with: ipshift rotate"))
    return "\n".join(out)


def render_rotation_started(rot: dict, style: Style) -> str:
    out = [f"{style.ok} Rotation started: a new address every {interval_text(rot.get('interval'))} "
           f"({rot.get('profiles_in_rotation', '?')} profile(s), strategy {rot.get('strategy', '?')})"]
    if rot.get("warning"):
        out.append(f"{style.warn} {rot['warning']}")
    if float(rot.get("interval") or 0) < 5:
        out.append(style.dim("  A cycle only counts as done when the new tunnel is up and the new public IP is verified,\n"
                             "  so the real pace can be slower than the interval; ticks that would overlap are skipped."))
    return "\n".join(out)


def render_killswitch(ks: dict, style: Style) -> str:
    return kv("Kill switch", killswitch_text(ks, style), style)


def render_hardening(h: dict, style: Style) -> str:
    return "\n".join(kv(label, text, style) for label, text in hardening_lines(h, style))
