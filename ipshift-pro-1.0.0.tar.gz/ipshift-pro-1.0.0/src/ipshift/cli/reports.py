"""Report-style views: privacy check, doctor, history, profiles, configuration, restore, import."""
from __future__ import annotations

import time

from .render import KIND_NAMES, kv
from .ui import Style, fmt_datetime, fmt_duration, fmt_ms, table, visible_len, wrap

APPLIES = {"now": "takes effect now", "next_connect": "takes effect at the next connection",
           "restart": "needs a daemon restart (sudo systemctl restart ipshiftd)"}


def _wrapped(text: str, width: int, indent: str, style: Style, *, dim: bool = False) -> str:
    out = wrap(text, width - len(indent), indent)
    return style.dim(out) if dim else out


# ---- privacy check -------------------------------------------------------------------------------
def render_report(rep: dict, style: Style, *, width: int = 100, verbose: bool = False) -> str:
    verdict = rep.get("verdict", "?")
    colour = {"protected": "green", "protected-with-warnings": "yellow", "blocked": "yellow",
              "at-risk": "red", "unprotected": "red", "exposed": "red"}.get(verdict, "dim")
    out = [style.bold("Privacy check") +
           style.dim(f"   {rep.get('mode', 'full')} test, {fmt_ms(rep.get('duration_ms'))}")]
    if rep.get("simulated"):
        out.append(style.paint(wrap("SIMULATION: these results come from the fake network, not from this machine",
                                    width, "  "), "magenta"))
    out += ["", style.paint(wrap(rep.get("headline", verdict), width, "  "), colour, "bold"),
            f"  Score {rep.get('score', '?')}/100, grade {rep.get('grade', '?')}",
            style.dim(wrap("a summary of what this tool can test, not a guarantee of anonymity", width, "  ")), ""]
    groups = (("Leaks", lambda f: f.get("status") == "fail" and f.get("leak")),
              ("Problems", lambda f: f.get("status") == "fail" and not f.get("leak")),
              ("Warnings", lambda f: f.get("status") == "warn"),
              ("Passed", lambda f: f.get("status") == "pass"),
              ("Not tested", lambda f: f.get("status") == "skip"))
    findings = rep.get("findings", [])
    for title, pick in groups:
        items = [f for f in findings if pick(f)]
        if not items:
            continue
        out.append(style.bold(f"  {title}"))
        for f in items:
            sym = style.status_symbol(f.get("status", "skip"))
            out.append(f"   {sym} {f.get('title', f.get('id', '?'))}")
            quiet = f.get("status") in ("pass", "skip")
            if f.get("detail"):
                out.append(_wrapped(f["detail"], width, "       ", style, dim=quiet))
            if f.get("hint") and f.get("status") in ("fail", "warn"):
                out.append(style.paint(_wrapped("fix: " + f["hint"], width, "       ", style), "cyan"))
            if verbose and f.get("evidence"):
                for k, v in f["evidence"].items():
                    out.append(style.dim(f"       {k}: {v}"))
        out.append("")
    out.append(style.bold("  What this check cannot see"))
    for line in rep.get("not_covered", []):
        out.append(style.dim(wrap(line, width, "     ", first="   " + style.bullet + " ")))
    return "\n".join(out)


# ---- doctor ---------------------------------------------------------------------------------------
def render_doctor(d: dict, style: Style, *, width: int = 100) -> str:
    checks = d.get("checks", [])
    w = max([len(c["title"]) for c in checks] or [10])
    sym_w = max(visible_len(style.status_symbol(s)) for s in ("ok", "info", "warn", "fail"))
    indent = 2 + sym_w + 1 + w + 2
    out = [style.bold("IPShift doctor"), ""]
    for c in checks:
        sym = style.status_symbol(c["status"])
        head = f"  {sym}{' ' * (sym_w - visible_len(sym))} {c['title'].ljust(w)}  "
        out.append(head + wrap(c["detail"], width, " " * indent)[indent:])
        if c.get("hint"):
            out.append(style.paint(" " * indent + style.arrow + " " + c["hint"], "cyan"))
    s = d.get("summary", {})
    out += ["", f"  {s.get('ok', 0)} ok, {s.get('info', 0)} notes, {s.get('warn', 0)} warnings, {s.get('fail', 0)} problems"]
    out.append("  " + (style.paint("Ready to use.", "green", "bold") if d.get("ready")
                       else style.paint("Not ready: fix the problems marked above first.", "red", "bold")))
    return "\n".join(out)


# ---- history --------------------------------------------------------------------------------------
STATUS_COLOUR = {"success": "green", "failed": "red", "unchanged": "yellow", "cancelled": "dim"}


def render_history(data: dict, style: Style, *, width: int = 100) -> str:
    rows = list(reversed(data.get("rotations", [])))           # oldest first: the newest is at the bottom
    st = data.get("stats") or {}
    out = []
    if not rows:
        out.append(style.dim("  No rotations recorded yet."))
    else:
        cells = []
        for r in rows:
            note = r.get("error") or r.get("reason") or ""
            cells.append([fmt_datetime(r.get("ts")), (r.get("status", "?"), STATUS_COLOUR.get(r.get("status"), "dim")),
                          r.get("profile_name") or "-", r.get("old_ip") or "-", r.get("new_ip") or "-",
                          fmt_ms(r.get("duration_ms")), note[:48]])
        out.append(table(cells, ["TIME", "RESULT", "PROFILE", "FROM", "TO", "TOOK", "NOTE"], style, indent="  "))
    if st.get("total"):
        avg = f", average {fmt_ms(st['avg_duration_ms'])}" if st.get("avg_duration_ms") is not None else ""
        out += ["", style.dim(f"  {st['total']} recorded: {st.get('success', 0)} changed the address, "
                              f"{st.get('failed', 0)} failed, {st.get('unchanged', 0)} unchanged; "
                              f"{st.get('unique_ips', 0)} different addresses{avg}")]
    ev = (data.get("events") or [])[:8]
    if ev:
        out += ["", style.bold("  Recent alerts")]
        for e in reversed(ev):
            sym = style.fail if e.get("level") in ("error", "critical") else style.warn
            out.append(f"   {fmt_datetime(e.get('ts'))}  {sym} {e.get('message') or e.get('kind')}")
    return "\n".join(out)


# ---- profiles -------------------------------------------------------------------------------------
def profile_state(p: dict, current: str | None, style: Style, now: float) -> tuple[str, str]:
    if p.get("id") == current:
        return "active", "green"
    if not p.get("enabled", True):
        return "disabled", "dim"
    if p.get("quarantined"):
        left = max(0.0, float(p.get("quarantined_until") or 0) - now)
        return f"benched {fmt_duration(left)}", "red"
    if p.get("needs_auth") and not p.get("has_auth"):
        return "needs login", "yellow"
    return "ready", "green"


def render_profiles(data: dict, style: Style, *, now: float | None = None) -> str:
    now = time.time() if now is None else now
    profiles = data.get("profiles", [])
    if not profiles:
        return "\n".join([style.dim("  No VPN profiles yet."), "",
                          "  Import one (free, paid or your own server):",
                          "    ipshift vpn import my-server.conf      # WireGuard",
                          "    ipshift vpn import provider.ovpn       # OpenVPN"])
    rotating = set(data.get("in_rotation") or [])
    rows = []
    for p in profiles:
        text, colour = profile_state(p, data.get("current"), style, now)
        rows.append([p.get("id", "?"), p.get("name", "?"), p.get("protocol", "?"), p.get("tier", "?"),
                     p.get("country") or "-", (text, colour), "yes" if p.get("id") in rotating else "-",
                     f"{p.get('ok_count', 0)}/{p.get('fail_count', 0)}"])
    out = [table(rows, ["ID", "NAME", "PROTOCOL", "TIER", "COUNTRY", "STATE", "ROTATING", "OK/FAIL"], style, indent="  ")]
    free = [p for p in profiles if p.get("tier") == "free"]
    if free:
        out += ["", style.dim("  Free VPNs can log your traffic, inject ads or sell data. For anything sensitive,"),
                style.dim("  use a paid provider or your own server.")]
    return "\n".join(out)


def render_import(res: dict, style: Style, *, width: int = 100) -> str:
    p = res.get("profile", {})
    ends = len(p.get("endpoints") or [])
    facts = ", ".join(x for x in (p.get("protocol"), p.get("tier"), p.get("country") or None) if x)
    out = [f"{style.ok} Imported {style.bold(p.get('name', '?'))} ({facts}), id {p.get('id', '?')}, "
           f"{ends} server{'s' if ends != 1 else ''}"]
    if p.get("needs_auth") and not p.get("has_auth"):
        out.append(f"{style.warn} It needs a username and password: ipshift vpn auth {p.get('id', 'NAME')}")
    for w in res.get("warnings", []):
        out.append(f"{style.warn} {w}")
    for r in res.get("removed", []):
        out.append(style.dim(f"  replaced {r}"))
    if p.get("tier") == "free":
        out.append(style.dim(_wrapped("Free VPNs can log, inject ads or sell your data; prefer paid or self-hosted "
                                      "servers for anything sensitive.", width, "  ", style)))
    return "\n".join(out)


# ---- configuration --------------------------------------------------------------------------------
def fmt_value(v) -> str:
    if isinstance(v, bool):
        return "true" if v else "false"
    if v is None:
        return "null"
    if isinstance(v, (list, tuple)):
        return ", ".join(fmt_value(x) for x in v) if v else "[]"
    if isinstance(v, str):
        return v if v else '""'
    return str(v)


def render_config(data: dict, style: Style, *, section: str | None = None) -> str:
    conf = data.get("config", {})
    out = [style.dim(f"  file: {data.get('file', '?')}" + ("  (simulation: changes are not saved)" if data.get("simulated") else ""))]
    for sec, values in conf.items():
        if section and sec != section:
            continue
        out += ["", style.bold(f"  [{sec}]")]
        w = max((len(k) for k in values), default=1)
        for k, v in values.items():
            out.append(f"    {k.ljust(w)}  {fmt_value(v)}")
    for w_ in data.get("warnings", []):
        out.append(f"{style.warn} {w_}")
    return "\n".join(out)


def render_config_set(res: dict, style: Style) -> str:
    when = APPLIES.get(res.get("applies", ""), "")
    saved = "saved to the config file" if res.get("saved") else "not saved to the config file"
    return (f"{style.ok} {res.get('key')}: {fmt_value(res.get('old'))} {style.arrow} {style.bold(fmt_value(res.get('value')))}"
            f"   {style.dim('(' + when + '; ' + saved + ')')}")


# ---- restore -----------------------------------------------------------------------------------------
def render_restore(rep: dict, style: Style) -> str:
    out = []
    ks = str(rep.get("killswitch", ""))
    failed = ks.startswith("FAILED")
    out.append(f"  {style.fail if failed else style.ok} {style.bold('Firewall'.ljust(14))}"
               f"{ks if failed else 'kill switch rules removed'}")
    dns = rep.get("dns")
    out.append(f"  {style.ok} {style.bold('DNS'.ljust(14))}{'original DNS settings put back' if dns else 'nothing to restore'}")
    v6 = rep.get("ipv6") or []
    out.append(f"  {style.ok} {style.bold('IPv6'.ljust(14))}" + (f"switched back on for {', '.join(v6)}" if v6 else "nothing to restore"))
    if "mac" in rep:
        mac = rep.get("mac") or []
        out.append(f"  {style.ok} {style.bold('MAC address'.ljust(14))}" + (f"original address put back on {', '.join(mac)}" if mac else "nothing to restore"))
    n = int(rep.get("openvpn_stopped") or 0)
    gone = rep.get("tunnel_interface_removed")
    bits = ([f"stopped {n} leftover OpenVPN process{'es' if n != 1 else ''}"] if n else []) + \
           (["removed the tunnel interface"] if gone else [])
    out.append(f"  {style.ok} {style.bold('Leftovers'.ljust(14))}" + (", ".join(bits) if bits else "none found"))
    if failed:
        out += ["", f"{style.warn} The firewall could not be removed, so the network may still be blocked.",
                "  Remove it by hand with:  sudo nft delete table inet ipshift"]
    return "\n".join(out)


# ---- small things used by several commands --------------------------------------------------------------
def render_kind(kind: str | None) -> str:
    return KIND_NAMES.get(kind or "", kind or "-")


def render_stop(res: dict, style: Style) -> str:
    if res.get("stopped") == "rotation":
        return f"{style.ok} Rotation stopped" + (" - the VPN connection stays up" if res.get("connected") else "")
    if res.get("released"):
        return f"{style.ok} Stopped. The VPN is disconnected and normal networking is back " \
               f"{style.dim('(your real IP address is visible again)')}"
    return f"{style.ok} Stopped. The VPN is disconnected, but the kill switch keeps blocking all traffic " \
           f"{style.dim('(release it with: ipshift killswitch off)')}"


def render_kv_block(rows: list[tuple[str, str]], style: Style) -> str:
    return "\n".join(kv(a, b, style) for a, b in rows)
