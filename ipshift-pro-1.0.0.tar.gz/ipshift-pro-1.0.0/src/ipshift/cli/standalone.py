"""What the CLI can still do when the daemon is not reachable.

Only things that are safe without it: read-only facts about this machine, the doctor, a
direct public-address lookup the person asked for, and the emergency ``restore`` (which
needs root).  Nothing here starts a VPN or arms a firewall.
"""
from __future__ import annotations

import logging
from pathlib import Path

from ..config import Config
from ..errors import ConfigError, IPShiftError, PrivilegeError
from ..firewall.killswitch import KillSwitch
from ..monitor import describe_network
from ..net.echo import EchoResolver
from ..net.local import NetInfo
from ..paths import Paths, default_paths
from ..privacy.hardening import restore_all
from ..sysutil import Runner, is_root
from ..vpn.profile import ProfileStore

log = logging.getLogger(__name__)


def system_paths() -> Paths:
    """The daemon always runs as root, so its files are where root's paths point, whoever asks."""
    return default_paths(euid=0)


def load_config(explicit: str | None = None) -> tuple[Config, Paths]:
    """The daemon's configuration if it can be read, the built-in defaults otherwise."""
    paths = system_paths()
    path = Path(explicit) if explicit else paths.config_file
    try:
        return Config.load(path), paths
    except ConfigError:
        if explicit:
            raise
        cfg = Config()
        cfg.warnings.append(f"could not read {path}: showing the built-in defaults")
        return cfg, paths


def local_facts(cfg: Config) -> dict:
    """What can be seen from this process alone: private addresses and, as root, the firewall."""
    runner = Runner()
    net = NetInfo(runner, cfg.vpn.ip_bin)
    out: dict = {"private": [], "network": "unknown", "killswitch_armed": None, "root": is_root(), "error": None}
    try:
        summary = net.summary()
        out["private"] = summary.get("private_ips", [])
        out["network"] = describe_network(summary)
    except Exception as e:                                   # no 'ip' program, odd namespace...
        out["error"] = str(e)
    if is_root():
        try:
            out["killswitch_armed"] = KillSwitch(cfg.killswitch, cfg.vpn, runner, net).is_armed()
        except IPShiftError as e:
            out["error"] = out["error"] or str(e)
    return out


def local_ip_info(cfg: Config, *, direct: bool = False) -> dict:
    """``ipshift ip`` without the daemon: private addresses, and the real public address on request."""
    facts = local_facts(cfg)
    out = {"private": facts["private"], "network": facts["network"], "state": "unknown", "protection": "unknown",
           "public": {"v4": None, "v6": None, "source": None, "verified_at": None}, "daemon": False,
           "note": "The daemon is not running, so the VPN state is unknown."}
    if facts["killswitch_armed"]:
        out["protection"] = "blocked"
        out["note"] = ("Firewall rules from IPShift are still in place and block all traffic "
                       "(release them with: sudo ipshift restore)")
        return out
    if direct:
        import time
        echo = EchoResolver(cfg.privacy)
        r4 = echo.lookup(4)
        r6 = echo.lookup(6) if cfg.privacy.check_ipv6 else None
        out["public"] = {"v4": r4.ip if r4.ok else None, "v6": r6.ip if r6 and r6.ok else None,
                         "source": "direct", "verified_at": time.time()}
        out["note"] = ("This is the address of this machine's own connection, with no VPN involved"
                       if r4.ok else f"The public address could not be looked up ({r4.error})")
    else:
        out["note"] += " To look up this machine's own public address anyway: ipshift ip --direct"
    return out


def standalone_doctor(cfg: Config, paths: Paths | None = None) -> dict:
    from ..doctor import run_doctor
    paths = paths or system_paths()
    store = None
    if paths.profiles_dir.is_dir():                          # never create the directory just to look at it
        try:
            store = ProfileStore(paths.profiles_dir)
        except OSError:
            store = None
    out = run_doctor(cfg, paths, runner=Runner(), store=store)
    out["daemon"] = False
    out["checks"].insert(0, {"id": "daemon", "title": "Daemon", "status": "warn",
                             "detail": "the IPShift daemon is not running, so nothing is protected or rotating",
                             "hint": "start it with: sudo systemctl start ipshiftd"})
    summary = {s: sum(1 for c in out["checks"] if c["status"] == s) for s in ("ok", "info", "warn", "fail")}
    out["summary"], out["ready"] = summary, summary["fail"] == 0
    return out


def standalone_restore(cfg: Config, paths: Paths | None = None, *, include_mac: bool = True) -> dict:
    """Undo everything IPShift did (firewall, DNS, IPv6, MAC, stray tunnels) without the daemon."""
    if not is_root():
        raise PrivilegeError("the daemon is not running, so restoring the network needs root",
                             hint="run: sudo ipshift restore")
    paths = paths or system_paths()
    runner = Runner()
    return restore_all(cfg, runner, NetInfo(runner, cfg.vpn.ip_bin), paths, include_mac=include_mac)
