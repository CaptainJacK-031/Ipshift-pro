"""``ipshift``: the command-line client of the IPShift daemon.

The CLI never needs root: it talks to ``ipshiftd`` over a Unix socket.  The few things it can do
without the daemon (doctor, ``ip --direct``, the emergency ``restore``) are in ``standalone``.
"""
from __future__ import annotations

import contextlib
import json
import os
import sys

from ..errors import DaemonUnavailable, IPShiftError
from .context import FAILED, INTERRUPTED, NO_DAEMON, OK, USAGE, Context, UsageError
from .parser import build_parser

__all__ = ["main"]


def report_error(ctx: Context, e: Exception, prefix: str = "ipshift") -> None:
    hint = getattr(e, "hint", None)
    if ctx.json:
        data = e.to_dict() if isinstance(e, IPShiftError) else {"code": "usage", "message": str(e), "hint": None}
        ctx.warn(json.dumps({"error": data}))
        return
    st = ctx.err_style
    ctx.warn(f"{prefix}: {st.paint(str(e), 'red')}" + (f"\n  {st.dim('hint: ' + hint)}" if hint else ""))


def main(argv: list[str] | None = None, *, out=None, err=None, inp=None, client_factory=None, sleep=None,
         secret_reader=None) -> int:
    """Run one command; returns the exit code (0 ok, 1 failed, 2 usage, 3 no daemon, 4 privacy problems, 130 Ctrl-C)."""
    extra = {k: v for k, v in (("out", out), ("err", err), ("inp", inp), ("client_factory", client_factory),
                               ("sleep", sleep), ("secret_reader", secret_reader)) if v is not None}
    ctx = Context(**extra)
    parser = build_parser()
    with contextlib.redirect_stdout(ctx.out), contextlib.redirect_stderr(ctx.err):
        try:
            args = parser.parse_args(sys.argv[1:] if argv is None else argv)
        except SystemExit as e:                              # --help, --version, or a usage error
            return e.code if isinstance(e.code, int) else (OK if e.code is None else USAGE)
    ctx.json, ctx.socket, ctx.config = args.json, args.socket, args.config
    ctx.no_color, ctx.ascii_only = args.no_color, args.ascii
    if args.func is None:
        with contextlib.redirect_stdout(ctx.out):
            (parser if args.command is None else _subparser(parser, args.command)).print_help()
        return OK
    try:
        return int(args.func(ctx, args) or OK)
    except UsageError as e:
        report_error(ctx, e)
        return USAGE
    except DaemonUnavailable as e:
        report_error(ctx, e)
        return NO_DAEMON
    except IPShiftError as e:
        report_error(ctx, e)
        return FAILED
    except KeyboardInterrupt:
        ctx.warn("")
        return INTERRUPTED
    except BrokenPipeError:                                  # `ipshift history | head`
        with contextlib.suppress(OSError, ValueError, AttributeError):
            os.dup2(os.open(os.devnull, os.O_WRONLY), ctx.out.fileno())    # so the exit flush cannot fail again
        return OK
    except Exception as e:                                   # a bug: say so plainly, keep the traceback for debugging
        if os.environ.get("IPSHIFT_DEBUG"):
            raise
        ctx.warn(f"ipshift: unexpected error ({type(e).__name__}: {e})\n"
                 "  This is a bug. Run again with IPSHIFT_DEBUG=1 to see the details, and please report it.")
        return FAILED


def _subparser(parser, name: str):
    for action in parser._actions:                           # noqa: SLF001 - argparse has no public lookup
        choices = getattr(action, "choices", None)
        if isinstance(choices, dict) and name in choices:
            return choices[name]
    return parser


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
