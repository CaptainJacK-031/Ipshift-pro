"""IPShift Pro - VPN-based IP rotation with leak protection and a kill switch."""

__version__ = "1.0.0"
APP_NAME = "IPShift Pro"
