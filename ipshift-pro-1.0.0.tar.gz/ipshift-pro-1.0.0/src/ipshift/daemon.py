"""ipshiftd - the privileged daemon.

It owns the engine (VPN, firewall, rotation, monitor) and serves the CLI and the GUI over a
Unix socket.  It needs root to manage nftables, routes and tunnels; ``--simulate`` runs the
whole thing against a fake network instead, without root and without touching the system.
"""
from __future__ import annotations

import argparse
import fcntl
import logging
import os
import signal
import socket
import sys
import threading
from pathlib import Path

from . import APP_NAME, __version__
from .config import Config
from .engine import Engine
from .errors import ConfigError, IPShiftError
from .ipc.server import IpcServer
from .logging_setup import setup_logging
from .paths import Paths, default_paths
from .sysutil import ensure_private_dir, is_root

log = logging.getLogger("ipshift.daemon")


def sd_notify(message: str) -> bool:
    """Tell systemd about our state (Type=notify).  Silently does nothing outside systemd."""
    addr = os.environ.get("NOTIFY_SOCKET")
    if not addr:
        return False
    if addr.startswith("@"):
        addr = "\0" + addr[1:]
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM) as s:
            s.connect(addr)
            s.sendall(message.encode())
        return True
    except OSError:
        return False


class PidLock:
    """One daemon per machine: an exclusive lock on the pid file, held for the process lifetime."""

    def __init__(self, path: Path):
        self.path = Path(path)
        self._fd: int | None = None

    def acquire(self) -> None:
        ensure_private_dir(self.path.parent)
        fd = os.open(self.path, os.O_RDWR | os.O_CREAT, 0o644)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            try:
                other = os.read(fd, 32).decode(errors="replace").strip()
            except OSError:
                other = "?"
            os.close(fd)
            raise IPShiftError(f"another ipshiftd is already running (pid {other})") from None
        os.ftruncate(fd, 0)
        os.write(fd, f"{os.getpid()}\n".encode())
        self._fd = fd

    def release(self) -> None:
        if self._fd is None:
            return
        try:
            self.path.unlink()
        except OSError:
            pass
        os.close(self._fd)
        self._fd = None


def harden_process() -> None:
    """The daemon holds VPN keys in memory: no core dumps, and nothing it creates is group/world readable."""
    os.umask(0o077)
    try:
        import resource
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    except (ImportError, ValueError, OSError):
        pass
    try:
        import ctypes
        ctypes.CDLL(None, use_errno=True).prctl(4, 0, 0, 0, 0)       # PR_SET_DUMPABLE = 0
    except (OSError, AttributeError):
        pass


class Daemon:
    """Engine + socket server + pid lock, startable and stoppable as a unit (tests use it in-process)."""

    def __init__(self, cfg: Config, paths: Paths, *, simulate: bool = False, sim_speed: float = 1.0,
                 demo: bool = True, socket_path: str | Path | None = None):
        self.cfg = cfg
        self.paths = paths
        self.simulate = simulate
        self.socket_path = Path(socket_path) if socket_path else paths.socket
        self.sim_speed, self.demo = sim_speed, demo
        self.engine: Engine | None = None
        self.server: IpcServer | None = None
        self.lock = PidLock(paths.pidfile)
        self.stopped = threading.Event()

    def start(self) -> None:
        self.lock.acquire()                               # nothing else is opened before we know we are the only daemon
        try:
            self.engine = Engine(self.cfg, self.paths, simulate=self.simulate, sim_speed=self.sim_speed,
                                 demo=self.demo)
            self.server = IpcServer(self.engine, self.socket_path, group=self.cfg.daemon.group,
                                    allowed_uids=self.cfg.daemon.allowed_uids)
            self.engine.start()
            self.server.start()
        except BaseException:
            self.stop()
            raise
        sd_notify("READY=1\nSTATUS=IPShift is running" + (" (simulation)" if self.simulate else ""))
        log.info("%s %s is ready%s", APP_NAME, __version__,
                 " (SIMULATION: no real network is touched)" if self.simulate else "")

    def request_stop(self) -> None:
        self.stopped.set()

    def reload(self) -> None:
        if self.engine is None:                           # a SIGHUP that arrives while still starting up
            return
        try:
            out = self.engine.config_reload()
            log.info("configuration reloaded (%d change(s))", len(out["changed"]))
        except IPShiftError as e:
            log.error("could not reload the configuration: %s", e)

    def wait(self) -> None:
        interval = None
        usec = os.environ.get("WATCHDOG_USEC")
        if usec and usec.isdigit() and int(usec) > 0:
            interval = int(usec) / 1e6 / 2
        while not self.stopped.wait(interval):
            sd_notify("WATCHDOG=1")

    def stop(self) -> None:
        sd_notify("STOPPING=1")
        try:
            if self.server:
                self.server.stop()
        finally:
            try:
                if self.engine:
                    self.engine.shutdown()
            finally:
                self.lock.release()
        self.stopped.set()


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="ipshiftd", description=f"{APP_NAME} daemon (needs root; or use --simulate)")
    p.add_argument("--config", help="configuration file (default: /etc/ipshift/config.json)")
    p.add_argument("--simulate", action="store_true",
                   help="run against a simulated network: no root needed, nothing real is touched")
    p.add_argument("--sim-speed", type=float, default=1.0, metavar="X",
                   help="simulation speed: 1 = realistic connection delays, 0 = instant (default 1)")
    p.add_argument("--no-demo", action="store_true", help="simulation: do not create the demo VPN profiles")
    p.add_argument("--socket", help="socket path (default: /run/ipshift/ipshift.sock)")
    p.add_argument("--log-level", choices=("debug", "info", "warning", "error"), help="override daemon.log_level")
    p.add_argument("--foreground", action="store_true", help="accepted for compatibility: the daemon never forks")
    p.add_argument("--version", action="store_true", help="print the version and exit")
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.version:
        print(f"ipshiftd {__version__}")
        return 0
    if args.sim_speed < 0 or args.sim_speed > 100:
        print("ipshiftd: --sim-speed must be between 0 and 100", file=sys.stderr)
        return 2
    if not args.simulate and not is_root():
        print("ipshiftd: must run as root (it manages the firewall, routes and tunnels).\n"
              "          To try it without root, use:  ipshiftd --simulate", file=sys.stderr)
        return 2
    paths = default_paths()
    try:
        cfg = Config.load(Path(args.config) if args.config else paths.config_file)
    except ConfigError as e:
        print(f"ipshiftd: {e}", file=sys.stderr)
        return 2
    setup_logging(args.log_level or cfg.daemon.log_level, None if args.simulate else paths.log_file,
                  redact=cfg.privacy.redact_logs)
    for w in cfg.warnings:
        log.warning("config: %s", w)
    if not args.simulate:
        harden_process()
    daemon = Daemon(cfg, paths, simulate=args.simulate, sim_speed=args.sim_speed, demo=not args.no_demo,
                    socket_path=args.socket or os.environ.get("IPSHIFT_SOCKET"))
    # Handlers first: a SIGTERM that arrives while the daemon is still starting must lead to a clean
    # stop (the event is checked as soon as start-up is done), not to a half-initialised exit.
    signal.signal(signal.SIGTERM, lambda *_: daemon.request_stop())
    signal.signal(signal.SIGINT, lambda *_: daemon.request_stop())
    signal.signal(signal.SIGHUP, lambda *_: daemon.reload())
    try:
        daemon.start()
    except IPShiftError as e:
        log.error("cannot start: %s%s", e, f" ({e.hint})" if e.hint else "")
        return 1
    except OSError as e:
        log.error("cannot start: %s", e)
        return 1
    try:
        daemon.wait()
    finally:
        log.info("shutting down")
        daemon.stop()
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
