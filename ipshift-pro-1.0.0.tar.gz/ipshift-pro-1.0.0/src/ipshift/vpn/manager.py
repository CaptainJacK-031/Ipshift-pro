"""VpnManager: the only place that brings tunnels up and down.

Every connection attempt follows the same order, and that order is what makes
rotation leak-safe:

  1. arm the kill switch - nothing may leave outside a tunnel from now on;
  2. resolve the server name over DoH, through a firewall window that is open
     only to the DoH resolvers and only while the lookup runs;
  3. let exactly that server (ip + protocol + port) through the firewall;
  4. bring the tunnel up and wait until it is really ready;
  5. lock DNS and IPv6 to the tunnel;
  6. ask independent echo services - through the tunnel - for the public IP and
     require them to agree;
  7. only then report success.

A failure at any step tears the tunnel down but leaves the kill switch armed:
traffic stays blocked instead of falling back to the real connection.  Only one
operation runs at a time; an overlapping request is refused with ``BusyError``.
"""
from __future__ import annotations

import contextlib
import logging
import random
import threading
import time
from dataclasses import dataclass, field

from ..errors import (BusyError, DependencyError, IPUnchanged, IPShiftError, KillSwitchError, LeakDetected,
                      PrivilegeError, ProfileError, VerificationError, VpnError, VpnTimeout)
from ..net.resolve import BootstrapResolver, ResolveError
from ..sysutil import parse_ip
from .backend import ConnectRequest, Target, TunnelInfo
from .profile import Profile

log = logging.getLogger(__name__)

STATES = ("disconnected", "connecting", "switching", "connected", "failed")
# errors that say nothing about the quality of the profile itself
_NOT_THE_PROFILES_FAULT = (ProfileError, DependencyError, KillSwitchError, PrivilegeError, BusyError)


@dataclass
class Connection:
    profile: Profile
    tunnel: TunnelInfo
    exit_ip: str
    exit_ipv6: str | None
    since: float
    via: str                                   # connect | hot-swap
    dns: list[str] = field(default_factory=list)


@dataclass
class ConnectResult:
    profile_id: str
    profile_name: str
    backend: str
    server: str
    exit_ip: str
    exit_ipv6: str | None
    previous_ip: str | None
    changed: bool
    via: str
    duration_ms: int
    dns: list[str]

    def to_dict(self) -> dict:
        return dict(self.__dict__)


class VpnManager:
    def __init__(self, cfg, runner, net, store, killswitch, hardening, resolver, echo, history, bus, backends,
                 *, rng: random.Random | None = None):
        self.cfg = cfg
        self.runner = runner
        self.net = net
        self.store = store
        self.ks = killswitch
        self.hardening = hardening
        self.resolver = resolver
        self.echo = echo
        self.history = history
        self.bus = bus
        self.backends = backends
        self._rng = rng or random.SystemRandom()
        self._op = threading.Lock()
        self._op_name: str | None = None
        self._lock = threading.RLock()
        self._cancel = threading.Event()
        self.state = "disconnected"
        self.conn: Connection | None = None
        self.last_profile_id: str | None = None
        self.last_error: str | None = None
        self.baseline_ip: str | None = None       # real IP, only known when privacy.baseline is on
        self.require_global_exit = True           # the simulator uses documentation addresses and turns this off
        self._warned_no_ks = False

    # ---- plumbing ----------------------------------------------------------
    @contextlib.contextmanager
    def _exclusive(self, name: str, wait: float = 0.0):
        got = self._op.acquire(timeout=wait) if wait else self._op.acquire(blocking=False)
        if not got:
            raise BusyError(f"another operation is in progress ({self._op_name})",
                            hint="wait for it to finish, or stop the rotation first")
        self._op_name = name
        try:
            yield
        finally:
            self._op_name = None
            self._op.release()

    def cancel(self) -> None:
        """Abort the connection attempt that is currently running (if any)."""
        self._cancel.set()

    def _set_state(self, state: str) -> None:
        with self._lock:
            self.state = state

    def _backend(self, profile: Profile):
        be = self.backends.get(profile.protocol)
        if be is None:
            raise DependencyError(f"no backend for protocol {profile.protocol!r}")
        why = be.available()
        if why:
            raise DependencyError(why)
        return be

    def _active_backend(self):
        c = self.conn
        return self.backends.get(c.tunnel.backend) if c else None

    @property
    def ks_on(self) -> bool:
        return bool(self.cfg.killswitch.enabled)

    # ---- firewall helpers --------------------------------------------------
    def _ensure_armed(self) -> None:
        if not self.ks_on:
            if not self._warned_no_ks:
                self._warned_no_ks = True
                self.bus.publish("killswitch_disabled", "warning",
                                 message="kill switch is disabled: traffic can leave unprotected while reconnecting")
            return
        if self.ks.in_lockdown or not self.ks.is_armed():
            self.ks.arm()                                  # raises: we never connect without the firewall

    def _resolve(self, host: str, family: int) -> list[str]:
        hosts = BootstrapResolver.doh_hosts(self.cfg.vpn.bootstrap_doh)
        if self.ks_on:
            self.ks.open_bootstrap(hosts)
        try:
            return self.resolver.resolve(host, family)
        finally:
            if self.ks_on:
                self.ks.close_bootstrap()

    def _targets(self, profile: Profile) -> list[Target]:
        out: list[Target] = []
        learned: dict[str, list[str]] = {}
        for ep in profile.endpoints:
            ips = list(ep.ips)
            if not ips:
                for family in (4, 6):
                    try:
                        ips = self._resolve(ep.host, family)
                    except ResolveError as e:
                        log.debug("cannot resolve %s (v%d): %s", ep.host, family, e)
                        continue
                    if ips:
                        break
                learned[ep.host] = ips
            out += [Target(ip, ep.port, ep.proto) for ip in ips]
        if learned:
            self.store.set_endpoint_ips(profile.id, learned)
        if not out:
            raise VpnError(f"could not find an address for any server of {profile.name}",
                           hint="the name may not exist, or DNS-over-HTTPS is blocked on this network")
        self._rng.shuffle(out)
        return out

    def _allow(self, targets: list[Target]) -> None:
        if self.ks_on:
            self.ks.set_endpoints(targets)

    # ---- verification ------------------------------------------------------
    def probe_exit_ip(self, family: int = 4, timeout: float | None = None):
        """Public address as seen from *inside* the tunnel (socket bound to its interface)."""
        return self.echo.lookup(family, device=self.cfg.vpn.interface, timeout=timeout)

    def _verify(self, tunnel: TunnelInfo, cancel: threading.Event) -> tuple[str, str | None]:
        cfg = self.cfg
        deadline = time.monotonic() + cfg.vpn.verify_timeout
        res = None
        while True:
            if cancel.is_set():
                raise VpnError("cancelled")
            left = deadline - time.monotonic()
            res = self.probe_exit_ip(4, timeout=max(1.0, min(cfg.privacy.http_timeout, left)))
            if res.ok:
                break
            if time.monotonic() >= deadline:
                raise VerificationError(f"could not confirm the public IP through the tunnel: {res.error}",
                                        hint="the tunnel is up but no traffic passes; try another server")
            cancel.wait(0.5)
        ip = res.ip
        parsed = parse_ip(ip)
        if parsed is None or (self.require_global_exit and not parsed.is_global):
            raise VerificationError(f"the tunnel reports a non-public exit address ({ip})")
        if self.baseline_ip and ip == self.baseline_ip:
            raise LeakDetected("the exit address equals your real IP - traffic is not going through the VPN")
        v6 = None
        if cfg.privacy.check_ipv6 and tunnel.ipv6:
            r6 = self.probe_exit_ip(6, timeout=cfg.privacy.http_timeout)
            v6 = r6.ip if r6.ok else None
        return ip, v6

    # ---- the main operation ------------------------------------------------
    def activate(self, ref: str, *, reason: str = "manual") -> ConnectResult:
        """Connect to a profile, or switch to it when already connected."""
        with self._exclusive("activate"):
            return self._activate(ref, reason)

    def _activate(self, ref: str, reason: str) -> ConnectResult:
        t0 = time.monotonic()
        profile = self.store.get(ref)
        prev = self.conn
        old_ip = prev.exit_ip if prev else None
        cancel = self._cancel = threading.Event()
        self.last_profile_id = profile.id
        try:
            if not profile.usable:
                raise ProfileError(f"profile {profile.name} cannot be used right now: " +
                                   ("disabled" if not profile.enabled else
                                    "needs credentials" if profile.needs_auth and not profile.has_auth else "quarantined"))
            backend = self._backend(profile)
            self._set_state("switching" if prev else "connecting")
            self.bus.publish("connecting", profile=profile.id, name=profile.name, reason=reason)
            self._ensure_armed()
            targets = self._targets(profile)               # resolved first, while any old tunnel still protects us
            tunnel, via = self._bring_up(profile, backend, targets, prev, cancel)
            dns_report = self.hardening.on_tunnel_up(
                tunnel.dns, tunnel_ipv6=tunnel.ipv6,
                route_dev=lambda s: getattr(self.net.route_get(s), "iface", None))
            exit_ip, exit_v6 = self._verify(tunnel, cancel)
            self._allow([tunnel.target])                   # from now on only the server that works
        except BaseException as e:
            self._failed(profile, e, t0, old_ip, reason, cancel)
            raise
        ms = int((time.monotonic() - t0) * 1000)
        changed = old_ip is None or exit_ip != old_ip
        conn = Connection(profile, tunnel, exit_ip, exit_v6, time.time(), via, list(dns_report.get("dns", [])))
        with self._lock:
            self.conn, self.state, self.last_error = conn, "connected", None
        server = f"{tunnel.target.ip}:{tunnel.target.port}/{tunnel.target.proto}"
        result = ConnectResult(profile.id, profile.name, tunnel.backend, server, exit_ip, exit_v6, old_ip,
                               changed, via, ms, conn.dns)
        if not changed and reason == "rotate" and self.cfg.rotation.require_change:
            self._record(profile, "unchanged", old_ip, exit_ip, ms, reason, None)
            self.bus.publish("unchanged", "warning", profile=profile.id, name=profile.name, ip=exit_ip)
            raise IPUnchanged(f"{profile.name} gave the same exit address as before")
        self.store.record_result(profile.id, True, ms, exit_ip)
        self._record(profile, "success", old_ip, exit_ip, ms, reason, None)
        self.bus.publish("connected", profile=profile.id, name=profile.name, ip=exit_ip, previous=old_ip,
                         via=via, ms=ms, reason=reason, changed=changed)
        return result

    def _bring_up(self, profile, backend, targets, prev, cancel) -> tuple[TunnelInfo, str]:
        budget = float(self.cfg.vpn.connect_timeout)
        hot = bool(prev and self.cfg.vpn.fast_switch and backend.hot_swap_capable
                   and prev.tunnel.backend == backend.name and backend.alive())
        attempts = targets[:2]
        old_targets = [prev.tunnel.target] if prev else []
        auth = self.store.read_auth(profile) if profile.needs_auth else None
        config = self.store.read_config(profile)
        if not hot:
            self._teardown(release=False)                  # the firewall keeps everything blocked meanwhile
        last: BaseException | None = None
        self._allow((old_targets if hot else []) + attempts)
        for i, target in enumerate(attempts):
            share = 0.6 if (i == 0 and len(attempts) > 1) else 1.0
            req = ConnectRequest(profile, config, target, auth, max(1.0, budget * share), cancel)
            try:
                tunnel = backend.hot_swap(req) if hot else backend.connect(req)
                return tunnel, "hot-swap" if hot else "connect"
            except (VpnError, OSError) as e:
                last = e
                if cancel.is_set() or hot:
                    break
                log.warning("server %s failed (%s)%s", target.ip, e,
                            "; trying the next one" if i + 1 < len(attempts) else "")
        assert last is not None
        if not cancel.is_set():                            # every server failed: look the names up again next time
            self.store.set_endpoint_ips(profile.id, {ep.host: [] for ep in profile.endpoints})
        raise last

    # ---- bookkeeping -------------------------------------------------------
    def _record(self, profile: Profile, status: str, old_ip, new_ip, ms, reason, error) -> None:
        try:
            self.history.add_rotation(status=status, profile_id=profile.id, profile_name=profile.name,
                                      kind=profile.protocol, tier=profile.tier, old_ip=old_ip, new_ip=new_ip,
                                      duration_ms=ms, reason=reason, error=error)
        except Exception:                                   # history must never break connecting
            log.exception("could not write the rotation history")

    def _failed(self, profile: Profile, exc: BaseException, t0: float, old_ip, reason, cancel) -> None:
        ms = int((time.monotonic() - t0) * 1000)
        message = str(exc) or exc.__class__.__name__
        cancelled = cancel.is_set()
        if isinstance(exc, IPUnchanged):
            return
        self._teardown(release=False)
        self._set_state("disconnected" if cancelled else "failed")
        if cancelled:
            self._record(profile, "cancelled", old_ip, None, ms, reason, None)
            self.bus.publish("cancelled", "info", profile=profile.id, name=profile.name)
            return
        self.last_error = message
        if not isinstance(exc, _NOT_THE_PROFILES_FAULT) and isinstance(exc, (IPShiftError, OSError)):
            self.store.record_result(profile.id, False, None, None, message)
        self._record(profile, "failed", old_ip, None, ms, reason, message[:300])
        level = "critical" if isinstance(exc, LeakDetected) else "warning"
        self.bus.publish("connect_failed", level, profile=profile.id, name=profile.name, error=message, reason=reason,
                         code=getattr(exc, "code", "error"), hint=getattr(exc, "hint", None))

    def _teardown(self, *, release: bool) -> None:
        be = self._active_backend()
        with self._lock:
            self.conn = None
        for b in ([be] if be else list(self.backends.values())):
            try:
                b.disconnect()
            except Exception:
                log.exception("backend %s did not disconnect cleanly", getattr(b, "name", "?"))
        if self.ks_on and self.ks.armed:
            self._allow([])                                # nobody to talk to until the next attempt
        if release:
            self.hardening.restore()

    # ---- disconnecting & recovery -------------------------------------------
    def disconnect(self, *, release: bool = True) -> None:
        """Take the tunnel down.  ``release`` also gives the network back (firewall
        removed, DNS and IPv6 restored); without it traffic stays blocked."""
        self.cancel()
        with self._exclusive("disconnect", wait=30.0):
            was = self.conn
            self._teardown(release=release)
            if release and self.ks_on:
                self.ks.disarm()
            self._set_state("disconnected")
        if was:
            self.bus.publish("disconnected", profile=was.profile.id, name=was.profile.name, released=release)

    def recover(self, ref: str | None = None) -> ConnectResult:
        """Bring the tunnel back after it died (same profile unless told otherwise)."""
        ref = ref or self.last_profile_id
        if not ref:
            raise VpnError("no profile to reconnect to")
        self.bus.publish("recovering", "warning", profile=ref)
        return self.activate(ref, reason="recover")

    def tunnel_alive(self) -> bool:
        be = self._active_backend()
        return bool(self.conn and be and be.alive())

    def on_network_change(self) -> str:
        """The physical network changed (Wi-Fi roam, hotspot switch, cable). Returns what was done."""
        if self.ks_on and self.ks.armed:
            self.ks.refresh()
        self.hardening.refresh()
        be = self._active_backend()
        if be is None:
            return "idle"
        if be.on_network_change():
            return "adapted"
        return "reconnect" if self.cfg.vpn.reconnect_on_network_change else "ignored"

    def status(self) -> dict:
        with self._lock:
            c, state = self.conn, self.state
        out: dict = {"state": state, "connected": bool(c and state == "connected"), "busy": self._op_name,
                     "last_error": self.last_error, "profile": None, "server": None, "backend": None,
                     "iface": self.cfg.vpn.interface, "exit_ip": None, "exit_ipv6": None, "since": None,
                     "uptime": None, "via": None, "dns": [], "health": {}}
        if c:
            be = self._active_backend()
            out.update(profile={"id": c.profile.id, "name": c.profile.name, "tier": c.profile.tier,
                                "protocol": c.profile.protocol, "country": c.profile.country},
                       server=f"{c.tunnel.target.ip}:{c.tunnel.target.port}/{c.tunnel.target.proto}",
                       backend=c.tunnel.backend, exit_ip=c.exit_ip, exit_ipv6=c.exit_ipv6, since=c.since,
                       uptime=int(time.time() - c.since), via=c.via, dns=list(c.dns),
                       health=be.health() if be else {})
        return out
