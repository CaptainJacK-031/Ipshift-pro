"""WireGuard backend: plain ``ip`` + ``wg setconf``, no wg-quick, no shell.

Why this matters for rotation: WireGuard has no connection to tear down.  The
kernel interface stays up and ``wg syncconf`` swaps the key and the peer
atomically, so moving to another server takes one handshake (tens of
milliseconds on a good link) and the default route never leaves the tunnel
device - there is no window in which traffic could fall back to the real link.
That is what makes a 1-second rotation interval realistic with WireGuard.
"""
from __future__ import annotations

import logging
import time

from ..errors import DependencyError, VpnError
from ..sysutil import which
from . import wgconf
from .backend import Backend, ConnectRequest, Target, TunnelInfo, wait_until

log = logging.getLogger(__name__)
DEFAULT_MTU = 1420
HANDSHAKE_STALE = 200      # seconds; the protocol gives up on a session after 180


def route_set(cfg: wgconf.WgConfig) -> set[str]:
    """Routes to install for the peers' AllowedIPs; default routes become two /1 halves
    so the physical default route is never replaced (and survives a tunnel crash)."""
    out: set[str] = set()
    for p in cfg.peers:
        for n in p.allowed_ips:
            if n == "0.0.0.0/0":
                out |= {"0.0.0.0/1", "128.0.0.0/1"}
            elif n == "::/0":
                out |= {"::/1", "8000::/1"}
            else:
                out.add(n)
    return out


class WireGuardBackend(Backend):
    name = "wireguard"
    hot_swap_capable = True

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self._cfg: wgconf.WgConfig | None = None
        self._target: Target | None = None
        self._peer = 0
        self._routes: set[str] = set()
        self._started = 0.0

    # ---- plumbing ----------------------------------------------------------
    def available(self) -> str | None:
        if not which(self.cfg.wg_bin):
            return "WireGuard tools are not installed (apt install wireguard-tools)"
        if not which(self.cfg.ip_bin):
            return "iproute2 is not installed (apt install iproute2)"
        return None

    def _wg(self, *args: str, input: str | None = None, check: bool = True):
        res = self.runner.run([self.cfg.wg_bin, *args], input=input, timeout=10)
        if check and not res.ok:
            raise VpnError(f"'wg {args[0]}' failed: {(res.stderr or res.stdout).strip()[:160]}")
        return res

    @staticmethod
    def _peer_index(cfg: wgconf.WgConfig) -> int:
        for i, p in enumerate(cfg.peers):
            if p.endpoint_host:
                return i
        raise VpnError("the profile has no peer with an endpoint")

    def _apply_wg(self, cfg, target: Target, idx: int, *, sync: bool) -> None:
        text = wgconf.render_setconf(cfg, {idx: (target.ip, target.port)}, keepalive=self.cfg.wg_keepalive)
        self._wg("syncconf" if sync else "setconf", self.iface, "/dev/stdin", input=text)

    def _apply_addresses(self, cfg) -> None:
        self.ip("address", "flush", "dev", self.iface, check=False)
        for a in cfg.addresses:
            fam = "-6" if ":" in a else "-4"
            res = self.ip(fam, "address", "add", a, "dev", self.iface, check=(fam == "-4"))
            if not res.ok:
                log.warning("could not add IPv6 address to the tunnel (IPv6 stays blocked)")

    def _apply_link(self, cfg) -> None:
        mtu = cfg.mtu or self.cfg.mtu or DEFAULT_MTU
        self.ip("link", "set", "dev", self.iface, "mtu", str(mtu), "up")

    def _apply_routes(self, cfg) -> None:
        want = route_set(cfg)
        for n in sorted(self._routes - want):
            self.ip("-6" if ":" in n else "-4", "route", "del", n, "dev", self.iface, check=False)
        for n in sorted(want):
            v6 = ":" in n
            self.ip("-6" if v6 else "-4", "route", "replace", n, "dev", self.iface, check=not v6)
        self._routes = want

    def _handshakes(self) -> dict[str, int]:
        res = self._wg("show", self.iface, "latest-handshakes", check=False)
        out = {}
        for line in res.stdout.splitlines():
            parts = line.split()
            if len(parts) == 2 and parts[1].isdigit():
                out[parts[0]] = int(parts[1])
        return out

    def _info(self, cfg, target: Target) -> TunnelInfo:
        return TunnelInfo(self.name, self.iface, [a.split("/")[0] for a in cfg.addresses], list(cfg.dns),
                          target, ipv6=cfg.has_ipv6)

    def _await_handshake(self, cfg, idx: int, req: ConnectRequest, since: float) -> None:
        pub = cfg.peers[idx].public_key
        outcome = wait_until(lambda: self._handshakes().get(pub, 0) >= int(since), req.timeout, req.cancel, 0.1)
        self.timeout_or_cancel(outcome, "WireGuard handshake")

    # ---- lifecycle ---------------------------------------------------------
    def connect(self, req: ConnectRequest) -> TunnelInfo:
        cfg = wgconf.parse(req.config)
        idx = self._peer_index(cfg)
        self.disconnect()
        since = time.time() - 1
        try:
            self.pin(req.target.ip)
            res = self.ip("link", "add", "dev", self.iface, "type", "wireguard", check=False)
            if not res.ok:
                msg = (res.stderr or res.stdout).strip()
                if "not supported" in msg.lower() or "unknown device type" in msg.lower():
                    raise DependencyError("this kernel has no WireGuard support",
                                          hint="sudo modprobe wireguard  (or install wireguard-dkms)")
                raise VpnError(f"cannot create the tunnel interface: {msg[:160]}")
            self._apply_wg(cfg, req.target, idx, sync=False)
            self._apply_addresses(cfg)
            self._apply_link(cfg)
            self._apply_routes(cfg)
            self._await_handshake(cfg, idx, req, since)
        except BaseException:
            self.disconnect()
            raise
        self._cfg, self._target, self._peer, self._started = cfg, req.target, idx, time.time()
        return self._info(cfg, req.target)

    def hot_swap(self, req: ConnectRequest) -> TunnelInfo:
        if self._cfg is None or not self.iface_exists():
            raise VpnError("no active WireGuard tunnel to retarget")
        cfg = wgconf.parse(req.config)
        idx = self._peer_index(cfg)
        old = self._target
        since = time.time() - 1
        self.pin(req.target.ip)                          # the new server must be reachable first
        self._apply_wg(cfg, req.target, idx, sync=True)  # atomic: new key + new peer
        self._apply_addresses(cfg)
        self._apply_link(cfg)
        self._apply_routes(cfg)
        self._await_handshake(cfg, idx, req, since)
        if old and old.ip != req.target.ip:
            self.unpin(old.ip)
        self._cfg, self._target, self._peer, self._started = cfg, req.target, idx, time.time()
        return self._info(cfg, req.target)

    def disconnect(self) -> None:
        self.delete_iface()                              # routes bound to the device vanish with it
        self.unpin()
        self._cfg = self._target = None
        self._routes = set()

    def alive(self) -> bool:
        if self._cfg is None or not self.iface_exists():
            return False
        hs = self._handshakes().get(self._cfg.peers[self._peer].public_key, 0)
        if hs == 0:
            return time.time() - self._started < 30
        return time.time() - hs < HANDSHAKE_STALE

    def health(self) -> dict:
        if self._cfg is None:
            return {}
        hs = self._handshakes().get(self._cfg.peers[self._peer].public_key, 0)
        return {"handshake_age": int(time.time() - hs) if hs else None, "uptime": int(time.time() - self._started)}

    def on_network_change(self) -> bool:
        """Roaming: re-pin the server route and poke the peer so it handshakes from the new link."""
        if not self._target or not self._cfg:
            return False
        try:
            self.pin(self._target.ip)
        except VpnError:
            return False
        self._wg("set", self.iface, "peer", self._cfg.peers[self._peer].public_key,
                 "persistent-keepalive", str(self.cfg.wg_keepalive or 25), check=False)
        return True
