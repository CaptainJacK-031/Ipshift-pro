"""Simulation mode: a fake world that behaves like VPN servers, an internet and a
Wi-Fi network, so the whole stack (rotation, kill-switch bookkeeping, history,
leak checks, CLI, GUI) can be run and tested without root, without a VPN
account and without touching the machine's real network.

Everything here uses documentation address ranges (RFC 5737 / RFC 3849): the
addresses shown in simulation can never be a real person's or a real server's.
"""
from __future__ import annotations

import hashlib
import ipaddress
import logging
import threading
import time
from collections import deque

from ..errors import VpnError, VpnTimeout
from ..net.echo import EchoResult
from ..net.local import Iface, NetInfo, Route
from ..net.resolve import ResolveError
from ..privacy.probes import DnsAnswer
from ..sysutil import CmdResult
from .backend import Backend, ConnectRequest, Target, TunnelInfo
from .profile import Endpoint, Profile, make_id

log = logging.getLogger(__name__)

DELAYS = {"wireguard": (0.15, 0.05), "openvpn": (1.8, 1.8)}     # (connect, hot-swap) seconds at speed 1.0
NETWORKS = {
    "home": ("wlan0", "wifi", "192.168.1.1", "192.168.1.23/24"),
    "hotspot": ("wlan0", "wifi", "192.168.43.1", "192.168.43.17/24"),
    "usb": ("usb0", "usb-tether", "172.20.10.1", "172.20.10.2/28"),
}


class SimServer:
    def __init__(self, profile_id: str, server_ip: str, exit_ip: str, exit_ipv6: str | None):
        self.profile_id, self.server_ip, self.exit_ip, self.exit_ipv6 = profile_id, server_ip, exit_ip, exit_ipv6


class SimWorld:
    """Shared state of the simulation; tests and demos poke it to cause trouble."""

    def __init__(self, *, real_ip: str = "192.0.2.77", speed: float = 1.0):
        self.real_ip = real_ip
        self.real_ipv6 = "2001:db8:aaaa::77"
        self.isp_resolver = "192.0.2.53"          # what a leaking DNS query would reveal
        self.vpn_resolver = "198.51.100.53"
        self.speed = speed                       # 0 = instant (tests); 1 = realistic delays
        self.lock = threading.RLock()
        self.servers: dict[str, SimServer] = {}
        self.fail: dict[str, str] = {}           # profile id -> error the connect fails with
        self.stuck: set[str] = set()             # profile ids whose connect hangs
        self.bad_servers: set[str] = set()       # server addresses that refuse connections
        self.tunnel_profile: str | None = None
        self.dead = False                        # tunnel silently stopped passing traffic
        self.offline = False                     # the physical network has no internet
        self.leaks: set[str] = set()             # inject "public" / "dns" / "ipv6" leaks for the detectors
        self.network = "home"
        self.blocked = lambda: False             # wired up by the engine: is the kill switch armed?
        self.echo_delay = 0.02

    # ---- servers -----------------------------------------------------------
    def server_for(self, profile: Profile) -> SimServer:
        with self.lock:
            s = self.servers.get(profile.id)
            if s is None:
                h = int(hashlib.sha256(profile.id.encode()).hexdigest()[:8], 16)
                n = h % 200 + 10
                s = SimServer(profile.id, f"203.0.113.{n}", f"198.51.100.{(h >> 8) % 200 + 10}", f"2001:db8:100::{n:x}")
                self.servers[profile.id] = s
            return s

    def delay(self, protocol: str, hot: bool) -> float:
        base = DELAYS.get(protocol, DELAYS["openvpn"])[1 if hot else 0]
        return base * self.speed

    def switch_network(self, name: str) -> None:
        if name not in NETWORKS:
            raise ValueError(f"unknown simulated network {name!r}")
        with self.lock:
            self.network = name

    # ---- what the outside world sees ----------------------------------------
    def tunnel_up(self) -> bool:
        return self.tunnel_profile is not None and not self.offline

    def exit_ip(self, family: int = 4) -> str | None:
        with self.lock:
            if not self.tunnel_up() or self.dead:
                return None
            s = self.servers.get(self.tunnel_profile)
            if s is None:
                return None
            return s.exit_ip if family == 4 else s.exit_ipv6


class SimBackend(Backend):
    """Behaves like the real backends for the manager: WireGuard-style profiles
    hot-swap in milliseconds, OpenVPN-style ones need a slow full reconnect."""

    def __init__(self, world: SimWorld, protocol: str, vpn_cfg, runner, paths, net):
        super().__init__(vpn_cfg, runner, paths, net)
        self.world = world
        self.name = protocol
        self.hot_swap_capable = protocol == "wireguard"
        self._started = 0.0

    def _wait(self, seconds: float, req: ConnectRequest) -> None:
        if seconds <= 0:
            if req.cancel.is_set():
                raise VpnError("cancelled")
            return
        limit = min(seconds, req.timeout)
        if req.cancel.wait(limit):
            raise VpnError("cancelled")
        if seconds > req.timeout:
            raise VpnTimeout(f"simulated {self.name} connection timed out")

    def _go(self, req: ConnectRequest, hot: bool) -> TunnelInfo:
        w, pid = self.world, req.profile.id
        server = w.server_for(req.profile)
        if w.offline:
            raise VpnError("no network route to the VPN server - are you online?")
        if pid in w.stuck:
            self._wait(req.timeout + 1, req)
        self._wait(w.delay(self.name, hot), req)
        if req.target.ip in w.bad_servers:
            raise VpnError(f"simulated: server {req.target.ip} did not answer")
        if pid in w.fail:
            raise VpnError(w.fail[pid])
        with w.lock:
            w.tunnel_profile, w.dead = pid, False
        self._started = time.time()
        return TunnelInfo(self.name, self.iface, ["10.8.0.2"], ["10.8.0.1"], req.target, ipv6=bool(server.exit_ipv6))

    def connect(self, req: ConnectRequest) -> TunnelInfo:
        self.disconnect()
        return self._go(req, hot=False)

    def hot_swap(self, req: ConnectRequest) -> TunnelInfo:
        if self.world.tunnel_profile is None:
            raise VpnError("no active tunnel to retarget")
        return self._go(req, hot=True)

    def disconnect(self) -> None:
        with self.world.lock:
            self.world.tunnel_profile = None

    def alive(self) -> bool:
        return self.world.tunnel_up() and not self.world.dead

    def health(self) -> dict:
        return {"simulated": True, "uptime": int(time.time() - self._started)} if self.alive() else {}


class SimEcho:
    """Stands in for EchoResolver: answers what an echo service would see."""

    def __init__(self, world: SimWorld):
        self.world = world

    def services(self, family: int) -> list[str]:
        return ["sim-echo-a", "sim-echo-b", "sim-echo-c"]

    def lookup(self, family: int = 4, *, device: str | None = None, source_ip: str | None = None,
               timeout: float | None = None, quorum: int | None = None, cafile: str | None = None) -> EchoResult:
        w = self.world
        time.sleep(w.echo_delay * (1 if w.speed else 0))
        res = EchoResult(family=family)
        via_tunnel = device is not None and device.startswith("ipshift")
        ip = None
        if family == 6 and "ipv6" in w.leaks and not via_tunnel and not (w.tunnel_up() and w.exit_ip(6)):
            ip = w.real_ipv6                         # injected IPv6 leak: the real address is visible
        elif w.offline:
            res.error = "no echo service answered (network unreachable)"
        elif w.tunnel_up() and (via_tunnel or device is None):
            ip = w.exit_ip(family)
            if ip is None:
                res.error = "no echo service answered (timeout)" if w.dead else "no IPv6 through this tunnel"
        elif via_tunnel:
            res.error = "no echo service answered (tunnel is down)"
        elif w.blocked() and "public" not in w.leaks:
            res.error = "no echo service answered (blocked by the firewall)"
        else:
            ip = w.real_ip if family == 4 else None
            if ip is None:
                res.error = "no IPv6 connectivity"
        if ip:
            res.ip = res.candidate = ip
            res.agree = res.asked = 3
            res.answers = {s: ip for s in self.services(family)}
        return res


class SimProbes:
    """Answers the leak probes from the world's state (see privacy/probes.py for the statuses)."""

    def __init__(self, world: SimWorld, vpn_iface: str = "ipshift0"):
        self.world = world
        self.vpn_iface = vpn_iface

    def _open_path(self, device: str | None, v6: bool, kind: str) -> bool:
        """Would a packet pinned to ``device`` actually get out?"""
        w = self.world
        if device == self.vpn_iface:
            return w.tunnel_up() and not w.dead
        if v6:
            return "ipv6" in w.leaks
        if kind == "dns" and "dns" in w.leaks:
            return True
        if kind == "tcp" and "public" in w.leaks:
            return True
        return not w.blocked()                       # no kill switch: the real network is wide open

    def dns(self, server: str, name: str, qtype: str = "A", *, device: str | None = None) -> DnsAnswer:
        w = self.world
        if device is None:                           # the normal path: through the tunnel when there is one
            if w.tunnel_up() and not w.dead:
                return DnsAnswer("ok", [w.isp_resolver if "dns" in w.leaks else w.vpn_resolver])
            device = "wlan0"
        if not self._open_path(device, ":" in server, "dns"):
            return DnsAnswer("blocked", detail="Operation not permitted")
        if w.offline:
            return DnsAnswer("timeout", detail="timeout")
        return DnsAnswer("ok", [w.vpn_resolver if device == self.vpn_iface else w.isp_resolver])

    def resolver_identity(self, server: str, *, device: str | None = None) -> DnsAnswer:
        return self.dns(server, "whoami.akamai.net", "A", device=device)

    def tcp(self, ip: str, port: int, *, device: str | None = None) -> str:
        w = self.world
        if not self._open_path(device or "wlan0", ":" in ip, "tcp"):
            return "blocked"
        return "timeout" if w.offline else "connected"


class SimNetInfo(NetInfo):
    """The real NetInfo summaries, fed by the simulated world instead of ``ip``."""

    def __init__(self, world: SimWorld, vpn_iface: str = "ipshift0"):
        super().__init__(runner=None)
        self.world = world
        self.vpn_iface = vpn_iface

    def _phys(self):
        return NETWORKS[self.world.network]

    def interfaces(self) -> list[Iface]:
        name, kind, _gw, cidr = self._phys()
        out = [Iface("lo", "loopback", True, None, ["127.0.0.1/8"], [], False),
               Iface(name, kind, True, "3c:52:82:aa:bb:01", [cidr], [], True)]
        if self.world.tunnel_up():
            out.append(Iface(self.vpn_iface, "tunnel", True, None, ["10.8.0.2/24"], [], False))
        return out

    def default_route(self, family: int = 4) -> Route | None:
        if family != 4:
            return None
        name, _kind, gw, cidr = self._phys()
        return Route(name, gw, cidr.split("/")[0], 100)

    def route_get(self, dest: str) -> Route | None:
        ip = ipaddress.ip_address(dest)
        if ip.version != 4:
            return None
        phys = self.default_route(4)
        if not self.world.tunnel_up():
            return phys
        tunnel = Route(self.vpn_iface, None, "10.8.0.2", 0)
        if str(ip).startswith("10.8."):                    # the tunnel's own network (its DNS server lives here)
            return tunnel
        if ip.is_private or any(s.server_ip == dest for s in self.world.servers.values()):
            return phys                                    # the LAN, and the pinned route to the VPN server
        return tunnel


class SimRunner:
    """Accepts every command and does nothing (simulation never touches the system)."""

    def __init__(self):
        self.calls: deque[tuple] = deque(maxlen=200)

    def run(self, args, *, timeout=15.0, input=None, env=None) -> CmdResult:
        args = tuple(str(a) for a in args)
        self.calls.append(args)
        return CmdResult(args, 0, "", "")

    def popen(self, args, **kw):  # pragma: no cover - the simulator never starts processes
        raise NotImplementedError("the simulator does not start processes")


class SimResolver:
    """BootstrapResolver stand-in: every name resolves to a stable documentation address."""

    def __init__(self, world: SimWorld):
        self.world = world
        self.ks = None

    def resolve(self, host: str, family: int = 4, *, use_cache: bool = True) -> list[str]:
        try:
            ipaddress.ip_address(host)
            return [host]
        except ValueError:
            pass
        if family != 4:
            raise ResolveError(f"no AAAA record for {host} (simulation)")
        suffix = ".sim.invalid"
        if host.endswith(suffix) and host[:-len(suffix)] in self.world.servers:
            return [self.world.servers[host[:-len(suffix)]].server_ip]
        n = int(hashlib.sha256(host.lower().encode()).hexdigest()[:8], 16) % 200 + 10
        return [f"203.0.113.{n}"]


DEMO = [  # name, protocol, tier, country, provider
    ("Demo WG Frankfurt", "wireguard", "paid", "DE", "SimVPN"),
    ("Demo WG Amsterdam", "wireguard", "paid", "NL", "SimVPN"),
    ("Demo WG Zurich", "wireguard", "self-hosted", "CH", "my-vps"),
    ("Demo WG Reykjavik", "wireguard", "paid", "IS", "SimVPN"),
    ("Demo OVPN New York", "openvpn", "free", "US", "FreeSim"),
    ("Demo OVPN Tokyo", "openvpn", "free", "JP", "FreeSim"),
    ("Demo OVPN Sao Paulo", "openvpn", "free", "BR", "FreeSim"),
    ("Demo OVPN Stockholm", "openvpn", "self-hosted", "SE", "my-vps"),
]


def make_demo_profiles(store, world: SimWorld) -> list[Profile]:
    """Fill an empty profile store with simulated servers (idempotent)."""
    if store.list():
        return []
    made = []
    for name, proto, tier, cc, provider in DEMO:
        text = f"# simulated {proto} profile\n"
        prof = Profile(make_id(name, text), name, proto, tier=tier, provider=provider, country=cc)
        server = world.server_for(prof)
        port = 51820 if proto == "wireguard" else 1194
        prof.endpoints = [Endpoint(f"{prof.id}.sim.invalid", port, "udp", [server.server_ip])]
        prof.dns = ["10.8.0.1"]
        store.add(prof, text)
        made.append(prof)
    return made
