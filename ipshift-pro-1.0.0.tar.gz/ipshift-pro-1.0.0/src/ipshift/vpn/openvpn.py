"""OpenVPN backend: one supervised ``openvpn`` process per connection.

* The runtime config (which may contain inline private keys) lives on tmpfs,
  mode 0600, and is deleted as soon as the tunnel is up or the attempt fails.
* OpenVPN drops root after set-up (``vpn.openvpn_user``) and is started with
  ``script-security 1``: it can only run its own built-in ``ip`` calls.
* Readiness, pushed DNS servers and failure causes are read from its log, so
  no management socket (and no extra attack surface) is needed.
* Giving up is fast and explicit: ``connect-retry-max 1`` + ``ping-exit`` make
  the process exit when the link dies; the manager notices and reconnects while
  the kill switch keeps traffic blocked.
"""
from __future__ import annotations

import logging
import os
import re
import signal
import subprocess
import threading
import time
from collections import deque
from pathlib import Path

from ..errors import DependencyError, ProfileError, VpnError, VpnTimeout
from ..sysutil import atomic_write, ensure_private_dir, which
from . import ovpn
from .backend import Backend, ConnectRequest, TunnelInfo, wait_until

log = logging.getLogger(__name__)

READY = "Initialization Sequence Completed"
_PUSH = re.compile(r"PUSH: Received control message: '(.*)'")
_DNS = re.compile(r"dhcp-option DNS6? ([0-9a-fA-F:.]+)")
_IFCONFIG = re.compile(r"(?:^|,)ifconfig (\d{1,3}(?:\.\d{1,3}){3}) ")
_FATAL = [
    (re.compile(r"AUTH_FAILED|auth-failure"), "authentication failed - check the username and password"),
    (re.compile(r"Cannot open TUN/TAP dev|/dev/net/tun"), "cannot open the TUN device (modprobe tun?)"),
    (re.compile(r"Options error"), "OpenVPN rejected the configuration"),
    (re.compile(r"TLS Error: TLS key negotiation failed|TLS handshake failed"), "TLS handshake failed (server unreachable or blocked)"),
    (re.compile(r"Exiting due to fatal error"), "OpenVPN exited with a fatal error"),
]


def drop_group(user: str) -> tuple[str | None, str | None]:
    """(user, group) to hand to OpenVPN, or (None, None) when the user does not exist."""
    try:
        import grp
        import pwd
        pw = pwd.getpwnam(user)
        return user, grp.getgrgid(pw.pw_gid).gr_name
    except (KeyError, ImportError):
        log.warning("user %r does not exist: OpenVPN will keep running as root", user)
        return None, None


class OpenVPNBackend(Backend):
    name = "openvpn"
    tun_path = "/dev/net/tun"

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self._proc: subprocess.Popen | None = None
        self._reader: threading.Thread | None = None
        self._log: deque[str] = deque(maxlen=40)
        self._ready = threading.Event()
        self._failed: str | None = None
        self._dns: list[str] = []
        self._ifconfig: str | None = None
        self._files: list[Path] = []
        self._target = None
        self._started = 0.0

    def available(self) -> str | None:
        if not which(self.cfg.openvpn_bin):
            return "OpenVPN is not installed (apt install openvpn)"
        if not which(self.cfg.ip_bin):
            return "iproute2 is not installed (apt install iproute2)"
        if not os.path.exists(self.tun_path):
            return "no /dev/net/tun device (sudo modprobe tun)"
        return None

    # ---- output parsing ----------------------------------------------------
    def _read(self, proc: subprocess.Popen) -> None:
        try:
            for raw in proc.stdout:                       # type: ignore[union-attr]
                line = raw.rstrip()
                if not line:
                    continue
                self._log.append(line)
                log.debug("openvpn: %s", line)
                self._parse(line)
        except (OSError, ValueError):
            pass

    def _parse(self, line: str) -> None:
        m = _PUSH.search(line)
        if m:
            reply = m.group(1)
            for ip in _DNS.findall(reply):
                if ip not in self._dns:
                    self._dns.append(ip)
            im = _IFCONFIG.search(reply)
            if im:
                self._ifconfig = im.group(1)
        if READY in line:
            self._ready.set()
            return
        for pat, msg in _FATAL:
            if pat.search(line) and self._failed is None:
                self._failed = msg
                return

    # ---- lifecycle ---------------------------------------------------------
    def _write_runtime(self, req: ConnectRequest) -> Path:
        run = ensure_private_dir(self.paths.runtime_dir)
        auth_path = None
        if req.auth:
            auth = run / "ovpn.auth"
            atomic_write(auth, f"{req.auth[0]}\n{req.auth[1]}\n", 0o600)
            self._files.append(auth)
            auth_path = str(auth)
        user, group = drop_group(self.cfg.openvpn_user) if self.cfg.openvpn_user else (None, None)
        text = ovpn.render(req.config, ip=req.target.ip, port=req.target.port, proto=req.target.proto,
                           iface=self.iface, user=user, group=group, auth_path=auth_path,
                           connect_timeout=int(max(5, min(req.timeout - 2, 60))))
        conf = run / "ovpn.conf"
        atomic_write(conf, text, 0o600)
        self._files.append(conf)
        return conf

    def _scrub_files(self) -> None:
        for f in self._files:
            try:
                f.unlink()
            except OSError:
                pass
        self._files = []

    def connect(self, req: ConnectRequest) -> TunnelInfo:
        self.disconnect()
        self._ready.clear()
        self._failed, self._dns, self._ifconfig = None, [], None
        self._log.clear()
        try:
            conf = self._write_runtime(req)
            self.delete_iface()
            self._proc = self.runner.popen(
                [self.cfg.openvpn_bin, "--config", str(conf)], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL, text=True, bufsize=1, start_new_session=True)
        except ProfileError:
            self._scrub_files()
            raise
        except OSError as e:
            self._scrub_files()
            raise DependencyError(f"cannot start OpenVPN: {e}") from None
        proc = self._proc
        self._reader = threading.Thread(target=self._read, args=(proc,), daemon=True, name="ovpn-log")
        self._reader.start()
        host = f"{req.target.ip}/{32 if req.target.family == 4 else 128}"
        self._pins[req.target.ip] = ["-6" if req.target.family == 6 else "-4", "route", "del", host]

        def done() -> bool:
            return self._ready.is_set() or self._failed is not None or proc.poll() is not None

        try:
            outcome = wait_until(done, req.timeout, req.cancel, 0.1)
            if outcome == "ok" and not self._ready.is_set():
                time.sleep(0.2)                           # let the reader drain the final lines
                detail = self._failed or (self._log[-1] if self._log else "no output")
                raise VpnError(f"OpenVPN stopped before the tunnel came up: {detail[:160]}")
            if outcome == "timeout":
                raise VpnTimeout(f"OpenVPN did not finish connecting within {req.timeout:.0f}s",
                                 hint="try another server; this one may be down or blocked")
            self.timeout_or_cancel(outcome, "OpenVPN connection")
        except BaseException:
            self.disconnect()
            raise
        self._scrub_files()                               # keys are no longer needed on disk
        self._target, self._started = req.target, time.time()
        local = self._ifconfig
        for i in self.net.interfaces():
            if i.name == self.iface:
                local = None
                ips = [c.split("/")[0] for c in i.ipv4 + i.ipv6]
                break
        else:
            ips = []
        return TunnelInfo(self.name, self.iface, ips or ([local] if local else []), list(self._dns), req.target,
                          ipv6=any(":" in a for a in ips))

    def disconnect(self) -> None:
        proc, self._proc = self._proc, None
        if proc is not None and proc.poll() is None:
            for sig, wait in ((signal.SIGTERM, 5), (signal.SIGKILL, 3)):
                try:
                    os.killpg(proc.pid, sig)
                except (ProcessLookupError, PermissionError):
                    break
                try:
                    proc.wait(wait)
                    break
                except subprocess.TimeoutExpired:
                    continue
        if proc is not None and proc.stdout:
            try:
                proc.stdout.close()
            except OSError:
                pass
        if self._reader is not None:
            self._reader.join(1.0)
            self._reader = None
        self._scrub_files()
        self.delete_iface()
        self.unpin()
        self._target = None
        self._ready.clear()

    def alive(self) -> bool:
        return self._proc is not None and self._proc.poll() is None and self._failed is None

    def health(self) -> dict:
        if not self.alive():
            return {}
        return {"pid": self._proc.pid, "uptime": int(time.time() - self._started)}

    def last_error(self) -> str:
        return self._failed or (self._log[-1] if self._log else "")
