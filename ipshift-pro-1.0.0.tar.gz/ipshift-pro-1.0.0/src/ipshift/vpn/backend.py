"""Backend interface shared by OpenVPN, WireGuard and the simulator, plus the
small amount of plumbing they have in common (``ip`` calls, endpoint pinning).

All external commands go through the injected Runner as argv lists - no shell,
and no value from a profile is ever interpolated into a command string.
"""
from __future__ import annotations

import ipaddress
import logging
import threading
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field, asdict

from ..errors import VpnError, VpnTimeout
from .profile import Profile

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class Target:
    """One concrete VPN server address the firewall must let through."""
    ip: str
    port: int
    proto: str = "udp"          # udp | tcp

    @property
    def family(self) -> int:
        return ipaddress.ip_address(self.ip).version


@dataclass
class TunnelInfo:
    backend: str
    iface: str
    local_ips: list[str]
    dns: list[str]
    target: Target
    ipv6: bool = False
    started: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class ConnectRequest:
    profile: Profile
    config: str                                   # the sanitised stored configuration
    target: Target
    auth: tuple[str, str] | None = None
    timeout: float = 30.0
    cancel: threading.Event = field(default_factory=threading.Event)


def wait_until(pred, timeout: float, cancel: threading.Event, interval: float = 0.1) -> str:
    """Poll ``pred`` -> 'ok' | 'timeout' | 'cancelled'."""
    end = time.monotonic() + timeout
    while True:
        if cancel.is_set():
            return "cancelled"
        if pred():
            return "ok"
        if time.monotonic() >= end:
            return "timeout"
        time.sleep(interval)


class Backend(ABC):
    name = "base"
    hot_swap_capable = False

    def __init__(self, vpn_cfg, runner, paths, net):
        self.cfg = vpn_cfg
        self.runner = runner
        self.paths = paths
        self.net = net
        self.iface = vpn_cfg.interface
        self._pins: dict[str, list[str]] = {}       # server ip -> argv that removes its host route

    # ---- to implement ------------------------------------------------------
    def available(self) -> str | None:
        """None when usable, else a one-line reason (shown with an install hint)."""
        return None

    @abstractmethod
    def connect(self, req: ConnectRequest) -> TunnelInfo: ...

    @abstractmethod
    def disconnect(self) -> None: ...

    @abstractmethod
    def alive(self) -> bool: ...

    def hot_swap(self, req: ConnectRequest) -> TunnelInfo:
        raise NotImplementedError

    def health(self) -> dict:
        return {}

    def on_network_change(self) -> bool:
        """Adapt to a new physical network without reconnecting.  True = handled."""
        return False

    # ---- shared helpers ----------------------------------------------------
    def ip(self, *args: str, check: bool = True, input: str | None = None, timeout: float = 10.0):
        res = self.runner.run([self.cfg.ip_bin, *args], timeout=timeout, input=input)
        if check and not res.ok:
            raise VpnError(f"'ip {' '.join(args[:4])}' failed: {(res.stderr or res.stdout).strip()[:160]}")
        return res

    def iface_exists(self) -> bool:
        return self.ip("link", "show", "dev", self.iface, check=False).ok

    def delete_iface(self) -> None:
        if self.iface_exists():
            self.ip("link", "del", "dev", self.iface, check=False)

    def pin(self, ip: str) -> None:
        """Host route that keeps the encrypted packets to the server on the physical link."""
        fam = ipaddress.ip_address(ip).version
        r = self.net.route_get(ip)
        if r is None or r.iface == self.iface:
            r = self.net.default_route(fam)           # tunnel routes would otherwise capture it
        if r is None or r.iface == self.iface:
            raise VpnError("no network route to the VPN server - are you online?")
        host = f"{ip}/{32 if fam == 4 else 128}"
        pre = ["-6"] if fam == 6 else ["-4"]
        add = [*pre, "route", "replace", host] + (["via", r.gateway] if r.gateway else []) + ["dev", r.iface]
        self.ip(*add)
        self._pins[ip] = [*pre, "route", "del", host]

    def unpin(self, ip: str | None = None) -> None:
        for key in ([ip] if ip else list(self._pins)):
            cmd = self._pins.pop(key, None)
            if cmd:
                self.ip(*cmd, check=False)

    def timeout_or_cancel(self, outcome: str, what: str) -> None:
        if outcome == "timeout":
            raise VpnTimeout(f"{what} timed out", hint="try another server, or check that UDP/TCP to it is not blocked")
        if outcome == "cancelled":
            raise VpnError("cancelled")
