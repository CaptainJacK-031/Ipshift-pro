"""OpenVPN configuration sanitiser.

The daemon runs as root and hands the result to ``openvpn``.  An .ovpn file is
effectively code: ``up``/``plugin``/``tls-verify``/``auth-user-pass-verify``
run programs or load libraries as root, and path directives read arbitrary
files.  So we do not try to blacklist the bad directives - we **allowlist** the
known-harmless ones, rewrite the few that matter (remote, proto, device,
routing, credentials), inline every certificate and key, and drop everything
else with a warning.  Client-side file reading is done by the *client* (see
:func:`referenced_files`); the daemon never opens a path named inside a profile.
"""
from __future__ import annotations

import ipaddress
import re
from dataclasses import dataclass, field

from ..errors import ProfileError
from .profile import Endpoint

MAX_BYTES = 512 * 1024
MAX_BLOCK = 64 * 1024
MAX_REMOTES = 64

_HOST = re.compile(r"^(?=.{1,253}$)[A-Za-z0-9_]([A-Za-z0-9_-]{0,61}[A-Za-z0-9_])?(\.[A-Za-z0-9_]([A-Za-z0-9_-]{0,61}[A-Za-z0-9_])?)*$")
TOKEN = r"[A-Za-z0-9_.:+=,@!-]{1,160}"          # no "/" or "\": none of these options takes a path
INT = r"\d{1,9}"
_BLOCK_OPEN = re.compile(r"<([A-Za-z0-9_-]{1,32})>")
_PEM = re.compile(r"-----BEGIN ([A-Z0-9 ]{1,40})-----\s+([A-Za-z0-9+/=\s]+?)\s*-----END \1-----")
_STATIC = re.compile(r"-----BEGIN OpenVPN Static key V1-----\s+([0-9a-fA-F\s]+?)\s*-----END OpenVPN Static key V1-----")

# name -> (min_args, max_args, pattern every argument must fully match, or None)
_PASS: dict[str, tuple[int, int, str | None]] = {
    "client": (0, 0, None), "tls-client": (0, 0, None), "pull": (0, 0, None), "float": (0, 0, None),
    "persist-key": (0, 0, None), "mute-replay-warnings": (0, 0, None),
    "remote-cert-tls": (1, 1, "server|client"), "ns-cert-type": (1, 1, "server|client"),
    "remote-cert-ku": (1, 8, "[0-9A-Fa-f]{2,4}"), "remote-cert-eku": (1, 1, TOKEN),
    "cipher": (1, 1, TOKEN), "data-ciphers": (1, 1, TOKEN), "data-ciphers-fallback": (1, 1, TOKEN),
    "ncp-ciphers": (1, 1, TOKEN), "auth": (1, 1, TOKEN),
    "tls-version-min": (1, 2, r"[0-9.]{1,5}|or-highest"), "tls-version-max": (1, 1, r"[0-9.]{1,5}"),
    "tls-cipher": (1, 1, TOKEN), "tls-ciphersuites": (1, 1, TOKEN), "tls-groups": (1, 1, TOKEN),
    "tls-cert-profile": (1, 1, TOKEN), "key-direction": (1, 1, "[01]"), "key-method": (1, 1, "2"),
    "reneg-sec": (1, 2, INT), "reneg-bytes": (1, 1, INT), "reneg-pkts": (1, 1, INT),
    "compress": (0, 1, TOKEN), "comp-lzo": (0, 1, TOKEN), "allow-compression": (1, 1, TOKEN),
    "mssfix": (0, 2, TOKEN), "fragment": (1, 2, TOKEN), "tun-mtu": (1, 1, INT), "link-mtu": (1, 1, INT),
    "tun-mtu-extra": (1, 1, INT), "sndbuf": (1, 1, INT), "rcvbuf": (1, 1, INT), "tls-timeout": (1, 1, INT),
    "hand-window": (1, 1, INT), "tran-window": (1, 1, INT), "replay-window": (1, 2, INT),
    "server-poll-timeout": (1, 1, INT), "auth-retry": (1, 1, "none|nointeract|interact"),
    "explicit-exit-notify": (0, 1, INT), "inactive": (1, 3, INT), "providers": (1, 3, "legacy|default"),
    "peer-fingerprint": (1, 1, r"([0-9A-Fa-f]{2}:){31}[0-9A-Fa-f]{2}"),
}
# options that name ciphers or digests: a value of "none" (alone or in a list) would send the traffic in the clear
_WEAK = {"cipher", "data-ciphers", "data-ciphers-fallback", "ncp-ciphers", "auth"}
# handled by IPShift itself: consumed or replaced, never copied through
_HANDLED = {
    "dev", "dev-type", "dev-node", "remote", "remote-random", "proto", "port", "rport", "nobind", "lport",
    "redirect-gateway", "redirect-private", "route", "route-ipv6", "route-gateway", "route-delay",
    "route-method", "route-nopull", "persist-tun", "resolv-retry", "connect-retry", "connect-retry-max",
    "connect-timeout", "keepalive", "ping", "ping-restart", "ping-exit", "verb", "mute", "setenv",
    "setenv-safe", "auth-nocache", "block-outside-dns", "dhcp-option", "auth-user-pass", "ca", "cert",
    "key", "tls-auth", "tls-crypt", "tls-crypt-v2", "crl-verify", "extra-certs", "dh", "ifconfig-nowarn",
    "ignore-unknown-option", "http-proxy", "http-proxy-option", "http-proxy-retry", "http-proxy-timeout",
    "socks-proxy", "socks-proxy-retry", "pkcs12", "secret", "askpass", "management-hold",
}
# anything that would run a program, load code, or touch the host: removed and reported
_DANGEROUS = {
    "up", "down", "route-up", "route-pre-down", "ipchange", "tls-verify", "tls-export-cert",
    "auth-user-pass-verify", "client-connect", "client-disconnect", "learn-address", "plugin",
    "script-security", "up-restart", "down-pre", "up-delay", "config", "cd", "chroot", "daemon", "log",
    "log-append", "syslog", "writepid", "status", "management", "management-client", "management-query-passwords",
    "user", "group", "setcon", "engine", "echo", "iproute", "tmp-dir", "ifconfig-noexec", "route-noexec",
    "mark", "bind-dev", "dns-updown", "tls-crypt-v2-verify",
}
_BLOCK_PEM = {"ca", "cert", "key", "extra-certs", "crl-verify"}
_BLOCK_STATIC = {"tls-auth", "tls-crypt"}
_FILE_DIRECTIVES = {"ca", "cert", "key", "extra-certs", "crl-verify", "tls-auth", "tls-crypt", "tls-crypt-v2",
                    "auth-user-pass"}
_PROTO = {"udp": "udp", "udp4": "udp", "udp6": "udp", "tcp": "tcp", "tcp4": "tcp", "tcp6": "tcp",
          "tcp-client": "tcp", "tcp4-client": "tcp", "tcp6-client": "tcp"}


@dataclass
class OvpnConfig:
    body: str
    endpoints: list[Endpoint]
    dns: list[str] = field(default_factory=list)
    needs_auth: bool = False
    auth: tuple[str, str] | None = None
    warnings: list[str] = field(default_factory=list)
    removed: list[str] = field(default_factory=list)      # dangerous directives that were stripped


def _basename(path: str) -> str:
    return re.split(r"[\\/]", path.strip())[-1]


def _tokens(line: str) -> list[str] | None:
    """Split a config line.  Whitespace separates tokens; '...' and "..." group them.
    A backslash is literal except for \\" and \\\\ inside double quotes, so Windows
    paths survive.  Returns None for an unterminated quote."""
    toks: list[str] = []
    cur: list[str] = []
    in_tok, quote, i, n = False, None, 0, len(line)
    while i < n:
        c = line[i]
        if quote:
            if c == quote:
                quote = None
            elif c == "\\" and quote == '"' and i + 1 < n and line[i + 1] in '"\\':
                cur.append(line[i + 1])
                i += 1
            else:
                cur.append(c)
        elif c in " \t":
            if in_tok:
                toks.append("".join(cur))
                cur, in_tok = [], False
        elif c in "\"'":
            quote, in_tok = c, True
        else:
            cur.append(c)
            in_tok = True
        i += 1
    if quote:
        return None
    if in_tok:
        toks.append("".join(cur))
    return toks


def _lines(text: str) -> list[str]:
    return text.lstrip("﻿").replace("\r\n", "\n").replace("\r", "\n").split("\n")


def _walk(text: str):
    """Yield ('directive', tokens) and ('block', tag, content) items."""
    if len(text) > MAX_BYTES:
        raise ProfileError("configuration is too large")
    if "\0" in text:
        raise ProfileError("configuration contains NUL bytes")
    lines = _lines(text)
    i = 0
    while i < len(lines):
        s = lines[i].strip()
        i += 1
        if not s or s[0] in "#;":
            continue
        m = _BLOCK_OPEN.fullmatch(s)
        if m:
            tag, j, buf = m.group(1).lower(), i, []
            while j < len(lines) and lines[j].strip().lower() != f"</{tag}>":
                buf.append(lines[j])
                j += 1
            if j >= len(lines):
                raise ProfileError(f"unterminated <{tag}> block")
            i = j + 1
            content = "\n".join(buf)
            if len(content) > MAX_BLOCK:
                raise ProfileError(f"<{tag}> block is too large")
            yield ("block", tag, content)
            continue
        toks = _tokens(s)
        if toks:
            yield ("directive", toks)


def referenced_files(text: str) -> list[str]:
    """File names a *client* must read and pass along (``files``) before import."""
    out: list[str] = []
    for item in _walk(text):
        if item[0] == "directive":
            t = item[1]
            if t[0].lower() in _FILE_DIRECTIVES and len(t) > 1:
                name = _basename(t[1])
                if name and name != "[inline]" and name not in out:
                    out.append(name)
    return out


def _pem_block(tag: str, content: str) -> str:
    found = _PEM.findall(content)
    if not found:
        raise ProfileError(f"<{tag}> has no valid PEM data")
    out = []
    for kind, body in found:
        if "ENCRYPTED" in kind:
            raise ProfileError("passphrase-protected private keys are not supported",
                               hint="export an unencrypted key or use a different profile")
        b64 = re.sub(r"\s+", "", body)
        out += [f"-----BEGIN {kind}-----", *[b64[i:i + 64] for i in range(0, len(b64), 64)], f"-----END {kind}-----"]
    return "\n".join(out)


def _static_block(tag: str, content: str) -> str:
    m = _STATIC.search(content)
    if m:
        hx = re.sub(r"\s+", "", m.group(1))
        return "\n".join(["-----BEGIN OpenVPN Static key V1-----", *[hx[i:i + 32] for i in range(0, len(hx), 32)],
                          "-----END OpenVPN Static key V1-----"])
    return _pem_block(tag, content)            # tls-crypt-v2 style keys are PEM


def _valid_host(h: str) -> bool:
    try:
        ipaddress.ip_address(h)
        return True
    except ValueError:
        return bool(_HOST.match(h))


def _quote(tok: str) -> str:
    return f'"{tok}"' if re.search(r"\s", tok) else tok


def _creds(text: str) -> tuple[str, str] | None:
    lines = [l.rstrip("\r") for l in text.split("\n")]
    lines = [l for l in lines if l.strip()] if len(lines) > 2 else lines
    if len(lines) >= 2 and lines[0] and lines[1]:
        return lines[0], lines[1]
    return None


def sanitize(text: str, files: dict[str, str] | None = None) -> OvpnConfig:
    files = {_basename(k): v for k, v in (files or {}).items()}
    out = OvpnConfig(body="", endpoints=[])
    keep: list[str] = []
    blocks: dict[str, str] = {}
    remotes: list[tuple[str, int | None, str | None]] = []
    global_proto, global_port, key_dir_set = "udp", None, False
    missing: list[str] = []

    def warn(msg: str) -> None:
        if msg not in out.warnings:
            out.warnings.append(msg)

    def inline_from_file(tag: str, name: str) -> None:
        data = files.get(_basename(name))
        if data is None:
            missing.append(_basename(name))
            return
        blocks[tag] = _pem_block(tag, data) if tag in _BLOCK_PEM else _static_block(tag, data)

    def add_remote(t: list[str]) -> None:
        if len(t) < 2 or not _valid_host(t[1]):
            raise ProfileError(f"invalid remote: {' '.join(t)[:80]!r}")
        port = None
        if len(t) > 2:
            if not t[2].isdigit() or not 1 <= int(t[2]) <= 65535:
                raise ProfileError(f"invalid remote port {t[2][:8]!r}")
            port = int(t[2])
        proto = None
        if len(t) > 3:
            if t[3] not in _PROTO:
                raise ProfileError(f"unsupported protocol {t[3]!r} on remote")
            proto = _PROTO[t[3]]
        remotes.append((t[1], port, proto))

    for item in _walk(text):
        if item[0] == "block":
            _, tag, content = item
            if tag in _BLOCK_PEM:
                blocks[tag] = _pem_block(tag, content)
            elif tag in _BLOCK_STATIC or tag == "tls-crypt-v2":
                blocks[tag] = _static_block(tag, content)
            elif tag == "auth-user-pass":
                out.needs_auth, out.auth = True, _creds(content)
            elif tag == "connection":
                rem, sub_proto, sub_port = None, None, None
                for sub in _walk(content):
                    if sub[0] != "directive":
                        continue
                    st, n = sub[1], sub[1][0].lower()
                    if n == "remote":
                        rem = st
                    elif n == "proto" and len(st) > 1 and st[1] in _PROTO:
                        sub_proto = _PROTO[st[1]]
                    elif n in ("port", "rport") and len(st) > 1 and st[1].isdigit():
                        sub_port = st[1]
                    else:
                        warn(f"ignored '{n}' inside <connection>")
                if rem is None:
                    warn("ignored a <connection> block without a remote")
                else:
                    if len(rem) < 3 and sub_port:
                        rem = rem + [sub_port]
                    add_remote(rem)
                    if remotes[-1][2] is None and sub_proto:
                        remotes[-1] = (remotes[-1][0], remotes[-1][1], sub_proto)
            elif tag in ("dh", "secret", "pkcs12"):
                warn(f"ignored <{tag}> block (not used by this client)")
            else:
                warn(f"ignored unknown block <{tag}>")
            continue

        t = item[1]
        name = t[0].lower()
        args = t[1:]
        if name == "remote":
            add_remote(t)
        elif name == "proto":
            if len(args) != 1 or args[0] not in _PROTO:
                raise ProfileError(f"unsupported protocol {' '.join(args)!r} (client UDP/TCP only)")
            global_proto = _PROTO[args[0]]
        elif name in ("port", "rport"):
            if len(args) == 1 and args[0].isdigit() and 1 <= int(args[0]) <= 65535:
                global_port = int(args[0])
        elif name == "pull-filter":
            ok = len(args) == 2 and args[0] in ("accept", "ignore", "reject") \
                and re.fullmatch(r"[A-Za-z0-9_.:/=,+!@ -]{1,80}", args[1])
            if ok:
                keep.append(" ".join(["pull-filter", args[0], _quote(args[1])]))
            else:
                warn("ignored 'pull-filter' with unsupported arguments")
        elif name in _BLOCK_PEM | _BLOCK_STATIC | {"tls-crypt-v2"}:
            if not args:
                warn(f"'{name}' without a file ignored")
                continue
            if args[0] == "[inline]":
                continue
            inline_from_file(name, args[0])
            if name == "tls-auth" and len(args) > 1 and args[1] in ("0", "1") and not key_dir_set:
                keep.append(f"key-direction {args[1]}")
                key_dir_set = True
        elif name == "auth-user-pass":
            out.needs_auth = True
            if args:
                data = files.get(_basename(args[0]))
                if data is None:
                    warn("credentials file not provided; supply a username/password when importing")
                else:
                    out.auth = _creds(data)
        elif name == "dhcp-option":
            if len(args) == 2 and args[0].upper() in ("DNS", "DNS6"):
                try:
                    ip = str(ipaddress.ip_address(args[1]))
                    if ip not in out.dns:
                        out.dns.append(ip)
                except ValueError:
                    warn("ignored dhcp-option with a non-IP DNS server")
        elif name in _PASS:
            lo, hi, pat = _PASS[name]
            if not lo <= len(args) <= hi or (pat and not all(re.fullmatch(pat, a) for a in args)):
                warn(f"ignored '{name}' with unsupported arguments")
                continue
            if name in _WEAK and any(part.lower() == "none" for a in args for part in a.split(":")):
                warn(f"ignored '{name}': it would switch off encryption or authentication")
                continue
            if name == "key-direction":
                key_dir_set = True
            keep.append(" ".join([name, *map(_quote, args)]))
        elif name == "verify-x509-name":
            ok = 1 <= len(args) <= 2 and re.fullmatch(r"[\x20-\x7e]{1,200}", args[0]) and not re.search(r"[\"'\\;#]", args[0]) \
                and (len(args) == 1 or args[1] in ("subject", "name", "name-prefix"))
            if ok:
                keep.append(" ".join(["verify-x509-name", *map(_quote, args)]))
            else:
                warn("ignored 'verify-x509-name' with unsupported arguments")
        elif name == "push-peer-info":
            warn("removed 'push-peer-info': it makes the client tell the server more about this machine")
        elif name in _DANGEROUS:
            out.removed.append(name)
            warn(f"removed unsafe directive '{name}' (it can run programs or touch the host)")
        elif name in _HANDLED:
            if name in ("http-proxy", "socks-proxy"):
                warn(f"'{name}' is not supported: the kill switch only allows the VPN server itself")
            elif name in ("pkcs12", "secret", "askpass"):
                warn(f"ignored '{name}': not supported (use separate certificate/key files)")
        else:
            warn(f"ignored unsupported directive '{name}'")

    if missing:
        raise ProfileError("referenced files were not provided: " + ", ".join(sorted(set(missing))),
                           hint="import from the file's own directory so certificates can be inlined")
    if not remotes:
        raise ProfileError("no 'remote' server found in the configuration")
    if len(remotes) > MAX_REMOTES:
        raise ProfileError(f"too many remote servers (max {MAX_REMOTES})")
    if "ca" not in blocks and not any(l.startswith("peer-fingerprint") for l in keep):
        warn("no CA certificate or peer-fingerprint: the server's identity cannot be verified")
    if "key" in blocks and "cert" not in blocks:
        warn("private key without a client certificate")

    seen: dict[tuple[str, int, str], Endpoint] = {}
    for host, port, proto in remotes:
        p, port = proto or global_proto, port or global_port or 1194
        seen.setdefault((host.lower(), port, p), Endpoint(host, port, p))
    out.endpoints = list(seen.values())
    parts = ["# sanitised by IPShift Pro - unsafe and unsupported directives removed", *keep]
    for tag, body in blocks.items():
        parts += [f"<{tag}>", body, f"</{tag}>"]
    out.body = "\n".join(parts) + "\n"
    return out


def render(body: str, *, ip: str, port: int, proto: str, iface: str, user: str | None = None,
           group: str | None = None, auth_path: str | None = None, connect_timeout: int = 20,
           ping: int = 10, ping_exit: int = 30) -> str:
    """Final runtime config: one pinned server address, our device, our routing."""
    addr = ipaddress.ip_address(ip)
    wire = ("udp6" if addr.version == 6 else "udp") if proto == "udp" else ("tcp6-client" if addr.version == 6 else "tcp-client")
    lines = [
        body.rstrip("\n"),
        f"dev {iface}", "dev-type tun",
        f"remote {addr} {int(port)} {wire}",
        "ignore-unknown-option disable-dco", "disable-dco",      # keep a classic tun device + plain logs
        "nobind", "resolv-retry 0", "connect-retry-max 1", f"connect-timeout {int(connect_timeout)}",
        "script-security 1", "redirect-gateway def1",
        f"ping {int(ping)}", f"ping-exit {int(ping_exit)}", "verb 3",
    ]
    if user:
        lines += [f"user {user}"] + ([f"group {group}"] if group else [])
    if auth_path:
        lines.append(f"auth-user-pass {auth_path}")
    return "\n".join(lines) + "\n"
