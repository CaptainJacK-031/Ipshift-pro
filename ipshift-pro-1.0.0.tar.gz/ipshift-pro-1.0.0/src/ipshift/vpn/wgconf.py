"""WireGuard configuration parser and renderer (wg-quick file format).

IPShift never runs ``wg-quick``: its PreUp/PostUp/PreDown/PostDown hooks are
shell commands that would execute as root.  We parse the file, validate every
value (keys, CIDRs, IPs, endpoints), drop the hooks with a warning, and
re-render a canonical config.  The result is applied with plain ``ip`` and
``wg setconf`` calls - never through a shell.
"""
from __future__ import annotations

import base64
import binascii
import ipaddress
import re
from dataclasses import dataclass, field

from ..errors import ProfileError
from .ovpn import _HOST
from .profile import Endpoint

MAX_BYTES = 64 * 1024
_UNSAFE = {"preup", "postup", "predown", "postdown", "saveconfig"}
_DROPPED = {"listenport", "fwmark", "table"}          # we pick these ourselves


@dataclass
class WgPeer:
    public_key: str
    allowed_ips: list[str]
    endpoint_host: str | None = None
    endpoint_port: int | None = None
    preshared_key: str | None = None
    keepalive: int | None = None


@dataclass
class WgConfig:
    private_key: str
    addresses: list[str]
    peers: list[WgPeer]
    dns: list[str] = field(default_factory=list)
    mtu: int | None = None
    warnings: list[str] = field(default_factory=list)
    removed: list[str] = field(default_factory=list)

    def endpoints(self) -> list[Endpoint]:
        return [Endpoint(p.endpoint_host, p.endpoint_port, "udp")
                for p in self.peers if p.endpoint_host and p.endpoint_port]

    @property
    def full_tunnel(self) -> bool:
        nets = {n for p in self.peers for n in p.allowed_ips}
        return "0.0.0.0/0" in nets

    @property
    def has_ipv6(self) -> bool:
        return any(":" in a for a in self.addresses)


def valid_key(k: str) -> bool:
    if not re.fullmatch(r"[A-Za-z0-9+/]{43}=", k):
        return False
    try:
        return len(base64.b64decode(k, validate=True)) == 32
    except (binascii.Error, ValueError):
        return False


def _csv(value: str) -> list[str]:
    return [x.strip() for x in value.split(",") if x.strip()]


def parse_endpoint(value: str) -> tuple[str, int]:
    host, sep, port = value.strip().rpartition(":")
    if not sep or not port.isdigit() or not 1 <= int(port) <= 65535:
        raise ProfileError(f"invalid Endpoint {value[:60]!r}")
    host = host[1:-1] if host.startswith("[") and host.endswith("]") else host
    try:
        host = str(ipaddress.ip_address(host))
    except ValueError:
        if not _HOST.match(host):
            raise ProfileError(f"invalid Endpoint host {host[:60]!r}") from None
    return host, int(port)


def parse(text: str) -> WgConfig:
    if len(text) > MAX_BYTES or "\0" in text:
        raise ProfileError("invalid or oversized WireGuard configuration")
    warnings: list[str] = []
    removed: list[str] = []
    iface: dict[str, str] = {}
    peers: list[dict[str, str]] = []
    section: dict[str, str] | None = None
    for n, raw in enumerate(text.lstrip("﻿").splitlines(), 1):
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        if line.startswith("["):
            tag = line.strip("[] ").lower()
            if tag == "interface":
                section = iface
            elif tag == "peer":
                section = {}
                peers.append(section)
            else:
                raise ProfileError(f"line {n}: unknown section {line[:30]!r}")
            continue
        if section is None or "=" not in line:
            raise ProfileError(f"line {n}: not a 'key = value' line")
        key, _, val = line.partition("=")
        key, val = key.strip().lower(), val.strip()
        if key in _UNSAFE:
            removed.append(key)
            warnings.append(f"removed unsafe hook '{key}' (it would run a shell command as root)")
        elif key in _DROPPED:
            warnings.append(f"ignored '{key}' (managed by IPShift)")
        else:
            section[key] = (section.get(key, "") + "," + val) if key in ("address", "dns", "allowedips") and key in section else val

    pk = iface.get("privatekey", "")
    if not valid_key(pk):
        raise ProfileError("missing or invalid [Interface] PrivateKey")
    addrs = []
    for a in _csv(iface.get("address", "")):
        try:
            addrs.append(str(ipaddress.ip_interface(a)))
        except ValueError:
            raise ProfileError(f"invalid Address {a[:40]!r}") from None
    if not addrs:
        raise ProfileError("[Interface] has no Address")
    dns = []
    for d in _csv(iface.get("dns", "")):
        try:
            dns.append(str(ipaddress.ip_address(d)))
        except ValueError:
            warnings.append(f"ignored non-IP DNS entry {d[:30]!r}")
    mtu = None
    if "mtu" in iface:
        if iface["mtu"].isdigit() and 576 <= int(iface["mtu"]) <= 1500:
            mtu = int(iface["mtu"])
        else:
            warnings.append("ignored MTU outside 576-1500")

    out_peers = []
    for p in peers:
        if not valid_key(p.get("publickey", "")):
            raise ProfileError("a [Peer] has a missing or invalid PublicKey")
        psk = p.get("presharedkey")
        if psk is not None and not valid_key(psk):
            raise ProfileError("invalid PresharedKey")
        nets = []
        for n in _csv(p.get("allowedips", "")):
            try:
                nets.append(str(ipaddress.ip_network(n, strict=False)))
            except ValueError:
                raise ProfileError(f"invalid AllowedIPs entry {n[:40]!r}") from None
        if not nets:
            raise ProfileError("a [Peer] has no AllowedIPs")
        host = port = None
        if "endpoint" in p:
            host, port = parse_endpoint(p["endpoint"])
        ka = p.get("persistentkeepalive")
        if ka is not None:
            ka = 0 if ka.lower() == "off" else (int(ka) if ka.isdigit() and int(ka) <= 65535 else None)
            if ka is None:
                raise ProfileError("invalid PersistentKeepalive")
        out_peers.append(WgPeer(p["publickey"], nets, host, port, psk, ka))
    if not out_peers:
        raise ProfileError("no [Peer] section found")
    if not any(p.endpoint_host for p in out_peers):
        raise ProfileError("no peer has an Endpoint (a client configuration needs one)")
    return WgConfig(pk, addrs, out_peers, dns, mtu, warnings, removed)


def render_canonical(cfg: WgConfig) -> str:
    lines = ["[Interface]", f"PrivateKey = {cfg.private_key}", f"Address = {', '.join(cfg.addresses)}"]
    if cfg.dns:
        lines.append(f"DNS = {', '.join(cfg.dns)}")
    if cfg.mtu:
        lines.append(f"MTU = {cfg.mtu}")
    for p in cfg.peers:
        lines += ["", "[Peer]", f"PublicKey = {p.public_key}"]
        if p.preshared_key:
            lines.append(f"PresharedKey = {p.preshared_key}")
        lines.append(f"AllowedIPs = {', '.join(p.allowed_ips)}")
        if p.endpoint_host:
            h = f"[{p.endpoint_host}]" if ":" in p.endpoint_host else p.endpoint_host
            lines.append(f"Endpoint = {h}:{p.endpoint_port}")
        if p.keepalive is not None:
            lines.append(f"PersistentKeepalive = {p.keepalive}")
    return "\n".join(lines) + "\n"


def render_setconf(cfg: WgConfig, targets: dict[int, tuple[str, int]], keepalive: int = 25) -> str:
    """The restricted format ``wg setconf``/``syncconf`` accepts (no Address/DNS/MTU).

    ``targets`` maps a peer index to the *resolved* (ip, port) to dial.  A
    keepalive is forced when the profile has none: it triggers an immediate
    handshake and keeps NAT mappings alive on mobile hotspots.
    """
    lines = ["[Interface]", f"PrivateKey = {cfg.private_key}"]
    for i, p in enumerate(cfg.peers):
        lines += ["", "[Peer]", f"PublicKey = {p.public_key}"]
        if p.preshared_key:
            lines.append(f"PresharedKey = {p.preshared_key}")
        lines.append(f"AllowedIPs = {', '.join(p.allowed_ips)}")
        if i in targets:
            ip, port = targets[i]
            lines.append(f"Endpoint = {'[' + ip + ']' if ':' in ip else ip}:{port}")
        ka = p.keepalive if p.keepalive else keepalive
        if ka:
            lines.append(f"PersistentKeepalive = {ka}")
    return "\n".join(lines) + "\n"
