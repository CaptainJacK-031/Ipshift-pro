"""VPN layer: profile store, config sanitizers, OpenVPN/WireGuard backends and
the manager that connects them safely (kill switch first, verify afterwards)."""
