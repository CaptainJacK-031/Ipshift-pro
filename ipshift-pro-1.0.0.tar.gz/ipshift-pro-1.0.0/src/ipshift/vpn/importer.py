"""Turn a user-supplied VPN configuration into a stored, sanitised profile.

Two halves, deliberately on different sides of the privilege boundary:

* :func:`read_bundle` runs in the *client* (CLI/GUI, as the invoking user).  It
  reads the config plus the certificate/key files named next to it - only from
  the config's own directory - and sends the contents.  The daemon therefore
  never opens a path that came out of a profile.
* :func:`import_profile` runs in the daemon: detect protocol, sanitise, resolve
  server names (DoH, never the ISP resolver), write the profile.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

from ..errors import ProfileError
from . import ovpn, wgconf
from .profile import Endpoint, Profile, ProfileStore, TIERS, make_id

ISO2 = frozenset("""AD AE AF AG AI AL AM AO AQ AR AS AT AU AW AX AZ BA BB BD BE BF BG BH BI BJ BL BM BN BO BQ BR
BS BT BV BW BY BZ CA CC CD CF CG CH CI CK CL CM CN CO CR CU CV CW CX CY CZ DE DJ DK DM DO DZ EC EE EG EH ER ES ET
FI FJ FK FM FO FR GA GB GD GE GF GG GH GI GL GM GN GP GQ GR GS GT GU GW GY HK HM HN HR HT HU ID IE IL IM IN IO IQ
IR IS IT JE JM JO JP KE KG KH KI KM KN KP KR KW KY KZ LA LB LC LI LK LR LS LT LU LV LY MA MC MD ME MF MG MH MK ML
MM MN MO MP MQ MR MS MT MU MV MW MX MY MZ NA NC NE NF NG NI NL NO NP NR NU NZ OM PA PE PF PG PH PK PL PM PN PR PS
PT PW PY QA RE RO RS RU RW SA SB SC SD SE SG SH SI SJ SK SL SM SN SO SR SS ST SV SX SY SZ TC TD TF TG TH TJ TK TL
TM TN TO TR TT TV TW TZ UA UG UM US UY UZ VA VC VE VG VI VN VU WF WS YE YT ZA ZM ZW""".split())
_NOT_COUNTRIES = {"my", "is", "to", "be", "it", "me", "as", "so", "do", "go", "an", "on", "or", "if", "by",
                  "he", "we", "am", "at", "in", "no"}
MAX_FILE = 64 * 1024


def guess_country(name: str) -> str:
    """Best-effort ISO code from names like ``us-nyc-12`` or ``Proton_NL-free-3``."""
    toks = [t for t in re.split(r"[^A-Za-z]+", name) if t]
    for tok in toks[:3]:
        if tok.lower() in _NOT_COUNTRIES:
            continue
        up = tok.upper()
        if up == "UK":
            return "GB"
        if len(up) == 2 and up in ISO2:
            return up
    return ""


def detect_protocol(text: str) -> str:
    if re.search(r"^\s*\[\s*(Interface|Peer)\s*\]", text, re.I | re.M):
        return "wireguard"
    if re.search(r"^\s*(remote|client|dev)\s", text, re.M):
        return "openvpn"
    raise ProfileError("this does not look like an OpenVPN or WireGuard configuration")


def read_bundle(path: str | Path) -> dict:
    """Client side: ``{"name", "text", "files"}`` ready for the profile.import RPC."""
    p = Path(path)
    try:
        if p.stat().st_size > ovpn.MAX_BYTES:
            raise ProfileError(f"{p.name} is too large")
        text = p.read_text(errors="replace")
    except OSError as e:
        raise ProfileError(f"cannot read {p}: {e.strerror or e}") from None
    files: dict[str, str] = {}
    if detect_protocol(text) == "openvpn":
        for ref in ovpn.referenced_files(text):
            cand = p.parent / ref                       # same directory only, never an absolute path
            try:
                if cand.is_file() and cand.stat().st_size <= MAX_FILE:
                    files[ref] = cand.read_text(errors="replace")
            except OSError:
                continue
    return {"name": p.stem, "text": text, "files": files}


@dataclass
class ImportResult:
    profile: Profile
    warnings: list[str] = field(default_factory=list)
    removed: list[str] = field(default_factory=list)


def import_profile(store: ProfileStore, *, text: str, files: dict[str, str] | None = None, name: str,
                   protocol: str | None = None, tier: str = "unknown", provider: str = "",
                   country: str = "", username: str | None = None, password: str | None = None,
                   resolver=None, replace: bool = False, notes: str = "") -> ImportResult:
    name = re.sub(r"[\x00-\x1f]", "", name).strip()[:60]
    if not name:
        raise ProfileError("a profile needs a name")
    if tier not in TIERS:
        raise ProfileError(f"tier must be one of {', '.join(TIERS)}")
    country = country.strip().upper()
    if country and country not in ISO2:
        raise ProfileError("country must be a 2-letter ISO code (e.g. NL)")
    proto = protocol or detect_protocol(text)
    auth: tuple[str, str] | None = (username, password) if username and password else None
    warnings: list[str] = []

    if proto == "openvpn":
        parsed = ovpn.sanitize(text, files)
        stored, endpoints, dns = parsed.body, parsed.endpoints, parsed.dns
        needs_auth, auth = parsed.needs_auth, auth or parsed.auth
        warnings, removed = parsed.warnings, parsed.removed
    elif proto == "wireguard":
        wg = wgconf.parse(text)
        stored, endpoints, dns = wgconf.render_canonical(wg), wg.endpoints(), wg.dns
        needs_auth, warnings, removed = False, wg.warnings, wg.removed
        if not wg.full_tunnel:
            warnings.append("AllowedIPs does not include 0.0.0.0/0: only part of your traffic would use this tunnel, "
                            "and the kill switch will block the rest")
    else:
        raise ProfileError(f"unsupported protocol {proto!r}")
    if needs_auth and auth is None:
        warnings.append("this profile needs a username and password: add them with 'ipshift vpn auth'")

    for ep in endpoints:                                # cache addresses; never ask the local resolver
        try:
            ep.ips = _resolve(ep, resolver)
        except OSError as e:
            warnings.append(f"could not resolve {ep.host} now ({e}); it will be resolved when connecting")

    prof = Profile(id=make_id(name, stored), name=name, protocol=proto, tier=tier, provider=provider.strip()[:40],
                   country=country or guess_country(name), endpoints=endpoints, dns=dns,
                   needs_auth=needs_auth, notes=notes[:200])
    store.add(prof, stored, auth, replace=replace)
    return ImportResult(prof, warnings, removed)


def _resolve(ep: Endpoint, resolver) -> list[str]:
    import ipaddress
    try:
        ipaddress.ip_address(ep.host)
        return [ep.host]
    except ValueError:
        pass
    if resolver is None:
        return []
    return resolver.resolve(ep.host)
