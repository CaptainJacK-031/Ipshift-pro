"""VPN profiles and the on-disk profile store.

Layout (directory 0700, files 0600, all owned by root when the daemon runs)::

    <id>.json   metadata: name, tier, protocol, endpoints, statistics (no secrets)
    <id>.cfg    the *sanitised* tunnel configuration (may hold keys)
    <id>.auth   "username\\npassword" for OpenVPN profiles that need it

Free, paid and self-hosted VPNs are all just profiles that differ in ``tier``;
the tier drives rotation filters and the trust warnings shown to the user.
"""
from __future__ import annotations

import hashlib
import json
import re
import threading
import time
from dataclasses import dataclass, field, asdict, fields
from pathlib import Path

from ..errors import NotFound, ProfileError
from ..sysutil import atomic_write, ensure_private_dir

TIERS = ("free", "paid", "self-hosted", "unknown")
PROTOCOLS = ("openvpn", "wireguard")
QUARANTINE_AFTER = 3          # consecutive failures before a profile is benched
QUARANTINE_BASE = 60.0        # seconds; doubles per extra failure, capped below
QUARANTINE_MAX = 3600.0


@dataclass
class Endpoint:
    host: str
    port: int
    proto: str = "udp"                                  # udp | tcp
    ips: list[str] = field(default_factory=list)        # cached, resolved addresses

    @classmethod
    def from_dict(cls, d: dict) -> "Endpoint":
        return cls(str(d["host"]), int(d["port"]), str(d.get("proto", "udp")), list(d.get("ips", [])))


@dataclass
class Profile:
    id: str
    name: str
    protocol: str
    tier: str = "unknown"
    provider: str = ""
    country: str = ""                                   # ISO-3166 alpha-2 when known
    endpoints: list[Endpoint] = field(default_factory=list)
    dns: list[str] = field(default_factory=list)
    enabled: bool = True
    needs_auth: bool = False
    has_auth: bool = False
    notes: str = ""
    created: float = field(default_factory=time.time)
    ok_count: int = 0
    fail_count: int = 0
    consecutive_failures: int = 0
    quarantined_until: float = 0.0
    last_used: float | None = None
    last_ip: str | None = None
    avg_ms: int | None = None
    last_error: str | None = None

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Profile":
        known = {f.name for f in fields(cls)}
        kw = {k: v for k, v in d.items() if k in known and k != "endpoints"}
        kw["endpoints"] = [Endpoint.from_dict(e) for e in d.get("endpoints", [])]
        return cls(**kw)

    @property
    def quarantined(self) -> bool:
        return self.quarantined_until > time.time()

    @property
    def usable(self) -> bool:
        return self.enabled and not self.quarantined and (not self.needs_auth or self.has_auth)

    def summary(self) -> dict:
        d = self.to_dict()
        d["quarantined"] = self.quarantined
        d["usable"] = self.usable
        return d


def slugify(text: str, limit: int = 24) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return (s or "profile")[:limit].strip("-") or "profile"


def make_id(name: str, config_text: str) -> str:
    return f"{slugify(name)}-{hashlib.sha256(config_text.encode()).hexdigest()[:6]}"


class ProfileStore:
    def __init__(self, directory: Path):
        self.dir = Path(directory)
        self._lock = threading.RLock()
        self._cache: dict[str, Profile] = {}
        ensure_private_dir(self.dir)
        self.reload()

    # ---- loading -----------------------------------------------------------
    def reload(self) -> None:
        with self._lock:
            self._cache.clear()
            for f in sorted(self.dir.glob("*.json")):
                try:
                    p = Profile.from_dict(json.loads(f.read_text()))
                except (OSError, ValueError, KeyError, TypeError):
                    continue                                  # ignore a corrupt entry, never crash
                if p.id == f.stem:
                    self._cache[p.id] = p

    def _path(self, pid: str, ext: str) -> Path:
        if not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,40}", pid):
            raise ProfileError(f"invalid profile id {pid!r}")
        return self.dir / f"{pid}.{ext}"

    def _save(self, p: Profile) -> None:
        atomic_write(self._path(p.id, "json"), json.dumps(p.to_dict(), indent=1, sort_keys=True), 0o600)

    # ---- queries -----------------------------------------------------------
    def list(self, *, tiers=None, protocol: str | None = None, enabled: bool | None = None,
             country: str | None = None, usable: bool | None = None) -> list[Profile]:
        with self._lock:
            out = list(self._cache.values())
        if tiers:
            out = [p for p in out if p.tier in tiers]
        if protocol:
            out = [p for p in out if p.protocol == protocol]
        if enabled is not None:
            out = [p for p in out if p.enabled == enabled]
        if country:
            out = [p for p in out if p.country.upper() == country.upper()]
        if usable is not None:
            out = [p for p in out if p.usable == usable]
        return sorted(out, key=lambda p: (p.tier, p.provider, p.country, p.name))

    def get(self, ref: str) -> Profile:
        ref = (ref or "").strip()
        with self._lock:
            if ref in self._cache:
                return self._cache[ref]
            low = ref.lower()
            by_name = [p for p in self._cache.values() if p.name.lower() == low]
            if len(by_name) == 1:
                return by_name[0]
            by_prefix = [p for p in self._cache.values() if len(low) >= 3 and p.id.startswith(low)]
            if len(by_prefix) == 1:
                return by_prefix[0]
            matches = by_name or by_prefix
        if matches:
            raise ProfileError(f"{ref!r} is ambiguous: " + ", ".join(sorted(p.id for p in matches)))
        raise NotFound(f"no such VPN profile: {ref!r}", hint="list profiles with: ipshift vpn list")

    # ---- mutation ----------------------------------------------------------
    def add(self, profile: Profile, config_text: str, auth: tuple[str, str] | None = None,
            *, replace: bool = False) -> Profile:
        if profile.tier not in TIERS or profile.protocol not in PROTOCOLS:
            raise ProfileError("invalid tier or protocol")
        with self._lock:
            if profile.id in self._cache and not replace:
                raise ProfileError(f"profile already imported as {profile.id!r}",
                                   hint="use --replace to overwrite it")
            atomic_write(self._path(profile.id, "cfg"), config_text, 0o600)
            if auth:
                atomic_write(self._path(profile.id, "auth"), f"{auth[0]}\n{auth[1]}\n", 0o600)
                profile.has_auth = True
            elif profile.id in self._cache and replace:
                profile.has_auth = self._path(profile.id, "auth").exists()
            self._save(profile)
            self._cache[profile.id] = profile
        return profile

    def remove(self, ref: str) -> Profile:
        with self._lock:
            p = self.get(ref)
            for ext in ("json", "cfg", "auth"):
                try:
                    self._path(p.id, ext).unlink()
                except FileNotFoundError:
                    pass
            self._cache.pop(p.id, None)
        return p

    def update(self, ref: str, **changes) -> Profile:
        allowed = {"name", "tier", "provider", "country", "enabled", "notes"}
        bad = set(changes) - allowed
        if bad:
            raise ProfileError("cannot change: " + ", ".join(sorted(bad)))
        if "tier" in changes and changes["tier"] not in TIERS:
            raise ProfileError(f"tier must be one of {', '.join(TIERS)}")
        if "country" in changes:
            c = str(changes["country"]).strip().upper()
            if c and not re.fullmatch(r"[A-Z]{2}", c):
                raise ProfileError("country must be a 2-letter ISO code")
            changes["country"] = c
        with self._lock:
            p = self.get(ref)
            for k, v in changes.items():
                setattr(p, k, v)
            self._save(p)
        return p

    def set_auth(self, ref: str, username: str, password: str) -> Profile:
        if not username or "\n" in username or "\n" in password or "\r" in password:
            raise ProfileError("invalid credentials")
        with self._lock:
            p = self.get(ref)
            atomic_write(self._path(p.id, "auth"), f"{username}\n{password}\n", 0o600)
            p.has_auth = True
            self._save(p)
        return p

    def set_endpoint_ips(self, ref: str, resolved: dict[str, list[str]]) -> None:
        with self._lock:
            p = self.get(ref)
            for e in p.endpoints:
                if e.host in resolved:
                    e.ips = list(resolved[e.host])
            self._save(p)

    def record_result(self, ref: str, ok: bool, ms: int | None = None, ip: str | None = None,
                      error: str | None = None) -> None:
        with self._lock:
            try:
                p = self.get(ref)
            except (NotFound, ProfileError):
                return
            now = time.time()
            if ok:
                p.ok_count += 1
                p.consecutive_failures = 0
                p.quarantined_until = 0.0
                p.last_used, p.last_ip, p.last_error = now, ip, None
                if ms is not None:
                    p.avg_ms = ms if p.avg_ms is None else int(0.7 * p.avg_ms + 0.3 * ms)
            else:
                p.fail_count += 1
                p.consecutive_failures += 1
                p.last_error = (error or "failed")[:200]
                if p.consecutive_failures >= QUARANTINE_AFTER:
                    wait = min(QUARANTINE_BASE * 2 ** (p.consecutive_failures - QUARANTINE_AFTER), QUARANTINE_MAX)
                    p.quarantined_until = now + wait
            self._save(p)

    def clear_quarantine(self, ref: str | None = None) -> int:
        n = 0
        with self._lock:
            for p in ([self.get(ref)] if ref else list(self._cache.values())):
                if p.quarantined_until or p.consecutive_failures:
                    p.quarantined_until, p.consecutive_failures = 0.0, 0
                    self._save(p)
                    n += 1
        return n

    # ---- secrets -----------------------------------------------------------
    def read_config(self, p: Profile) -> str:
        try:
            return self._path(p.id, "cfg").read_text()
        except OSError as e:
            raise ProfileError(f"profile {p.id} has no readable configuration: {e}") from None

    def read_auth(self, p: Profile) -> tuple[str, str] | None:
        try:
            lines = self._path(p.id, "auth").read_text().splitlines()
        except OSError:
            return None
        return (lines[0], lines[1]) if len(lines) >= 2 else None
