"""Findings, score and verdict of a privacy check.

The score is a summary for humans, not a certificate: a high score means *the
things this tool can test* are in order.  ``NOT_COVERED`` is part of every
report so nobody mistakes it for a guarantee of anonymity.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field

STATUSES = ("pass", "warn", "fail", "skip")

NOT_COVERED = [
    "Browser leaks (WebRTC, canvas/font fingerprinting, cookies, logins) - use a hardened browser profile",
    "What your VPN provider logs or sells - a VPN moves trust, it does not remove it",
    "Correlation by an observer who sees both ends of the connection (timing, traffic volume)",
    "Anything you tell a website yourself (accounts, payment details, writing style)",
    "Malware or other software on this machine that talks to the network by itself",
]


@dataclass
class Finding:
    id: str
    title: str
    status: str                       # pass | warn | fail | skip
    detail: str = ""
    hint: str | None = None
    leak: bool = False                # a failure here means traffic or identity can escape the tunnel
    weight: int = 10                  # points lost when it fails (half when it only warns)
    evidence: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {"id": self.id, "title": self.title, "status": self.status, "detail": self.detail,
                "hint": self.hint, "leak": self.leak, "weight": self.weight, "evidence": self.evidence}


def grade_for(score: int) -> str:
    return "A" if score >= 95 else "B" if score >= 85 else "C" if score >= 70 else "D" if score >= 50 else "F"


@dataclass
class Report:
    findings: list[Finding]
    mode: str = "full"
    ts: float = field(default_factory=time.time)
    duration_ms: int = 0
    simulated: bool = False

    def get(self, finding_id: str) -> Finding | None:
        return next((f for f in self.findings if f.id == finding_id), None)

    @property
    def counts(self) -> dict:
        return {s: sum(1 for f in self.findings if f.status == s) for s in STATUSES}

    @property
    def leaks(self) -> list[Finding]:
        return [f for f in self.findings if f.leak and f.status == "fail"]

    @property
    def score(self) -> int:
        lost = sum(f.weight if f.status == "fail" else f.weight // 2 if f.status == "warn" else 0
                   for f in self.findings)
        score = max(0, 100 - lost)
        return min(score, 39) if self.leaks else score

    @property
    def grade(self) -> str:
        return grade_for(self.score)

    @property
    def verdict(self) -> str:
        """exposed | unprotected | blocked | at-risk | protected-with-warnings | protected"""
        if self.leaks:
            return "exposed"
        tunnel, ks = self.get("tunnel"), self.get("killswitch")
        if tunnel and tunnel.status == "fail":
            return "blocked" if ks and ks.status == "pass" else "unprotected"
        c = self.counts
        if c["fail"]:
            return "at-risk"
        return "protected-with-warnings" if c["warn"] else "protected"

    def headline(self) -> str:
        return {
            "exposed": "EXPOSED - traffic or DNS can leave outside the VPN",
            "unprotected": "NOT PROTECTED - no VPN and no kill switch",
            "blocked": "OFFLINE BY DESIGN - the VPN is down and the kill switch is blocking all traffic",
            "at-risk": "AT RISK - the tunnel works but protections are incomplete",
            "protected-with-warnings": "PROTECTED (with warnings)",
            "protected": "PROTECTED - every check this tool can run passed",
        }[self.verdict]

    def to_dict(self) -> dict:
        return {"verdict": self.verdict, "headline": self.headline(), "score": self.score, "grade": self.grade,
                "counts": self.counts, "mode": self.mode, "ts": self.ts, "duration_ms": self.duration_ms,
                "simulated": self.simulated, "findings": [f.to_dict() for f in self.findings],
                "not_covered": list(NOT_COVERED)}
