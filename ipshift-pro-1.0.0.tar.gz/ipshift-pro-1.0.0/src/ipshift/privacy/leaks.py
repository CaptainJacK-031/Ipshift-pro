"""Runs the privacy checks (in parallel) and builds the report."""
from __future__ import annotations

import concurrent.futures as cf
import logging
import time

from .checks import Checks
from .report import Finding, Report

log = logging.getLogger(__name__)

FULL = ("tunnel", "killswitch", "public_ip", "dns_config", "dns_path", "dns_escape", "ipv6", "escape", "lan", "mac")
QUICK = ("tunnel", "killswitch", "public_ip", "dns_config")
TITLES = {
    "tunnel": "VPN tunnel", "killswitch": "Kill switch", "public_ip": "Public IP address",
    "dns_config": "DNS configuration", "dns_path": "DNS resolution path", "dns_escape": "DNS escape test",
    "ipv6": "IPv6 leak test", "escape": "Escape test (IPv4)", "lan": "Local network exposure",
    "mac": "MAC address privacy",
}


class PrivacyChecker(Checks):
    """``probes`` pins test packets to network interfaces (NetProbes), or fakes them (SimProbes)."""

    def run(self, mode: str = "full", only: list[str] | None = None, *, simulated: bool = False) -> Report:
        if only:
            unknown = [n for n in only if n not in FULL]
            if unknown:
                raise ValueError("unknown check(s): " + ", ".join(unknown) + " (valid: " + ", ".join(FULL) + ")")
            names = list(dict.fromkeys(only))
        else:
            names = list(QUICK if mode == "quick" else FULL)
        t0 = time.monotonic()
        with cf.ThreadPoolExecutor(max_workers=6, thread_name_prefix="check") as ex:
            futures = [ex.submit(self._safe, n) for n in names]
            findings = [f.result() for f in futures]
        return Report(findings, mode="custom" if only else mode, duration_ms=int((time.monotonic() - t0) * 1000),
                      simulated=simulated)

    def _safe(self, name: str) -> Finding:
        try:
            return getattr(self, name)()
        except Exception as e:                       # one broken probe must not hide the other results
            log.exception("privacy check %s failed", name)
            return Finding(name, TITLES.get(name, name), "skip", f"The check could not run ({e.__class__.__name__}: {e})")
