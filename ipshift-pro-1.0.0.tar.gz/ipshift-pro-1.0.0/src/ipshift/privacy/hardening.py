"""Everything IPShift changes on the machine besides the firewall, in one place,
plus ``restore_all`` - the "put it all back" routine that works without the
daemon (``ipshift restore``).
"""
from __future__ import annotations

import logging
import os
import shutil
import signal
import time
from pathlib import Path

from ..errors import IPShiftError
from ..firewall.killswitch import KillSwitch
from .dnslock import DnsLock
from .ipv6 import Ipv6Guard
from .mac import NM_DROPIN, MacPolicy
from .state import StateStore

log = logging.getLogger(__name__)


class Hardening:
    def __init__(self, cfg, runner, net, paths, *, resolv: str | Path = "/etc/resolv.conf",
                 sysctl_root: str | Path = "/proc/sys", nm_dropin: str | Path = NM_DROPIN):
        self.cfg = cfg
        self.paths = paths
        self.store = StateStore(paths.backup_dir)
        self.dns = DnsLock(cfg.dns, runner, self.store, iface=cfg.vpn.interface, resolv=resolv)
        self.ipv6 = Ipv6Guard(self.store, net, sysctl_root=sysctl_root)
        self.mac = MacPolicy(self.store, runner, net, ip_bin=cfg.vpn.ip_bin, nm_dropin=nm_dropin)

    # ---- tunnel lifecycle --------------------------------------------------
    def on_tunnel_up(self, vpn_dns: list[str], *, tunnel_ipv6: bool = False, route_dev=None) -> dict:
        """Called once a tunnel is up and *before* the exit IP is verified (the
        echo services need name resolution that already goes through the tunnel)."""
        report: dict = {"dns": [], "ipv6_disabled": []}
        if self.cfg.dns.manage:
            servers = self.dns.choose(vpn_dns, route_dev=route_dev, allow_v6=tunnel_ipv6)
            self.dns.apply(servers)
            report["dns"] = servers
        if self.cfg.privacy.disable_ipv6_on_physical:
            report["ipv6_disabled"] = self.ipv6.apply()
        return report

    def refresh(self) -> dict:
        """Re-assert the settings after a network change or when something
        (NetworkManager, dhclient, a USB tether appearing) undid them."""
        fixed: dict = {}
        if self.dns.servers and not self.dns.intact():
            self.dns.apply(self.dns.servers)
            fixed["dns"] = list(self.dns.servers)
        if self.cfg.privacy.disable_ipv6_on_physical and self.ipv6.disabled():
            newly = self.ipv6.apply()
            if newly or not self.ipv6.intact():
                fixed["ipv6"] = newly
        return fixed

    def status(self) -> dict:
        return {
            "dns_locked": self.dns.active(),
            "dns_servers": list(self.dns.servers),
            "dns_intact": self.dns.intact() if self.dns.active() else None,
            "ipv6_guard": self.ipv6.disabled(),
            "ipv6_intact": self.ipv6.intact() if self.ipv6.disabled() else None,
            "mac_nm_policy": self.mac.nm_enabled(),
            "mac_overrides": sorted((self.store.get("mac") or {}).keys()),
        }

    def restore(self, *, include_mac: bool = False) -> dict:
        out = {"dns": self.dns.restore(), "ipv6": self.ipv6.restore()}
        if include_mac:
            out["mac"] = self.mac.restore()
        return out


# ---- recovery without the daemon ---------------------------------------------
def find_stray_openvpn(runtime_dir: str | Path, proc: str | Path = "/proc") -> list[int]:
    """PIDs of OpenVPN processes started by IPShift (they keep running if the
    daemon is killed): identified by the runtime config path on their command line."""
    want = str(Path(runtime_dir) / "ovpn.conf").encode()
    pids: list[int] = []
    try:
        names = os.listdir(proc)
    except OSError:
        return pids
    for name in names:
        if not name.isdigit():
            continue
        try:
            argv = (Path(proc) / name / "cmdline").read_bytes().split(b"\0")
        except OSError:
            continue
        if want in argv:
            pids.append(int(name))
    return pids


def _alive(pid: int, proc: str | Path = "/proc") -> bool:
    """Running (a zombie that only waits to be reaped does not count)."""
    try:
        stat = (Path(proc) / str(pid) / "stat").read_text()
    except OSError:
        return False
    return stat.rpartition(")")[2].strip()[:1] not in ("Z", "X", "")


def _terminate(pids: list[int], grace: float = 3.0) -> list[int]:
    for sig, wait in ((signal.SIGTERM, grace), (signal.SIGKILL, 1.0)):
        alive = []
        for pid in pids:
            try:
                os.kill(pid, sig)
                alive.append(pid)
            except ProcessLookupError:
                pass
            except PermissionError:
                log.warning("not allowed to signal process %s", pid)
        end = time.monotonic() + wait
        while alive and time.monotonic() < end:
            time.sleep(0.1)
            alive = [p for p in alive if _alive(p)]
        pids = alive
        if not pids:
            break
    return pids


def cleanup_strays(cfg, runner, paths, *, proc: str | Path = "/proc") -> dict:
    """Stop a tunnel left behind by an earlier run (a crashed daemon leaves OpenVPN
    running and the interface in place)."""
    stray = find_stray_openvpn(paths.runtime_dir, proc)
    stopped = len(stray) - len(_terminate(stray)) if stray else 0
    res = runner.run([cfg.vpn.ip_bin, "link", "del", "dev", cfg.vpn.interface])
    return {"openvpn_stopped": stopped, "tunnel_interface_removed": res.ok}


def restore_all(cfg, runner, net, paths, *, include_mac: bool = True, resolv: str | Path = "/etc/resolv.conf",
                sysctl_root: str | Path = "/proc/sys", nm_dropin: str | Path = NM_DROPIN,
                proc: str | Path = "/proc") -> dict:
    """Undo everything: stop leftover tunnels, remove the firewall rules, put
    DNS / IPv6 / (optionally) MAC addresses back.  Never raises for one failed
    step - it reports each outcome so the user can see what is left."""
    report: dict = cleanup_strays(cfg, runner, paths, proc=proc)
    h = Hardening(cfg, runner, net, paths, resolv=resolv, sysctl_root=sysctl_root, nm_dropin=nm_dropin)
    report.update(h.restore(include_mac=include_mac))
    try:
        KillSwitch(cfg.killswitch, cfg.vpn, runner, net).disarm()
        report["killswitch"] = "removed"
    except IPShiftError as e:
        report["killswitch"] = f"FAILED: {e}"
    runtime = Path(paths.runtime_dir)
    if runtime.is_dir():
        for child in runtime.iterdir():
            try:
                shutil.rmtree(child) if child.is_dir() else child.unlink()
            except OSError:
                pass
    return report
