"""Record of every system setting IPShift changed, kept on disk.

The point is crash safety: if the daemon dies while DNS, IPv6 or a MAC address
is changed, ``ipshift restore`` can still put things back because the original
values are in this file, not in the dead process's memory.
"""
from __future__ import annotations

import json
import logging
import threading
import time
from pathlib import Path

from ..sysutil import atomic_write, ensure_private_dir

log = logging.getLogger(__name__)


class StateStore:
    def __init__(self, backup_dir: Path):
        self.dir = Path(backup_dir)
        self.path = self.dir / "hardening.json"
        self._lock = threading.RLock()

    def _read(self) -> dict:
        try:
            data = json.loads(self.path.read_text())
            return data if isinstance(data, dict) else {}
        except FileNotFoundError:
            return {}
        except (OSError, ValueError):
            log.warning("state file %s is unreadable; ignoring it", self.path)
            return {}

    def _write(self, data: dict) -> None:
        ensure_private_dir(self.dir)
        if not data:
            try:
                self.path.unlink()
            except FileNotFoundError:
                pass
            return
        atomic_write(self.path, json.dumps(data, indent=1, sort_keys=True), 0o600)

    def get(self, section: str, default=None):
        with self._lock:
            return self._read().get(section, default)

    def put(self, section: str, value) -> None:
        with self._lock:
            data = self._read()
            data[section] = value
            data["updated"] = time.time()
            self._write(data)

    def drop(self, section: str) -> None:
        with self._lock:
            data = self._read()
            if section in data:
                del data[section]
                if not [k for k in data if k != "updated"]:
                    data = {}
                self._write(data)

    def sections(self) -> list[str]:
        with self._lock:
            return sorted(k for k in self._read() if k != "updated")
