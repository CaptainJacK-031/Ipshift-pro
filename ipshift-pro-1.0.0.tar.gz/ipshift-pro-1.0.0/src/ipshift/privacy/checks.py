"""The individual privacy checks.  Each one returns a Finding and never raises
(an internal error becomes a "skip" so one broken probe cannot hide the rest).
"""
from __future__ import annotations

import concurrent.futures as cf
import ipaddress
import re

from ..sysutil import parse_ip
from .dnslock import usable_server
from .report import Finding

V4_TARGETS = ("9.9.9.9", "1.1.1.1")
V6_TARGET = "2620:fe::fe"
_TOKEN = re.compile(r"[0-9a-fA-F:.]{3,45}")


def first_ip(values) -> str | None:
    for v in values:
        for tok in _TOKEN.findall(v):
            ip = parse_ip(tok)
            if ip is not None:
                return str(ip)
    return None


def same_network(a: str, b: str) -> bool:
    """Same /24 (IPv4) or /48 (IPv6) - resolvers of one ISP usually share a prefix with its customers."""
    ia, ib = parse_ip(a), parse_ip(b)
    if ia is None or ib is None or ia.version != ib.version:
        return False
    prefix = 24 if ia.version == 4 else 48
    return ipaddress.ip_network(f"{ia}/{prefix}", strict=False) == ipaddress.ip_network(f"{ib}/{prefix}", strict=False)


class Checks:
    def __init__(self, cfg, manager, hardening, killswitch, net, echo, probes):
        self.cfg = cfg
        self.mgr = manager
        self.h = hardening
        self.ks = killswitch
        self.net = net
        self.echo = echo
        self.probes = probes

    # ---- helpers -----------------------------------------------------------
    @property
    def iface(self) -> str:
        return self.cfg.vpn.interface

    def _connected(self) -> bool:
        return bool(self.mgr.status()["connected"] and self.mgr.tunnel_alive())

    def _idle_open(self) -> bool:
        """No VPN, none being set up and no firewall: traffic simply uses the real network, so
        "can traffic leave outside the tunnel?" is not a meaningful question."""
        return self.mgr.state == "disconnected" and self.mgr.conn is None and not self.ks.is_armed()

    @staticmethod
    def _idle_finding(fid: str, title: str) -> Finding:
        return Finding(fid, title, "skip",
                       "No VPN is connected and no kill switch is active, so traffic simply uses your real network")

    def _parallel(self, fn, items) -> list:
        items = list(items)
        if not items:
            return []
        with cf.ThreadPoolExecutor(max_workers=min(8, len(items)), thread_name_prefix="probe") as ex:
            return list(ex.map(fn, items))

    def _nameservers(self) -> list[str]:
        """Every nameserver the system resolver will use, loopback stubs included."""
        out: list[str] = []
        try:
            lines = self.h.dns.resolv.read_text(errors="replace").splitlines()
        except OSError:
            return out
        for line in lines:
            parts = line.split()
            if len(parts) >= 2 and parts[0] == "nameserver":
                ip = parse_ip(parts[1])
                if ip is not None and str(ip) not in out:
                    out.append(str(ip))
        return out

    def _originals(self) -> list[str]:
        """Resolvers the network handed out before IPShift pinned DNS (usually the ISP's / the router)."""
        rec = self.h.store.get("dns") or {}
        out = []
        for line in str(rec.get("content", "")).splitlines():
            parts = line.split()
            if len(parts) >= 2 and parts[0] == "nameserver":
                s = usable_server(parts[1])
                if s and s not in out:
                    out.append(s)
        return out

    def _route_dev(self, ip: str) -> str | None:
        r = self.net.route_get(ip)
        return r.iface if r else None

    def _phys(self) -> list[str]:
        return self.net.physical_ifaces()[:2]

    # ---- checks ------------------------------------------------------------
    def tunnel(self) -> Finding:
        st = self.mgr.status()
        if st["connected"] and self.mgr.tunnel_alive():
            p = st["profile"]
            return Finding("tunnel", "VPN tunnel", "pass",
                           f"Connected through {p['name']} ({st['backend']}); exit address {st['exit_ip']}",
                           evidence={"profile": p["name"], "tier": p["tier"], "backend": st["backend"],
                                     "uptime": st["uptime"], "via": st["via"]})
        if st["state"] in ("connecting", "switching"):
            return Finding("tunnel", "VPN tunnel", "warn", "The VPN is (re)connecting right now; traffic is held back meanwhile")
        return Finding("tunnel", "VPN tunnel", "fail", "The VPN is not connected", weight=40,
                       hint="connect with: ipshift vpn connect", evidence={"state": st["state"], "last_error": st["last_error"]})

    def killswitch(self) -> Finding:
        if self.ks.is_armed():
            st = self.ks.status()
            n = st.get("blocked_packets", 0)
            more = f"; it has blocked {n} packet(s) so far" if n else ""
            return Finding("killswitch", "Kill switch", "pass",
                           "Firewall kill switch is active: nothing may leave except through the tunnel and to the VPN server" + more,
                           evidence={"blocked_packets": n, "lockdown": st.get("lockdown", False)})
        if not self.cfg.killswitch.enabled:
            return Finding("killswitch", "Kill switch", "fail",
                           "The kill switch is turned off in the configuration: if the VPN drops, traffic leaves in the clear",
                           weight=35, hint="ipshift config set killswitch.enabled true")
        return Finding("killswitch", "Kill switch", "fail", "The kill switch is enabled but NOT active in the firewall",
                       weight=35, hint="re-arm it with: ipshift killswitch on")

    def public_ip(self) -> Finding:
        if not self._connected():
            return Finding("public_ip", "Public IP address", "skip", "There is no tunnel to test")
        res = self.mgr.probe_exit_ip(4)
        if not res.ok:
            return Finding("public_ip", "Public IP address", "fail",
                           f"Could not confirm the public IP through the tunnel ({res.error})", weight=25,
                           hint="the tunnel is up but may not pass traffic; try another server")
        base, conn = self.mgr.baseline_ip, self.mgr.conn
        ev = {"ip": res.ip, "agree": res.agree, "asked": res.asked, "baseline_tested": bool(base)}
        if base and res.ip == base:
            return Finding("public_ip", "Public IP address", "fail",
                           f"Your public IP ({res.ip}) is your REAL address: traffic is not going through the VPN",
                           weight=60, leak=True, evidence=ev)
        note = "" if base else " (your real IP was not measured; the escape tests below cover that)"
        if conn and res.ip != conn.exit_ip:
            return Finding("public_ip", "Public IP address", "warn",
                           f"The exit address changed since it was verified ({conn.exit_ip} -> {res.ip}); the provider may rotate it",
                           weight=6, evidence=ev)
        return Finding("public_ip", "Public IP address", "pass",
                       f"Seen from the internet as {res.ip} ({res.agree}/{res.asked} independent services agree){note}",
                       evidence=ev)

    def dns_config(self) -> Finding:
        if self._idle_open():
            return self._idle_finding("dns_config", "DNS configuration")
        servers = self._nameservers()
        if not servers:
            return Finding("dns_config", "DNS configuration", "fail", "No nameserver is configured", weight=20,
                           hint="ipshift config set dns.manage true")
        armed = self.ks.is_armed()
        outside, stub, inside = [], [], []
        for s in servers:
            ip = parse_ip(s)
            if ip is not None and ip.is_loopback:
                stub.append(s)
                continue
            dev = self._route_dev(s)
            (inside if dev == self.iface else outside).append(s if dev == self.iface else f"{s} (via {dev or 'no route'})")
        ev = {"servers": servers, "outside": outside, "stub": stub, "locked": self.h.dns.active()}
        if outside:
            suffix = ("They are blocked by the kill switch, so name resolution will fail."
                      if armed else "Their queries leave outside the tunnel.")
            return Finding("dns_config", "DNS configuration", "fail",
                           "DNS servers reached outside the tunnel: " + ", ".join(outside) + ". " + suffix,
                           weight=30, leak=not armed, evidence=ev,
                           hint="ipshift config set dns.manage true   (IPShift pins DNS to the tunnel)")
        notes = []
        if self.cfg.dns.manage and self._connected() and self.h.dns.active() and not self.h.dns.intact():
            notes.append("resolv.conf was rewritten by another program; IPShift will re-apply its DNS lock")
        if stub:
            notes.append("a local stub resolver (" + ", ".join(stub) +
                         ") is in use; where it forwards to is checked by the DNS path test")
        if notes:
            return Finding("dns_config", "DNS configuration", "warn", "; ".join(notes).capitalize(), weight=8, evidence=ev)
        return Finding("dns_config", "DNS configuration", "pass",
                       "DNS servers " + ", ".join(inside) + " are reached through the tunnel", evidence=ev)

    def dns_path(self) -> Finding:
        if not self._connected():
            return Finding("dns_path", "DNS resolution path", "skip", "There is no tunnel to test")
        servers = self._nameservers()[:3]
        if not servers:
            return Finding("dns_path", "DNS resolution path", "skip", "No nameserver is configured")
        results = self._parallel(lambda ns: (ns, self.probes.resolver_identity(ns)), servers)
        seen = [(ns, first_ip(a.values)) for ns, a in results if a.answered and first_ip(a.values)]
        ev = {"queried": {ns: a.status for ns, a in results}, "resolvers_seen": [r for _, r in seen]}
        if not seen:
            why = "; ".join(f"{ns}: {a.status}" for ns, a in results)
            return Finding("dns_path", "DNS resolution path", "fail",
                           f"No DNS server could be queried through the tunnel ({why})", weight=20, evidence=ev,
                           hint="the VPN's DNS may be down; set dns.servers to a resolver you trust")
        base, originals = self.mgr.baseline_ip, set(self._originals())
        bad = [r for _, r in seen if r in originals or (base and same_network(r, base))]
        if bad:
            return Finding("dns_path", "DNS resolution path", "fail",
                           "DNS queries are being resolved by " + ", ".join(sorted(set(bad))) +
                           " - that is your ISP's or local network's resolver, not the VPN's",
                           weight=45, leak=True, evidence=ev, hint="ipshift config set dns.manage true")
        return Finding("dns_path", "DNS resolution path", "pass",
                       "Queries are resolved through the tunnel; the internet sees the resolver as " +
                       ", ".join(sorted({r for _, r in seen})), evidence=ev)

    def _dns_targets(self) -> list[str]:
        out = list(self._originals())
        r = self.net.default_route(4)
        if r and r.gateway:
            out.append(r.gateway)
        out.append("9.9.9.9")
        return list(dict.fromkeys(out))[:4]

    def dns_escape(self) -> Finding:
        if self._idle_open():
            return self._idle_finding("dns_escape", "DNS escape test")
        phys = self._phys()
        if not phys:
            return Finding("dns_escape", "DNS escape test", "skip", "No physical network interface found")
        jobs = [(i, t) for i in phys for t in self._dns_targets()]
        res = self._parallel(lambda j: (j, self.probes.resolver_identity(j[1], device=j[0])), jobs)
        leaked = [(i, t, a) for (i, t), a in res if a.answered]
        if leaked:
            i, t, a = leaked[0]
            return Finding("dns_escape", "DNS escape test", "fail",
                           f"DNS queries can leave through {i} outside the tunnel: {t} answered (resolver seen as {first_ip(a.values)})",
                           weight=45, leak=True, evidence={"leaks": [[i, t] for i, t, _ in leaked]},
                           hint="arm the kill switch: ipshift killswitch on")
        if all(a.status == "unavailable" for _, a in res):
            return Finding("dns_escape", "DNS escape test", "skip",
                           "Needs root: the probe pins a DNS query to your real network card to prove it is blocked",
                           hint="run: sudo ipshift privacy-check")
        statuses = sorted({a.status for _, a in res})
        return Finding("dns_escape", "DNS escape test", "pass",
                       f"DNS sent through {', '.join(phys)} outside the tunnel gets no answer ({', '.join(statuses)})",
                       evidence={"probes": len(res)})

    def ipv6(self) -> Finding:
        if not self.cfg.privacy.check_ipv6:
            return Finding("ipv6", "IPv6 leak test", "skip", "IPv6 checking is switched off in the configuration")
        if self._idle_open():
            return self._idle_finding("ipv6", "IPv6 leak test")
        phys = self._phys()
        esc = self._parallel(lambda i: (i, self.probes.tcp(V6_TARGET, 443, device=i)), phys)
        leaked = [i for i, st in esc if st == "connected"]
        ev = {"physical_probe": dict(esc), "guard": self.h.ipv6.disabled()}
        if leaked:
            return Finding("ipv6", "IPv6 leak test", "fail",
                           f"IPv6 traffic can leave through {', '.join(leaked)} outside the tunnel", weight=40, leak=True,
                           evidence=ev, hint="ipshift config set privacy.disable_ipv6_on_physical true; keep the kill switch on")
        conn = self.mgr.conn if self._connected() else None
        tunnel_v6 = bool(conn and conn.tunnel.ipv6)
        r6 = self.echo.lookup(6)
        ev["address"] = r6.ip
        if r6.ok and not tunnel_v6:
            return Finding("ipv6", "IPv6 leak test", "fail",
                           f"Your IPv6 address {r6.ip} is visible: the VPN does not carry IPv6, so IPv6 traffic bypasses it",
                           weight=40, leak=True, evidence=ev,
                           hint="ipshift config set privacy.disable_ipv6_on_physical true")
        if tunnel_v6 and not r6.ok:
            return Finding("ipv6", "IPv6 leak test", "warn",
                           "The tunnel has an IPv6 address but no IPv6 traffic passes through it", weight=8, evidence=ev)
        if tunnel_v6 and conn.exit_ipv6 and r6.ip != conn.exit_ipv6:
            return Finding("ipv6", "IPv6 leak test", "warn",
                           f"IPv6 is seen as {r6.ip}, not as the tunnel's {conn.exit_ipv6}", weight=8, evidence=ev)
        if all(st == "unavailable" for _, st in esc) and phys:
            return Finding("ipv6", "IPv6 leak test", "warn",
                           "No IPv6 address is visible, but the escape probe on the real network card needs root", weight=4,
                           evidence=ev, hint="run: sudo ipshift privacy-check")
        msg = f"IPv6 works through the tunnel ({r6.ip})" if tunnel_v6 else "No IPv6 connectivity outside the tunnel"
        return Finding("ipv6", "IPv6 leak test", "pass", msg, evidence=ev)

    def escape(self) -> Finding:
        if self._idle_open():
            return self._idle_finding("escape", "Escape test (IPv4)")
        phys = self._phys()
        if not phys:
            return Finding("escape", "Escape test (IPv4)", "skip", "No physical network interface found")
        jobs = [(i, t) for i in phys for t in V4_TARGETS]
        res = self._parallel(lambda j: (j, self.probes.tcp(j[1], 443, device=j[0])), jobs)
        leaked = [(i, t) for (i, t), st in res if st == "connected"]
        if leaked:
            return Finding("escape", "Escape test (IPv4)", "fail",
                           f"Traffic can leave through {leaked[0][0]} outside the tunnel (connected to {leaked[0][1]})",
                           weight=45, leak=True, evidence={"leaks": [list(x) for x in leaked]},
                           hint="arm the kill switch: ipshift killswitch on")
        if all(st == "unavailable" for _, st in res):
            return Finding("escape", "Escape test (IPv4)", "skip",
                           "Needs root: the probe pins a connection to your real network card to prove it is blocked",
                           hint="run: sudo ipshift privacy-check")
        return Finding("escape", "Escape test (IPv4)", "pass",
                       f"Connections pinned to {', '.join(phys)} (outside the tunnel) cannot reach the internet",
                       evidence={"probes": len(res)})

    def lan(self) -> Finding:
        k = self.cfg.killswitch
        risks = []
        if k.allow_lan:
            risks.append("LAN access is allowed outside the tunnel")
        if k.allow_ifaces:
            risks.append("extra interfaces bypass the tunnel: " + ", ".join(k.allow_ifaces))
        if k.allow_forward:
            risks.append("forwarding is allowed, so devices behind this host can bypass the tunnel")
        if risks:
            return Finding("lan", "Local network exposure", "warn", "; ".join(risks), weight=8,
                           hint="these are deliberate settings; turn them off for maximum privacy")
        return Finding("lan", "Local network exposure", "pass",
                       "The local network, extra interfaces and forwarding are all closed outside the tunnel")

    def mac(self) -> Finding:
        m = self.h.mac
        if m.nm_enabled() or self.h.store.get("mac"):
            return Finding("mac", "MAC address privacy", "pass", "MAC address randomisation is active")
        for i in self.net.interfaces():
            if i.physical and i.mac:
                try:
                    if int(i.mac.split(":")[0], 16) & 2:
                        return Finding("mac", "MAC address privacy", "pass",
                                       f"{i.name} already uses a locally administered (randomised) MAC address")
                except ValueError:
                    pass
        return Finding("mac", "MAC address privacy", "warn",
                       "Your network card's real MAC address is visible to the Wi-Fi access point or hotspot; a VPN cannot hide it",
                       weight=6, hint="ipshift harden mac enable")
