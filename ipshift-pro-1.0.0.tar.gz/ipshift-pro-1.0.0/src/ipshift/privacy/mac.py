"""MAC address privacy for Wi-Fi and Ethernet.

A VPN hides your IP from the sites you visit, not your network card's MAC
address from the access point, hotspot or switch you are plugged into.  Two
tools:

* ``enable_nm``  - the durable option: tell NetworkManager to use a random MAC
  for every connection (and while scanning).  Takes effect at the next connect.
* ``randomize``  - change one interface right now with ``ip link`` (the link
  drops for a moment).  The original address is saved and ``restore`` puts it
  back.
"""
from __future__ import annotations

import logging
import re
import secrets
from pathlib import Path

from ..errors import DependencyError, HardeningError
from ..sysutil import atomic_write

log = logging.getLogger(__name__)

NM_DROPIN = Path("/etc/NetworkManager/conf.d/90-ipshift-mac.conf")
NM_HEADER = "# Managed by IPShift Pro ('ipshift harden mac enable|disable')\n"
NM_TEXT = NM_HEADER + """[device-mac-randomization]
wifi.scan-rand-mac-address=yes

[connection-mac-randomization]
ethernet.cloned-mac-address=random
wifi.cloned-mac-address=random
"""
_MAC = re.compile(r"^(?:[0-9a-f]{2}:){5}[0-9a-f]{2}$")
_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,14}$")


def random_mac() -> str:
    b = bytearray(secrets.token_bytes(6))
    b[0] = (b[0] & 0xFE) | 0x02              # unicast, locally administered
    return ":".join(f"{x:02x}" for x in b)


def valid_mac(value: str) -> bool:
    return bool(_MAC.match(value)) and not int(value[:2], 16) & 1     # not multicast


class MacPolicy:
    def __init__(self, store, runner, net, *, ip_bin: str = "ip", nmcli: str = "nmcli",
                 nm_dropin: str | Path = NM_DROPIN):
        self.store = store
        self.runner = runner
        self.net = net
        self.ip_bin = ip_bin
        self.nmcli = nmcli
        self.dropin = Path(nm_dropin)

    # ---- NetworkManager policy --------------------------------------------
    def nm_enabled(self) -> bool:
        try:
            return self.dropin.read_text().startswith(NM_HEADER)
        except OSError:
            return False

    def _reload_nm(self) -> None:
        self.runner.run([self.nmcli, "general", "reload", "conf"])

    def enable_nm(self) -> None:
        if not self.dropin.parent.is_dir():
            raise DependencyError("NetworkManager does not seem to be installed here",
                                  hint="use 'ipshift harden mac randomize <iface>' instead")
        atomic_write(self.dropin, NM_TEXT, 0o644)
        self._reload_nm()
        log.info("NetworkManager will randomise MAC addresses at the next connection")

    def disable_nm(self) -> bool:
        if not self.nm_enabled():
            return False
        self.dropin.unlink()
        self._reload_nm()
        return True

    # ---- immediate change --------------------------------------------------
    def _link(self, *args: str, check: bool = True):
        res = self.runner.run([self.ip_bin, "link", *args], timeout=10)
        if check and not res.ok:
            raise HardeningError(f"'ip link {' '.join(args[:4])}' failed: {(res.stderr or res.stdout).strip()[:160]}")
        return res

    def randomize(self, iface: str, mac: str | None = None) -> str:
        if not _NAME.match(iface):
            raise HardeningError(f"bad interface name {iface!r}")
        info = next((i for i in self.net.interfaces() if i.name == iface), None)
        if info is None:
            raise HardeningError(f"no such interface: {iface}")
        if not info.physical:
            raise HardeningError(f"{iface} is not a physical interface")
        new = (mac or random_mac()).lower()
        if not valid_mac(new):
            raise HardeningError(f"{new!r} is not a valid unicast MAC address")
        saved = dict(self.store.get("mac") or {})
        if info.mac and iface not in saved:
            saved[iface] = info.mac.lower()
            self.store.put("mac", saved)                     # record the original before touching anything
        self._link("set", "dev", iface, "down")
        try:
            self._link("set", "dev", iface, "address", new)
        finally:
            self._link("set", "dev", iface, "up", check=False)
        log.info("MAC address of %s changed", iface)
        return new

    def restore(self) -> list[str]:
        saved = dict(self.store.get("mac") or {})
        done: list[str] = []
        have = {i.name for i in self.net.interfaces()}
        for iface, mac in saved.items():
            if iface not in have or not _NAME.match(iface) or not _MAC.match(mac):
                continue
            self._link("set", "dev", iface, "down", check=False)
            res = self._link("set", "dev", iface, "address", mac, check=False)
            self._link("set", "dev", iface, "up", check=False)
            if res.ok:
                done.append(iface)
        self.store.drop("mac")
        return done
