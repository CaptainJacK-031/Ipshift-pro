"""IPv6 guard: switch IPv6 off on the *physical* interfaces while the tunnel is up.

The firewall already refuses any IPv6 packet that is not going through the
tunnel.  Turning IPv6 off on the real network cards on top of that removes the
leftovers the firewall cannot hide: router advertisements, neighbour discovery
chatter, and addresses derived from the card's MAC.  The tunnel interface is
never touched, so a VPN that does carry IPv6 keeps working.

Previous values are stored (and put back by ``restore``); an interface that was
already disabled by the user is left alone and not recorded.
"""
from __future__ import annotations

import logging
import re
from pathlib import Path

log = logging.getLogger(__name__)

_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,14}$")


class Ipv6Guard:
    def __init__(self, store, net, *, sysctl_root: str | Path = "/proc/sys"):
        self.store = store
        self.net = net
        self.root = Path(sysctl_root)

    def _knob(self, iface: str) -> Path | None:
        if not _NAME.match(iface) or iface in (".", ".."):
            return None
        p = self.root / "net" / "ipv6" / "conf" / iface / "disable_ipv6"
        return p if p.exists() else None

    @staticmethod
    def _get(p: Path) -> str | None:
        try:
            return p.read_text().strip()
        except OSError:
            return None

    def apply(self) -> list[str]:
        """Disable IPv6 on every physical interface; returns the ones changed now."""
        recorded = dict(self.store.get("ipv6") or {})
        changed: list[str] = []
        for iface in self.net.physical_ifaces():
            knob = self._knob(iface)
            if knob is None:
                continue
            cur = self._get(knob)
            if cur == "1":
                continue                                   # already off: not ours to restore
            if cur is None:
                continue
            recorded.setdefault(iface, cur)
            self.store.put("ipv6", recorded)               # record before changing
            try:
                knob.write_text("1")
            except OSError as e:
                log.warning("cannot disable IPv6 on %s: %s", iface, e)
                continue
            changed.append(iface)
        if changed:
            log.info("IPv6 disabled on %s", ", ".join(changed))
        return changed

    def disabled(self) -> list[str]:
        return sorted((self.store.get("ipv6") or {}).keys())

    def intact(self) -> bool:
        """Every interface we disabled is still disabled (nothing re-enabled IPv6)."""
        for iface in self.disabled():
            knob = self._knob(iface)
            if knob is not None and self._get(knob) != "1":
                return False
        return True

    def restore(self) -> list[str]:
        recorded = dict(self.store.get("ipv6") or {})
        done: list[str] = []
        for iface, prev in recorded.items():
            knob = self._knob(iface)
            if knob is None:
                continue                                   # the interface is gone
            try:
                knob.write_text(prev if prev in ("0", "1") else "0")
                done.append(iface)
            except OSError as e:
                log.warning("cannot restore IPv6 on %s: %s", iface, e)
        self.store.drop("ipv6")
        if done:
            log.info("IPv6 restored on %s", ", ".join(done))
        return done
