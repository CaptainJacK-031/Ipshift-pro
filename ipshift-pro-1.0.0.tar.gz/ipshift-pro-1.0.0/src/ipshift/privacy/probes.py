"""Active network probes for the leak checks.

Each probe returns a small status string instead of raising, so the checker can
be tested with fakes and with the simulator.  Statuses:

  ok / answered   something came back (for a probe pinned to the *physical*
                  interface that is the bad outcome: it means traffic can
                  leave outside the tunnel)
  blocked         the local firewall refused to send it (EPERM)
  timeout         nothing came back
  unreachable     no route
  unavailable     the probe cannot run here (usually: pinning to an interface
                  needs root)
  error           anything else
"""
from __future__ import annotations

import errno
import socket
import struct
from dataclasses import dataclass, field

from ..net.dnswire import build_query, parse_response
from ..net.http import SO_BINDTODEVICE

IDENTITY_QUERIES = (("whoami.akamai.net", "A"), ("o-o.myaddr.l.google.com", "TXT"))
_BLOCKED = {errno.EPERM, errno.EACCES}
_UNREACH = {errno.ENETUNREACH, errno.EHOSTUNREACH, errno.EADDRNOTAVAIL, errno.ENODEV}


@dataclass
class DnsAnswer:
    status: str
    values: list[str] = field(default_factory=list)
    detail: str = ""

    @property
    def answered(self) -> bool:
        return self.status == "ok"


def _classify(e: OSError) -> str:
    if isinstance(e, socket.timeout):
        return "timeout"
    if e.errno in _BLOCKED:
        return "blocked"
    if e.errno in _UNREACH:
        return "unreachable"
    return "error"


def _open(family: int, kind: int, device: str | None, timeout: float):
    s = socket.socket(family, kind)
    s.settimeout(timeout)
    if device:
        try:
            s.setsockopt(socket.SOL_SOCKET, SO_BINDTODEVICE, device.encode() + b"\0")
        except OSError:
            s.close()
            raise
    return s


class NetProbes:
    def __init__(self, timeout: float = 3.0):
        self.timeout = timeout

    def dns(self, server: str, name: str, qtype: str = "A", *, device: str | None = None,
            port: int = 53) -> DnsAnswer:
        fam = socket.AF_INET6 if ":" in server else socket.AF_INET
        query = build_query(name, qtype)
        txid = struct.unpack("!H", query[:2])[0]
        try:
            s = _open(fam, socket.SOCK_DGRAM, device, self.timeout)
        except OSError as e:
            return DnsAnswer("unavailable" if device else "error", detail=str(e))
        try:
            s.connect((server, port))
            s.send(query)                           # a kill switch refuses here with EPERM
            while True:
                msg = parse_response(s.recv(4096))
                if msg.id == txid:
                    break
        except OSError as e:                         # DnsError is an OSError too (errno None -> "error")
            return DnsAnswer(_classify(e), detail=str(e))
        finally:
            s.close()
        vals = msg.values(qtype)
        if msg.rcode == 0 and vals:
            return DnsAnswer("ok", vals)
        return DnsAnswer("error", detail=f"rcode {msg.rcode}, no {qtype} answer")

    def resolver_identity(self, server: str, *, device: str | None = None) -> DnsAnswer:
        """Which recursive resolver does ``server`` use to reach the internet?
        (Authoritative servers that echo the asker's address tell us.)"""
        last = DnsAnswer("error", detail="no identity service answered")
        for name, qtype in IDENTITY_QUERIES:
            ans = self.dns(server, name, qtype, device=device)
            if ans.answered:
                return ans
            last = ans
            if ans.status in ("blocked", "unavailable", "unreachable"):
                break
        return last

    def tcp(self, ip: str, port: int, *, device: str | None = None) -> str:
        fam = socket.AF_INET6 if ":" in ip else socket.AF_INET
        try:
            s = _open(fam, socket.SOCK_STREAM, device, self.timeout)
        except OSError:
            return "unavailable" if device else "error"
        try:
            s.connect((ip, port))
            return "connected"
        except ConnectionRefusedError:
            return "connected"                      # something answered: the path exists
        except OSError as e:
            return _classify(e)
        finally:
            s.close()
