"""DNS lock: while the VPN is up the system resolver talks to the tunnel's DNS
servers - and only to those.

The kill switch is what actually stops a DNS leak (nothing but tunnel traffic
may leave the machine).  The lock makes sure resolution *works* through the
tunnel instead of timing out against the router's resolver, and the monitor
re-applies it when NetworkManager or dhclient rewrites ``resolv.conf``.

The original file is saved to the state store first, so ``ipshift restore`` can
put it back even if the daemon died.
"""
from __future__ import annotations

import ipaddress
import logging
import os
import time
from pathlib import Path

from ..errors import ConfigError, PrivilegeError
from ..sysutil import atomic_write, parse_ip, which

log = logging.getLogger(__name__)

HEADER = "# Managed by IPShift Pro - restored by 'ipshift stop' or 'ipshift restore'\n"
OPTIONS = "options timeout:3 attempts:2\n"
MAX_SERVERS = 3                      # glibc reads at most three nameserver lines


def usable_server(value: str) -> str | None:
    """Normalised address of a DNS server worth using through a tunnel, else None."""
    ip = parse_ip(value)
    if ip is None:
        return None
    if ip.is_loopback or ip.is_unspecified or ip.is_multicast or ip.is_link_local or ip.is_reserved:
        return None
    return str(ip)


class DnsLock:
    def __init__(self, dns_cfg, runner, store, *, iface: str = "ipshift0",
                 resolv: str | Path = "/etc/resolv.conf", resolvectl: str = "resolvectl"):
        self.cfg = dns_cfg
        self.runner = runner
        self.store = store
        self.iface = iface
        self.resolv = Path(resolv)
        self.resolvectl = resolvectl
        self.servers: list[str] = list((store.get("dns") or {}).get("servers", []))

    # ---- policy ------------------------------------------------------------
    def choose(self, vpn_dns: list[str], *, route_dev=None, allow_v6: bool = True) -> list[str]:
        """Pick the resolvers to use.

        Order of preference: servers forced in the config, then the ones the VPN
        pushed, then the fallback list (public resolvers, reached *through* the
        tunnel).  Servers that would be reached outside the tunnel are skipped.
        """
        cfg = self.cfg
        pools = [list(cfg.servers)] if cfg.servers else \
            [list(vpn_dns) if cfg.use_vpn_pushed else [], list(cfg.fallback)]
        for pool in pools:
            out: list[str] = []
            for raw in pool:
                s = usable_server(raw)
                if s is None or s in out:
                    continue
                if not allow_v6 and ipaddress.ip_address(s).version == 6:
                    continue
                if route_dev is not None:
                    dev = route_dev(s)
                    if dev and dev != self.iface:
                        log.warning("DNS server %s would be reached outside the tunnel (via %s); skipped", s, dev)
                        continue
                out.append(s)
            if out:
                return out[:MAX_SERVERS]
        raise ConfigError("no usable DNS server for the tunnel",
                          hint="set dns.servers, e.g. ipshift config set dns.servers 9.9.9.9")

    # ---- the file ----------------------------------------------------------
    def _inspect(self) -> dict:
        p = self.resolv
        if p.is_symlink():
            return {"kind": "symlink", "target": os.readlink(p)}
        try:
            text = p.read_text(errors="replace")
        except FileNotFoundError:
            return {"kind": "missing"}
        except OSError as e:
            raise PrivilegeError(f"cannot read {p}: {e}") from None
        return {"kind": "file", "content": text, "mode": p.stat().st_mode & 0o777}

    def current(self) -> list[str]:
        try:
            lines = self.resolv.read_text(errors="replace").splitlines()
        except OSError:
            return []
        out = []
        for line in lines:
            parts = line.split()
            if len(parts) >= 2 and parts[0] == "nameserver":
                s = usable_server(parts[1].split("%")[0])
                if s:
                    out.append(s)
        return out

    def _ours(self, info: dict) -> bool:
        return info["kind"] == "file" and info["content"].startswith(HEADER)

    def _use_resolved(self, rec: dict) -> bool:
        return rec.get("kind") == "symlink" and "systemd/resolve" in rec.get("target", "") \
            and bool(which(self.resolvectl))

    def apply(self, servers: list[str]) -> None:
        if not servers:
            raise ConfigError("no DNS servers to apply")
        if list(servers) == self.servers and self.intact():
            return                                       # a fast rotation must not rewrite the file every second
        info = self._inspect()
        rec = self.store.get("dns")
        if rec is None or not self._ours(info):
            rec = dict(info, ts=time.time())             # a new original (never overwrite it with our own file)
        rec["servers"] = list(servers)
        text = HEADER + "".join(f"nameserver {s}\n" for s in servers) + OPTIONS
        self.store.put("dns", rec)                       # record first: a crash mid-way must stay recoverable
        try:
            atomic_write(self.resolv, text, 0o644)
        except PermissionError as e:
            self.store.drop("dns")
            raise PrivilegeError(f"cannot write {self.resolv}: {e}",
                                 hint="is the file immutable (chattr -i) or are you not root?") from None
        self.servers = list(servers)
        if self._use_resolved(rec):
            self.runner.run([self.resolvectl, "dns", self.iface, *servers])
            self.runner.run([self.resolvectl, "domain", self.iface, "~."])
            self.runner.run([self.resolvectl, "default-route", self.iface, "yes"])
            self.runner.run([self.resolvectl, "flush-caches"])
        log.info("DNS locked to %d server(s) through the tunnel", len(servers))

    def active(self) -> bool:
        return self.store.get("dns") is not None

    def intact(self) -> bool:
        """The resolver file still says what we wrote (nothing rewrote it)."""
        if not self.servers:
            return False
        try:
            if not self.resolv.read_text(errors="replace").startswith(HEADER):
                return False
        except OSError:
            return False
        return self.current() == self.servers

    def restore(self) -> bool:
        rec = self.store.get("dns")
        if rec is None:
            return False
        kind, p = rec.get("kind"), self.resolv
        try:
            if kind == "symlink":
                tmp = p.with_name(f".{p.name}.ipshift")
                try:
                    tmp.unlink()
                except FileNotFoundError:
                    pass
                os.symlink(rec["target"], tmp)
                os.replace(tmp, p)
            elif kind == "file":
                atomic_write(p, rec.get("content", ""), int(rec.get("mode", 0o644)))
            elif kind == "missing":
                if self._ours(self._inspect()):
                    p.unlink()
        except OSError as e:
            log.error("could not restore %s: %s", p, e)
            return False
        if self._use_resolved(rec):
            self.runner.run([self.resolvectl, "revert", self.iface])
        self.store.drop("dns")
        self.servers = []
        log.info("original DNS configuration restored")
        return True
