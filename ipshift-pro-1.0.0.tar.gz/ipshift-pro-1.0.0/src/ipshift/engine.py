"""The engine: builds the parts (real or simulated), keeps them consistent and is the
single API the daemon exposes to the CLI and the GUI.

Everything a person can ask for - connect, rotate, stop, check privacy, manage
profiles, change settings - is a method here.  The IPC layer is only a dispatcher,
and tests can drive the whole stack without a socket.

Two ideas shape the control methods:

* ``_want_vpn`` / ``_protect`` record what the *person* asked for.  The monitor
  only repairs things the person wants (reconnect a dropped tunnel, put removed
  firewall rules back); after an explicit stop it leaves everything alone.
* Failing closed: after a failed or interrupted connection the firewall stays up
  and traffic stays blocked.  Only an explicit ``stop`` (or ``restore``) gives the
  normal network back.
"""
from __future__ import annotations

import contextlib
import dataclasses
import io
import logging
import os
import random
import threading
import time

from . import __version__
from .config import MIN_INTERVAL, Config
from .errors import BusyError, ConfigError, IPShiftError, NotFound, PrivilegeError, ProfileError, VpnError
from .events import EventBus
from .firewall.killswitch import KillSwitch
from .history import History
from .monitor import Monitor, describe_network
from .net.echo import EchoResolver
from .net.local import NetInfo
from .net.resolve import BootstrapResolver
from .paths import Paths
from .privacy.hardening import Hardening, cleanup_strays, restore_all
from .privacy.leaks import FULL, PrivacyChecker
from .privacy.probes import NetProbes
from .scheduler import NothingToRotate, RotationScheduler, check_interval
from .sysutil import Runner, ensure_private_dir, is_root
from .vpn import importer
from .vpn.manager import VpnManager
from .vpn.openvpn import OpenVPNBackend
from .vpn.profile import ProfileStore
from .vpn.sim import (SimBackend, SimEcho, SimNetInfo, SimProbes, SimResolver, SimRunner, SimWorld,
                      make_demo_profiles)
from .vpn.wireguard import WireGuardBackend

log = logging.getLogger(__name__)

# What a client of the daemon (CLI, GUI, anything in the ipshift group) may change over the
# socket.  Paths to programs, the tunnel interface name and the daemon's own settings are
# deliberately absent: they decide what root executes or touches, so they are edited in the
# config file by an administrator.
IPC_SETTABLE_SECTIONS = frozenset({"rotation", "dns", "privacy"})
IPC_SETTABLE_KEYS = frozenset({
    "vpn.connect_timeout", "vpn.verify_timeout", "vpn.auto_reconnect", "vpn.reconnect_on_network_change",
    "vpn.fast_switch", "vpn.pin_endpoints", "vpn.allow_plain_bootstrap_dns", "vpn.mtu", "vpn.wg_keepalive",
    "killswitch.enabled", "killswitch.arm_on_start", "killswitch.release_on_exit", "killswitch.allow_lan",
    "killswitch.allow_ifaces", "killswitch.allow_forward", "killswitch.allow_dhcp", "killswitch.log_drops",
})
RESTART_KEYS = frozenset({"vpn.interface", "privacy.history"})
MAX_PROFILE_FILES = 20


def ipc_settable(key: str) -> bool:
    return key in IPC_SETTABLE_KEYS or key.split(".")[0] in IPC_SETTABLE_SECTIONS


class Engine:
    def __init__(self, cfg: Config, paths: Paths, *, simulate: bool = False, sim_speed: float = 1.0,
                 demo: bool = True, rng: random.Random | None = None):
        self.cfg = cfg
        self.simulate = simulate
        self.paths = dataclasses.replace(paths, state_dir=paths.state_dir / "sim") if simulate else paths
        self.started = time.time()
        self.world: SimWorld | None = None
        self.bus = EventBus(backlog=300)
        self._ctl = threading.RLock()
        self._ctl_name: str | None = None
        self._want_vpn = False
        self._protect = False
        self._closed = False
        self._ks_cache: tuple[float, dict] | None = None
        self._last_report: dict | None = None
        self._sim_system: dict = {}
        ensure_private_dir(self.paths.state_dir)
        if simulate:
            self._build_sim(sim_speed, demo)
        else:
            self._build_real()
        self.history = History(None if simulate or not cfg.privacy.history else self.paths.history_db,
                               retention_days=cfg.privacy.history_retention_days,
                               mask_ips=cfg.privacy.mask_ips_in_history, max_rows=cfg.privacy.history_max_rows)
        self.mgr = VpnManager(cfg, self.runner, self.net, self.store, self.ks, self.hardening, self.resolver,
                              self.echo, self.history, self.bus, self.backends, rng=rng)
        if simulate:
            self.mgr.require_global_exit = False           # documentation addresses are not "global"
        self.scheduler = RotationScheduler(cfg, self.mgr, self.store, self.bus, rng=rng)
        self.checker = PrivacyChecker(cfg, self.mgr, self.hardening, self.ks, self.net, self.echo, self.probes)
        self.monitor = Monitor(cfg, self.mgr, self.ks, self.hardening, self.net, self.bus, self)
        self.bus.subscribe(self._on_event)

    # ---- assembling the parts ------------------------------------------------
    def _build_real(self) -> None:
        cfg, paths = self.cfg, self.paths
        self.runner = Runner()
        self.net = NetInfo(self.runner, cfg.vpn.ip_bin)
        self.store = ProfileStore(paths.profiles_dir)
        self.ks = KillSwitch(cfg.killswitch, cfg.vpn, self.runner, self.net)
        self.hardening = Hardening(cfg, self.runner, self.net, paths)
        self.echo = EchoResolver(cfg.privacy)
        self.resolver = BootstrapResolver(cfg.vpn)
        self.backends = {"openvpn": OpenVPNBackend(cfg.vpn, self.runner, paths, self.net),
                         "wireguard": WireGuardBackend(cfg.vpn, self.runner, paths, self.net)}
        self.probes = NetProbes(timeout=3.0)

    def _build_sim(self, speed: float, demo: bool) -> None:
        """A complete fake world: nothing here touches the real network, firewall, DNS or MAC."""
        cfg, paths = self.cfg, self.paths
        sysdir = ensure_private_dir(paths.state_dir / "simsys")
        resolv = sysdir / "resolv.conf"
        if not resolv.exists():
            resolv.write_text("nameserver 192.168.1.1\n")
        knob = sysdir / "proc_sys" / "net" / "ipv6" / "conf" / "wlan0" / "disable_ipv6"
        if not knob.exists():
            knob.parent.mkdir(parents=True, exist_ok=True)
            knob.write_text("0\n")
        self._sim_system = {"resolv": resolv, "sysctl_root": sysdir / "proc_sys", "nm_dropin": sysdir / "nm.conf",
                            "proc": sysdir / "proc"}
        self.world = SimWorld(speed=speed)
        self.runner = SimRunner()
        self.net = SimNetInfo(self.world, cfg.vpn.interface)
        self.store = ProfileStore(paths.profiles_dir)
        if demo:
            make_demo_profiles(self.store, self.world)
        self.ks = KillSwitch(cfg.killswitch, cfg.vpn, self.runner, self.net, dry_run=True)
        self.world.blocked = lambda: self.ks.armed
        self.hardening = Hardening(cfg, self.runner, self.net, paths, resolv=resolv,
                                   sysctl_root=self._sim_system["sysctl_root"], nm_dropin=self._sim_system["nm_dropin"])
        self.echo = SimEcho(self.world)
        self.resolver = SimResolver(self.world)
        self.backends = {p: SimBackend(self.world, p, cfg.vpn, self.runner, paths, self.net)
                         for p in ("wireguard", "openvpn")}
        self.probes = SimProbes(self.world, cfg.vpn.interface)

    # ---- lifecycle -------------------------------------------------------------
    def start(self) -> None:
        if not self.simulate:
            cleaned = cleanup_strays(self.cfg, self.runner, self.paths)
            if cleaned["openvpn_stopped"]:
                log.warning("stopped an OpenVPN process left over from an earlier run")
        try:
            armed = self.ks.is_armed()
        except IPShiftError:
            armed = False
        if armed:
            # rules from an earlier run (or a crash) are still in the kernel: keep blocking, start clean
            try:
                self.ks.arm()
            except IPShiftError as e:                        # the old rules are still in force either way
                log.warning("could not refresh the existing kill switch rules: %s", e)
            self._protect = True
            self.bus.publish("killswitch_adopted", "warning",
                             message="A kill switch from an earlier run is still active and was kept in place",
                             hint="connect a VPN, or run 'ipshift stop' to release it")
        elif self.cfg.killswitch.enabled and self.cfg.killswitch.arm_on_start:
            self.ks.arm()
            self._protect = True
            self.bus.publish("killswitch_armed", "info", message="Always-on kill switch armed at start")
        self.monitor.start()
        self.bus.publish("daemon_started", version=__version__, simulated=self.simulate,
                         message="IPShift is running" + (" in SIMULATION mode" if self.simulate else ""))

    def shutdown(self) -> None:
        """Stop everything.  The firewall stays up unless ``killswitch.release_on_exit`` is set:
        a daemon that merely dies must not expose the person."""
        if self._closed:
            return
        self._closed = True
        self._want_vpn = False
        self.mgr.cancel()
        self.scheduler.stop(timeout=15)
        self.monitor.stop()
        release = bool(self.cfg.killswitch.release_on_exit)
        try:
            self.mgr.disconnect(release=release)
        except IPShiftError as e:
            log.warning("could not disconnect cleanly: %s", e)
        if not release and self.ks.armed:
            log.warning("the kill switch stays active; 'ipshift restore' gives you the normal network back")
        self.history.close()

    @contextlib.contextmanager
    def _control(self, name: str, *, wait: float = 2.0):
        """Serialise compound control operations; a second caller gets a clear 'busy' error."""
        if not self._ctl.acquire(timeout=wait):
            raise BusyError(f"another operation is in progress ({self._ctl_name})",
                            hint="wait for it to finish, or run 'ipshift stop'")
        prev, self._ctl_name = self._ctl_name, name
        try:
            yield
        finally:
            self._ctl_name = prev
            self._ctl.release()

    # ---- what the person wants (read by the monitor) --------------------------------
    def protect_wanted(self) -> bool:
        return self._protect

    def vpn_wanted(self) -> bool:
        return self._want_vpn

    def rotating(self) -> bool:
        return self.scheduler.running

    def recover_tunnel(self):
        """Bring the tunnel back: the same profile first, then up to two others."""
        last = self.mgr.last_profile_id
        err: Exception | None = None
        if last:
            try:
                return self.mgr.recover(last)
            except BusyError:
                raise
            except IPShiftError as e:
                err = e
        tried = {last} if last else set()
        for _ in range(2):
            nxt = self.scheduler.selector.pick(None, tried)
            if nxt is None or nxt.id in tried:
                break
            tried.add(nxt.id)
            try:
                return self.mgr.activate(nxt.id, reason="recover")
            except BusyError:
                raise
            except IPShiftError as e:
                err = e
        raise err or VpnError("no usable VPN profile to reconnect to",
                              hint="import a profile with 'ipshift vpn import'")

    def _on_event(self, ev) -> None:
        if ev.kind == "network_changed":
            self.mgr.baseline_ip = None                      # the real address belongs to the old network
        if ev.is_alert and not self._closed:
            try:
                self.history.add_event(ev.level, ev.kind, str(ev.data.get("message") or ev.kind))
            except Exception:                                # the history must never break the engine
                log.debug("could not store the event", exc_info=True)

    # ---- status -----------------------------------------------------------------
    def _net_summary(self) -> dict:
        try:
            return self.net.summary()
        except Exception:
            log.debug("network summary failed", exc_info=True)
            return {}

    def _forget_views(self) -> None:
        """After connecting, stopping or locking down, the cached firewall and network views are stale."""
        self._ks_cache = None
        self.monitor.summary = {}

    def _ks_status(self) -> dict:
        now = time.monotonic()
        hit = self._ks_cache
        if hit and now - hit[0] < 1.0:
            return hit[1]
        try:
            st = self.ks.status()
        except IPShiftError as e:
            st = {"armed": False, "error": str(e), "enabled": self.cfg.killswitch.enabled}
        self._ks_cache = (now, st)
        return st

    @staticmethod
    def _protection(vpn: dict, ks: dict) -> dict:
        armed = bool(ks.get("armed"))
        state = vpn["state"]
        if state in ("connecting", "switching"):
            level, msg = "connecting", "Connecting - traffic is blocked until the tunnel is verified" if armed else "Connecting"
        elif vpn["connected"] and armed:
            level, msg = "protected", "Traffic goes through the VPN; the kill switch is armed"
        elif vpn["connected"]:
            level, msg = "no-killswitch", "Connected, but there is no kill switch: traffic could leak if the VPN drops"
        elif armed:
            level, msg = "blocked", "Not connected - the kill switch is blocking all traffic"
        else:
            level, msg = "unprotected", "Not connected - your real IP address is exposed"
        return {"level": level, "message": msg}

    def _public(self, vpn: dict) -> dict:
        conn = self.mgr.conn
        if conn and vpn["connected"]:
            verified = max(conn.since, self.monitor.last_ip_check or 0.0)
            return {"v4": conn.exit_ip, "v6": conn.exit_ipv6, "source": "tunnel", "verified_at": verified}
        return {"v4": None, "v6": None, "source": None, "verified_at": None}

    def status(self, *, fresh: bool = False) -> dict:
        vpn = self.mgr.status()
        net = self._net_summary() if (fresh or not self.monitor.summary) else self.monitor.summary
        ks = self._ks_status()
        alerts = [e.to_dict() for e in self.bus.recent(10, "warning")]
        return {
            "daemon": {"version": __version__, "pid": os.getpid(), "uptime": int(time.time() - self.started),
                       "simulated": self.simulate, "root": is_root()},
            "protection": self._protection(vpn, ks),
            "vpn": vpn,
            "rotation": self.scheduler.status(),
            "killswitch": ks,
            "network": {"default_iface": net.get("default_iface"), "gateway": net.get("gateway"),
                        "kind": net.get("kind"), "hotspot": net.get("hotspot"),
                        "description": describe_network(net) if net else "unknown",
                        "private_ips": net.get("private_ips", [])},
            "public": self._public(vpn),
            "hardening": self.hardening.status(),
            "alerts": alerts,
            "privacy": self._last_report and {k: self._last_report[k] for k in
                                              ("score", "grade", "verdict", "headline", "ts")},
            "wanted": {"vpn": self._want_vpn, "protect": self._protect},
            "profiles": {"total": len(self.store.list()), "usable": len(self.store.list(usable=True))},
        }

    def ip_info(self, *, refresh: bool = False, direct: bool = False) -> dict:
        """Private addresses (always) and the public address as seen from inside the tunnel.

        Without a tunnel the real public address is only looked up when asked for explicitly
        (``direct``): the tool does not contact echo services on its own while unprotected."""
        net = self._net_summary()
        vpn = self.mgr.status()
        ks = self._ks_status()
        out: dict = {"private": net.get("private_ips", []), "network": describe_network(net) if net else "unknown",
                     "state": vpn["state"], "protection": self._protection(vpn, ks)["level"],
                     "public": {"v4": None, "v6": None, "source": None, "verified_at": None}, "note": None}
        conn = self.mgr.conn
        if conn and vpn["connected"]:
            if refresh:
                r4 = self.mgr.probe_exit_ip(4)
                if r4.ok:
                    if r4.ip != conn.exit_ip:
                        self.bus.publish("ip_changed", "warning", old=conn.exit_ip, new=r4.ip,
                                         message=f"The public IP changed without a rotation: {conn.exit_ip} -> {r4.ip}")
                        conn.exit_ip = r4.ip
                    self.monitor.last_ip_check = time.time()
                else:
                    out["note"] = f"The public IP could not be confirmed right now ({r4.error})"
                if conn.tunnel.ipv6:
                    r6 = self.mgr.probe_exit_ip(6)
                    conn.exit_ipv6 = r6.ip if r6.ok else None
            out["public"] = self._public(vpn)
        elif ks.get("armed"):
            out["note"] = "The kill switch is blocking all traffic, so there is no public address to show"
        elif direct:
            r4 = self.echo.lookup(4)
            r6 = self.echo.lookup(6) if self.cfg.privacy.check_ipv6 else None
            out["public"] = {"v4": r4.ip, "v6": r6.ip if r6 and r6.ok else None, "source": "direct",
                             "verified_at": time.time()}
            out["note"] = "This is your real, unprotected address"
        else:
            out["note"] = "Not connected: the public address is not looked up while you are unprotected"
        return out

    # ---- connecting -----------------------------------------------------------------
    def _measure_baseline(self) -> None:
        """Opt-in (privacy.baseline): learn the real address once, before the firewall goes up, so a
        tunnel that does not actually carry traffic can be recognised.  Kept in memory only."""
        if not self.cfg.privacy.baseline or self.mgr.baseline_ip or self.mgr.conn or self.ks.armed:
            return
        res = self.echo.lookup(4)
        if res.ok:
            self.mgr.baseline_ip = res.ip

    def _default_profile(self):
        last = self.mgr.last_profile_id
        if last:
            with contextlib.suppress(NotFound, ProfileError):
                p = self.store.get(last)
                if p.usable:
                    return p
        nxt = self.scheduler.selector.pick(None)
        if nxt is None:
            raise ProfileError("there is no usable VPN profile", hint="import one with: ipshift vpn import FILE")
        return nxt

    def connect(self, profile: str | None = None, *, keep_rotation: bool = False) -> dict:
        """Connect (or switch) to one profile.  An explicit choice pauses the rotation, which
        would otherwise move away from it at the next tick."""
        with self._control("connect"):
            stopped = False
            if self.scheduler.running and not keep_rotation:
                self.scheduler.stop()
                stopped = True
            prof = self.store.get(profile) if profile else self._default_profile()
            self._measure_baseline()
            if self.cfg.killswitch.enabled:
                self._protect = True                         # the attempt arms the firewall, even if it then fails
            res = self.mgr.activate(prof.id, reason="manual")
            self._want_vpn = True
            self._forget_views()
        out = res.to_dict()
        out["rotation_stopped"] = stopped
        return out

    def cancel(self) -> dict:
        self.mgr.cancel()
        return {"cancelled": True}

    def stop(self, *, keep_blocking: bool = False, keep_vpn: bool = False) -> dict:
        """Stop rotating and disconnect.  By default the normal network comes back (firewall removed,
        DNS and IPv6 restored); ``keep_blocking`` stays fail-closed, ``keep_vpn`` only stops the rotation."""
        if keep_vpn:
            self.scheduler.stop(cancel=False)                # a switch under way finishes: the VPN is meant to stay up
            return {"stopped": "rotation", "connected": bool(self.mgr.conn)}
        self._want_vpn = False                               # the monitor must not reconnect from now on
        self.mgr.cancel()
        with self._control("stop", wait=45.0):
            self.scheduler.stop()
            self.mgr.disconnect(release=not keep_blocking)
            if keep_blocking:
                self._protect = True
                if not self.ks.is_armed():
                    self.ks.arm()
            else:
                self._protect = False
                if self.ks.armed or self.ks.is_armed():
                    self.ks.disarm()
            self._forget_views()
        self.bus.publish("stopped", released=not keep_blocking,
                         message="Stopped. " + ("Traffic stays blocked (kill switch)." if keep_blocking
                                                else "Normal networking restored."))
        return {"stopped": "all", "released": not keep_blocking}

    # ---- rotation -----------------------------------------------------------------
    def rotate_start(self, interval: float | None = None, *, immediate: bool = True) -> dict:
        if interval is not None:
            interval = check_interval(interval, MIN_INTERVAL)       # refuse before anything changes
        with self._control("rotate"):
            usable = self.scheduler.selector.candidates()
            if not usable:
                raise ProfileError("there is no usable VPN profile to rotate between",
                                   hint="import profiles with 'ipshift vpn import', or relax rotation.tiers / rotation.profiles")
            self._measure_baseline()
            self._want_vpn = True
            if self.cfg.killswitch.enabled:
                self._protect = True
            self.scheduler.start(interval, immediate=immediate)
        out = self.scheduler.status()
        out["profiles_in_rotation"] = len(usable)
        if len(usable) == 1:
            out["warning"] = "only one usable profile: the address cannot change until you add another"
        return out

    def rotate_stop(self) -> dict:
        self.scheduler.stop(cancel=False)
        return self.scheduler.status()

    def rotate_now(self) -> dict:
        self._want_vpn = True
        if self.cfg.killswitch.enabled:
            self._protect = True
        self._measure_baseline()
        try:
            res = self.scheduler.rotate_now()
        except NothingToRotate as e:
            raise ProfileError(str(e), hint=e.hint) from None
        return res.to_dict()

    def set_interval(self, value: float) -> dict:
        value = check_interval(value, MIN_INTERVAL)
        if self.scheduler.running:
            self.scheduler.set_interval(value)
        else:
            self.cfg.rotation.interval = value
        return {"interval": self.cfg.rotation.interval, "running": self.scheduler.running,
                "minimum": MIN_INTERVAL}

    # ---- privacy check ------------------------------------------------------------
    def privacy_check(self, mode: str = "full", only: list[str] | None = None) -> dict:
        if mode not in ("full", "quick"):
            raise ConfigError("mode must be 'full' or 'quick'")
        try:
            report = self.checker.run(mode, only, simulated=self.simulate)
        except ValueError as e:
            raise IPShiftError(str(e)) from None
        data = report.to_dict()
        self._last_report = data
        if report.leaks:
            self.bus.publish("leak_detected", "critical", message=report.headline(),
                             leaks=[f.id for f in report.leaks])
        return data

    def last_report(self) -> dict | None:
        return self._last_report

    # ---- profiles ---------------------------------------------------------------------
    def profiles(self) -> dict:
        conn = self.mgr.conn
        return {"profiles": [p.summary() for p in self.store.list()],
                "current": conn.profile.id if conn else None,
                "in_rotation": [p.id for p in self.scheduler.selector.candidates()]}

    def profile_import(self, *, text: str, name: str, files: dict | None = None, protocol: str | None = None,
                       tier: str = "unknown", provider: str = "", country: str = "", username: str | None = None,
                       password: str | None = None, replace: bool = False, notes: str = "") -> dict:
        """The client reads the configuration (and the certificate files next to it) and sends the
        contents: the daemon never opens a path that came from a profile."""
        files = dict(files or {})
        if len(files) > MAX_PROFILE_FILES or any(
                not isinstance(k, str) or not isinstance(v, str) or len(k) > 200 or len(v) > importer.MAX_FILE
                for k, v in files.items()):
            raise ProfileError("too many attached files, or one of them is too large")
        # With the firewall up the lookup would only time out: names are resolved when connecting instead.
        resolver = None if self.ks.armed else self.resolver
        res = importer.import_profile(self.store, text=text, files=files, name=name, protocol=protocol, tier=tier,
                                      provider=provider, country=country, username=username, password=password,
                                      resolver=resolver, replace=replace, notes=notes)
        self.bus.publish("profile_imported", "info", profile=res.profile.id, name=res.profile.name,
                         message=f"Imported {res.profile.name}")
        return {"profile": res.profile.summary(), "warnings": res.warnings, "removed": res.removed}

    def profile_remove(self, ref: str) -> dict:
        prof = self.store.get(ref)
        if self.mgr.conn and self.mgr.conn.profile.id == prof.id:
            raise ProfileError(f"{prof.name} is the active connection", hint="disconnect first: ipshift stop")
        self.store.remove(prof.id)
        self.bus.publish("profile_removed", "info", profile=prof.id, message=f"Removed {prof.name}")
        return {"removed": prof.id, "name": prof.name}

    def profile_update(self, ref: str, **changes) -> dict:
        return {"profile": self.store.update(ref, **changes).summary()}

    def profile_auth(self, ref: str, username: str, password: str) -> dict:
        return {"profile": self.store.set_auth(ref, username, password).summary()}

    def profile_clear_quarantine(self, ref: str | None = None) -> dict:
        return {"cleared": self.store.clear_quarantine(ref)}

    # ---- history & events ------------------------------------------------------------------
    def history_get(self, limit: int = 100) -> dict:
        limit = max(1, min(int(limit), 5000))
        return {"rotations": self.history.recent_rotations(limit), "stats": self.history.stats(),
                "events": self.history.recent_events(min(limit, 200))}

    def history_clear(self) -> dict:
        self.history.clear()
        return {"cleared": True}

    def history_export(self, limit: int = 100_000) -> dict:
        """CSV text of the newest ``limit`` rotations, oldest first (capped so it fits one reply)."""
        import csv
        from .history import ROTATION_COLUMNS
        rows = self.history.recent_rotations(max(1, min(int(limit), 1_000_000)))
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(ROTATION_COLUMNS)
        n, truncated = 0, False
        for r in reversed(rows):
            w.writerow([r[c] for c in ROTATION_COLUMNS])
            n += 1
            if buf.tell() > 4_000_000:
                truncated = True
                break
        return {"csv": buf.getvalue(), "rows": n, "truncated": truncated}

    def events(self, n: int = 50, min_level: str = "info") -> list[dict]:
        return [e.to_dict() for e in self.bus.recent(max(1, min(int(n), 300)), min_level)]

    # ---- configuration -------------------------------------------------------------------------
    def config_get(self, key: str | None = None) -> dict:
        if key:
            return {"key": key, "value": self.cfg.get(key), "settable": ipc_settable(key)}
        return {"config": self.cfg.to_dict(), "file": str(self.paths.config_file),
                "warnings": list(self.cfg.warnings), "simulated": self.simulate}

    def _persist(self) -> bool:
        if self.simulate:
            return False                                     # a demo must never rewrite the real settings
        try:
            self.cfg.save(self.paths.config_file)
            return True
        except OSError as e:
            log.warning("could not save the configuration: %s", e)
            return False

    def _apply_change(self, key: str, value) -> str:
        """Make a changed setting take effect where it can; returns now | next_connect | restart."""
        cfg = self.cfg
        if key in RESTART_KEYS:
            return "restart"
        if key == "rotation.interval":
            if self.scheduler.running:
                self.scheduler.set_interval(value)
            return "now"
        if key == "privacy.mask_ips_in_history":
            self.history.mask_ips = bool(value)
            return "now"
        if key == "privacy.history_retention_days":
            self.history.retention_days = int(value)
            return "now"
        if key == "privacy.history_max_rows":
            self.history.max_rows = int(value)
            return "now"
        if key == "privacy.disable_ipv6_on_physical" and self.mgr.conn:
            self.hardening.ipv6.apply() if value else self.hardening.ipv6.restore()
            return "now"
        if key == "killswitch.enabled":
            if not value and self.ks.armed:
                self.ks.disarm()
                self._protect = False
                self.bus.publish("killswitch_disabled", "warning",
                                 message="The kill switch is turned off: traffic can leave outside the VPN if it drops")
            elif value and self.mgr.conn:
                self.ks.arm()
                self._protect = True
            self._ks_cache = None
            return "now"
        if key == "killswitch.arm_on_start":
            return "restart"
        if key == "killswitch.release_on_exit":
            return "now"
        if key.startswith("killswitch."):
            if self.ks.armed:
                self.ks.refresh()
                self._ks_cache = None
                return "now"
            return "next_connect"
        if key == "daemon.log_level":
            logging.getLogger("ipshift").setLevel(getattr(logging, str(value).upper(), logging.INFO))
            return "now"
        if key.startswith(("rotation.", "privacy.")):
            return "now"
        return "next_connect"                                # dns.* and vpn.*: used by the next connection

    def config_set(self, key: str, value) -> dict:
        old = self.cfg.get(key)                              # unknown keys fail here with the list of valid ones
        if not ipc_settable(key):
            raise PrivilegeError(f"{key} can only be changed by editing {self.paths.config_file} as root",
                                 hint="settings that decide which programs run or which interface is touched are not "
                                      "changeable through the daemon")
        with self._control("config"):
            new = self.cfg.set(key, value)
            applies = self._apply_change(key, new)
            saved = self._persist()
        return {"key": key, "old": old, "value": new, "applies": applies, "saved": saved}

    def config_reload(self) -> dict:
        """Re-read the config file (an invalid file leaves the running settings untouched)."""
        fresh = Config.load(self.paths.config_file)
        pending = sorted(k for k in RESTART_KEYS if fresh.get(k) != self.cfg.get(k))
        with self._control("config"):
            changed = self.cfg.update_from(fresh, skip=tuple(RESTART_KEYS))
            for key in changed:
                self._apply_change(key, self.cfg.get(key))
        if pending:
            self.bus.publish("restart_required", "warning", keys=pending,
                             message="These settings only apply after the daemon restarts: " + ", ".join(pending))
        return {"changed": changed, "restart_required": pending, "warnings": list(self.cfg.warnings)}

    # ---- firewall, hardening, recovery ------------------------------------------------------------------
    def killswitch_status(self) -> dict:
        self._ks_cache = None
        return self._ks_status()

    def killswitch_on(self) -> dict:
        with self._control("killswitch"):
            self.ks.arm()
            self._protect = True
            self._ks_cache = None
        self.bus.publish("killswitch_armed", "info", message="Kill switch armed")
        return self._ks_status()

    def killswitch_off(self) -> dict:
        with self._control("killswitch"):
            self.ks.disarm()
            self._protect = False
            self._ks_cache = None
        self.bus.publish("killswitch_released", "warning",
                         message="Kill switch released: traffic can leave outside the VPN")
        return self._ks_status()

    def lockdown(self) -> dict:
        """Panic button: drop the tunnel and block everything, including the VPN server."""
        self._want_vpn = False
        self.mgr.cancel()
        with self._control("lockdown", wait=45.0):
            self.scheduler.stop()
            self.mgr.disconnect(release=False)
            self.ks.lockdown()
            self._protect = True
            self._forget_views()
        self.bus.publish("lockdown", "critical", message="LOCKDOWN: all network traffic is blocked")
        return self._ks_status()

    def harden_status(self) -> dict:
        return self.hardening.status()

    def mac_policy(self, action: str, iface: str | None = None, mac: str | None = None) -> dict:
        m = self.hardening.mac
        if action == "enable":
            m.enable_nm()
            return {"nm_policy": True, "note": "NetworkManager picks a random MAC address at each new connection"}
        if action == "disable":
            return {"nm_policy": False, "was_enabled": m.disable_nm()}
        if action == "randomize":
            if not iface:
                raise ConfigError("randomize needs an interface name")
            new = m.randomize(iface, mac)
            self.bus.publish("mac_changed", "warning", iface=iface,
                             message=f"MAC address of {iface} changed; the link drops for a moment")
            return {"iface": iface, "mac": new}
        if action == "restore":
            return {"restored": m.restore()}
        raise ConfigError("action must be one of: enable, disable, randomize, restore")

    def restore_network(self, *, include_mac: bool = True) -> dict:
        """Undo everything IPShift did to this machine (works even if something is stuck)."""
        self._want_vpn = False
        self.mgr.cancel()
        with self._control("restore", wait=45.0):
            self.scheduler.stop()
            with contextlib.suppress(IPShiftError):
                self.mgr.disconnect(release=True)
            sim = self._sim_system
            kw = ({"resolv": sim["resolv"], "sysctl_root": sim["sysctl_root"], "nm_dropin": sim["nm_dropin"],
                   "proc": sim["proc"]} if self.simulate else {})
            report = restore_all(self.cfg, self.runner, self.net, self.paths, include_mac=include_mac, **kw)
            self._protect = False
            self._forget_views()
        self.bus.publish("restored", "info", message="Normal networking restored")
        return report

    def doctor(self) -> dict:
        from .doctor import run_doctor
        return run_doctor(self.cfg, self.paths, runner=self.runner, net=self.net, store=self.store,
                          simulate=self.simulate)
