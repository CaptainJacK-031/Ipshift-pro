"""Privacy-aware logging: optionally masks IP addresses before they reach any
log sink, so a log file never becomes a record of where you were."""
from __future__ import annotations

import ipaddress
import logging
import logging.handlers
import os
import re
import sys
from pathlib import Path

_V4 = re.compile(r"(?<![\d.])(?:\d{1,3}\.){3}\d{1,3}(?![\d.]*\d)")
_V6 = re.compile(r"(?<![0-9A-Fa-f:])(?:[0-9A-Fa-f]{0,4}:){2,7}[0-9A-Fa-f]{0,4}(?![0-9A-Fa-f:])")


def mask_ip(ip: str) -> str:
    """``203.0.113.77`` -> ``203.0.113.x``; IPv6 keeps only the first 48 bits."""
    try:
        addr = ipaddress.ip_address(ip.split("%")[0])
    except ValueError:
        return ip
    if addr.version == 4:
        a, b, c, _ = str(addr).split(".")
        return f"{a}.{b}.{c}.x"
    parts = addr.exploded.split(":")
    return ":".join(parts[:3]) + "::x"


def redact_text(text: str) -> str:
    def v4(m: re.Match) -> str:
        tok = m.group(0)
        try:
            ipaddress.IPv4Address(tok)
        except ValueError:
            return tok
        return mask_ip(tok)

    def v6(m: re.Match) -> str:
        tok = m.group(0)
        try:
            ipaddress.IPv6Address(tok)
        except ValueError:
            return tok
        return mask_ip(tok)

    return _V6.sub(v6, _V4.sub(v4, text))


class RedactFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        try:
            record.msg = redact_text(record.getMessage())
            record.args = ()
        except Exception:  # never drop a log line because redaction failed
            pass
        return True


_HANDLER_TAG = "_ipshift_handler"


def setup_logging(level: str = "INFO", log_file: Path | None = None, redact: bool = True,
                  stream=None) -> logging.Logger:
    logger = logging.getLogger("ipshift")
    for h in list(logger.handlers):
        if getattr(h, _HANDLER_TAG, False):
            logger.removeHandler(h)
            h.close()
    logger.setLevel(getattr(logging, str(level).upper(), logging.INFO))
    logger.propagate = False
    fmt = logging.Formatter("%(asctime)s %(levelname)-7s %(name)s: %(message)s", "%H:%M:%S")
    handlers: list[logging.Handler] = []
    if stream is not False:
        handlers.append(logging.StreamHandler(stream or sys.stderr))
    if log_file is not None:
        try:
            Path(log_file).parent.mkdir(parents=True, exist_ok=True)
            fd = os.open(log_file, os.O_CREAT | os.O_APPEND | os.O_WRONLY, 0o600)
            os.close(fd)
            handlers.append(logging.handlers.RotatingFileHandler(
                log_file, maxBytes=1_000_000, backupCount=2, encoding="utf-8"))
        except OSError:
            pass  # file logging is best-effort; stderr/journald still works
    for h in handlers:
        h.setFormatter(fmt)
        if redact:
            h.addFilter(RedactFilter())
        setattr(h, _HANDLER_TAG, True)
        logger.addHandler(h)
    return logger
