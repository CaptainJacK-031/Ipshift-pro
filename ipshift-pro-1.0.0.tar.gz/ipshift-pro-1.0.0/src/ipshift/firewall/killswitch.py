"""Kill switch controller: owns the dynamic state (which VPN servers may be
reached, whether a DoH lookup is in flight) and applies the ruleset atomically.

Fail-closed guarantees
----------------------
* ``arm()`` raises if the rules could not be installed - callers must not bring
  a tunnel up without them.
* Rules live in the kernel, not in this process: if the daemon crashes or is
  killed, traffic stays blocked until you run ``ipshift killswitch off`` (or
  ``ipshift restore``), which works without the daemon.
* Every change is a full-table replacement in one nft transaction; a failed
  update leaves the previous (still restrictive) ruleset in place.
"""
from __future__ import annotations

import json
import logging
import threading

from ..errors import DependencyError, KillSwitchError
from ..sysutil import which
from .rules import COMMENT_BLOCKED, TABLE, RuleSpec, render

log = logging.getLogger(__name__)


class KillSwitch:
    def __init__(self, ks_cfg, vpn_cfg, runner, net, *, dry_run: bool = False):
        self.ks = ks_cfg
        self.vpn = vpn_cfg
        self.runner = runner
        self.net = net
        self.dry_run = dry_run
        self._lock = threading.RLock()
        self._endpoints: list = []
        self._bootstrap: list[str] = []
        self._armed = False
        self._lockdown = False
        self.last_ruleset = ""

    # ---- ruleset -----------------------------------------------------------
    def spec(self) -> RuleSpec:
        k = self.ks
        return RuleSpec(tunnel_iface=self.vpn.interface, endpoints=list(self._endpoints),
                        bootstrap_hosts=list(self._bootstrap), allow_lan=k.allow_lan,
                        allow_ifaces=list(k.allow_ifaces), allow_dhcp=k.allow_dhcp, allow_forward=k.allow_forward,
                        physical_ifaces=[] if k.allow_forward else self.net.physical_ifaces(),
                        log_drops=k.log_drops, lockdown=self._lockdown)

    def render(self) -> str:
        return render(self.spec())

    def _nft(self, *args: str, input: str | None = None):
        return self.runner.run([self.ks.nft_bin, *args], input=input, timeout=15)

    def _apply(self) -> None:
        text = self.render()
        if self.dry_run:
            self.last_ruleset = text
            return
        if not which(self.ks.nft_bin):
            raise DependencyError("nftables is not installed", hint="apt install nftables")
        res = self._nft("-f", "-", input=text)
        if not res.ok:
            raise KillSwitchError("could not install the firewall rules: " + (res.stderr or res.stdout).strip()[:300],
                                  hint="the previous rules (if any) are still in force")
        self.last_ruleset = text

    # ---- control -----------------------------------------------------------
    def arm(self) -> None:
        with self._lock:
            self._lockdown = False
            self._apply()
            self._armed = True
        log.info("kill switch armed")

    def lockdown(self) -> None:
        """Panic mode: loopback only - no DHCP, no VPN server, nothing."""
        with self._lock:
            self._lockdown = True
            self._apply()
            self._armed = True
        log.warning("kill switch in LOCKDOWN: all traffic blocked")

    def disarm(self) -> None:
        with self._lock:
            if not self.dry_run:
                res = self._nft("delete", "table", "inet", TABLE)
                if not res.ok and "No such file" not in res.text and "does not exist" not in res.text:
                    raise KillSwitchError("could not remove the firewall rules: " + res.text.strip()[:200])
            self._armed = self._lockdown = False
        log.info("kill switch released")

    def set_endpoints(self, targets) -> None:
        with self._lock:
            self._endpoints = list(targets)
            if self._armed:
                self._apply()

    def open_bootstrap(self, hosts: list[str]) -> None:
        with self._lock:
            self._bootstrap = list(hosts)
            if self._armed and hosts:
                self._apply()

    def close_bootstrap(self) -> None:
        with self._lock:
            had = bool(self._bootstrap)
            self._bootstrap = []
            if self._armed and had:
                self._apply()

    def refresh(self) -> None:
        """Re-apply (the set of physical interfaces may have changed)."""
        with self._lock:
            if self._armed:
                self._apply()

    # ---- inspection --------------------------------------------------------
    @property
    def armed(self) -> bool:
        """What this process believes (no system call); ``is_armed`` asks the kernel."""
        return self._armed

    @property
    def in_lockdown(self) -> bool:
        return self._lockdown

    def is_armed(self) -> bool:
        if self.dry_run:
            return self._armed
        return self._nft("list", "table", "inet", TABLE).ok

    def counters(self) -> dict:
        if self.dry_run:
            return {"blocked_packets": 0, "blocked_bytes": 0}
        res = self._nft("-j", "list", "table", "inet", TABLE)
        pk = by = 0
        if res.ok:
            try:
                for item in json.loads(res.stdout).get("nftables", []):
                    rule = item.get("rule")
                    if rule and rule.get("comment") == COMMENT_BLOCKED:
                        for expr in rule.get("expr", []):
                            c = expr.get("counter")
                            if c:
                                pk += int(c.get("packets", 0))
                                by += int(c.get("bytes", 0))
            except (ValueError, AttributeError):
                pass
        return {"blocked_packets": pk, "blocked_bytes": by}

    def status(self) -> dict:
        armed = self.is_armed()
        out = {"armed": armed, "lockdown": self._lockdown and armed, "dry_run": self.dry_run,
               "endpoints": [f"{e.ip}:{e.port}/{e.proto}" for e in self._endpoints],
               "allow_lan": self.ks.allow_lan, "enabled": self.ks.enabled}
        out.update(self.counters() if armed else {"blocked_packets": 0, "blocked_bytes": 0})
        return out
