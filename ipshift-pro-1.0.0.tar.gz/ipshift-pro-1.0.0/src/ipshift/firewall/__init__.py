"""Firewall kill switch (nftables)."""
