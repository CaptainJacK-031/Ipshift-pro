"""nftables ruleset generation for the kill switch (a pure function).

Policy
------
* OUTPUT is **default-drop**.  Only these may leave the machine:
    - loopback;
    - anything that goes out of the tunnel interface;
    - the encrypted packets to the *specific* VPN server (ip + protocol + port);
    - DHCPv4 on the physical link (optional, needed to keep Wi-Fi/hotspots alive);
    - TCP/443 to the DoH bootstrap resolvers, only while a lookup is in flight;
    - optional extras the user asked for (LAN, lab interfaces) - never DNS to the LAN.
* INPUT is default-drop except loopback, replies to our own traffic and DHCP.
* FORWARD cannot leave through a physical interface (VMs/containers behind this
  host would otherwise bypass the tunnel) unless explicitly allowed.
* IPv6 follows the same rules: nothing leaves except through the tunnel.

The whole table is replaced in one nft transaction, so there is never a moment
without a policy - not at arm time, not on a server switch, not on update.
"""
from __future__ import annotations

import ipaddress
import re
from dataclasses import dataclass, field

TABLE = "ipshift"
_IFACE = re.compile(r"^[A-Za-z0-9_.-]{1,14}\*?$")
_LAN4 = "{ 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16, 169.254.0.0/16 }"
_LAN6 = "{ fc00::/7, fe80::/10 }"
COMMENT_BLOCKED = "ipshift-blocked"


@dataclass
class RuleSpec:
    tunnel_iface: str = "ipshift0"
    endpoints: list = field(default_factory=list)        # objects with .ip .port .proto
    bootstrap_hosts: list[str] = field(default_factory=list)
    allow_lan: bool = False
    allow_ifaces: list[str] = field(default_factory=list)
    allow_dhcp: bool = True
    allow_forward: bool = False
    physical_ifaces: list[str] = field(default_factory=list)
    log_drops: bool = False
    lockdown: bool = False        # loopback only: even DHCP and the VPN server are blocked


def _iface(name: str) -> str:
    if not _IFACE.match(name):
        raise ValueError(f"unsafe interface name {name!r}")
    return name


def _q(name: str) -> str:
    return f'"{_iface(name)}"'


def render(spec: RuleSpec) -> str:
    tun = _q(spec.tunnel_iface)
    v4, v6, boot = [], [], []
    for ep in ([] if spec.lockdown else spec.endpoints):
        ip = ipaddress.ip_address(ep.ip)
        proto, port = ep.proto, int(ep.port)
        if proto not in ("udp", "tcp") or not 1 <= port <= 65535:
            raise ValueError(f"bad endpoint {ep!r}")
        (v4 if ip.version == 4 else v6).append(f"{ip} . {proto} . {port}")
    for h in ([] if spec.lockdown else spec.bootstrap_hosts):
        boot.append(ipaddress.ip_address(h))
    boot4 = sorted({str(b) for b in boot if b.version == 4})
    boot6 = sorted({str(b) for b in boot if b.version == 6})

    def elems(items):
        return f"\n        elements = {{ {', '.join(sorted(set(items)))} }}" if items else ""

    out: list[str] = [
        f"add table inet {TABLE}",
        f"delete table inet {TABLE}",             # atomic replace: both lines are part of the same transaction
        f"table inet {TABLE} {{",
        "    set servers4 {", "        type ipv4_addr . inet_proto . inet_service" + elems(v4), "    }",
        "    set servers6 {", "        type ipv6_addr . inet_proto . inet_service" + elems(v6), "    }",
        "    chain output {",
        "        type filter hook output priority -150; policy drop;",
        '        oifname "lo" accept',
        f"        oifname {tun} accept",
    ]
    if not spec.lockdown:
        out += ["        ip daddr . meta l4proto . th dport @servers4 accept",
                "        ip6 daddr . meta l4proto . th dport @servers6 accept"]
        if v6:   # neighbour discovery is needed to reach an IPv6 server over the physical link
            out.append("        icmpv6 type { nd-neighbor-solicit, nd-neighbor-advert, nd-router-solicit } accept")
        if spec.allow_dhcp:
            out.append("        udp sport 68 udp dport 67 accept comment \"DHCPv4 renewals\"")
        if boot4:
            out.append(f"        ip daddr {{ {', '.join(boot4)} }} tcp dport 443 accept comment \"DoH bootstrap\"")
        if boot6:
            out.append(f"        ip6 daddr {{ {', '.join(boot6)} }} tcp dport 443 accept comment \"DoH bootstrap\"")
        for pat in spec.allow_ifaces:
            out.append(f"        oifname {_q(pat)} accept")
        if spec.allow_lan:
            # LAN reachable, but never DNS: a router's resolver forwards to the ISP.
            out += [f"        ip daddr {_LAN4} meta l4proto {{ tcp, udp }} th dport {{ 53, 853 }} drop",
                    f"        ip6 daddr {_LAN6} meta l4proto {{ tcp, udp }} th dport {{ 53, 853 }} drop",
                    f"        ip daddr {_LAN4} accept", f"        ip6 daddr {_LAN6} accept"]
    if spec.log_drops:
        out.append('        limit rate 5/second log prefix "ipshift-drop: "')
    out += [f'        counter drop comment "{COMMENT_BLOCKED}"', "    }",
            "    chain input {",
            "        type filter hook input priority -150; policy drop;",
            '        iifname "lo" accept']
    if not spec.lockdown:
        out.append("        ct state established,related accept")
        if spec.allow_dhcp:
            out.append("        udp sport 67 udp dport 68 accept comment \"DHCPv4 replies\"")
        for pat in spec.allow_ifaces:
            out.append(f"        iifname {_q(pat)} accept")
        if spec.allow_lan:
            out += [f"        ip saddr {_LAN4} accept", f"        ip6 saddr {_LAN6} accept"]
    out += [f'        counter drop comment "{COMMENT_BLOCKED}"', "    }"]
    if not spec.allow_forward:
        phys = [_q(n) for n in spec.physical_ifaces if n != spec.tunnel_iface]
        out += ["    chain forward {", "        type filter hook forward priority -150; policy accept;",
                f"        oifname {tun} accept"]
        if phys:
            out.append(f"        oifname {{ {', '.join(phys)} }} counter drop comment \"{COMMENT_BLOCKED}\"")
        out.append("    }")
    out.append("}")
    return "\n".join(out) + "\n"
