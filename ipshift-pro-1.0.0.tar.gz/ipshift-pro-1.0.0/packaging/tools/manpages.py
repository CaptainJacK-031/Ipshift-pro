"""Manual pages (roff, man(7) macros) generated from the real command line grammar."""
from __future__ import annotations

import argparse
import re

from . import grammar


def esc(text: str) -> str:
    """Plain text made safe for roff: backslashes, hyphens (printed as minus signs) and a leading dot or quote."""
    text = text.replace("\\", "\\\\").replace("-", "\\-")
    return re.sub(r"(?m)^([.'])", r"\\&\1", text)


def paragraphs(text: str) -> list[str]:
    """Blank-line separated paragraphs with the line breaks inside them removed."""
    return [" ".join(p.split()) for p in re.split(r"\n\s*\n", text.strip()) if p.strip()]


def _option_label(opt: grammar.Opt) -> str:
    names = ", ".join(f"\\fB{esc(n)}\\fR" for n in opt.names)
    if opt.metavar is None:
        return names
    value = f"\\fI{esc(opt.metavar)}\\fR"
    return f"{names} {value}" if opt.required_value else f"{names} [{value}]"


def _with_choices(text: str, choices: list[str]) -> str:
    if not choices:
        return text
    text = text.rstrip()
    if text and text[-1] not in ".!?":
        text += "."
    return f"{text} One of: {', '.join(choices)}.".strip()


def _options(options: list[grammar.Opt]) -> list[str]:
    out: list[str] = []
    for opt in options:
        if opt.names == ["-h", "--help"]:
            continue
        text = _with_choices(opt.help or "", opt.choices).strip()
        if not text and "--version" in opt.names:
            text = "print the version and exit"
        out += [".TP", _option_label(opt), esc(text)]
    return out


def _positionals(positionals: list[grammar.Pos]) -> list[str]:
    out: list[str] = []
    for pos in positionals:
        text = _with_choices(pos.help, pos.choices).strip()
        if text:
            out += [".TP", f"\\fI{esc(pos.metavar)}\\fR", esc(text)]
    return out


def _usage(prog: str, node: grammar.Node) -> str:
    words = [f"\\fB{esc(prog)}\\fR"] + [f"\\fB{esc(w)}\\fR" for w in node.path]
    if node.options:
        words.append("[\\fIoptions\\fR]")
    if node.children:
        words.append("\\fIaction\\fR" if node.path else "\\fIcommand\\fR")
    for pos in node.positionals:
        name = f"\\fI{esc(pos.metavar)}\\fR" + ("..." if pos.many else "")
        words.append(f"[{name}]" if pos.optional else name)
    return " ".join(words)


def _commands(prog: str, node: grammar.Node, global_names: set[str]) -> list[str]:
    out: list[str] = []
    for child in node.children:
        names = ", ".join([child.path[-1], *child.aliases])
        out += [f'.SS "{esc(" ".join(child.path))}"' if not child.aliases else
                f'.SS "{esc(" ".join(child.path))} ({esc(", ".join(child.aliases))})"',
                _usage(prog, child), ".PP", esc(child.description or names)]
        local = [o for o in child.options if not set(o.names) <= global_names]
        out += _options(local) + _positionals(child.positionals)
        out += _commands(prog, child, global_names)
    return out


def page(prog: str, section: int, summary: str, root: argparse.ArgumentParser, version: str, *,
         description: str, examples: list[tuple[str, str]] = (), extra: list[tuple[str, str]] = (),
         see_also: list[str] = ()) -> str:
    """One manual page: NAME, SYNOPSIS, DESCRIPTION, OPTIONS, COMMANDS (when there are any), EXAMPLES, the extra
    sections and SEE ALSO.  ``examples`` are (command line, what it does) pairs."""
    tree = grammar.read(root)
    global_names = {n for o in tree.options for n in o.names}
    out = [f'.TH {prog.upper()} {section} "" "ipshift-pro {esc(version)}" "IPShift Pro"',
           ".SH NAME", f"{esc(prog)} \\- {esc(summary)}",
           ".SH SYNOPSIS", _usage(prog, tree) if not tree.children else
           f"\\fB{esc(prog)}\\fR [\\fIoptions\\fR] \\fIcommand\\fR [\\fIarguments\\fR]",
           ".SH DESCRIPTION"]
    for para in paragraphs(description):
        out += [".PP", esc(para)]
    out += [".SH OPTIONS"] + _options(tree.options)
    if tree.children:
        out += [".SH COMMANDS", "Every command also accepts the global options above."]
        out += _commands(prog, tree, global_names)
    if examples:
        out.append(".SH EXAMPLES")
        for command, text in examples:
            out += [".TP", f"\\fB{esc(command)}\\fR", esc(text)]
    for title, text in extra:
        out.append(f".SH {esc(title.upper())}")
        for para in paragraphs(text):
            out += [".PP", esc(para)]
    if see_also:
        out += [".SH SEE ALSO", ",\n".join(f"\\fB{esc(name)}\\fR({n})" for name, n in (s.split(":") for s in see_also))]
    return "\n".join(out) + "\n"
