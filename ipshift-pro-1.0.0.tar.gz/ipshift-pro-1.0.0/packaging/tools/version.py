"""Print the version of the program, read from ``src/ipshift/__init__.py`` without importing it."""
from __future__ import annotations

import re
import sys
from pathlib import Path

INIT = Path(__file__).resolve().parents[2] / "src" / "ipshift" / "__init__.py"


def version() -> str:
    found = re.search(r'^__version__\s*=\s*"([0-9][0-9A-Za-z.+~-]*)"\s*$', INIT.read_text(), re.M)
    if not found:
        raise SystemExit(f"no usable __version__ in {INIT}")
    return found.group(1)


if __name__ == "__main__":
    sys.stdout.write(version() + "\n")
