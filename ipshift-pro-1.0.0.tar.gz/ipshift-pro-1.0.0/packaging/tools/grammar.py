"""Reading the grammar of an argparse parser: commands, sub-commands, options and positional words.

The completion script and the manual pages are generated from this, so they cannot drift away from the real
command line.  It looks at a few private attributes of argparse (``_actions``, ``_SubParsersAction``); the
tests would notice if a newer Python changed them.
"""
from __future__ import annotations

import argparse
import re
from dataclasses import dataclass, field
from typing import Iterator

# "FILE", "PATH" and "FILE_OR_FOLDER" name a path; "PROFILE" (which merely contains FILE) does not.
FILE_LIKE = re.compile(r"(^|_)(FILE|PATH|FOLDER|DIR)($|_)")


@dataclass
class Opt:
    names: list[str]                 # ["-w", "--watch"]
    metavar: str | None              # None for a flag
    required_value: bool             # False for a flag and for an optional value (nargs="?")
    choices: list[str]
    file: bool
    help: str


@dataclass
class Pos:
    metavar: str
    choices: list[str]
    file: bool
    many: bool                       # nargs "+" or "*": further words belong to it as well
    optional: bool
    help: str


@dataclass
class Node:
    path: tuple[str, ...]            # () for the program itself, ("vpn", "import") for a sub-command
    aliases: list[str]               # other names of the same command (the last word of the path)
    description: str
    options: list[Opt] = field(default_factory=list)
    positionals: list[Pos] = field(default_factory=list)
    children: list["Node"] = field(default_factory=list)

    @property
    def key(self) -> str:
        return " ".join(self.path)

    def keys(self) -> list[str]:
        """The key of the command and of each alias of it: ``vpn list`` and ``vpn ls``."""
        return [self.key] + [" ".join(self.path[:-1] + (a,)) for a in self.aliases]


def _help(action: argparse.Action) -> str:
    text = "" if action.help in (None, argparse.SUPPRESS) else str(action.help)
    return text.replace("%(default)s", "").replace("%%", "%")


def read(parser: argparse.ArgumentParser, path: tuple[str, ...] = (), aliases=()) -> Node:
    node = Node(path, list(aliases), (parser.description or "").strip())
    for a in parser._actions:
        if isinstance(a, argparse._SubParsersAction):
            groups: dict[int, tuple[argparse.ArgumentParser, list[str]]] = {}
            for name, sub in a.choices.items():              # aliases share the parser; the first name is the real one
                groups.setdefault(id(sub), (sub, []))[1].append(name)
            for sub, names in groups.values():
                node.children.append(read(sub, path + (names[0],), names[1:]))
        elif a.option_strings:
            flag = a.nargs == 0
            metavar = None if flag else (a.metavar or a.dest.upper())
            node.options.append(Opt(list(a.option_strings), metavar, not flag and a.nargs != "?",
                                    [str(c) for c in a.choices or ()],
                                    bool(metavar and FILE_LIKE.search(str(metavar))), _help(a)))
        else:
            metavar = str(a.metavar or a.dest)
            node.positionals.append(Pos(metavar, [str(c) for c in a.choices or ()], bool(FILE_LIKE.search(metavar)),
                                        a.nargs in ("+", "*"), a.nargs in ("?", "*"), _help(a)))
    return node


def flatten(node: Node) -> Iterator[Node]:
    """The node and every command below it, parents first."""
    yield node
    for child in node.children:
        yield from flatten(child)
