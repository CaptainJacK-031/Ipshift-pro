"""A bash completion script generated from the real command line grammar."""
from __future__ import annotations

import argparse
import re

from . import grammar, render

TOKEN_OK = re.compile(r"^[A-Za-z0-9_.@:,=/+-]+\Z")

# The script is plain bash (no dependency on the bash-completion package).  The generated lookup functions answer
# five questions about a command, named by its words joined with a space ("vpn import"; "" is the program itself):
#   children   which sub-commands it has            valued   which options need a value
#   options    every option                         choices  the values one option accepts ("@file": a path)
#   positional what the n-th plain word may be      ("@file": a path)
TEMPLATE = r"""# bash completion for @PROG@: generated from the real command line grammar by packaging/stage.py.
# Do not edit; it is written again at every install.

@FUNCTIONS@
_@PROG@_in() {
    local x=$1 e
    shift
    for e; do
        [[ $e == "$x" ]] && return 0
    done
    return 1
}

_@PROG@_reply() {      # $1: the candidates separated by spaces, or @file;  $2: what has been typed so far
    if [[ $1 == "@file" ]]; then
        compopt -o filenames 2>/dev/null
        mapfile -t COMPREPLY < <(compgen -f -- "$2")
    elif [[ -n $1 ]]; then
        mapfile -t COMPREPLY < <(compgen -W "$1" -- "$2")
    fi
}

_@PROG@() {
    local cur prev node="" i w skip=0 npos=0 words
    cur=${COMP_WORDS[COMP_CWORD]}
    prev=${COMP_WORDS[COMP_CWORD-1]}
    COMPREPLY=()

    # Which command (and sub-command) is this line in, and how many plain words does it hold so far?
    for ((i = 1; i < COMP_CWORD; i++)); do
        w=${COMP_WORDS[i]}
        if ((skip)); then
            skip=0
            continue
        fi
        case $w in
            -*)
                if _@PROG@_in "$w" $(_@PROG@_valued "$node"); then
                    skip=1
                fi
                continue ;;
        esac
        if _@PROG@_in "$w" $(_@PROG@_children "$node"); then
            node=${node:+$node }$w
            npos=0
        else
            npos=$((npos + 1))
        fi
    done

    if _@PROG@_in "$prev" $(_@PROG@_valued "$node"); then      # the word before the cursor is an option that needs a value
        _@PROG@_reply "$(_@PROG@_choices "$node" "$prev")" "$cur"
        return 0
    fi
    if [[ $cur == -* ]]; then
        _@PROG@_reply "$(_@PROG@_options "$node")" "$cur"
        return 0
    fi
    words=$(_@PROG@_children "$node")
    [[ -n $words ]] || words=$(_@PROG@_positional "$node" "$npos")
    _@PROG@_reply "$words" "$cur"
    return 0
}

complete -F _@PROG@ @PROG@
"""


def _safe(token: str) -> str:
    if not TOKEN_OK.match(token):
        raise ValueError(f"cannot put {token!r} into a completion script")
    return token


def _function(prog: str, name: str, subject: str, entries: list[tuple[str, str | None]]) -> str:
    """``_prog_name() { case "$subject" in ... esac }``: one ``pattern) echo "words"`` line per entry.

    An entry without words is left out; one whose words are ``None`` is kept as ``pattern) ;;`` so that it
    answers "nothing" and stops a later, wider pattern from answering instead."""
    lines = [f"_{prog}_{name}() {{", f'    case "{subject}" in']
    for pattern, words in entries:
        if words == "":
            continue
        # the star of a wildcard pattern has to stay outside the quotes
        shown = f'"{pattern[:-1]}"*' if pattern.endswith("/*") else f'"{pattern}"'
        lines.append(f"        {shown}) ;;" if words is None else f'        {shown}) echo "{words}" ;;')
    lines += ["    esac", "}", ""]
    return "\n".join(lines)


def _positionals(key: str, node: grammar.Node) -> list[tuple[str, str | None]]:
    """What each plain word of a command may be.  The word that takes any number of values answers for its own
    position and every later one; the plain words before it get an explicit answer (possibly "nothing"), so that
    the wildcard cannot answer for them."""
    has_many = any(p.many for p in node.positionals)
    out: list[tuple[str, str | None]] = []
    for i, pos in enumerate(node.positionals):
        words = "@file" if pos.file else " ".join(_safe(c) for c in pos.choices)
        if pos.many:
            out.append((f"{key}/*", words))
            break
        out.append((f"{key}/{i}", words or (None if has_many else "")))
    return out


def bash_completion(root: argparse.ArgumentParser, prog: str = "ipshift") -> str:
    tree = grammar.read(root)
    children, options, valued, choices, positional = [], [], [], [], []
    for node in grammar.flatten(tree):
        for key in node.keys():
            _safe(key.replace(" ", "_") or "_")
            children.append((key, " ".join(_safe(n) for c in node.children for n in [c.path[-1], *c.aliases])))
            options.append((key, " ".join(_safe(o) for opt in node.options for o in opt.names)))
            valued.append((key, " ".join(_safe(o) for opt in node.options if opt.required_value for o in opt.names)))
            for opt in node.options:
                if not opt.required_value:
                    continue
                words = "@file" if opt.file else " ".join(_safe(c) for c in opt.choices)
                choices += [(f"{key}/{o}", words) for o in opt.names]
            positional += _positionals(key, node)
    functions = "\n".join([
        _function(prog, "children", "$1", children),
        _function(prog, "options", "$1", options),
        _function(prog, "valued", "$1", valued),
        _function(prog, "choices", "$1/$2", choices),
        _function(prog, "positional", "$1/$2", positional),
    ])
    return render.fill(TEMPLATE, {"PROG": _safe(prog), "FUNCTIONS": functions})
