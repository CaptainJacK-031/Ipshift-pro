"""Filling in templates and writing the small launcher scripts."""
from __future__ import annotations

import re

TOKEN = re.compile(r"@([A-Z][A-Z0-9_]*)@")
SAFE_PATH = re.compile(r"^/[A-Za-z0-9._+/-]*\Z")

# name -> (module, function, isolated)
#
# The daemon and the command line may run as root (``sudo ipshift restore``), so they start Python in
# isolated mode: no PYTHON* environment variables, no user site directory, nothing from the current
# directory.  The window runs as the person, and PySide6 installed with ``pip --user`` has to stay visible.
LAUNCHERS: dict[str, tuple[str, str, bool]] = {
    "ipshift": ("ipshift.cli", "main", True),
    "ipshiftd": ("ipshift.daemon", "main", True),
    "ipshift-gui": ("ipshift.gui.app", "main", False),
}


def fill(text: str, values: dict[str, str]) -> str:
    """Replace every ``@NAME@``.  A token without a value is an error: a half-filled unit file must never be installed."""
    missing = sorted({m.group(1) for m in TOKEN.finditer(text)} - set(values))
    if missing:
        raise KeyError("no value for " + ", ".join("@" + name + "@" for name in missing))
    return TOKEN.sub(lambda m: values[m.group(1)], text)


def check_path(name: str, value: str) -> str:
    """Paths end up inside generated scripts: only plain absolute paths are accepted."""
    if not SAFE_PATH.match(value) or "//" in value or "/../" in value + "/" or value.endswith("/.."):
        raise ValueError(f"{name} must be a plain absolute path (letters, digits and . _ + - /), got {value!r}")
    return value.rstrip("/") or "/"


def launcher(name: str, pylib: str, python: str) -> str:
    """The text of the executable that starts ``name`` from the installed package directory ``pylib``."""
    module, func, isolated = LAUNCHERS[name]
    pylib, python = check_path("pylib", pylib), check_path("python", python)
    flag = " -I" if isolated else ""
    return (
        f"#!{python}{flag}\n"
        f"# {name}: written by the IPShift Pro installer.  Do not edit; install again instead.\n"
        "import sys\n"
        "\n"
        "if sys.version_info < (3, 10):\n"
        f"    sys.exit(\"{name}: Python 3.10 or newer is needed (this is %d.%d)\" % sys.version_info[:2])\n"
        f"sys.path.insert(0, {pylib!r})\n"
        "\n"
        f"from {module} import {func}\n"
        "\n"
        f"sys.exit({func}())\n"
    )
