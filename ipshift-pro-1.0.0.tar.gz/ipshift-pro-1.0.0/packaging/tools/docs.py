"""The prose of the manual pages.  The options and commands come from the real parsers (see manpages.py)."""
from __future__ import annotations

# What a person has to know about the limits.  Kept honest on purpose: the same points are in README.md.
LIMITS = """\
A VPN moves trust, it does not remove it. The provider can see where your traffic goes and, unless it is encrypted
end to end, what it contains. Free providers in particular may keep logs, sell them or change your traffic.
A server you rent yourself is only as anonymous as the account you rented it with.

Changing the public IP address does not make you anonymous. Signing in to an account, cookies, browser
fingerprints, WebRTC, and the timing and size of your traffic can still identify you, and a network tool cannot hide
them. Use a browser built for that (for example Tor Browser) when it matters.

The kill switch and the leak tests cover this machine: DNS, IPv6 and traffic that would leave outside the tunnel.
They do not cover other devices, a router, virtual machines that bridge the network, or programs that already know
your real address.

Rotation speed is limited by the VPN. OpenVPN needs several seconds to connect; WireGuard can switch servers in a
fraction of a second. An interval of 1 second is accepted, but a change only counts once the new tunnel is up and
the new public address has been checked, and two changes never overlap.

Stopping or crashing the daemon leaves the kill switch up on purpose, so that a dead daemon cannot expose you.
"ipshift restore" gives you the normal network back.
"""

FILES = """\
/etc/ipshift/config.json: the settings (change them with "ipshift config set", or edit it and send ipshiftd SIGHUP).

/var/lib/ipshift: the daemon's state: history.db (the rotation history), profiles/ (your VPN profiles, which can hold
credentials; only root can read them) and backup/ (what "ipshift restore" puts back).

/run/ipshift/ipshift.sock: the socket the command line and the window talk to. Only root and the group ipshift can
open it.

/var/log/ipshift/ipshift.log: the log. Addresses are masked unless you turn that off in the settings.
"""

IPSHIFT = dict(
    summary="change your public IP address through VPNs, with leak protection and a firewall kill switch",
    description="""\
ipshift controls the IPShift Pro daemon, ipshiftd(8). It connects VPN profiles, changes between them on a timer,
reports a change only after the new public IP address has been checked, tests for DNS and IPv6 leaks, and manages a
firewall kill switch.

The command line is a client of the daemon, which runs as root. To use it you have to belong to the group ipshift.
Membership of that group is equivalent to the right to control this machine's network: add only people you trust
with that.

A VPN changes who can see your traffic. It does not make you anonymous. See LIMITS.
""",
    examples=[
        ("ipshift vpn import ~/vpn/", "import every .ovpn and .conf file in a folder"),
        ("ipshift vpn connect", "connect, and verify the new public address"),
        ("ipshift rotate --interval 1", "change the public address as fast as the VPNs allow"),
        ("ipshift status --watch", "a live view"),
        ("ipshift privacy-check", "DNS, IPv6 and kill switch tests"),
        ("ipshift stop", "stop rotating, disconnect, give the normal network back"),
    ],
    extra=[
        ("Exit status", """\
0 success. 1 failed. 2 wrong usage. 3 the daemon cannot be reached. 4 the privacy check found problems.
130 interrupted.
"""),
        ("Files", FILES),
        ("Limits", LIMITS),
    ],
    see_also=["ipshiftd:8", "ipshift-gui:1"],
)

IPSHIFTD = dict(
    summary="the IPShift Pro daemon",
    description="""\
ipshiftd owns the VPN connections, the firewall kill switch, the rotation timer and the history. The command line,
ipshift(1), and the window, ipshift-gui(1), are clients of it. It needs root, because it manages nftables, routes,
tunnels and DNS settings; with --simulate it runs against a pretend network instead and touches nothing real.

Run it as a service: systemctl enable --now ipshiftd. It reports to systemd (Type=notify) and answers its watchdog.

Stopping or crashing the daemon leaves the kill switch up on purpose. Run "ipshift restore" to get the normal network
back.
""",
    extra=[
        ("Signals", """\
SIGHUP reads the configuration file again. SIGTERM and SIGINT stop the daemon cleanly; the firewall stays up unless
the setting killswitch.release_on_exit is on.
"""),
        ("Files", FILES),
        ("Limits", LIMITS),
    ],
    see_also=["ipshift:1", "ipshift-gui:1"],
)

IPSHIFT_GUI = dict(
    summary="the IPShift Pro window",
    description="""\
ipshift-gui shows the public and private IP address, the VPN status, the protection level, the rotation controls,
the DNS and IPv6 leak test results, the rotation history and connection alerts. It is a remote control for the
daemon, ipshiftd(8): it needs no root, but you have to belong to the group ipshift. Closing the window leaves the VPN and
the rotation running.

It needs PySide6 (Qt for Python). On Kali and Debian: apt install python3-pyside6.qtwidgets.

--demo opens the window against a private simulated daemon, so you can look around without root and without touching
the network. --selftest drives the window through a scripted run against the simulator and exits with 0 when every
check passed; it needs no display.
""",
    extra=[("Limits", LIMITS)],
    see_also=["ipshift:1", "ipshiftd:8"],
)
