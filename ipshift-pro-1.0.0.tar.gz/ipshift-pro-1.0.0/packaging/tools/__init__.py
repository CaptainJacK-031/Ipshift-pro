"""Build-time helpers for packaging IPShift Pro (templates, launcher scripts, completion, manual pages).

Nothing here is imported by the program itself; ``packaging/stage.py`` uses it to lay out an installable tree.
"""
