#!/bin/bash
# Install IPShift Pro on this machine (Kali, Debian, or anything with systemd, nftables and Python 3.10+).
#
#   sudo packaging/install.sh [--prefix /usr/local] [--add-user NAME] [--enable]
#
# It copies the program to root-owned places, writes the launchers, the systemd unit, the desktop entry,
# the completion and the manual pages, and creates the group "ipshift".  It does NOT start the daemon and
# it does NOT give anyone control of it unless you ask (--enable, --add-user).
set -euo pipefail
umask 022

PREFIX=/usr/local
PYTHON=/usr/bin/python3
ADD_USER=""
ENABLE=0
HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)

say()  { printf '%s\n' "$*"; }
warn() { printf 'warning: %s\n' "$*" >&2; }
die()  { printf 'install.sh: %s\n' "$*" >&2; exit 1; }

usage() {
    cat <<'EOF'
usage: sudo packaging/install.sh [options]

  --prefix DIR     where to install (default /usr/local; /usr works too)
  --add-user NAME  add NAME to the group "ipshift". Members of that group control this machine's network.
  --enable         also start the daemon now and at every boot (default: do not)
  -h, --help       this text

Remove it again with packaging/uninstall.sh.
EOF
}

while [ $# -gt 0 ]; do
    case $1 in
        --prefix)       [ $# -ge 2 ] || die "--prefix needs a directory"; PREFIX=$2; shift 2 ;;
        --prefix=*)     PREFIX=${1#--prefix=}; shift ;;
        --add-user)     [ $# -ge 2 ] || die "--add-user needs a user name"; ADD_USER=$2; shift 2 ;;
        --add-user=*)   ADD_USER=${1#--add-user=}; shift ;;
        --enable)       ENABLE=1; shift ;;
        -h|--help)      usage; exit 0 ;;
        *)              die "unknown option: $1 (try --help)" ;;
    esac
done

[ "$(id -u)" -eq 0 ] || die "this installer has to run as root:  sudo $0"
[ -x "$PYTHON" ] || die "$PYTHON not found: install python3"
"$PYTHON" -c 'import sys; raise SystemExit(sys.version_info < (3, 10))' \
    || die "Python 3.10 or newer is needed ($("$PYTHON" -V 2>&1))"
[ -f "$HERE/stage.py" ] || die "run this from a complete copy of the IPShift Pro sources (stage.py is missing)"

missing=()
for tool in nft ip; do
    command -v "$tool" >/dev/null 2>&1 || missing+=("$tool")
done
if ! command -v wg >/dev/null 2>&1 && ! command -v openvpn >/dev/null 2>&1; then
    missing+=("wg or openvpn")
fi
if [ "${#missing[@]}" -gt 0 ]; then
    warn "not found: ${missing[*]}"
    warn "on Kali / Debian:  sudo apt install nftables iproute2 wireguard-tools openvpn"
fi

if ! getent group ipshift >/dev/null 2>&1; then
    groupadd --system ipshift
    say "created the group ipshift"
fi

"$PYTHON" -I "$HERE/stage.py" --destdir / --prefix "$PREFIX" --python "$PYTHON" >/dev/null
"$PYTHON" -I -m compileall -q "$PREFIX/lib/ipshift/ipshift" || warn "could not precompile the Python files (it still works)"

if [ -n "$ADD_USER" ]; then
    id -u "$ADD_USER" >/dev/null 2>&1 || die "no such user: $ADD_USER"
    usermod -aG ipshift "$ADD_USER"
    say "added $ADD_USER to the group ipshift (they have to log out and in again)"
fi

if [ -d /run/systemd/system ]; then
    systemctl daemon-reload
    if [ "$ENABLE" -eq 1 ]; then
        systemctl enable --now ipshiftd
        say "the daemon is running and will start at boot"
    elif systemctl is-active --quiet ipshiftd; then
        say "the daemon is still running the old version; restart it when it suits you:  sudo systemctl restart ipshiftd"
    fi
elif [ "$ENABLE" -eq 1 ]; then
    warn "systemd is not running here; start the daemon yourself:  $PREFIX/bin/ipshiftd"
fi

say ""
say "$("$PREFIX/bin/ipshift" --version) is installed under $PREFIX."
say ""
say "Next:"
n=1
if [ -z "$ADD_USER" ]; then
    say "  $n. Let your user control it (members of the group ipshift control this machine's network):"
    say "         sudo usermod -aG ipshift ${SUDO_USER:-YOUR_USER}      then log out and in again"
    n=$((n + 1))
fi
if [ "$ENABLE" -eq 0 ]; then
    say "  $n. Start the daemon:               sudo systemctl enable --now ipshiftd"
    n=$((n + 1))
fi
say "  $n. Check this machine:             ipshift doctor"
say "     Import VPN profiles:             ipshift vpn import ~/vpn/"
say "     Connect and rotate:              ipshift vpn connect   then   ipshift rotate --interval 1"
say "     The window:                      ipshift-gui   (needs: sudo apt install python3-pyside6.qtwidgets)"
say ""
say "If IPShift ever leaves you without network:  sudo ipshift restore"
