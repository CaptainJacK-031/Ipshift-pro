#!/bin/bash
# Pack the sources into a tarball that packaging/install.sh can be run from.
#
#   packaging/build_tarball.sh [OUTPUT_DIR]      (default: dist/)
set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT=$(dirname "$HERE")
OUT=${1:-$ROOT/dist}

VERSION=$(python3 -I "$HERE/tools/version.py")
NAME=ipshift-pro-$VERSION
mkdir -p "$OUT"
FILE=$OUT/$NAME.tar.gz

tar -C "$ROOT" --exclude='./dist' --exclude='__pycache__' --exclude='*.pyc' --exclude='./.git' \
    --exclude='*.egg-info' --exclude='./build' --owner=0 --group=0 --numeric-owner \
    --transform "s,^\\.,$NAME," -cf - . | gzip -9n > "$FILE"
printf '%s\n' "$FILE"
