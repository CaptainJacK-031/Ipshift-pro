#!/usr/bin/env python3
"""Lay out an installable IPShift Pro tree under a destination directory.

    stage.py --destdir DIR [--prefix /usr/local] [--pylib /usr/local/lib/ipshift] [--python /usr/bin/python3]

Everything that ends up on a system is made here, in one place, whether it is installed straight onto ``/``
(``packaging/install.sh``) or collected for a package (``packaging/build_deb.sh``):

    <pylib>/ipshift/               the Python package (root-owned; the daemon runs code from here)
    <prefix>/bin/                  ipshift, ipshiftd, ipshift-gui   (small launchers)
    <prefix>/lib/systemd/system/   ipshiftd.service
    <prefix>/share/                desktop entry, icon, bash completion, manual pages, documentation

and prints one ``F``/``T``/``D`` line per installed file, tree or directory (the uninstall manifest).
"""
from __future__ import annotations

import argparse
import gzip
import grp
import os
import shutil
import stat
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path[:0] = [str(ROOT / "src"), str(HERE)]

from tools import completion, docs, manpages, render  # noqa: E402

DEFAULT_PREFIX = "/usr/local"
DEFAULT_PYTHON = "/usr/bin/python3"
MANIFEST_NAME = "MANIFEST"


class StageError(Exception):
    pass


class Stage:
    """Writes files below ``destdir`` and remembers what it wrote, under the names they will have on the target."""

    def __init__(self, destdir: str | Path, *, owner_root: bool | None = None):
        self.destdir = Path(destdir)
        self.files: list[str] = []
        self.trees: list[str] = []
        self.dirs: list[str] = []
        self.owner_root = (os.geteuid() == 0) if owner_root is None else owner_root

    def real(self, target: str) -> Path:
        return self.destdir / target.lstrip("/")

    def _own(self, path: Path) -> None:
        if self.owner_root:
            os.chown(path, 0, 0)

    def mkdir(self, target: str, *, own: bool = True) -> None:
        """Create a directory and its parents (mode 0755).  ``own``: the uninstaller may remove it when empty."""
        parts = Path(target).parts[1:]
        for i in range(len(parts)):
            sub = "/" + "/".join(parts[: i + 1])
            real = self.real(sub)
            if not real.is_dir():
                real.mkdir(mode=0o755, parents=True)       # parents: the staging directory itself may not exist yet
                os.chmod(real, 0o755)
                self._own(real)
                if own and sub not in self.dirs:
                    self.dirs.append(sub)

    def write(self, target: str, data: bytes | str, mode: int = 0o644) -> None:
        self.mkdir(str(Path(target).parent))
        real = self.real(target)
        tmp = real.with_name("." + real.name + ".new")
        tmp.write_bytes(data.encode() if isinstance(data, str) else data)
        os.chmod(tmp, mode)
        self._own(tmp)
        os.replace(tmp, real)                          # a running program never sees a half-written file
        if target not in self.files:
            self.files.append(target)

    def manifest(self) -> list[str]:
        """``F`` file, ``T`` a tree to remove as a whole, ``D`` a directory to remove when it is empty (deepest first)."""
        return ([f"F {p}" for p in sorted(self.files)] + [f"T {p}" for p in self.trees]
                + [f"D {p}" for p in sorted(self.dirs, key=lambda d: (-d.count("/"), d))])


def require_root_owned(path: str, what: str) -> None:
    """Root will run what is installed here.  The path and every directory above it must belong to root and
    must not be writable by anyone else; Debian's /usr/local, which belongs to the group staff, is accepted
    because that group is trusted with local changes by convention."""
    probe = Path(path)
    while not os.path.lexists(probe):
        probe = probe.parent
    probe = Path(os.path.realpath(probe))
    for entry in (probe, *probe.parents):
        info = os.stat(entry)
        group_ok = not info.st_mode & stat.S_IWGRP
        if not group_ok:
            try:
                group_ok = info.st_gid == 0 or grp.getgrgid(info.st_gid).gr_name == "staff"
            except KeyError:
                group_ok = False
        if info.st_uid != 0 or info.st_mode & stat.S_IWOTH or not group_ok:
            raise StageError(f"{what}: {entry} is not owned by root alone (owner {info.st_uid}, mode "
                             f"{stat.S_IMODE(info.st_mode):o}); refusing to install code there that root will run")


def previous_dirs(st: Stage, manifest: str) -> list[str]:
    """The directories an earlier install created, so that an upgrade does not forget them."""
    path = st.real(manifest)
    if not path.is_file():
        return []
    found = []
    for line in path.read_text().splitlines():
        kind, _, target = line.partition(" ")
        if kind == "D" and render.SAFE_PATH.match(target) and "/../" not in target + "/":
            found.append(target)
    return found


def copy_package(st: Stage, src: Path, pylib: str) -> None:
    """The Python package, put in place as a whole: the old copy is moved aside first, so no stale module survives."""
    target = f"{pylib}/ipshift"
    st.mkdir(pylib)
    new, old = st.real(f"{pylib}/.ipshift-new"), st.real(f"{pylib}/.ipshift-old")
    for leftover in (new, old):
        if leftover.exists():
            shutil.rmtree(leftover)
    shutil.copytree(src, new, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo", ".*"))
    for dirpath, dirnames, filenames in os.walk(new):
        os.chmod(dirpath, 0o755)
        st._own(Path(dirpath))
        for name in filenames:
            os.chmod(os.path.join(dirpath, name), 0o644)
            st._own(Path(dirpath, name))
    real = st.real(target)
    if real.exists():
        os.rename(real, old)
    os.rename(new, real)
    if old.exists():
        shutil.rmtree(old)
    st.trees.append(target)


def gz(text: str) -> bytes:
    """gzip with no timestamp, so the same input always gives the same bytes."""
    import io
    buf = io.BytesIO()
    with gzip.GzipFile(filename="", mode="wb", fileobj=buf, compresslevel=9, mtime=0) as f:
        f.write(text.encode())
    return buf.getvalue()


def stage(destdir: str | Path, *, prefix: str = DEFAULT_PREFIX, pylib: str | None = None, python: str = DEFAULT_PYTHON,
          source: Path = ROOT, with_manifest: bool = True, owner_root: bool | None = None) -> Stage:
    prefix = render.check_path("prefix", prefix)
    pylib = render.check_path("pylib", pylib or f"{prefix}/lib/ipshift")
    python = render.check_path("python", python)
    if pylib == "/":
        raise StageError("the Python library directory cannot be /")
    if Path(destdir) == Path("/"):                                   # a real install: root will run all of this
        for what, path in (("python", python), ("pylib", pylib), ("prefix", prefix)):
            require_root_owned(path, what)
    sys.path.insert(0, str(source / "src"))
    from ipshift import __version__
    from ipshift.cli.parser import build_parser
    from ipshift.daemon import build_parser as daemon_parser
    from ipshift.gui.app import build_parser as gui_parser

    st = Stage(destdir, owner_root=owner_root)
    bindir = f"{prefix}/bin"
    values = {"BINDIR": bindir}

    copy_package(st, source / "src" / "ipshift", pylib)
    for name in render.LAUNCHERS:
        st.write(f"{bindir}/{name}", render.launcher(name, pylib, python), 0o755)

    pk = source / "packaging"
    st.write(f"{prefix}/lib/systemd/system/ipshiftd.service",
             render.fill((pk / "systemd" / "ipshiftd.service.in").read_text(), values))
    st.write(f"{prefix}/share/applications/ipshift-pro.desktop",
             render.fill((pk / "desktop" / "ipshift-pro.desktop.in").read_text(), values))
    st.write(f"{prefix}/share/icons/hicolor/scalable/apps/ipshift-pro.svg", (pk / "desktop" / "ipshift-pro.svg").read_bytes())
    st.write(f"{prefix}/share/bash-completion/completions/ipshift", completion.bash_completion(build_parser(), "ipshift"))

    for prog, section, parser, page in (("ipshift", 1, build_parser(), docs.IPSHIFT),
                                        ("ipshiftd", 8, daemon_parser(), docs.IPSHIFTD),
                                        ("ipshift-gui", 1, gui_parser(), docs.IPSHIFT_GUI)):
        text = manpages.page(prog, section, page["summary"], parser, __version__, description=page["description"],
                             examples=page.get("examples", []), extra=page.get("extra", []),
                             see_also=page.get("see_also", []))
        st.write(f"{prefix}/share/man/man{section}/{prog}.{section}.gz", gz(text))

    docdir = f"{prefix}/share/doc/ipshift-pro"
    for name in ("README.md",):
        if (source / name).is_file():
            st.write(f"{docdir}/{name}", (source / name).read_bytes())
    if with_manifest:
        mpath = f"{prefix}/share/ipshift-pro/{MANIFEST_NAME}"
        for d in previous_dirs(st, mpath):
            if d not in st.dirs:
                st.dirs.append(d)
        st.mkdir(f"{prefix}/share/ipshift-pro")
        st.files.append(mpath)                                    # the manifest lists itself
        st.write(mpath, "\n".join(st.manifest()) + "\n")
    return st


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="stage.py", description=__doc__.split("\n\n")[0])
    p.add_argument("--destdir", required=True, help="where to build the tree ('/' installs for real)")
    p.add_argument("--prefix", default=DEFAULT_PREFIX)
    p.add_argument("--pylib", help="where the Python package goes (default: <prefix>/lib/ipshift)")
    p.add_argument("--python", default=DEFAULT_PYTHON, help="the interpreter the launchers use")
    p.add_argument("--no-manifest", action="store_true", help="do not write the uninstall manifest (for packages)")
    args = p.parse_args(argv)
    try:
        st = stage(args.destdir, prefix=args.prefix, pylib=args.pylib, python=args.python,
                   with_manifest=not args.no_manifest)
    except (StageError, ValueError, OSError, KeyError) as e:
        print(f"stage.py: {e}", file=sys.stderr)
        return 1
    print("\n".join(st.manifest()))
    return 0


if __name__ == "__main__":
    sys.exit(main())
