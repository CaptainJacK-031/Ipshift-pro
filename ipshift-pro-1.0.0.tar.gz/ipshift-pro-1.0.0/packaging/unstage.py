#!/usr/bin/env python3
"""Remove what ``stage.py`` installed, as listed in its manifest, and nothing else.

    unstage.py --destdir / --manifest /usr/local/share/ipshift-pro/MANIFEST

It runs as root, so it is strict: a manifest line must be a plain absolute path of a known kind, files are only
unlinked (never followed), a directory is only removed when it is empty and is not one of the system's own,
and the one tree that is removed as a whole has to be a real directory called ``ipshift``.
"""
from __future__ import annotations

import argparse
import os
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from tools import render  # noqa: E402

# Directories that belong to the system, whoever created them.
PROTECTED = {
    "/", "/bin", "/boot", "/dev", "/etc", "/home", "/lib", "/lib64", "/media", "/mnt", "/opt", "/proc", "/root",
    "/run", "/sbin", "/srv", "/sys", "/tmp", "/usr", "/var",
    "/usr/bin", "/usr/lib", "/usr/lib64", "/usr/sbin", "/usr/share", "/usr/local", "/usr/local/bin",
    "/usr/local/lib", "/usr/local/sbin", "/usr/local/share", "/usr/local/etc",
}


def parse(text: str) -> list[tuple[str, str]]:
    """``(kind, path)`` for every line; a line that is not understood raises ValueError (nothing is removed then)."""
    entries = []
    for number, line in enumerate(text.splitlines(), 1):
        if not line.strip():
            continue
        kind, _, path = line.partition(" ")
        if kind not in ("F", "T", "D"):
            raise ValueError(f"line {number}: unknown kind {kind!r}")
        if not render.SAFE_PATH.match(path) or path == "/" or "//" in path or "/../" in path + "/" or path.endswith("/"):
            raise ValueError(f"line {number}: {path!r} is not a plain absolute path")
        if kind in ("F", "T") and path.count("/") < 3:
            raise ValueError(f"line {number}: {path!r} is too close to the root of the file system")
        if kind == "T" and os.path.basename(path) != "ipshift":
            raise ValueError(f"line {number}: only a tree called ipshift may be removed as a whole, not {path!r}")
        entries.append((kind, path))
    return entries


def remove(destdir: str | Path, entries: list[tuple[str, str]], *, log=print) -> int:
    """Remove the listed files, trees and empty directories under ``destdir``.  Returns how many things went."""
    base = Path(destdir)
    count = 0

    def real(path: str) -> Path:
        return base / path.lstrip("/")

    for kind, path in entries:
        if kind != "F":
            continue
        target = real(path)
        try:
            if target.is_dir() and not target.is_symlink():
                log(f"not removing {path}: it is a directory, not a file")
                continue
            os.unlink(target)
            count += 1
        except FileNotFoundError:
            pass
        except OSError as e:
            log(f"could not remove {path}: {e}")
    for kind, path in entries:
        if kind != "T":
            continue
        target = real(path)
        if not os.path.lexists(target):
            continue
        if target.is_symlink() or not target.is_dir():
            log(f"not removing {path}: it is not a plain directory")
            continue
        if os.path.realpath(target) != os.path.join(os.path.realpath(base), path.lstrip("/")):
            log(f"not removing {path}: a part of the path is a symbolic link")
            continue
        shutil.rmtree(target)
        count += 1
    for kind, path in sorted((e for e in entries if e[0] == "D"), key=lambda e: (-e[1].count("/"), e[1])):
        if path in PROTECTED:
            continue
        try:
            os.rmdir(real(path))
            count += 1
        except (FileNotFoundError, NotADirectoryError):
            pass
        except OSError:                              # not empty: somebody else keeps something in it
            pass
    return count


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="unstage.py", description=__doc__.split("\n\n")[0])
    p.add_argument("--destdir", required=True)
    p.add_argument("--manifest", required=True, help="the manifest, as an absolute path on the target system")
    args = p.parse_args(argv)
    manifest = Path(args.destdir) / args.manifest.lstrip("/")
    try:
        entries = parse(manifest.read_text())
    except OSError as e:
        print(f"unstage.py: cannot read the manifest: {e}", file=sys.stderr)
        return 1
    except ValueError as e:
        print(f"unstage.py: the manifest is not usable, nothing was removed: {e}", file=sys.stderr)
        return 1
    count = remove(args.destdir, entries, log=lambda m: print(m, file=sys.stderr))
    print(f"removed {count} item(s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
