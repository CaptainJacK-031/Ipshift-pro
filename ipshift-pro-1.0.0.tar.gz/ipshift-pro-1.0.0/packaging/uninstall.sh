#!/bin/bash
# Remove IPShift Pro again.
#
#   sudo packaging/uninstall.sh [--prefix /usr/local] [--purge] [--force]
#
# First it stops the daemon and gives you the normal network back ("ipshift restore"), because the kill switch
# is made to survive the daemon.  Then it removes exactly the files the installer listed in its manifest.
# Your settings, VPN profiles and history stay in /etc/ipshift and /var/lib/ipshift unless you say --purge.
set -euo pipefail

PREFIX=/usr/local
PYTHON=/usr/bin/python3
PURGE=0
FORCE=0
HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)

say()  { printf '%s\n' "$*"; }
warn() { printf 'warning: %s\n' "$*" >&2; }
die()  { printf 'uninstall.sh: %s\n' "$*" >&2; exit 1; }

usage() {
    cat <<'EOF'
usage: sudo packaging/uninstall.sh [options]

  --prefix DIR   where it was installed (default /usr/local)
  --purge        also delete the settings, the VPN profiles (with any stored passwords), the history,
                 the log, and the group "ipshift". The files are unlinked, not wiped: on SSDs and
                 journaling file systems the data may stay recoverable.
  --force        carry on even if the normal network could not be restored first
  -h, --help     this text
EOF
}

while [ $# -gt 0 ]; do
    case $1 in
        --prefix)    [ $# -ge 2 ] || die "--prefix needs a directory"; PREFIX=$2; shift 2 ;;
        --prefix=*)  PREFIX=${1#--prefix=}; shift ;;
        --purge)     PURGE=1; shift ;;
        --force)     FORCE=1; shift ;;
        -h|--help)   usage; exit 0 ;;
        *)           die "unknown option: $1 (try --help)" ;;
    esac
done

[ "$(id -u)" -eq 0 ] || die "this has to run as root:  sudo $0"
MANIFEST="$PREFIX/share/ipshift-pro/MANIFEST"
[ -f "$MANIFEST" ] || die "no install manifest at $MANIFEST: nothing from the installer is here (wrong --prefix?)"
[ -x "$PYTHON" ] || die "$PYTHON not found"

# 1. Stop the daemon.  This leaves the kill switch up, on purpose.
if [ -d /run/systemd/system ] && systemctl cat ipshiftd.service >/dev/null 2>&1; then
    systemctl disable --now ipshiftd >/dev/null 2>&1 || warn "could not stop the ipshiftd service"
fi

# 2. Give the normal network back (firewall, DNS, IPv6, MAC addresses, stray tunnels).
if [ -x "$PREFIX/bin/ipshift" ]; then
    if "$PREFIX/bin/ipshift" restore; then
        say "the normal network is back"
    elif [ "$FORCE" -eq 1 ]; then
        warn "could not restore everything; going on because of --force"
        warn "if the network stays blocked:  sudo nft delete table inet ipshift"
    else
        die "could not restore the normal network, so nothing was removed. Look at the messages above and run
  sudo $PREFIX/bin/ipshift restore
again, or use --force to remove the files anyway (then, if the network stays blocked:  sudo nft delete table inet ipshift)"
    fi
else
    warn "$PREFIX/bin/ipshift is missing, so the network could not be restored from here"
    warn "if the network is blocked:  sudo nft delete table inet ipshift"
fi

# 3. Remove what the installer put there.
"$PYTHON" -I "$HERE/unstage.py" --destdir / --manifest "$MANIFEST"

if [ -d /run/systemd/system ]; then
    systemctl daemon-reload || true
fi

# 4. With --purge, also what the daemon kept.
if [ "$PURGE" -eq 1 ]; then
    rm -rf -- /etc/ipshift /var/lib/ipshift /var/log/ipshift /run/ipshift
    if getent group ipshift >/dev/null 2>&1; then
        groupdel ipshift || warn "could not remove the group ipshift"
    fi
    say "settings, profiles, history and logs are deleted"
else
    say "your settings, profiles and history are kept (/etc/ipshift, /var/lib/ipshift); --purge deletes them"
fi
say "IPShift Pro is removed."
