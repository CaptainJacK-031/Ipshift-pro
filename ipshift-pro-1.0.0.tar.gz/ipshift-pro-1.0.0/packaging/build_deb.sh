#!/bin/bash
# Build the Debian / Kali package.
#
#   packaging/build_deb.sh [OUTPUT_DIR]          (default: dist/)
#
# Name yourself as the maintainer with:  IPSHIFT_MAINTAINER="Your Name <you@example.org>" packaging/build_deb.sh
# Needs dpkg-deb (package dpkg-dev, or any Debian / Kali system).  Does not need root.
set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT=$(dirname "$HERE")
OUT=${1:-$ROOT/dist}
MAINTAINER=${IPSHIFT_MAINTAINER:-"IPShift Pro <root@localhost>"}

die() { printf 'build_deb.sh: %s\n' "$*" >&2; exit 1; }

command -v dpkg-deb >/dev/null 2>&1 || die "dpkg-deb is needed (sudo apt install dpkg-dev)"
re='^[^<>[:cntrl:]]+ <[^<> [:cntrl:]]+>$'
[[ $MAINTAINER =~ $re ]] || die "IPSHIFT_MAINTAINER must look like: Your Name <you@example.org>"

VERSION=$(python3 -I "$HERE/tools/version.py")
EPOCH=${SOURCE_DATE_EPOCH:-$(date +%s)}
WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT
PKG=$WORK/ipshift-pro_${VERSION}_all

# The files, laid out the Debian way: the program in dist-packages, the rest under /usr.
python3 -I "$HERE/stage.py" --destdir "$PKG" --prefix /usr --pylib /usr/lib/python3/dist-packages \
    --python /usr/bin/python3 --no-manifest >/dev/null

DOC=$PKG/usr/share/doc/ipshift-pro
install -d -m 0755 "$DOC"
install -m 0644 "$HERE/debian/copyright" "$DOC/copyright"
printf 'ipshift-pro (%s) unstable; urgency=medium\n\n  * Packaged release.\n\n -- %s  %s\n' \
    "$VERSION" "$MAINTAINER" "$(date -R -u -d "@$EPOCH")" | gzip -9n > "$DOC/changelog.Debian.gz"
chmod 0644 "$DOC/changelog.Debian.gz"

SIZE=$(du -sk "$PKG" | cut -f1)
install -d -m 0755 "$PKG/DEBIAN"
python3 -I - "$HERE" "$VERSION" "$MAINTAINER" "$SIZE" > "$PKG/DEBIAN/control" <<'PY'
import sys
here, version, maintainer, size = sys.argv[1:5]
sys.path.insert(0, here)
from tools import render
print(render.fill(open(here + "/debian/control.in").read(),
                  {"VERSION": version, "MAINTAINER": maintainer, "SIZE": size}), end="")
PY
chmod 0644 "$PKG/DEBIAN/control"
for script in postinst prerm postrm; do
    install -m 0755 "$HERE/debian/$script" "$PKG/DEBIAN/$script"
done
(cd "$PKG" && find . -type f -not -path './DEBIAN/*' -printf '%P\0' | LC_ALL=C sort -z | xargs -0 md5sum) \
    > "$PKG/DEBIAN/md5sums"
chmod 0644 "$PKG/DEBIAN/md5sums"

mkdir -p "$OUT"
DEB=$OUT/ipshift-pro_${VERSION}_all.deb
dpkg-deb --root-owner-group -Zxz --build "$PKG" "$DEB" >/dev/null
printf '%s\n' "$DEB"
