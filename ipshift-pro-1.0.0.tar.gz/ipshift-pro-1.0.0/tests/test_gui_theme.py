"""The style sheet: complete (nothing left unfilled) and covering every tone the views can produce."""
from __future__ import annotations

import re
import unittest

import helpers  # noqa: F401  (puts src/ on the path)
from ipshift.gui import theme, views


class StyleSheetTests(unittest.TestCase):
    def setUp(self):
        self.css = theme.qss()

    def test_no_placeholder_is_left_over(self):
        self.assertNotIn("$", self.css)
        self.assertNotIn("{good}", self.css)

    def test_braces_balance(self):
        self.assertEqual(self.css.count("{"), self.css.count("}"))

    def test_every_tone_has_a_colour_and_a_rule_for_each_kind_of_widget(self):
        for tone in views.TONES:
            self.assertRegex(theme.tone_color(tone), r"^#[0-9a-f]{6}$", tone)
        for tone in (views.GOOD, views.WARN, views.BAD, views.INFO, views.MUTED):
            for selector in (f'QLabel[tone="{tone}"]', f'QLabel[pill="true"][tone="{tone}"]',
                             f'QFrame#banner[tone="{tone}"]', f'QFrame#tile[tone="{tone}"]',
                             f'QFrame#toast[tone="{tone}"]'):
                self.assertIn(selector, self.css)

    def test_a_tone_rule_uses_the_colour_of_its_tone(self):
        for tone in (views.GOOD, views.WARN, views.BAD, views.INFO):
            rule = re.search(r'QLabel\[tone="%s"\] \{ color: (#[0-9a-f]{6});' % tone, self.css)
            self.assertIsNotNone(rule, tone)
            self.assertEqual(rule.group(1), theme.tone_color(tone))

    def test_every_colour_in_the_sheet_comes_from_the_palette_or_is_a_named_tint(self):
        palette = set(theme.PALETTE.values())
        for hexcode in set(re.findall(r"#[0-9a-fA-F]{6}\b", self.css)):
            self.assertTrue(hexcode in palette or hexcode == "#ffffff", hexcode)

    def test_a_different_palette_changes_the_sheet(self):
        other = dict(theme.PALETTE, bg="#000001")
        self.assertIn("#000001", theme.qss(other))
        self.assertNotIn("#000001", self.css)

    def test_the_interval_box_and_navigation_are_styled_by_object_name(self):
        for name in ("QDoubleSpinBox#interval", "QListWidget#nav", "QFrame#card", "QFrame#sep"):
            self.assertIn(name, self.css)

    def test_the_tint_table_covers_the_same_tones_as_the_palette_keys(self):
        for tone in (views.GOOD, views.WARN, views.BAD, views.INFO, views.MUTED):
            self.assertIn(tone, theme.TINT)
            self.assertIn(theme.TONE_KEY[tone], theme.PALETTE)
        self.assertEqual(theme.TONE_KEY[views.PLAIN], "text")


if __name__ == "__main__":
    unittest.main()
