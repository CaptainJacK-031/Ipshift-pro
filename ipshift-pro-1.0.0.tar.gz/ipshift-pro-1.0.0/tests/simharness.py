"""A complete simulated stack (world, firewall in dry-run, hardening, manager) for tests."""
from __future__ import annotations

import random
from pathlib import Path

from ipshift.config import Config
from ipshift.events import EventBus
from ipshift.firewall.killswitch import KillSwitch
from ipshift.history import History
from ipshift.net.resolve import ResolveError
from ipshift.paths import default_paths
from ipshift.privacy.hardening import Hardening
from ipshift.privacy.leaks import PrivacyChecker
from ipshift.vpn.manager import VpnManager
from ipshift.vpn.profile import ProfileStore
from ipshift.vpn.sim import SimBackend, SimEcho, SimNetInfo, SimProbes, SimRunner, SimWorld, make_demo_profiles


class StubResolver:
    """BootstrapResolver stand-in: answers from a dict and records how it was called."""

    def __init__(self, answers=None):
        self.answers = dict(answers or {})
        self.calls = []
        self.ks = None
        self.window_open_during_call = []

    def resolve(self, host, family=4, *, use_cache=True):
        self.calls.append((host, family))
        if self.ks is not None:
            self.window_open_during_call.append(bool(self.ks._bootstrap))
        ips = self.answers.get((host, family)) or self.answers.get(host)
        if not ips:
            raise ResolveError(f"could not resolve {host}")
        return list(ips)


class SimStack:
    def __init__(self, tmp: Path, *, speed: float = 0.0, cfg: Config | None = None, demo: bool = True):
        self.tmp = Path(tmp)
        self.paths = default_paths()
        self.cfg = cfg or Config()
        self.cfg.vpn.connect_timeout = 5.0
        self.cfg.vpn.verify_timeout = 2.0
        self.world = SimWorld(speed=speed)
        self.runner = SimRunner()
        self.net = SimNetInfo(self.world)
        self.store = ProfileStore(self.paths.profiles_dir)
        if demo:
            make_demo_profiles(self.store, self.world)
        self.ks = KillSwitch(self.cfg.killswitch, self.cfg.vpn, self.runner, self.net, dry_run=True)
        self.world.blocked = lambda: self.ks.armed
        sysdir = self.tmp / "simsys"
        sysdir.mkdir(parents=True, exist_ok=True)
        self.resolv = sysdir / "resolv.conf"
        self.resolv.write_text("nameserver 192.168.1.1\n")
        self.sysctl = sysdir / "proc_sys"
        knob = self.sysctl / "net" / "ipv6" / "conf" / "wlan0" / "disable_ipv6"
        knob.parent.mkdir(parents=True, exist_ok=True)
        knob.write_text("0\n")
        self.knob = knob
        self.hardening = Hardening(self.cfg, self.runner, self.net, self.paths, resolv=self.resolv,
                                   sysctl_root=self.sysctl, nm_dropin=sysdir / "nm.conf")
        self.history = History(None)
        self.bus = EventBus()
        self.events = []
        self.bus.subscribe(self.events.append)
        self.echo = SimEcho(self.world)
        self.resolver = StubResolver()
        self.resolver.ks = self.ks
        self.backends = {p: SimBackend(self.world, p, self.cfg.vpn, self.runner, self.paths, self.net)
                         for p in ("wireguard", "openvpn")}
        self.mgr = VpnManager(self.cfg, self.runner, self.net, self.store, self.ks, self.hardening, self.resolver,
                              self.echo, self.history, self.bus, self.backends, rng=random.Random(1))
        self.mgr.require_global_exit = False
        self.probes = SimProbes(self.world)
        self.checker = PrivacyChecker(self.cfg, self.mgr, self.hardening, self.ks, self.net, self.echo, self.probes)

    def close(self) -> None:
        self.history.close()

    def profiles(self, protocol: str | None = None):
        return [p for p in self.store.list(protocol=protocol)]

    def kinds(self) -> list[str]:
        return [e.kind for e in self.events]

    def last_event(self, kind: str):
        return next((e for e in reversed(self.events) if e.kind == kind), None)
