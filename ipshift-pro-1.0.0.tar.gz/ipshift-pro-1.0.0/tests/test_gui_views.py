"""The dashboard view-models: every word and every button rule, without Qt or a daemon."""
from __future__ import annotations

import unittest

import helpers  # noqa: F401  (puts src/ on the path)
import guifix
from ipshift.gui import views
from ipshift.gui.views import BAD, GOOD, INFO, MUTED, PLAIN, WARN


class BannerTests(unittest.TestCase):
    def test_each_protection_level_has_its_own_title_and_tone(self):
        cases = {"protected": ("PROTECTED", GOOD), "connecting": ("CONNECTING", INFO), "blocked": ("BLOCKED", WARN),
                 "no-killswitch": ("NO KILL SWITCH", WARN), "unprotected": ("UNPROTECTED", BAD)}
        for level, (title, tone) in cases.items():
            b = views.banner_view(guifix.status(protection={"level": level, "message": "m"}))
            self.assertEqual((b.title, b.tone, b.detail), (title, tone, "m"), level)

    def test_an_unknown_level_is_shown_as_is_and_muted(self):
        b = views.banner_view(guifix.status(protection={"level": "strange", "message": ""}))
        self.assertEqual((b.title, b.tone), ("STRANGE", MUTED))

    def test_no_status_means_the_daemon_is_not_reachable(self):
        b = views.banner_view(None, "permission denied on /run/ipshift/ipshift.sock")
        self.assertEqual((b.level, b.tone), ("offline", WARN))
        self.assertIn("permission denied", b.detail)
        self.assertIn("cannot reach", views.banner_view(None).detail)


class VpnCardTests(unittest.TestCase):
    def test_connected(self):
        v = views.vpn_view(guifix.status())
        self.assertEqual((v.badge, v.tone, v.connected, v.working), ("CONNECTED", GOOD, True, False))
        self.assertEqual((v.profile, v.facts, v.iface), ("NL 1", "wireguard, paid, NL", "ipshift0"))
        self.assertEqual((v.uptime, v.handshake, v.server), ("1 min 35 s", "12 s ago", "203.0.113.9:51820/udp"))
        self.assertEqual(v.note, "")

    def test_connecting_and_switching_show_what_the_daemon_is_doing(self):
        for state in ("connecting", "switching"):
            st = guifix.idle()
            st["vpn"]["state"], st["vpn"]["busy"] = state, "bringing the tunnel up"
            v = views.vpn_view(st)
            self.assertEqual((v.badge, v.tone, v.working, v.connected), (state.upper(), INFO, True, False))
            self.assertEqual(v.note, "bringing the tunnel up ...")

    def test_failed_shows_the_error_in_red(self):
        st = guifix.idle()
        st["vpn"]["state"], st["vpn"]["last_error"] = "failed", "handshake did not complete"
        v = views.vpn_view(st)
        self.assertEqual((v.badge, v.tone, v.note_tone), ("FAILED", BAD, BAD))
        self.assertIn("handshake did not complete", v.note)

    def test_disconnected_after_an_error_is_a_warning_not_an_alarm(self):
        st = guifix.idle()
        st["vpn"]["last_error"] = "timeout"
        v = views.vpn_view(st)
        self.assertEqual((v.badge, v.tone, v.note_tone), ("DISCONNECTED", MUTED, WARN))
        self.assertEqual((v.profile, v.uptime, v.handshake, v.iface), ("-", "-", "-", "-"))

    def test_a_connected_vpn_without_a_handshake_reading_shows_a_dash(self):
        st = guifix.status()
        st["vpn"]["health"] = {}
        self.assertEqual(views.vpn_view(st).handshake, "-")


class PublicIpTests(unittest.TestCase):
    def test_protected_shows_the_tunnel_address_as_verified(self):
        v = views.public_ip_view(guifix.status(), now=1000.0)
        self.assertEqual((v.value, v.tone, v.offer_direct), ("198.51.100.7", GOOD, False))
        self.assertEqual(v.note, "seen through the tunnel, verified 10 s ago")
        self.assertEqual(v.v6, "none (the tunnel carries no IPv6)")

    def test_a_tunnel_without_a_kill_switch_is_not_called_good(self):
        st = guifix.status(protection={"level": "no-killswitch", "message": "x"})
        self.assertEqual(views.public_ip_view(st).tone, WARN)

    def test_ipv6_is_shown_when_the_tunnel_carries_it(self):
        st = guifix.status(public={"v4": "198.51.100.7", "v6": "2001:db8::7", "source": "tunnel", "verified_at": None})
        v = views.public_ip_view(st)
        self.assertEqual(v.v6, "2001:db8::7")
        self.assertEqual(v.note, "seen through the tunnel")

    def test_unprotected_hides_the_address_and_offers_a_lookup(self):
        v = views.public_ip_view(guifix.idle("unprotected"))
        self.assertEqual((v.value, v.offer_direct, v.tone), ("hidden", True, MUTED))
        self.assertIn("Not looked up", v.note)

    def test_a_requested_real_address_is_shown_in_red_and_the_offer_goes_away(self):
        direct = {"public": {"v4": "192.0.2.77", "v6": None, "source": "direct"}}
        v = views.public_ip_view(guifix.idle("unprotected"), direct=direct)
        self.assertEqual((v.value, v.tone, v.offer_direct), ("192.0.2.77", BAD, False))
        self.assertIn("real, unprotected", v.note)

    def test_a_lookup_that_found_nothing_keeps_the_offer(self):
        direct = {"public": {"v4": None, "v6": None, "source": None}}
        self.assertTrue(views.public_ip_view(guifix.idle("unprotected"), direct=direct).offer_direct)

    def test_blocked_and_connecting(self):
        b = views.public_ip_view(guifix.idle("blocked"))
        self.assertEqual((b.value, b.tone, b.offer_direct), ("none", WARN, False))
        c = views.public_ip_view(guifix.idle("blocked", protection={"level": "connecting", "message": ""}))
        self.assertEqual((c.value, c.tone), ("...", INFO))

    def test_an_unknown_level_shows_a_dash(self):
        v = views.public_ip_view(guifix.idle(protection={"level": "?", "message": ""}))
        self.assertEqual((v.value, v.tone), ("-", MUTED))


class PrivateIpTests(unittest.TestCase):
    def test_ipv4_addresses_with_their_interface_and_role(self):
        rows = views.private_ip_rows(guifix.status())
        self.assertEqual([(r.ip, r.iface, r.tags, r.tunnel) for r in rows],
                         [("192.168.1.23", "wlan0", "Wi-Fi, default route", False),
                          ("10.2.0.2", "ipshift0", "VPN tunnel", True)])

    def test_ipv6_only_hosts_still_show_something(self):
        st = guifix.status()
        st["network"]["private_ips"] = [p for p in st["network"]["private_ips"] if p["family"] == 6]
        self.assertEqual([r.ip for r in views.private_ip_rows(st)], ["fd00::23"])

    def test_no_addresses(self):
        st = guifix.status()
        st["network"]["private_ips"] = []
        self.assertEqual(views.private_ip_rows(st), ())

    def test_a_hotspot_is_named_in_the_network_text(self):
        d = views.dashboard_view(guifix.status(network={"default_iface": "wlan0", "gateway": "172.20.10.1",
                                                        "kind": "wifi", "hotspot": "iPhone hotspot",
                                                        "private_ips": []}))
        self.assertEqual(d.network, "iPhone hotspot on wlan0, gateway 172.20.10.1")


class RotationTests(unittest.TestCase):
    def test_running(self):
        r = views.rotation_view(guifix.status())
        self.assertEqual((r.running, r.interval, r.minimum, r.tone), (True, 1.0, 1.0, GOOD))
        self.assertEqual(r.state, "Running: a new address every 1 s")
        self.assertEqual(r.counts, "8 changed, 1 failed, 1 unchanged, 0 skipped")
        self.assertEqual((r.last, r.last_tone), ("Last: changed NL 1 198.51.100.7 in 850 ms", GOOD))
        self.assertEqual(r.problem, "")

    def test_stopped_shows_the_interval_the_next_start_will_use(self):
        r = views.rotation_view(guifix.idle())
        self.assertEqual((r.running, r.state, r.interval, r.tone, r.counts), (False, "Stopped", 30.0, MUTED, ""))

    def test_stalled_is_critical(self):
        st = guifix.status()
        st["rotation"].update(stalled=True, consecutive_failures=5)
        r = views.rotation_view(st)
        self.assertEqual(r.problem_tone, BAD)
        self.assertIn("STALLED: 5 failures in a row", r.problem)

    def test_a_few_failures_are_a_warning(self):
        st = guifix.status()
        st["rotation"]["consecutive_failures"] = 2
        r = views.rotation_view(st)
        self.assertEqual((r.problem, r.problem_tone), ("2 failure(s) in a row", WARN))

    def test_last_result_wording_and_tones(self):
        for status_, word, tone in (("unchanged", "same address", WARN), ("failed", "failed", BAD)):
            st = guifix.status()
            st["rotation"]["last"] = {"status": status_, "profile": "X", "ip": None, "ms": None,
                                      "error": "e" * 200}
            r = views.rotation_view(st)
            self.assertTrue(r.last.startswith(f"Last: {word} X"), r.last)
            self.assertEqual(r.last_tone, tone)
            self.assertLess(len(r.last), 130, "a long error must be cut")

    def test_the_minimum_defaults_to_the_one_second_floor(self):
        st = guifix.status()
        del st["rotation"]["minimum_interval"]
        self.assertEqual(views.rotation_view(st).minimum, 1.0)

    def test_countdown_runs_down_between_updates_and_never_goes_negative(self):
        st = guifix.status()                                   # next_in is 0.6 s
        self.assertEqual(views.countdown_text(st, received_at=10.0, now=10.0), "next change in 0.6 s")
        self.assertEqual(views.countdown_text(st, received_at=10.0, now=10.4), "next change in 0.2 s")
        self.assertEqual(views.countdown_text(st, received_at=10.0, now=15.0), "next change in 0.0 s")

    def test_no_countdown_when_stopped_or_unknown(self):
        self.assertEqual(views.countdown_text(guifix.idle(), 0.0, 1.0), "")
        self.assertEqual(views.countdown_text(None, 0.0, 1.0), "")
        st = guifix.status()
        st["rotation"]["next_in"] = None
        self.assertEqual(views.countdown_text(st, 0.0, 1.0), "")


class IntervalTests(unittest.TestCase):
    def test_the_floor_is_one_second_and_the_ceiling_a_day(self):
        self.assertEqual(views.clean_interval(0.2), 1.0)
        self.assertEqual(views.clean_interval(-5), 1.0)
        self.assertEqual(views.clean_interval(1), 1.0)
        self.assertEqual(views.clean_interval("2.5"), 2.5)
        self.assertEqual(views.clean_interval(1e9), 86400.0)

    def test_garbage_falls_back_to_the_default(self):
        for bad in ("abc", None, float("nan"), [], {}):
            self.assertEqual(views.clean_interval(bad, default=30.0), 30.0, repr(bad))

    def test_advice_warns_about_openvpn_at_short_intervals_only(self):
        mixed = {"profiles": [{"id": "a", "protocol": "openvpn"}, {"id": "b", "protocol": "wireguard"}],
                 "in_rotation": ["a", "b"]}
        text = views.interval_advice(mixed, 1.0)
        self.assertIn("1 OpenVPN profile(s)", text)
        self.assertIn("WireGuard profiles can switch in about a second", text)
        self.assertEqual(views.interval_advice(mixed, 5.0), "")
        self.assertEqual(views.interval_advice(mixed, None), "")
        self.assertEqual(views.interval_advice(None, 1.0), "")

    def test_advice_ignores_profiles_that_are_not_in_the_rotation(self):
        data = {"profiles": [{"id": "a", "protocol": "openvpn"}], "in_rotation": []}
        self.assertEqual(views.interval_advice(data, 1.0), "")
        data = {"profiles": [{"id": "b", "protocol": "wireguard"}], "in_rotation": ["b"]}
        self.assertEqual(views.interval_advice(data, 1.0), "")


class KillSwitchTests(unittest.TestCase):
    def test_armed(self):
        k = views.killswitch_view(guifix.status())
        self.assertEqual((k.badge, k.tone, k.armed, k.lockdown), ("ARMED", GOOD, True, False))
        self.assertEqual(k.detail, "LAN blocked, 12 packets blocked")
        self.assertEqual(k.endpoints, "Allowed to leave: only the VPN server 203.0.113.9:51820/udp")

    def test_one_packet_is_singular_and_lan_allowed_is_said(self):
        st = guifix.status()
        st["killswitch"].update(blocked_packets=1, allow_lan=True)
        self.assertEqual(views.killswitch_view(st).detail, "LAN allowed, 1 packet blocked")

    def test_lockdown(self):
        st = guifix.idle("blocked")
        st["killswitch"].update(lockdown=True, endpoints=["203.0.113.9:51820/udp"])
        k = views.killswitch_view(st)
        self.assertEqual((k.badge, k.tone, k.lockdown, k.endpoints), ("LOCKDOWN", BAD, True, ""))
        self.assertIn("including the VPN", k.detail)

    def test_not_armed_off_and_unknown(self):
        self.assertEqual(views.killswitch_view(guifix.idle()).badge, "NOT ARMED")
        st = guifix.idle()
        st["killswitch"]["enabled"] = False
        k = views.killswitch_view(st)
        self.assertEqual((k.badge, k.enabled), ("OFF", False))
        st["killswitch"] = {"armed": False, "error": "nft failed", "enabled": True}
        k = views.killswitch_view(st)
        self.assertEqual((k.badge, k.tone, k.detail), ("UNKNOWN", BAD, "nft failed"))

    def test_dry_run_is_mentioned(self):
        st = guifix.status()
        st["killswitch"]["dry_run"] = True
        self.assertIn("dry run", views.killswitch_view(st).detail)


class HardeningTests(unittest.TestCase):
    def rows(self, **h):
        st = guifix.status()
        st["hardening"].update(h)
        return {r.label: r for r in views.hardening_rows(st)}

    def test_locked_dns_and_ipv6_guard_are_good(self):
        r = self.rows()
        self.assertEqual((r["DNS"].text, r["DNS"].tone), ("Locked to 10.0.0.1", GOOD))
        self.assertEqual((r["IPv6"].text, r["IPv6"].tone), ("Switched off on the physical interfaces", GOOD))
        self.assertEqual((r["MAC address"].text, r["MAC address"].tone), ("Unchanged", MUTED))

    def test_tampering_is_red(self):
        r = self.rows(dns_intact=False, ipv6_intact=False)
        self.assertEqual((r["DNS"].tone, r["IPv6"].tone), (BAD, BAD))
        self.assertIn("changed by another program", r["DNS"].text)
        self.assertIn("changed by another program", r["IPv6"].text)

    def test_unlocked_is_muted_and_says_when_it_happens(self):
        r = self.rows(dns_locked=False, ipv6_guard=False)
        self.assertEqual((r["DNS"].tone, r["IPv6"].tone), (MUTED, MUTED))
        self.assertIn("locked while connected", r["DNS"].text)

    def test_mac_policy_and_overrides(self):
        r = self.rows(mac_nm_policy=True, mac_overrides=["wlan0"])
        self.assertEqual(r["MAC address"].tone, GOOD)
        self.assertEqual(r["MAC address"].text, "random MAC for each new connection, changed by hand on wlan0")


class ProblemTests(unittest.TestCase):
    def texts(self, st):
        return [p.text for p in views.problems(st)]

    def test_a_healthy_session_has_no_problems(self):
        self.assertEqual(views.problems(guifix.status()), ())
        self.assertEqual(views.problems(None), ())

    def test_stalled_rotation(self):
        st = guifix.status()
        st["rotation"].update(stalled=True, consecutive_failures=4)
        p = views.problems(st)[0]
        self.assertEqual(p.tone, BAD)
        self.assertIn("stalled after 4 failures", p.text)
        self.assertIn("Profiles page", p.hint)

    def test_failed_vpn(self):
        st = guifix.idle()
        st["vpn"].update(state="failed", last_error="auth failed")
        self.assertIn("The VPN connection failed: auth failed", self.texts(st))

    def test_tampered_dns_and_ipv6(self):
        st = guifix.status()
        st["hardening"].update(dns_intact=False, ipv6_intact=False)
        t = " ".join(self.texts(st))
        self.assertIn("changed the DNS settings", t)
        self.assertIn("switched IPv6 back on", t)

    def test_unknown_kill_switch_state(self):
        st = guifix.idle()
        st["killswitch"] = {"armed": False, "error": "nft: permission denied", "enabled": True}
        self.assertIn("The kill switch state is unknown: nft: permission denied", self.texts(st))

    def test_connected_without_a_kill_switch(self):
        st = guifix.status(protection={"level": "no-killswitch", "message": ""})
        self.assertTrue(any("without a kill switch" in t for t in self.texts(st)))

    def test_no_profiles_is_information_and_no_usable_one_is_a_warning(self):
        none = views.problems(guifix.idle(profiles={"total": 0, "usable": 0}))
        self.assertEqual((none[0].tone, none[0].text), (INFO, "No VPN profiles yet."))
        unusable = views.problems(guifix.idle(profiles={"total": 3, "usable": 0}))
        self.assertEqual((unusable[0].tone, unusable[0].text), (WARN, "No VPN profile is usable right now."))

    def test_the_most_serious_come_first(self):
        st = guifix.status(protection={"level": "no-killswitch", "message": ""})
        st["rotation"].update(stalled=True, consecutive_failures=3)
        st["hardening"]["dns_intact"] = False
        tones = [p.tone for p in views.problems(st)]
        self.assertEqual(tones, sorted(tones, key=lambda t: {BAD: 0, WARN: 1, INFO: 2}[t]))


class AlertTests(unittest.TestCase):
    EVENTS = [
        {"kind": "connected", "level": "info", "ts": 100.0, "data": {"name": "A", "ip": "198.51.100.1"}},
        {"kind": "connect_failed", "level": "error", "ts": 101.0, "data": {"name": "B", "error": "timeout",
                                                                         "hint": "try another"}},
        {"kind": "network_changed", "level": "warning", "ts": 102.0, "data": {"message": "Wi-Fi changed"}},
        {"kind": "tunnel_lost", "level": "critical", "ts": 103.0, "data": {"message": "The VPN dropped"}},
    ]

    def test_only_warnings_and_worse_newest_first(self):
        rows = views.alert_rows(self.EVENTS)
        self.assertEqual([r.kind for r in rows], ["tunnel_lost", "network_changed", "connect_failed"])
        self.assertEqual([r.tone for r in rows], [BAD, WARN, BAD])

    def test_text_and_hint(self):
        rows = {r.kind: r for r in views.alert_rows(self.EVENTS)}
        self.assertEqual(rows["connect_failed"].text, "Could not connect to B: timeout")
        self.assertEqual(rows["connect_failed"].hint, "try another")
        self.assertEqual(rows["tunnel_lost"].text, "The VPN dropped")
        self.assertEqual(rows["tunnel_lost"].hint, "")

    def test_the_list_is_capped(self):
        many = [{"kind": "network_changed", "level": "warning", "ts": float(i), "data": {"message": str(i)}}
                for i in range(200)]
        rows = views.alert_rows(many, limit=50)
        self.assertEqual(len(rows), 50)
        self.assertEqual(rows[0].text, "199")

    def test_nothing(self):
        self.assertEqual(views.alert_rows(None), ())
        self.assertEqual(views.alert_rows([]), ())

    def test_only_errors_and_critical_events_interrupt_with_a_notification(self):
        notes = [views.notification_for(e) for e in self.EVENTS]
        self.assertEqual(notes[0], None)
        self.assertEqual(notes[1], ("VPN connection failed", "Could not connect to B: timeout"))
        self.assertEqual(notes[2], None)                      # a warning is listed, not announced
        self.assertEqual(notes[3], ("VPN connection lost", "The VPN dropped"))

    def test_an_unlisted_critical_kind_gets_a_generic_title(self):
        ev = {"kind": "something_new", "level": "critical", "ts": 1.0, "data": {"message": "bad"}}
        self.assertEqual(views.notification_for(ev), ("IPShift alert", "bad"))


class StopOptionTests(unittest.TestCase):
    def test_three_choices_and_only_the_last_exposes_the_address(self):
        self.assertEqual([o.key for o in views.STOP_OPTIONS], ["rotation", "block", "release"])
        self.assertEqual([o.risky for o in views.STOP_OPTIONS], [False, False, True])

    def test_each_choice_maps_to_the_daemons_flags(self):
        self.assertEqual(views.stop_kwargs("rotation"), {"keep_vpn": True})
        self.assertEqual(views.stop_kwargs("block"), {"keep_blocking": True})
        self.assertEqual(views.stop_kwargs("release"), {})
        with self.assertRaises(KeyError):
            views.stop_kwargs("explode")


class StopChoiceTests(unittest.TestCase):
    def keys(self, st):
        return [o.key for o in views.stop_choices(st)]

    def test_a_running_rotation_offers_all_three_safest_first(self):
        self.assertEqual(self.keys(guifix.status()), ["rotation", "block", "release"])

    def test_a_manual_connection_has_no_rotation_to_stop(self):
        st = guifix.status()
        st["rotation"]["running"] = False
        self.assertEqual(self.keys(st), ["block", "release"])

    def test_a_blocking_firewall_without_a_vpn_can_only_be_released(self):
        self.assertEqual(self.keys(guifix.idle("blocked")), ["release"])

    def test_a_connection_in_progress_can_be_dropped_and_kept_blocked(self):
        st = guifix.idle()
        st["vpn"]["state"] = "connecting"
        self.assertEqual(self.keys(st), ["block", "release"])

    def test_nothing_without_a_daemon(self):
        self.assertEqual(views.stop_choices(None), ())

    def test_the_preselected_choice_never_exposes_the_real_address(self):
        for st in (guifix.status(), guifix.idle("blocked")):
            first = views.stop_choices(st)[0]
            if len(views.stop_choices(st)) > 1:
                self.assertFalse(first.risky)


class ControlTests(unittest.TestCase):
    def test_no_daemon_disables_everything(self):
        c = views.controls_view(None)
        self.assertFalse(any((c.can_start, c.can_stop, c.can_rotate_now, c.can_cancel, c.can_edit_interval)))

    def test_idle_with_profiles_can_start_but_has_nothing_to_stop(self):
        c = views.controls_view(guifix.idle())
        self.assertEqual((c.can_start, c.can_stop, c.can_rotate_now, c.can_cancel, c.can_edit_interval),
                         (True, False, True, False, True))
        self.assertEqual(c.start_hint, "")

    def test_a_running_rotation_can_be_stopped_not_started_again(self):
        c = views.controls_view(guifix.status())
        self.assertEqual((c.can_start, c.can_stop), (False, True))
        self.assertEqual(c.start_hint, "The rotation is already running.")

    def test_a_blocking_firewall_can_be_released_with_stop(self):
        self.assertTrue(views.controls_view(guifix.idle("blocked")).can_stop)

    def test_a_manual_connection_in_progress_can_be_cancelled(self):
        st = guifix.idle()
        st["vpn"]["state"] = "connecting"
        c = views.controls_view(st)
        self.assertEqual((c.can_cancel, c.can_start, c.can_rotate_now, c.can_stop), (True, False, False, True))
        self.assertIn("Busy", c.start_hint)

    def test_while_rotating_a_switch_in_flight_is_not_cancelled_by_itself(self):
        st = guifix.status()
        st["vpn"]["state"] = "switching"
        self.assertFalse(views.controls_view(st).can_cancel)

    def test_a_command_in_flight_blocks_the_other_connection_commands(self):
        for name in ("connect", "rotate_start", "rotate_now", "stop", "lockdown", "killswitch_on"):
            c = views.controls_view(guifix.idle(), frozenset({name}))
            self.assertFalse(c.can_start, name)
            self.assertFalse(c.can_rotate_now, name)

    def test_a_stop_in_flight_cannot_be_repeated(self):
        self.assertFalse(views.controls_view(guifix.status(), frozenset({"stop"})).can_stop)

    def test_unrelated_commands_in_flight_do_not_block_anything(self):
        c = views.controls_view(guifix.idle(), frozenset({"privacy_check", "history_export", "config_set"}))
        self.assertTrue(c.can_start and c.can_rotate_now)

    def test_no_usable_profile_explains_where_to_get_one(self):
        c = views.controls_view(guifix.idle(profiles={"total": 0, "usable": 0}))
        self.assertEqual((c.can_start, c.can_rotate_now), (False, False))
        self.assertIn("Profiles page", c.start_hint)


class KillSwitchButtonTests(unittest.TestCase):
    def flags(self, st, busy=frozenset()):
        c = views.controls_view(st, busy)
        return c.can_arm, c.can_release, c.can_lockdown

    def test_nothing_without_a_daemon(self):
        self.assertEqual(self.flags(None), (False, False, False))

    def test_an_open_firewall_can_be_armed_not_released(self):
        self.assertEqual(self.flags(guifix.idle()), (True, False, True))

    def test_an_armed_firewall_can_be_released_not_armed_again(self):
        self.assertEqual(self.flags(guifix.idle("blocked")), (False, True, True))

    def test_lockdown_is_released_but_not_repeated(self):
        st = guifix.idle("blocked")
        st["killswitch"]["lockdown"] = True
        self.assertEqual(self.flags(st), (False, True, False))

    def test_a_disabled_kill_switch_cannot_be_armed_from_the_dashboard(self):
        st = guifix.idle()
        st["killswitch"]["enabled"] = False
        self.assertEqual(self.flags(st), (False, False, True))

    def test_arming_and_releasing_wait_for_a_connection_attempt_but_the_panic_button_does_not(self):
        st = guifix.idle()
        st["vpn"]["state"] = "connecting"
        self.assertEqual(self.flags(st), (False, False, True))
        st = guifix.idle("blocked")
        st["vpn"]["state"] = "switching"
        self.assertEqual(self.flags(st), (False, False, True))

    def test_a_protected_connection_can_be_released_or_locked_down_after_a_confirmation(self):
        self.assertEqual(self.flags(guifix.status()), (False, True, True))

    def test_any_connection_command_in_flight_blocks_arming_and_releasing_but_not_the_panic_button(self):
        for name in ("connect", "rotate_start", "rotate_now", "stop"):
            self.assertEqual(self.flags(guifix.status(), frozenset({name})), (False, False, True), name)

    def test_a_lockdown_in_flight_is_not_repeated(self):
        self.assertFalse(views.controls_view(guifix.idle(), frozenset({"lockdown"})).can_lockdown)

    def test_a_kill_switch_command_in_flight_blocks_the_other_two(self):
        for name in ("killswitch_on", "killswitch_off"):
            self.assertEqual(self.flags(guifix.idle("blocked"), frozenset({name})), (False, False, True), name)


class DashboardTests(unittest.TestCase):
    def test_equal_data_gives_equal_views_so_the_window_can_skip_redrawing(self):
        a = views.dashboard_view(guifix.status(), now=1000.0)
        b = views.dashboard_view(guifix.status(), now=1000.0)
        self.assertEqual(a, b)
        self.assertNotEqual(a, views.dashboard_view(guifix.idle(), now=1000.0))

    def test_no_daemon(self):
        d = views.dashboard_view(None, link_error="not running")
        self.assertEqual((d.banner.level, d.banner.detail), ("offline", "not running"))
        self.assertFalse(d.controls.can_start)
        self.assertEqual(d.private, ())

    def test_the_daemon_line_and_simulation_flag(self):
        st = guifix.status()
        st["daemon"]["simulated"] = True
        d = views.dashboard_view(st)
        self.assertTrue(d.simulated)
        self.assertEqual(d.daemon, "IPShift Pro 1.0.0, daemon pid 42, up 2 min 05 s")

    def test_profiles_and_privacy_lines(self):
        d = views.dashboard_view(guifix.status(profiles={"total": 8, "usable": 5}))
        self.assertEqual(d.profiles, "5 usable of 8")
        self.assertEqual(views.dashboard_view(guifix.idle(profiles={"total": 0, "usable": 0})).profiles, "none imported")
        self.assertEqual((d.privacy_tone, d.privacy.startswith("Not tested")), (MUTED, True))
        st = guifix.status(privacy={"score": 87, "grade": "B", "verdict": "protected-with-warnings", "ts": 990.0,
                                    "headline": "x"})
        d = views.dashboard_view(st, now=1000.0)
        self.assertEqual(d.privacy, "Grade B (87/100): protected-with-warnings, checked 10 s ago")
        self.assertEqual(d.privacy_tone, GOOD)

    def test_every_view_copes_with_the_daemons_real_answers_in_every_state(self):
        for st in (guifix.status(), guifix.idle("unprotected"), guifix.idle("blocked"),
                   guifix.status(protection={"level": "connecting", "message": ""}),
                   guifix.status(protection={"level": "no-killswitch", "message": ""}),
                   guifix.status(vpn={"state": "failed", "connected": False, "last_error": "x", "profile": None})):
            d = views.dashboard_view(st)
            for tone in (d.banner.tone, d.vpn.tone, d.public.tone, d.rotation.tone, d.killswitch.tone, d.privacy_tone):
                self.assertIn(tone, views.TONES)

    def test_the_floor_constant_is_the_daemons(self):
        from ipshift.config import MIN_INTERVAL
        self.assertEqual(views.clean_interval(0), MIN_INTERVAL)
        self.assertEqual(MIN_INTERVAL, 1.0)


if __name__ == "__main__":
    unittest.main()
