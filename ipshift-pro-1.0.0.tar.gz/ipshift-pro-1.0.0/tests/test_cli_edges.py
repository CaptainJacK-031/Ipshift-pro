"""The ipshift command where things go wrong or there is no daemon: fallbacks, Ctrl-C, errors, the real entry point."""
from __future__ import annotations

import io
import json
import os
import subprocess
import sys
import unittest
from pathlib import Path
from unittest import mock

from helpers import TmpRootCase

from ipshift.cli import main, standalone
from ipshift.cli import commands as cmds
from ipshift.config import Config
from ipshift.daemon import Daemon
from ipshift.errors import DaemonUnavailable, PrivilegeError, VpnError
from ipshift.paths import default_paths

ROOT = Path(__file__).resolve().parents[1]

SUMMARY = {"default_iface": "eth0", "gateway": "192.0.2.1", "kind": "ethernet", "hotspot": None,
           "private_ips": [{"iface": "eth0", "ip": "192.0.2.2", "prefix": 24, "family": 4, "scope": "documentation",
                            "kind": "ethernet", "primary": True}]}


class FakeNet:
    def __init__(self, runner=None, ip_bin="ip"):
        pass

    def summary(self):
        return dict(SUMMARY)


class FakeKs:
    armed = False

    def __init__(self, *a, **kw):
        pass

    def is_armed(self):
        return FakeKs.armed


class TTY(io.StringIO):
    def isatty(self):
        return True


class Stub:
    """A daemon client that answers from a table and records what it was asked."""

    def __init__(self, **handlers):
        self.calls: list[tuple] = []
        self._handlers = handlers

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)

        def call(*args, **kw):
            self.calls.append((name, args, kw))
            if name not in self._handlers:
                raise AssertionError(f"unexpected call: {name}")
            return self._handlers[name](*args, **kw)
        return call

    def names(self):
        return [c[0] for c in self.calls]


def run(argv, *, client=None, stdin="", tty=False, **kw):
    out, err = io.StringIO(), TTY() if tty else io.StringIO()
    inp = TTY(stdin) if tty else io.StringIO(stdin)
    extra = {"client_factory": lambda sock: client} if client is not None else {}
    code = main(argv, out=out, err=err, inp=inp, sleep=lambda s: None, **extra, **kw)
    return code, out.getvalue(), err.getvalue()


class NoDaemonTests(TmpRootCase):
    """Nothing listens on the socket."""

    def setUp(self):
        super().setUp()
        self.sock = str(self.tmp / "nothing-here.sock")
        for target, fake in (("NetInfo", FakeNet), ("KillSwitch", FakeKs)):
            p = mock.patch.object(standalone, target, fake)
            p.start()
            self.addCleanup(p.stop)
        FakeKs.armed = False

    def cli(self, *argv, **kw):
        return run(["--socket", self.sock, *argv], **kw)

    def test_every_command_that_needs_the_daemon_says_so_and_exits_with_three(self):
        for argv in (["vpn", "connect"], ["vpn", "list"], ["vpn", "disconnect"], ["rotate"], ["rotate", "--now"], ["stop"],
                     ["privacy-check"], ["killswitch"], ["killswitch", "on"], ["config"], ["history"], ["harden"],
                     ["events"], ["vpn", "reset"], ["vpn", "cancel"]):
            code, out, err = self.cli(*argv)
            self.assertEqual(code, 3, argv)
            self.assertIn("daemon is not running", err, argv)
            self.assertIn("hint:", err, argv)
            self.assertEqual(out, "", argv)

    def test_status_still_shows_what_can_be_seen_locally(self):
        code, out, err = self.cli("status")
        self.assertEqual(code, 3)
        self.assertIn("not running", err)
        self.assertIn("not reachable", out)
        self.assertIn("Ethernet (eth0, 192.0.2.2)", out)
        self.assertIn("unknown (run as root to look)" if os.geteuid() else "not armed", out)

    def test_status_notices_firewall_rules_left_by_an_earlier_run(self):
        FakeKs.armed = True
        with mock.patch.object(standalone, "is_root", lambda: True):
            code, out, _ = self.cli("status")
        self.assertEqual(code, 3)
        self.assertIn("firewall rules from IPShift are blocking traffic", out)
        self.assertIn("sudo ipshift restore", out)

    def test_status_json_without_a_daemon(self):
        code, out, err = self.cli("--json", "status")
        self.assertEqual(code, 3)
        data = json.loads(out)
        self.assertIsNone(data["daemon"])
        self.assertEqual(data["error"]["code"], "daemon_unavailable")
        self.assertEqual(data["local"]["network"], "Ethernet (eth0, 192.0.2.2)")

    def test_watch_survives_the_daemon_going_away(self):
        code, out, _ = self.cli("status", "--watch", "--count", "2")
        self.assertEqual(code, 0)
        self.assertEqual(out.count("daemon not reachable"), 2)

    def test_ip_falls_back_to_local_facts(self):
        code, out, _ = self.cli("ip")
        self.assertEqual(code, 0)
        self.assertIn("192.0.2.2", out)
        self.assertIn("The daemon is not running, so the VPN state is unknown", out)
        self.assertIn("ipshift ip --direct", out)
        self.assertIn("UNKNOWN", out)

    def test_ip_private_works_and_public_does_not(self):
        code, out, _ = self.cli("ip", "--private")
        self.assertEqual((code, out), (0, "192.0.2.2\n"))
        code, out, err = self.cli("ip", "--public")
        self.assertEqual((code, out), (1, ""))
        self.assertIn("no public address", err)

    def test_direct_lookup_needs_no_daemon(self):
        class Echo:
            def __init__(self, privacy):
                pass

            def lookup(self, family=4, **kw):
                return mock.Mock(ok=family == 4, ip="203.0.113.99" if family == 4 else None, error=None)
        with mock.patch.object(standalone, "EchoResolver", Echo):
            code, out, _ = self.cli("ip", "--direct")
            self.assertEqual(code, 0)
            self.assertIn("203.0.113.99", out)
            self.assertIn("no VPN involved", out)
            code, out, _ = self.cli("ip", "--direct", "--public")
            self.assertEqual((code, out), (0, "203.0.113.99\n"))

    def test_direct_lookup_failure_is_explained(self):
        class Echo:
            def __init__(self, privacy):
                pass

            def lookup(self, family=4, **kw):
                return mock.Mock(ok=False, ip=None, error="no echo service answered (timed out x4)")
        with mock.patch.object(standalone, "EchoResolver", Echo):
            code, out, _ = self.cli("ip", "--direct")
        self.assertEqual(code, 0)
        self.assertIn("could not be looked up (no echo service answered (timed out x4))", out)

    def test_direct_lookup_is_skipped_when_our_firewall_blocks_everything(self):
        FakeKs.armed = True
        with mock.patch.object(standalone, "is_root", lambda: True), \
                mock.patch.object(standalone, "EchoResolver", side_effect=AssertionError("must not look up")):
            code, out, _ = self.cli("ip", "--direct")
        self.assertEqual(code, 0)
        self.assertIn("still in place and block all traffic", out)
        self.assertIn("BLOCKED", out)

    def test_doctor_runs_without_the_daemon_and_reports_it(self):
        code, out, _ = self.cli("doctor")
        self.assertIn("IPShift doctor", out)
        self.assertIn("Daemon", out)
        self.assertIn("the IPShift daemon is not running", out)
        self.assertIn("sudo systemctl start ipshiftd", out)
        rep = json.loads(self.cli("--json", "doctor")[1])
        self.assertFalse(rep["daemon"])
        self.assertEqual(rep["checks"][0]["id"], "daemon")
        self.assertEqual(sum(rep["summary"].values()), len(rep["checks"]))
        self.assertEqual(code, 0 if rep["ready"] else 1)

    def test_restore_without_root_and_without_a_daemon_asks_for_sudo(self):
        with mock.patch("ipshift.cli.manage.is_root", lambda: False):
            code, out, err = self.cli("restore")
        self.assertEqual((code, out), (1, ""))
        self.assertIn("needs root", err)
        self.assertIn("sudo ipshift restore", err)

    def test_restore_as_root_works_directly(self):
        report = {"killswitch": "removed", "dns": True, "ipv6": [], "mac": [], "openvpn_stopped": 0,
                  "tunnel_interface_removed": False}
        seen = {}

        def fake_restore(cfg, runner, net, paths, **kw):
            seen.update(kw, paths=paths)
            return report
        with mock.patch("ipshift.cli.manage.is_root", lambda: True), mock.patch.object(standalone, "is_root", lambda: True), \
                mock.patch.object(standalone, "restore_all", fake_restore):
            code, out, err = self.cli("restore", "--keep-mac")
        self.assertEqual(code, 0, err)
        self.assertIn("the daemon is not running; restoring directly", err)
        self.assertIn("kill switch rules removed", out)
        self.assertFalse(seen["include_mac"])
        self.assertEqual(seen["paths"].config_file, self.tmp / "etc" / "config.json")     # root's paths, whoever asks

    def test_a_failed_firewall_removal_is_not_reported_as_success(self):
        report = {"killswitch": "FAILED: nft said no", "dns": False, "ipv6": [], "mac": [], "openvpn_stopped": 0,
                  "tunnel_interface_removed": False}
        with mock.patch("ipshift.cli.manage.is_root", lambda: True), mock.patch.object(standalone, "is_root", lambda: True), \
                mock.patch.object(standalone, "restore_all", lambda *a, **kw: report):
            code, out, _ = self.cli("restore")
        self.assertEqual(code, 1)
        self.assertIn("sudo nft delete table inet ipshift", out)

    def test_permission_denied_on_the_socket_is_not_mistaken_for_no_daemon_when_restoring(self):
        err = DaemonUnavailable("permission denied on /run/ipshift/ipshift.sock", hint="join the 'ipshift' group")
        client = Stub(restore=lambda **kw: (_ for _ in ()).throw(err))
        with mock.patch("ipshift.cli.manage.is_root", lambda: False):
            code, out, e = run(["restore"], client=client)
        self.assertEqual(code, 3)
        self.assertIn("permission denied", e)
        self.assertIn("ipshift' group", e)

    def test_config_problems_do_not_stop_the_fallbacks(self):
        bad = self.tmp / "bad.json"
        bad.write_text("{not json")
        code, out, err = self.cli("--config", str(bad), "ip", "--private")
        self.assertNotEqual(code, 0)                    # an explicitly named, broken file is an error ...
        self.assertIn("cannot read", err)
        etc = self.tmp / "etc"
        etc.mkdir()
        (etc / "config.json").write_text("{not json")
        code, out, _ = self.cli("ip", "--private")      # ... the daemon's own file falls back to the defaults
        self.assertEqual((code, out), (0, "192.0.2.2\n"))


class FollowAndInterruptTests(unittest.TestCase):
    EVENTS = [{"kind": "connecting", "level": "info", "ts": 1_700_000_000, "data": {"name": "A"}},
              {"kind": "connected", "level": "info", "ts": 1_700_000_001,
               "data": {"name": "A", "ip": "198.51.100.1", "previous": "198.51.100.9", "ms": 1200}},
              {"kind": "connect_failed", "level": "warning", "ts": 1_700_000_002,
               "data": {"name": "B", "error": "handshake timed out", "hint": "try another server"}}]

    @staticmethod
    def started(**kw):
        base = {"running": True, "interval": 1.0, "strategy": "diverse", "profiles_in_rotation": 4}
        return dict(base, **kw)

    def client(self, events, end="interrupt", **extra):
        def gen(min_level="info", replay=0):
            yield from events
            if end == "interrupt":
                raise KeyboardInterrupt
        return Stub(rotate_start=lambda *a, **kw: self.started(), profiles=lambda: {"profiles": [], "in_rotation": []},
                    events=gen, stop=lambda **kw: {"stopped": "all", "released": True}, **extra)

    def test_following_a_rotation_prints_results_and_hides_the_noise(self):
        c = self.client(self.EVENTS)
        code, out, _ = run(["rotate", "--interval", "1"], client=c)
        self.assertEqual(code, 0)
        self.assertIn("Following the rotation", out)
        self.assertNotIn("Connecting to A", out)                         # "connecting" is skipped at one tick per second
        self.assertIn("Connected to A: public IP 198.51.100.1 (was 198.51.100.9) in 1.2 s", out)
        self.assertIn("Could not connect to B: handshake timed out", out)
        self.assertIn("hint: try another server", out)
        self.assertIn("The rotation keeps running in the background; stop it with: ipshift stop", out)
        self.assertNotIn("stop", [n for n in c.names() if n == "stop"])      # Ctrl-C alone stops nothing

    def test_start_arguments_reach_the_daemon(self):
        c = self.client([])
        run(["rotate", "--interval", "2.5", "--no-immediate"], client=c)
        name, args, kw = c.calls[0]
        self.assertEqual((name, args, kw), ("rotate_start", (2.5,), {"immediate": False}))
        c = self.client([])
        run(["rotate"], client=c)
        self.assertEqual(c.calls[0][1:], ((None,), {"immediate": True}))

    def test_stop_on_exit_stops_everything(self):
        c = self.client(self.EVENTS)
        code, out, _ = run(["rotate", "--stop-on-exit"], client=c)
        self.assertEqual(code, 0)
        self.assertIn("stop", c.names())
        self.assertIn("normal networking is back", out)
        self.assertNotIn("keeps running", out)

    def test_losing_the_daemon_while_following_is_an_error(self):
        c = self.client(self.EVENTS[1:2], end="eof")
        code, out, err = run(["rotate"], client=c)
        self.assertEqual(code, 3)
        self.assertIn("lost the connection to the daemon", err)

    def test_json_follow_prints_one_event_per_line(self):
        c = self.client(self.EVENTS)
        code, out, _ = run(["--json", "rotate"], client=c)
        lines = out.strip().splitlines()
        docs = [json.loads(l) for l in lines]                  # every line parses on its own
        self.assertEqual(docs[0]["running"], True)                       # the start reply comes first
        self.assertEqual([d["kind"] for d in docs[1:]], ["connected", "connect_failed"])

    def test_events_follow_replays_and_filters_by_level(self):
        seen = {}

        def gen(min_level="info", replay=0):
            seen.update(min_level=min_level, replay=replay)
            yield from self.EVENTS
            raise KeyboardInterrupt
        c = Stub(events=gen)
        code, out, _ = run(["events", "--follow", "--level", "warning", "-n", "7"], client=c)
        self.assertEqual(code, 0)
        self.assertEqual(seen, {"min_level": "warning", "replay": 7})
        self.assertIn("Connecting to A", out)                                    # nothing is hidden here

    def test_ctrl_c_during_connect_cancels_the_attempt(self):
        def interrupted(*a, **kw):
            raise KeyboardInterrupt
        c = Stub(connect=interrupted, cancel=lambda: {"cancelled": True})
        code, out, err = run(["vpn", "connect", "x"], client=c)
        self.assertEqual(code, 130)
        self.assertIn("cancel", c.names())
        self.assertIn("cancelled; traffic stays blocked", err)
        self.assertIn("ipshift stop", err)

    def test_ctrl_c_anywhere_else_exits_quietly_with_130(self):
        def interrupted(*a, **kw):
            raise KeyboardInterrupt
        code, out, err = run(["privacy-check"], client=Stub(privacy_check=interrupted))
        self.assertEqual((code, out), (130, ""))

    def test_ctrl_c_in_watch_mode_is_a_normal_exit(self):
        def interrupted(*a, **kw):
            raise KeyboardInterrupt
        code, _, _ = run(["status", "--watch"], client=Stub(status=interrupted))
        self.assertEqual(code, 0)


class ErrorReportingTests(unittest.TestCase):
    def test_errors_carry_message_and_hint(self):
        c = Stub(privacy_check=lambda *a: (_ for _ in ()).throw(VpnError("tunnel exploded", hint="turn it off and on")))
        code, out, err = run(["privacy-check"], client=c)
        self.assertEqual((code, out), (1, ""))
        self.assertIn("ipshift: tunnel exploded", err)
        self.assertIn("hint: turn it off and on", err)

    def test_json_errors_are_json_on_stderr(self):
        c = Stub(status=lambda **kw: (_ for _ in ()).throw(PrivilegeError("nope", hint="sudo")))
        code, out, err = run(["--json", "status"], client=c)
        self.assertEqual((code, out), (1, ""))
        self.assertEqual(json.loads(err), {"error": {"code": "privilege", "message": "nope", "hint": "sudo"}})

    def test_usage_errors_in_json_mode(self):
        code, out, err = run(["--json", "config", "get"], client=Stub())
        self.assertEqual(code, 2)
        self.assertEqual(json.loads(err)["error"]["code"], "usage")

    def test_colour_in_error_text_only_on_a_terminal(self):
        c = Stub(status=lambda **kw: (_ for _ in ()).throw(VpnError("bad")))
        _, _, plain = run(["status"], client=c)
        self.assertNotIn("\x1b[", plain)
        with mock.patch.dict(os.environ, {"TERM": "xterm"}):
            os.environ.pop("NO_COLOR", None)
            out, err = io.StringIO(), TTY()
            main(["status"], out=out, err=err, inp=io.StringIO(), client_factory=lambda s: c)
        self.assertIn("\x1b[31m", err.getvalue())
        out, err = io.StringIO(), TTY()
        main(["--no-color", "status"], out=out, err=err, inp=io.StringIO(), client_factory=lambda s: c)
        self.assertNotIn("\x1b[", err.getvalue())

    def test_a_bug_is_reported_plainly_and_can_be_traced(self):
        c = Stub(status=lambda **kw: 1 / 0)
        code, out, err = run(["status"], client=c)
        self.assertEqual(code, 1)
        self.assertIn("unexpected error (ZeroDivisionError", err)
        self.assertIn("IPSHIFT_DEBUG=1", err)
        self.assertNotIn("Traceback", err)
        with mock.patch.dict(os.environ, {"IPSHIFT_DEBUG": "1"}):
            with self.assertRaises(ZeroDivisionError):
                run(["status"], client=c)

    def test_a_closed_pipe_ends_quietly(self):
        class Closed(io.StringIO):
            def write(self, s):
                raise BrokenPipeError

            def flush(self):
                raise BrokenPipeError
        c = Stub(status=lambda **kw: {"protection": {"level": "protected", "message": ""}, "daemon": {}, "vpn": {},
                                      "rotation": {}, "killswitch": {}, "network": {}, "public": {}, "hardening": {},
                                      "alerts": [], "profiles": {}})
        err = io.StringIO()
        code = main(["status"], out=Closed(), err=err, inp=io.StringIO(), client_factory=lambda s: c)
        self.assertEqual(code, 0)
        self.assertEqual(err.getvalue(), "")

    def test_prompts_without_a_terminal_never_hang(self):
        c = Stub()
        for argv in (["vpn", "remove", "x"], ["history", "--clear"]):
            code, out, err = run(argv, client=c)
            self.assertEqual(code, 2, argv)
            self.assertIn("--yes", err)
        self.assertEqual(c.calls, [])

    def test_secrets_are_never_echoed(self):
        c = Stub(profile_auth=lambda ref, user, pw: {"profile": {"name": "P"}})
        code, out, err = run(["vpn", "auth", "p", "--username", "alice", "--password-stdin"], client=c, stdin="hunter2\n")
        self.assertEqual(code, 0)
        self.assertNotIn("hunter2", out + err)
        self.assertEqual(c.calls[0], ("profile_auth", ("p", "alice", "hunter2"), {}))


class EntryPointTests(TmpRootCase):
    """The installed command: a real process, real pipes, a real socket."""

    def setUp(self):
        super().setUp()
        cfg = Config()
        cfg.vpn.connect_timeout, cfg.vpn.verify_timeout = 5.0, 3.0
        self.sock = self.tmp / "run" / "ipshift.sock"
        self.daemon = Daemon(cfg, default_paths(), simulate=True, sim_speed=0.0, socket_path=self.sock)
        self.daemon.start()
        self.addCleanup(self.daemon.stop)
        self.env = {**os.environ, "PYTHONPATH": str(ROOT / "src"), "IPSHIFT_ROOT": str(self.tmp)}
        self.env.pop("NO_COLOR", None)

    def ipshift(self, *argv, sock=True, stdin=None):
        args = [sys.executable, "-m", "ipshift.cli", *(["--socket", str(self.sock)] if sock else []), *argv]
        return subprocess.run(args, capture_output=True, text=True, timeout=60, env=self.env, input=stdin)

    def test_status_in_a_pipe_is_plain_text(self):
        r = self.ipshift("status")
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertEqual(r.stderr, "")
        self.assertIn("UNPROTECTED", r.stdout)
        self.assertNotIn("\x1b", r.stdout)
        self.assertTrue(r.stdout.isascii(), "no fancy symbols when the output is not a terminal that says it can show them")

    def test_json_is_valid_and_exit_codes_work(self):
        r = self.ipshift("--json", "status")
        self.assertEqual(json.loads(r.stdout)["protection"]["level"], "unprotected")
        self.assertEqual(self.ipshift("status", "--check").returncode, 1)
        self.assertEqual(self.ipshift("vpn", "connect").returncode, 0)
        self.assertEqual(self.ipshift("status", "--check").returncode, 0)
        self.assertEqual(self.ipshift("privacy-check", "--strict").returncode, 4)
        self.assertEqual(self.ipshift("stop").returncode, 0)

    def test_usage_error_and_missing_daemon_exit_codes(self):
        r = self.ipshift("rotate", "--interval", "0.5")
        self.assertEqual(r.returncode, 2)
        self.assertIn("shortest interval is 1 second", r.stderr)
        r = self.ipshift("--socket", str(self.tmp / "nowhere.sock"), "stop", sock=False)
        self.assertEqual(r.returncode, 3)
        self.assertIn("daemon is not running", r.stderr)

    def test_help_and_version(self):
        r = self.ipshift("--help", sock=False)
        self.assertEqual(r.returncode, 0)
        self.assertIn("rotate", r.stdout)
        r = self.ipshift("--version", sock=False)
        self.assertEqual(r.stdout.strip(), "ipshift 1.0.0")

    def test_password_from_a_pipe(self):
        text = "client\ndev tun\nproto udp\nremote 203.0.113.70 1194\nauth-user-pass\n"
        f = self.tmp / "p.ovpn"
        f.write_text(text + "<ca>\n-----BEGIN CERTIFICATE-----\nMIIBkTCB+wIJAK\nAAAAAAAAAAA=\n-----END CERTIFICATE-----\n</ca>\n")
        r = self.ipshift("vpn", "import", str(f), "--username", "alice", "--password-stdin", "--tier", "paid", stdin="pw\n")
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertNotIn("pw\n", r.stdout + r.stderr)
        self.assertNotIn("need a login", r.stdout)

    def test_packaging_points_at_the_entry_point(self):
        text = (ROOT / "pyproject.toml").read_text()
        self.assertIn('ipshift = "ipshift.cli:main"', text)
        self.assertTrue(callable(cmds.cmd_status))
        from ipshift.cli import main as entry
        self.assertTrue(callable(entry))


if __name__ == "__main__":  # pragma: no cover
    unittest.main()
