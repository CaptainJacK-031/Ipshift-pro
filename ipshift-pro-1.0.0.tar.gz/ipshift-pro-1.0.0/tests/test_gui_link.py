"""The window's link to the daemon, with a scripted stand-in for the daemon (deterministic, no sockets)."""
from __future__ import annotations

import copy
import queue
import threading
import time
import unittest

import helpers  # noqa: F401
import guifix
from ipshift.errors import BusyError, DaemonUnavailable
from ipshift.gui.link import COMMANDS, DaemonLink, Listener, Result, Timing

FAST = Timing(poll=0.05, min_gap=0.01, profiles_every=0.2, profiles_gap=0.02, history_every=0.2, history_gap=0.02,
              reconnect=0.02, reconnect_max=0.05)


class World:
    """What the pretend daemon says right now; shared by every StubClient the link creates."""

    def __init__(self):
        self.down = False
        self.down_error = DaemonUnavailable("the daemon is not running", hint="start it")
        self.status = guifix.idle()
        self.profiles = guifix.profiles()
        self.history = guifix.history(2)
        self.report = None
        self.calls: list = []
        self.stream: queue.Queue = queue.Queue()
        self.streams_opened = 0
        self.gates: dict[str, threading.Event] = {}
        self.results: dict = {}

    def count(self, name: str) -> int:
        return sum(1 for c in list(self.calls) if (c if isinstance(c, str) else c[0]) == name)


class FakeSocket:
    def __init__(self, stream):
        self.stream = stream

    def shutdown(self, how):
        self.stream.put(None)                              # like closing the real socket: the reader wakes up


class StubClient:
    def __init__(self, world: World):
        self.w = world

    def _answer(self, name, value):
        if self.w.down:
            raise self.w.down_error
        self.w.calls.append(name)
        return copy.deepcopy(value)

    def status(self, fresh=False):
        return self._answer("status", self.w.status)

    def profiles(self):
        return self._answer("profiles", self.w.profiles)

    def history(self, limit=100):
        return self._answer("history", self.w.history)

    def report(self):
        return self._answer("report", self.w.report)

    def events(self, min_level="info", replay=0, *, on_open=None):
        if self.w.down:
            raise self.w.down_error
        self.w.streams_opened += 1
        if on_open is not None:
            on_open(FakeSocket(self.w.stream))
        while True:
            ev = self.w.stream.get()
            if ev is None:
                return
            yield ev

    def __getattr__(self, name):                           # every command: record it, maybe wait, maybe fail
        def call(**kw):
            self.w.calls.append((name, kw))
            gate = self.w.gates.get(name)
            if gate is not None:
                gate.wait(5.0)
            r = self.w.results.get(name, {"ok": True})
            if isinstance(r, Exception):
                raise r
            return r
        return call


class Rec(Listener):
    def __init__(self):
        self.cv = threading.Condition()
        self.items: list = []

    def _add(self, *item):
        with self.cv:
            self.items.append(item)
            self.cv.notify_all()

    def on_link(self, up, error, hint): self._add("link", up, error, hint)
    def on_status(self, status): self._add("status", status)
    def on_event(self, event): self._add("event", event)
    def on_data(self, name, data): self._add("data", name, data)
    def on_busy(self, busy): self._add("busy", busy)
    def on_result(self, result): self._add("result", result)

    def of(self, kind):
        with self.cv:
            return [i[1:] for i in self.items if i[0] == kind]

    def count(self, kind, *match):
        return sum(1 for i in self.of(kind) if i[:len(match)] == match)

    def wait(self, pred, timeout=5.0):
        with self.cv:
            return self.cv.wait_for(lambda: pred(), timeout)


class LinkCase(unittest.TestCase):
    timing = FAST

    def setUp(self):
        self.world = World()
        self.rec = Rec()
        self.link = DaemonLink(self.rec, lambda: StubClient(self.world), timing=self.timing)
        self.addCleanup(self.link.close)

    def begin(self):
        self.link.start()
        self.assertTrue(self.rec.wait(lambda: self.rec.count("status") >= 1), "no status arrived")


class ConnectionTests(LinkCase):
    def test_the_link_comes_up_once_and_statuses_keep_flowing(self):
        self.begin()
        self.assertTrue(self.rec.wait(lambda: self.rec.count("status") >= 4))
        self.assertEqual(self.rec.of("link"), [(True, "", "")])
        self.assertIs(self.link.up, True)

    def test_a_missing_daemon_is_reported_once_with_its_hint_and_recovery_is_noticed(self):
        self.world.down = True
        self.link.start()
        self.assertTrue(self.rec.wait(lambda: self.rec.count("link") >= 1))
        time.sleep(0.3)                                                # many failed polls later ...
        self.assertEqual(self.rec.of("link"), [(False, "the daemon is not running", "start it")])
        self.assertIs(self.link.up, False)
        self.world.down = False
        self.assertTrue(self.rec.wait(lambda: self.rec.count("link", True) == 1))
        self.assertTrue(self.rec.wait(lambda: self.rec.count("status") >= 1))
        self.assertTrue(self.rec.wait(lambda: self.rec.count("data", "profiles") >= 1), "profiles after link-up")
        self.assertTrue(self.rec.wait(lambda: self.rec.count("data", "report") >= 1), "last report after link-up")

    def test_losing_the_daemon_in_the_middle_and_getting_it_back(self):
        self.begin()
        self.world.down = True
        self.assertTrue(self.rec.wait(lambda: self.rec.count("link", False) == 1))
        self.world.down = False
        self.assertTrue(self.rec.wait(lambda: self.rec.count("link", True) == 2))
        self.assertEqual([i[0] for i in self.rec.of("link")], [True, False, True])

    def test_a_changed_reason_is_reported_again(self):
        self.world.down = True
        self.link.start()
        self.assertTrue(self.rec.wait(lambda: self.rec.count("link") >= 1))
        self.world.down_error = DaemonUnavailable("permission denied on /run/ipshift/ipshift.sock",
                                                  hint="join the 'ipshift' group")
        self.assertTrue(self.rec.wait(lambda: self.rec.count("link") >= 2))
        self.assertEqual(self.rec.of("link")[-1], (False, "permission denied on /run/ipshift/ipshift.sock",
                                                   "join the 'ipshift' group"))

    def test_the_first_status_arrives_before_anything_is_reported_down(self):
        self.begin()
        self.assertEqual(self.rec.count("link", False), 0)


class EventTests(LinkCase):
    def test_events_arrive_in_order(self):
        self.begin()
        for i in range(3):
            self.world.stream.put({"kind": f"k{i}", "level": "info", "ts": float(i), "data": {}})
        self.assertTrue(self.rec.wait(lambda: self.rec.count("event") >= 3))
        self.assertEqual([e[0]["kind"] for e in self.rec.of("event")], ["k0", "k1", "k2"])

    def test_an_event_brings_a_new_status_at_once_even_with_a_slow_poll(self):
        self.link = DaemonLink(self.rec, lambda: StubClient(self.world),
                               timing=Timing(poll=30.0, min_gap=0.01, reconnect=0.02, reconnect_max=0.05))
        self.addCleanup(self.link.close)
        self.begin()
        n = self.rec.count("status")
        self.world.stream.put({"kind": "connected", "level": "info", "ts": 1.0, "data": {}})
        self.assertTrue(self.rec.wait(lambda: self.rec.count("status") > n, 2.0))

    def test_the_stream_is_opened_again_when_it_ends(self):
        self.begin()
        self.assertTrue(self.rec.wait(lambda: self.world.streams_opened >= 1))
        self.world.stream.put(None)                                    # the daemon hung up
        self.assertTrue(self.rec.wait(lambda: self.world.streams_opened >= 2))
        self.world.stream.put({"kind": "after", "level": "info", "ts": 1.0, "data": {}})
        self.assertTrue(self.rec.wait(lambda: self.rec.count("event") >= 1))

    def test_the_stream_is_retried_while_the_daemon_is_away(self):
        self.world.down = True
        self.link.start()
        time.sleep(0.2)
        self.world.down = False
        self.assertTrue(self.rec.wait(lambda: self.world.streams_opened >= 1))


class DataTests(LinkCase):
    def test_the_history_is_fetched_only_while_it_is_on_screen(self):
        self.begin()
        time.sleep(0.4)
        self.assertEqual(self.world.count("history"), 0)
        self.link.want_history(True)
        self.assertTrue(self.rec.wait(lambda: self.rec.count("data", "history") >= 1))
        self.link.want_history(False)
        time.sleep(0.1)
        n = self.world.count("history")
        self.world.stream.put({"kind": "connected", "level": "info", "ts": 1.0, "data": {}})
        time.sleep(0.5)
        self.assertEqual(self.world.count("history"), n)

    def test_a_rotation_result_refreshes_the_history_table_that_is_showing(self):
        self.begin()
        self.link.want_history(True)
        self.assertTrue(self.rec.wait(lambda: self.world.count("history") >= 1))
        time.sleep(0.3)                                                # let the periodic refresh settle
        n = self.world.count("history")
        self.world.history = guifix.history(5)
        self.world.stream.put({"kind": "connected", "level": "info", "ts": 1.0, "data": {}})
        self.assertTrue(self.rec.wait(lambda: self.world.count("history") > n))
        last = self.rec.of("data")[-1]
        self.assertTrue(any(d[0] == "history" and len(d[1]["rotations"]) == 5 for d in self.rec.of("data")), last)

    def test_profile_events_refresh_the_profiles(self):
        self.begin()
        self.assertTrue(self.rec.wait(lambda: self.world.count("profiles") >= 1))
        n = self.world.count("profiles")
        self.world.profiles = guifix.profiles(current="wg-nl")
        self.world.stream.put({"kind": "profile_imported", "level": "info", "ts": 1.0, "data": {}})
        self.assertTrue(self.rec.wait(lambda: any(d[0] == "profiles" and d[1]["current"] == "wg-nl"
                                                  for d in self.rec.of("data"))))
        self.assertGreater(self.world.count("profiles"), n)

    def test_a_leak_alert_refetches_the_last_report(self):
        self.begin()
        self.assertTrue(self.rec.wait(lambda: self.rec.count("data", "report") >= 1))
        self.world.report = guifix.report(ipv6="fail")
        self.world.stream.put({"kind": "leak_detected", "level": "critical", "ts": 1.0, "data": {}})
        self.assertTrue(self.rec.wait(lambda: any(d[0] == "report" and d[1] and d[1]["verdict"] == "exposed"
                                                  for d in self.rec.of("data"))))

    def test_a_failing_secondary_fetch_does_not_take_the_link_down(self):
        self.begin()
        orig = StubClient.profiles

        def broken(self_):
            raise BusyError("busy")
        StubClient.profiles = broken
        self.addCleanup(setattr, StubClient, "profiles", orig)
        self.link.refresh(everything=True)
        with self.assertLogs("ipshift.gui", "WARNING"):
            time.sleep(0.3)
        self.assertIs(self.link.up, True)
        self.assertEqual(self.rec.count("link", False), 0)


class CommandTests(LinkCase):
    def test_a_command_runs_in_the_background_and_reports_its_result(self):
        self.begin()
        gate = self.world.gates["connect"] = threading.Event()
        self.world.results["connect"] = {"profile_name": "NL 1", "exit_ip": "198.51.100.7"}
        self.link.run("connect", profile="nl-1")
        self.assertTrue(self.rec.wait(lambda: self.world.count("connect") == 1))
        self.assertEqual(self.link.busy, frozenset({"connect"}))
        self.assertIn(frozenset({"connect"}), [b[0] for b in self.rec.of("busy")])
        self.assertEqual(self.rec.count("result"), 0, "nothing is reported until it finishes")
        gate.set()
        self.assertTrue(self.rec.wait(lambda: self.rec.count("result") == 1))
        res = self.rec.of("result")[0][0]
        self.assertEqual(res, Result("connect", True, {"profile_name": "NL 1", "exit_ip": "198.51.100.7"}))
        self.assertTrue(self.rec.wait(lambda: self.link.busy == frozenset()))
        self.assertIn(("connect", {"profile": "nl-1"}), self.world.calls)

    def test_cancel_is_not_stuck_behind_a_connection_in_progress(self):
        self.begin()
        gate = self.world.gates["connect"] = threading.Event()
        self.link.run("connect")
        self.assertTrue(self.rec.wait(lambda: self.world.count("connect") == 1))
        self.link.run("cancel")
        self.assertTrue(self.rec.wait(lambda: any(r[0].name == "cancel" for r in self.rec.of("result"))))
        self.assertEqual(self.link.busy, frozenset({"connect"}))
        gate.set()
        self.assertTrue(self.rec.wait(lambda: self.link.busy == frozenset()))

    def test_a_daemon_error_becomes_a_failed_result_with_its_hint(self):
        self.begin()
        self.world.results["connect"] = BusyError("another operation is running", hint="wait a moment")
        self.link.run("connect")
        self.assertTrue(self.rec.wait(lambda: self.rec.count("result") == 1))
        res = self.rec.of("result")[0][0]
        self.assertFalse(res.ok)
        self.assertEqual((res.message, res.hint, res.error["code"]), ("another operation is running", "wait a moment",
                                                                        "busy"))

    def test_a_lost_daemon_during_a_command_is_a_failed_result_too(self):
        self.begin()
        self.world.results["stop"] = DaemonUnavailable("lost the connection", hint="try again")
        self.link.run("stop", keep_blocking=True)
        self.assertTrue(self.rec.wait(lambda: self.rec.count("result") == 1))
        self.assertEqual(self.rec.of("result")[0][0].error["code"], "daemon_unavailable")

    def test_a_bug_in_a_job_is_reported_and_the_link_keeps_working(self):
        self.begin()
        self.world.results["stop"] = RuntimeError("boom")
        with self.assertLogs("ipshift.gui", "ERROR"):
            self.link.run("stop")
            self.assertTrue(self.rec.wait(lambda: self.rec.count("result") == 1))
        res = self.rec.of("result")[0][0]
        self.assertEqual((res.ok, res.error["code"]), (False, "internal"))
        self.assertIn("RuntimeError: boom", res.message)
        self.assertEqual(self.link.busy, frozenset())
        n = self.rec.count("status")
        self.assertTrue(self.rec.wait(lambda: self.rec.count("status") > n))

    def test_unknown_commands_are_refused_before_anything_runs(self):
        self.begin()
        for bad in ("rm_rf", "__class__", "status", "events", ""):
            with self.assertRaises(ValueError):
                self.link.run(bad)
        self.assertEqual(self.world.count("rm_rf"), 0)

    def test_every_allowed_command_is_a_method_of_the_client(self):
        from ipshift.ipc.client import Client
        for name in COMMANDS:
            self.assertTrue(callable(getattr(Client, name, None)), name)

    def test_a_custom_job_gets_its_own_client_and_its_result_is_reported(self):
        self.begin()
        self.link.submit("profile_import", lambda client: [client.profiles()["current"], 42])
        self.assertTrue(self.rec.wait(lambda: self.rec.count("result") == 1))
        self.assertEqual(self.rec.of("result")[0][0], Result("profile_import", True, [None, 42]))

    def test_after_a_command_everything_is_fetched_again(self):
        self.link = DaemonLink(self.rec, lambda: StubClient(self.world),
                               timing=Timing(poll=30.0, min_gap=0.01, profiles_every=30.0, profiles_gap=0.01,
                                             history_every=30.0, history_gap=0.01, reconnect=0.02))
        self.addCleanup(self.link.close)
        self.begin()
        self.link.want_history(True)
        self.assertTrue(self.rec.wait(lambda: self.world.count("history") >= 1))
        before = {k: self.world.count(k) for k in ("status", "profiles", "history", "report")}
        self.link.run("rotate_now")
        self.assertTrue(self.rec.wait(lambda: all(self.world.count(k) > before[k]
                                                  for k in ("status", "profiles", "history", "report")), 3.0),
                        {k: self.world.count(k) for k in before})

    def test_several_commands_of_one_name_keep_the_busy_flag_until_the_last_ends(self):
        self.begin()
        gate = self.world.gates["privacy_check"] = threading.Event()
        self.link.run("privacy_check")
        self.link.run("privacy_check", mode="quick")
        self.assertTrue(self.rec.wait(lambda: self.world.count("privacy_check") == 2))
        self.assertEqual(self.link.busy, frozenset({"privacy_check"}))
        gate.set()
        self.assertTrue(self.rec.wait(lambda: self.rec.count("result") == 2))
        self.assertTrue(self.rec.wait(lambda: self.link.busy == frozenset()))


class LifecycleTests(LinkCase):
    def alive(self):
        return [t.name for t in threading.enumerate() if t.name.startswith(("ipshift-gui-poll", "ipshift-gui-events"))
                and t.is_alive()]

    def test_close_ends_both_threads_even_while_the_stream_is_waiting_for_an_event(self):
        self.begin()
        self.assertTrue(self.rec.wait(lambda: self.world.streams_opened >= 1))
        self.assertEqual(len(self.alive()), 2)
        began = time.monotonic()
        self.link.close()
        self.assertLess(time.monotonic() - began, 2.0)
        self.assertEqual(self.alive(), [])
        self.assertTrue(self.link.closed)

    def test_nothing_reaches_the_listener_after_close(self):
        self.begin()
        self.link.close()
        n = len(self.rec.items)
        self.world.stream.put({"kind": "late", "level": "info", "ts": 1.0, "data": {}})
        time.sleep(0.2)
        self.assertEqual(len(self.rec.items), n)

    def test_closing_twice_and_closing_before_starting_are_harmless(self):
        self.link.close()
        self.link.close()
        link = DaemonLink(Rec(), lambda: StubClient(self.world), timing=FAST)
        link.close()

    def test_a_broken_listener_does_not_stop_the_link(self):
        class Broken(Rec):
            def on_status(self, status):
                raise RuntimeError("listener bug")
        rec = Broken()
        link = DaemonLink(rec, lambda: StubClient(self.world), timing=FAST)
        self.addCleanup(link.close)
        with self.assertLogs("ipshift.gui", "ERROR"):
            link.start()
            self.world.stream.put({"kind": "still-works", "level": "info", "ts": 1.0, "data": {}})
            self.assertTrue(rec.wait(lambda: rec.count("event") >= 1))
            time.sleep(0.15)
        self.assertTrue(link.up)

    def test_the_poll_can_be_slowed_while_the_window_is_hidden(self):
        self.begin()
        self.link.set_poll(0.5)
        time.sleep(0.15)
        n = self.rec.count("status")
        time.sleep(0.3)
        self.assertLessEqual(self.rec.count("status") - n, 2)

    def test_set_poll_never_goes_below_half_a_second(self):
        self.link.set_poll(0.0)
        self.assertEqual(self.link._poll, 0.5)


if __name__ == "__main__":
    unittest.main()
