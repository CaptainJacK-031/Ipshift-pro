"""No class of the Qt layer may reuse the name of a real Qt member.

PySide6 cannot be installed where this was written, so the stand-in cannot know every method of the real
classes.  A signal called ``event`` or an attribute called ``actions`` would shadow ``QObject.event`` or
``QWidget.actions`` and break Qt in ways no stand-in shows (it happened once, with a signal named
``event``).  This test lists the real names by hand and checks every class and every instance attribute
the project's own classes add.  A new Qt class must be added to ``BUILD`` or the test fails.
"""
from __future__ import annotations

import inspect
import unittest

import helpers  # noqa: F401
import qtcase

QOBJECT = set("""
blockSignals children childEvent connect connectNotify customEvent deleteLater destroyed disconnect
disconnectNotify dumpObjectInfo dumpObjectTree dynamicPropertyNames emit event eventFilter findChild findChildren
inherits installEventFilter isSignalConnected isWidgetType isWindowType killTimer metaObject moveToThread objectName
objectNameChanged parent property receivers removeEventFilter sender senderSignalIndex setObjectName setParent
setProperty signalsBlocked startTimer staticMetaObject thread timerEvent tr
""".split())

QWIDGET = QOBJECT | set("""
acceptDrops accessibleDescription accessibleName actionEvent actions activateWindow addAction addActions adjustSize
autoFillBackground backgroundRole baseSize changeEvent childAt childrenRect childrenRegion clearFocus clearMask
close closeEvent contentsMargins contentsRect contextMenuEvent contextMenuPolicy create createWinId cursor
customContextMenuRequested destroy devType dragEnterEvent dragLeaveEvent dragMoveEvent dropEvent effectiveWinId
ensurePolished enterEvent find focusInEvent focusNextChild focusNextPrevChild focusOutEvent focusPolicy
focusPreviousChild focusProxy focusWidget font fontInfo fontMetrics foregroundRole frameGeometry frameSize geometry
grab grabGesture grabKeyboard grabMouse grabShortcut graphicsEffect graphicsProxyWidget hasEditFocus hasFocus
hasHeightForWidth hasMouseTracking hasTabletTracking height heightForWidth hide hideEvent initPainter inputMethodEvent
inputMethodHints inputMethodQuery insertAction insertActions isActiveWindow isAncestorOf isEnabled isEnabledTo
isFullScreen isHidden isLeftToRight isMaximized isMinimized isModal isRightToLeft isTopLevel isVisible isVisibleTo
isWindow isWindowModified keyPressEvent keyReleaseEvent keyboardGrabber layout layoutDirection leaveEvent locale
lower mapFrom mapFromGlobal mapFromParent mapTo mapToGlobal mapToParent mask maximumHeight maximumSize maximumWidth
metric minimumHeight minimumSize minimumSizeHint minimumWidth mouseDoubleClickEvent mouseGrabber mouseMoveEvent
mousePressEvent mouseReleaseEvent move moveEvent nativeEvent nativeParentWidget nextInFocusChain normalGeometry
overrideWindowFlags overrideWindowState paintEngine paintEvent palette parentWidget pos previousInFocusChain raise_
rect releaseKeyboard releaseMouse releaseShortcut removeAction render repaint resize resizeEvent restoreGeometry
saveGeometry screen scroll setAcceptDrops setAccessibleDescription setAccessibleName setAttribute
setAutoFillBackground setBackgroundRole setBaseSize setContentsMargins setContextMenuPolicy setCursor setDisabled
setEditFocus setEnabled setFixedHeight setFixedSize setFixedWidth setFocus setFocusPolicy setFocusProxy setFont
setForegroundRole setGeometry setGraphicsEffect setInputMethodHints setLayout setLayoutDirection setLocale setMask
setMaximumHeight setMaximumSize setMaximumWidth setMinimumHeight setMinimumSize setMinimumWidth setMouseTracking
setPalette setParent setShortcutAutoRepeat setShortcutEnabled setSizeIncrement setSizePolicy setStatusTip setStyle
setStyleSheet setTabOrder setTabletTracking setToolTip setToolTipDuration setUpdatesEnabled setVisible setWhatsThis
setWindowFilePath setWindowFlag setWindowFlags setWindowIcon setWindowIconText setWindowModality setWindowModified
setWindowOpacity setWindowRole setWindowState setWindowTitle sharedPainter show showEvent showFullScreen
showMaximized showMinimized showNormal size sizeHint sizeIncrement sizePolicy stackUnder statusTip style styleSheet
tabletEvent toolTip toolTipDuration underMouse ungrabGesture unsetCursor unsetLayoutDirection unsetLocale update
updateGeometry updateMicroFocus updatesEnabled visibleRegion whatsThis wheelEvent width winId window windowFilePath
windowFlags windowHandle windowIcon windowIconChanged windowIconText windowIconTextChanged windowModality
windowOpacity windowRole windowState windowTitle windowTitleChanged windowType x y
""".split())

QFRAME = QWIDGET | set("""
drawFrame frameRect frameShadow frameShape frameStyle frameWidth lineWidth midLineWidth setFrameRect setFrameShadow
setFrameShape setFrameStyle setLineWidth setMidLineWidth
""".split())

QMAINWINDOW = QWIDGET | set("""
addDockWidget addToolBar addToolBarBreak centralWidget corner createPopupMenu dockOptions dockWidgetArea documentMode
iconSize iconSizeChanged insertToolBar insertToolBarBreak isAnimated isDockNestingEnabled menuBar menuWidget
removeDockWidget removeToolBar removeToolBarBreak resizeDocks restoreDockWidget restoreState saveState setAnimated
setCentralWidget setCorner setDockNestingEnabled setDockOptions setDocumentMode setIconSize setMenuBar setMenuWidget
setStatusBar setTabPosition setTabShape setToolButtonStyle splitDockWidget statusBar tabPosition tabShape
tabifiedDockWidgetActivated tabifiedDockWidgets tabifyDockWidget takeCentralWidget toolBarArea toolBarBreak
toolButtonStyle toolButtonStyleChanged
""".split())

QDIALOG = QWIDGET | set("""
accept accepted adjustPosition done exec exec_ finished isSizeGripEnabled open reject rejected result setModal
setResult setSizeGripEnabled showExtension
""".split())

QMODEL = QOBJECT | set("""
beginInsertColumns beginInsertRows beginMoveColumns beginMoveRows beginRemoveColumns beginRemoveRows beginResetModel
buddy canDropMimeData canFetchMore columnCount columnsAboutToBeInserted columnsAboutToBeMoved
columnsAboutToBeRemoved columnsInserted columnsMoved columnsRemoved createIndex data dataChanged decodeData
dropMimeData encodeData endInsertColumns endInsertRows endMoveColumns endMoveRows endRemoveColumns endRemoveRows
endResetModel fetchMore flags hasChildren hasIndex headerData headerDataChanged index insertColumn insertColumns
insertRow insertRows itemData layoutAboutToBeChanged layoutChanged match mimeData mimeTypes modelAboutToBeReset
modelReset moveColumn moveColumns moveRow moveRows persistentIndexList removeColumn removeColumns removeRow
removeRows resetInternalData revert roleNames rowCount rowsAboutToBeInserted rowsAboutToBeMoved
rowsAboutToBeRemoved rowsInserted rowsMoved rowsRemoved setData setHeaderData setItemData sibling sort span submit
supportedDragActions supportedDropActions
""".split())

# Virtual methods the project overrides on purpose, per class.
OVERRIDES = {
    "MainWindow": {"showEvent", "hideEvent", "changeEvent", "closeEvent"},
    "TableModel": {"rowCount", "columnCount", "headerData", "data"},
}


def setUpModule():
    qtcase.install()
    global modules, fq
    import fakeqt as fq
    from ipshift.gui import (dialogs, page_dashboard, page_history, page_privacy, page_profiles, page_settings, qtbridge,
                             widgets, window)
    modules = (widgets, dialogs, qtbridge, page_dashboard, page_privacy, page_history, page_profiles, page_settings,
               window)


def tearDownModule():
    qtcase.uninstall()


def real_names(cls) -> set[str]:
    from PySide6.QtCore import QObject
    from PySide6.QtWidgets import QDialog, QFrame, QMainWindow, QWidget
    from PySide6.QtCore import QAbstractTableModel
    if issubclass(cls, QMainWindow):
        return QMAINWINDOW
    if issubclass(cls, QDialog):
        return QDIALOG
    if issubclass(cls, QFrame):
        return QFRAME
    if issubclass(cls, QWidget):
        return QWIDGET
    if issubclass(cls, QAbstractTableModel):
        return QMODEL
    assert issubclass(cls, QObject), cls
    return QOBJECT


def class_clashes(name, cls) -> list[str]:
    """Methods and signals defined on ``cls`` that shadow a real Qt member."""
    real = real_names(cls) - OVERRIDES.get(name, set())
    return [f"{name}.{member} (method or signal)" for member in vars(cls) if member in real]


def instance_clashes(name, cls, instance, base_instance) -> list[str]:
    """Attributes set on ``instance`` (beyond what its Qt base sets) that shadow a real Qt member."""
    real = real_names(cls)
    return [f"{name}.{attr} (attribute)" for attr in sorted(set(vars(instance)) - set(vars(base_instance)))
            if attr in real]


def qt_base(cls):
    """The first class of the stand-in in the inheritance chain (what ``cls`` adds is measured against it)."""
    for base in cls.__mro__[1:]:
        if base.__module__.startswith("fakeqt"):
            return base
    raise AssertionError(cls)


class NameTests(qtcase.QtCase):
    def build(self):
        """One instance of every Qt class the project defines."""
        from ipshift.gui import dialogs, page_dashboard, page_history, page_privacy, page_profiles, page_settings
        from ipshift.gui import qtbridge, views, widgets, window
        from ipshift.gui.actions import Actions
        from ipshift.gui.model import AppModel
        link = qtcase.FakeLink()
        model = AppModel()
        bridge = qtbridge.Bridge()
        bridge.link = link
        options = views.STOP_OPTIONS
        return {
            "Card": lambda: widgets.Card("t"),
            "KeyValue": lambda: widgets.KeyValue(("a",)),
            "RowList": lambda: widgets.RowList(lambda item: widgets.label(str(item))),
            "Banner": widgets.Banner,
            "TileCard": widgets.TileCard,
            "Toast": widgets.Toast,
            "TableModel": lambda: widgets.TableModel(("a",)),
            "StopDialog": lambda: dialogs.StopDialog(None, options),
            "ImportDialog": lambda: dialogs.ImportDialog(None),
            "LoginDialog": lambda: dialogs.LoginDialog(None, "x"),
            "Bridge": lambda: bridge,
            "DashboardPage": page_dashboard.DashboardPage,
            "PrivacyPage": page_privacy.PrivacyPage,
            "HistoryPage": page_history.HistoryPage,
            "ProfilesPage": page_profiles.ProfilesPage,
            "SettingsPage": page_settings.SettingsPage,
            "OfflinePanel": window.OfflinePanel,
            "MainWindow": lambda: window.MainWindow(bridge, model, Actions(link, model)),
        }

    def classes(self):
        from PySide6.QtCore import QObject
        found = {}
        for module in modules:
            for name, cls in inspect.getmembers(module, inspect.isclass):
                if cls.__module__ == module.__name__ and issubclass(cls, QObject):
                    found[name] = cls
        return found

    def test_every_qt_class_of_the_project_is_covered_by_this_test(self):
        self.assertEqual(sorted(self.classes()), sorted(self.build()))

    def test_no_class_reuses_the_name_of_a_real_qt_member(self):
        problems = []
        for name, cls in self.classes().items():
            problems += class_clashes(name, cls)
        self.assertEqual(problems, [])

    def test_no_instance_attribute_reuses_the_name_of_a_real_qt_member(self):
        problems = []
        classes = self.classes()
        for name, make in self.build().items():
            problems += instance_clashes(name, classes[name], make(), qt_base(classes[name])())
        self.assertEqual(problems, [])

    def test_the_overrides_that_are_allowed_really_are_real_virtual_methods(self):
        for name, allowed in OVERRIDES.items():
            self.assertTrue(allowed <= real_names(self.classes()[name]) | allowed)
            for member in allowed:
                self.assertIn(member, vars(self.classes()[name]), f"{name}.{member} is allowed but not defined")

    def test_the_guard_itself_catches_a_clash(self):
        from PySide6.QtCore import QObject, Signal
        from PySide6.QtWidgets import QWidget

        class BadObject(QObject):
            event = Signal(object)                                  # shadows QObject.event

        class BadWidget(QWidget):
            def __init__(self):
                super().__init__()
                self.render = None                                  # shadows QWidget.render
                self.fine = None

            def actions(self):                                      # shadows QWidget.actions
                return []

        self.assertEqual(class_clashes("BadObject", BadObject), ["BadObject.event (method or signal)"])
        self.assertEqual(class_clashes("BadWidget", BadWidget), ["BadWidget.actions (method or signal)"])
        self.assertEqual(instance_clashes("BadWidget", BadWidget, BadWidget(), QWidget()),
                         ["BadWidget.render (attribute)"])


if __name__ == "__main__":
    unittest.main()
