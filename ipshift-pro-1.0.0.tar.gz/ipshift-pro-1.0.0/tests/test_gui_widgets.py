"""The widget kit (ipshift.gui.widgets), run against the stand-in for PySide6."""
from __future__ import annotations

import unittest
from unittest import mock

import helpers  # noqa: F401
import guifix
import qtcase
from ipshift.gui import leakviews, tables, views
from ipshift.gui.views import BAD, GOOD, INFO, MUTED, PLAIN, WARN


def setUpModule():
    qtcase.install()
    global widgets, Qt
    from PySide6.QtCore import Qt
    from ipshift.gui import widgets


def tearDownModule():
    qtcase.uninstall()


class StylingTests(qtcase.QtCase):
    def test_set_prop_applies_the_style_again_only_when_the_value_changes(self):
        lab = widgets.label("x")
        before = len(lab._polish_log)
        widgets.set_tone(lab, BAD)
        self.assertEqual(lab.property("tone"), BAD)
        self.assertEqual(lab._polish_log[before:], ["unpolish", "polish"])
        widgets.set_tone(lab, BAD)
        self.assertEqual(len(lab._polish_log), before + 2)
        widgets.set_tone(lab, GOOD)
        self.assertEqual(len(lab._polish_log), before + 4)

    def test_set_text_leaves_an_unchanged_label_alone(self):
        lab = widgets.label("same")
        calls = []
        real = lab.setText
        lab.setText = lambda t: (calls.append(t), real(t))
        widgets.set_text(lab, "same")
        widgets.set_text(lab, "new")
        widgets.set_text(lab, "new")
        self.assertEqual(calls, ["new"])

    def test_labels_never_guess_rich_text(self):
        for lab in (widgets.label("<b>x</b>"), widgets.label("<img src=x>", wrap=True, selectable=True, pill=True)):
            self.assertIs(lab.textFormat(), Qt.TextFormat.PlainText)
        self.assertEqual(widgets.label("<b>x</b>").text(), "<b>x</b>")

    def test_label_options(self):
        plain = widgets.label("a")
        self.assertFalse(plain.wordWrap())
        self.assertEqual(plain.textInteractionFlags(), Qt.TextInteractionFlag.NoTextInteraction)
        rich = widgets.label("b", role="muted", tone=WARN, wrap=True, selectable=True)
        self.assertTrue(rich.wordWrap())
        self.assertEqual(rich.textInteractionFlags(), Qt.TextInteractionFlag.TextSelectableByMouse)
        self.assertEqual((rich.property("role"), rich.property("tone")), ("muted", WARN))
        pill = widgets.label("c", pill=True, tone=GOOD)
        self.assertEqual(pill.property("pill"), "true")
        self.assertEqual(pill.alignment(), Qt.AlignmentFlag.AlignCenter)

    def test_button_calls_back_once_per_click_and_not_when_disabled(self):
        hits = []
        b = widgets.button("Go", role="primary", tip="does it", on_click=lambda: hits.append(1))
        self.assertEqual((b.text(), b.property("role"), b.toolTip()), ("Go", "primary", "does it"))
        b.click()
        b.setEnabled(False)
        b.click()
        self.assertEqual(hits, [1])

    def test_a_button_without_a_callback_is_fine(self):
        widgets.button("x").click()

    def test_a_signal_can_be_the_callback(self):
        from PySide6.QtCore import QObject, Signal

        class Source(QObject):
            fired = Signal()

        s, got = Source(), []
        s.fired.connect(lambda: got.append(1))
        widgets.button("x", on_click=s.fired.emit).click()
        self.assertEqual(got, [1])

    def test_separator_is_a_one_pixel_line(self):
        line = widgets.separator()
        self.assertEqual((line.objectName(), line.sizes["fixed_height"]), ("sep", 1))


class LayoutTests(qtcase.QtCase):
    def test_items_can_be_widgets_layouts_stretches_gaps_and_weighted_pairs(self):
        a, b = widgets.label("a"), widgets.label("b")
        inner = widgets.hbox(widgets.label("c"))
        lay = widgets.vbox(a, (b, 2), None, 12, inner, margins=(1, 2, 3, 4), spacing=5)
        kinds = []
        for i in range(lay.count()):
            item = lay.itemAt(i)
            kinds.append("widget" if item.widget() else "layout" if item.layout() else item.spacerItem())
        self.assertEqual(kinds, ["widget", "widget", "stretch", "spacing", "layout"])
        self.assertEqual((lay.margins, lay.spacing_value), ((1, 2, 3, 4), 5))

    def test_something_that_is_not_a_widget_or_layout_is_refused(self):
        with self.assertRaises(TypeError):
            widgets.vbox("a text")

    def test_a_holder_owns_the_widgets_of_its_layout_and_its_nested_layouts(self):
        a, b = widgets.label("a"), widgets.label("b")
        box = widgets.holder(widgets.vbox(a, widgets.hbox(b)), "name")
        self.assertEqual(box.objectName(), "name")
        self.assertIs(a.parent(), box)
        self.assertIs(b.parent(), box)

    def test_clear_layout_empties_it_and_deletes_the_widgets_including_nested_ones(self):
        a, b, c = widgets.label("a"), widgets.label("b"), widgets.label("c")
        lay = widgets.vbox(a, widgets.hbox(b), None, c)
        widgets.holder(lay)
        widgets.clear_layout(lay)
        self.assertEqual(lay.count(), 0)
        self.app.processEvents()
        for w in (a, b, c):
            with self.assertRaises(RuntimeError):
                w.setText("gone")


class CardTests(qtcase.QtCase):
    def test_a_card_shows_its_title_in_capitals_and_takes_items_in_order(self):
        a, b = widgets.label("a"), widgets.label("b")
        card = widgets.Card("VPN connection")
        self.assertIs(card.add(a, b), card)
        self.assertEqual(card.objectName(), "card")
        self.assertEqual(self.texts(card), ["VPN CONNECTION", "a", "b"])

    def test_a_card_without_a_title_has_none(self):
        self.assertEqual(self.texts(widgets.Card().add(widgets.label("x"))), ["x"])

    def test_key_value_shows_values_with_tones(self):
        kv = widgets.KeyValue(("Server", "Uptime"))
        self.assertEqual((kv.text("Server"), kv.text("Uptime")), ("-", "-"))
        kv.set("Server", "203.0.113.9", GOOD)
        self.assertEqual(kv.text("Server"), "203.0.113.9")
        self.assertEqual(kv._values["Server"].property("tone"), GOOD)
        kv.set("Server", "x")
        self.assertEqual(kv._values["Server"].property("tone"), PLAIN)
        with self.assertRaises(KeyError):
            kv.set("Nope", "x")


class RowListTests(qtcase.QtCase):
    def test_rows_are_rebuilt_only_when_the_items_change(self):
        built = []

        def build(item):
            built.append(item)
            return widgets.label(str(item))

        rows = widgets.RowList(build)
        rows.set_items([1, 2])
        rows.set_items([1, 2])
        self.assertEqual(built, [1, 2])
        rows.set_items([1, 3])
        self.assertEqual(built, [1, 2, 1, 3])
        self.assertEqual(rows.count, 2)

    def test_replaced_rows_are_deleted(self):
        rows = widgets.RowList(lambda item: widgets.label(str(item)))
        rows.set_items(["a"])
        old = rows.findChildren(type(widgets.label("")))[0]
        rows.set_items(["b"])
        self.app.processEvents()
        with self.assertRaises(RuntimeError):
            old.setText("x")
        self.assertEqual(self.texts(rows), ["b"])

    def test_an_empty_list_shows_its_empty_text_and_nothing_else(self):
        rows = widgets.RowList(lambda item: widgets.label(str(item)), empty="Nothing here.")
        rows.set_items([])
        self.assertEqual(self.texts(rows), ["Nothing here."])
        rows.set_items(["x"])
        self.app.processEvents()
        self.assertEqual(self.texts(rows), ["x"])
        self.assertEqual(rows.count, 1)

    def test_items_are_compared_by_value(self):
        built = []
        rows = widgets.RowList(lambda item: (built.append(1), widgets.label("x"))[1])
        a = views.Problem("p", BAD, "h")
        rows.set_items((a,))
        rows.set_items((views.Problem("p", BAD, "h"),))
        self.assertEqual(len(built), 1)


class RowBuilderTests(qtcase.QtCase):
    def test_an_alert_shows_the_time_the_text_and_the_hint(self):
        a = views.AlertRow(ts=1.0, time="12:00:01", level="error", tone=BAD, text="VPN lost", hint="reconnecting",
                           kind="tunnel_lost")
        row = widgets.build_alert(a)
        self.assertEqual(self.texts(row), ["12:00:01", "VPN lost", "reconnecting"])
        text = [lab for lab in row.findChildren(type(widgets.label(""))) if lab.text() == "VPN lost"][0]
        self.assertEqual(text.property("tone"), BAD)

    def test_an_alert_without_a_hint_has_no_hint_line(self):
        a = views.AlertRow(1.0, "12:00:01", "warning", WARN, "slow", "", "x")
        self.assertEqual(self.texts(widgets.build_alert(a)), ["12:00:01", "slow"])

    def test_a_problem_shows_a_dot_the_text_and_what_to_do(self):
        row = widgets.build_problem(views.Problem("DNS changed", BAD, "Reconnect."))
        self.assertEqual(self.texts(row), ["●", "DNS changed", "Reconnect."])

    def test_a_private_address_row_marks_the_tunnel(self):
        row = widgets.build_private_ip(views.PrivateIp("10.2.0.2", "ipshift0", "VPN tunnel", True))
        self.assertEqual(self.texts(row), ["10.2.0.2", "ipshift0", "VPN tunnel"])
        ip = row.findChildren(type(widgets.label("")))[0]
        self.assertEqual(ip.property("tone"), INFO)
        other = widgets.build_private_ip(views.PrivateIp("192.168.1.2", "wlan0", "Wi-Fi", False))
        self.assertIsNone(other.findChildren(type(widgets.label("")))[0].property("tone"))

    def test_text_from_the_daemon_is_never_shown_as_markup(self):
        row = widgets.build_alert(views.AlertRow(1.0, "t", "error", BAD, "<a href='x'>click</a>", "", "k"))
        for lab in row.findChildren(type(widgets.label(""))):
            self.assertIs(lab.textFormat(), Qt.TextFormat.PlainText)


class BannerTests(qtcase.QtCase):
    def test_banner_shows_title_detail_and_extra_with_the_tone(self):
        b = widgets.Banner()
        b.show_view(views.Banner("protected", "PROTECTED", "kill switch armed", GOOD), "IPShift Pro 1.0")
        self.assertEqual((b.title.text(), b.detail.text(), b.extra.text()),
                         ("PROTECTED", "kill switch armed", "IPShift Pro 1.0"))
        self.assertEqual((b.property("tone"), b.title.property("tone")), (GOOD, GOOD))
        self.assertFalse(b.extra.isHidden())

    def test_an_empty_extra_line_is_hidden(self):
        b = widgets.Banner()
        b.show_view(views.Banner("blocked", "BLOCKED", "x", WARN))
        self.assertTrue(b.extra.isHidden())
        self.assertEqual(b.property("tone"), WARN)


class TileCardTests(qtcase.QtCase):
    def test_a_passing_tile(self):
        card = widgets.TileCard()
        card.show_tile(leakviews.make_tile("tunnel", "VPN tunnel", "pass", "up"))
        self.assertEqual((card.glyph.text(), card.title.text(), card.word.text(), card.detail.text()),
                         ("✔", "VPN tunnel", "PASS", "up"))
        self.assertTrue(card.hint.isHidden())
        self.assertEqual((card.property("tone"), card.word.property("tone")), (GOOD, GOOD))
        self.assertEqual(card.tile_id, "tunnel")

    def test_a_failing_tile_shows_how_to_fix_it_and_calls_a_leak_a_leak(self):
        card = widgets.TileCard(big=True)
        card.show_tile(leakviews.make_tile("dns", "DNS leak test", "fail", "queries leave outside", "reconnect",
                                           leak=True))
        self.assertEqual(card.word.text(), "LEAK")
        self.assertEqual(card.hint.text(), "How to fix it: reconnect")
        self.assertFalse(card.hint.isHidden())
        self.assertEqual(card.property("tone"), BAD)

    def test_a_tile_without_detail_hides_the_detail_line(self):
        card = widgets.TileCard()
        card.show_tile(leakviews.make_tile("x", "X", "skip", ""))
        self.assertTrue(card.detail.isHidden())

    def test_a_tile_can_be_shown_again_with_another_result(self):
        card = widgets.TileCard()
        card.show_tile(leakviews.make_tile("x", "X", "fail", "bad", "fix"))
        card.show_tile(leakviews.make_tile("x", "X", "pass", "fine"))
        self.assertEqual((card.word.text(), card.property("tone"), card.hint.text()), ("PASS", GOOD, ""))
        self.assertTrue(card.hint.isHidden())


class ToastTests(qtcase.QtCase):
    def make(self):
        win = __import__("PySide6.QtWidgets", fromlist=["QMainWindow"]).QMainWindow()
        toast = widgets.Toast()
        win.setCentralWidget(widgets.holder(widgets.vbox(toast)))
        win.show()
        return toast

    def test_it_starts_hidden_and_takes_no_room(self):
        toast = self.make()
        self.assertFalse(toast.isVisible())

    def test_a_message_shows_then_goes_away_by_itself(self):
        toast = self.make()
        toast.show_message("Rotation started", GOOD, "hint text")
        self.assertTrue(toast.isVisible())
        self.assertEqual((toast.text.text(), toast.hint.text()), ("Rotation started", "hint text"))
        self.assertEqual(toast.frame.property("tone"), GOOD)
        self.pump(7.9)
        self.assertTrue(toast.isVisible())
        self.pump(0.2)
        self.assertFalse(toast.isVisible())

    def test_an_error_stays_longer(self):
        toast = self.make()
        toast.show_message("It failed", BAD)
        self.pump(20)
        self.assertTrue(toast.isVisible())
        self.pump(6)
        self.assertFalse(toast.isVisible())

    def test_a_new_message_restarts_the_time(self):
        toast = self.make()
        toast.show_message("one", INFO)
        self.pump(6)
        toast.show_message("two", INFO)
        self.pump(6)
        self.assertTrue(toast.isVisible())
        self.assertEqual(toast.text.text(), "two")

    def test_an_empty_hint_is_hidden_and_the_dismiss_button_closes_it(self):
        toast = self.make()
        toast.show_message("x", INFO)
        self.assertTrue(toast.hint.isHidden())
        close = [b for b in toast.findChildren(type(widgets.button("x"))) if b.text() == "✕"][0]
        close.click()
        self.assertFalse(toast.isVisible())

    def test_the_seconds_can_be_chosen(self):
        toast = self.make()
        toast.show_message("x", INFO, seconds=1.0)
        self.pump(1.1)
        self.assertFalse(toast.isVisible())


class TableTests(qtcase.QtCase):
    def history(self, n=3):
        return tables.history_rows(guifix.history(n))

    def test_the_model_reports_its_shape_and_headers(self):
        m = widgets.TableModel(tables.HISTORY_COLUMNS, tone_column=1)
        m.set_rows(self.history(3))
        self.assertEqual((m.rowCount(), m.columnCount()), (3, len(tables.HISTORY_COLUMNS)))
        self.assertEqual(m.headerData(0, Qt.Orientation.Horizontal), "Time")
        self.assertIsNone(m.headerData(0, Qt.Orientation.Vertical))
        self.assertIsNone(m.headerData(99, Qt.Orientation.Horizontal))

    def test_cells_come_from_the_row_and_the_tone_colours_one_column(self):
        m = widgets.TableModel(tables.HISTORY_COLUMNS, tone_column=1)
        rows = self.history(2)
        m.set_rows(rows)
        for col, text in enumerate(rows[0].cells()):
            self.assertEqual(m.data(m.index(0, col)), text)
            self.assertEqual(m.data(m.index(0, col), Qt.ItemDataRole.ToolTipRole), text)
        brush = m.data(m.index(0, 1), Qt.ItemDataRole.ForegroundRole)
        self.assertEqual(brush.color.name(), "#3fb950")                  # "Changed" is a good result: green
        self.assertIsNone(m.data(m.index(0, 2), Qt.ItemDataRole.ForegroundRole))
        self.assertIsNone(m.data(m.index(0, 0), 99))

    def test_a_plain_tone_has_no_colour(self):
        m = widgets.TableModel(tables.EVENT_COLUMNS, tone_column=-1)
        m.set_rows(tables.event_rows({"events": [{"ts": 1.0, "level": "info", "kind": "x", "message": "m"}]}))
        self.assertIsNone(m.data(m.index(0, 1), Qt.ItemDataRole.ForegroundRole))

    def test_invalid_indexes_give_nothing(self):
        m = widgets.TableModel(("a",), tone_column=-1)
        m.set_rows(self.history(1))
        self.assertIsNone(m.data(m.index(5, 0)))
        self.assertEqual(m.rowCount(m.index(0, 0)), 0)                   # a table has no children

    def test_setting_equal_rows_does_not_reset_the_model(self):
        m = widgets.TableModel(tables.HISTORY_COLUMNS, tone_column=1)
        self.assertTrue(m.set_rows(self.history(3)))
        before = m.reset_count
        self.assertFalse(m.set_rows(self.history(3)))
        self.assertEqual(m.reset_count, before)
        self.assertTrue(m.set_rows(self.history(4)))
        self.assertEqual(m.reset_count, before + 1)

    def test_a_table_is_read_only_with_whole_row_selection_and_a_stretching_last_column(self):
        m = widgets.TableModel(tables.HISTORY_COLUMNS, tone_column=1)
        view = widgets.make_table(m)
        from PySide6.QtWidgets import QAbstractItemView, QHeaderView
        self.assertIs(view.options["behavior"], QAbstractItemView.SelectionBehavior.SelectRows)
        self.assertIs(view.options["mode"], QAbstractItemView.SelectionMode.SingleSelection)
        self.assertEqual(view.options["edit"], QAbstractItemView.EditTrigger.NoEditTriggers)
        modes = view.horizontalHeader().modes
        last = len(tables.HISTORY_COLUMNS) - 1
        self.assertIs(modes[last], QHeaderView.ResizeMode.Stretch)
        self.assertTrue(all(modes[i] is QHeaderView.ResizeMode.ResizeToContents for i in range(last)))
        self.assertTrue(view.verticalHeader().isHidden())

    def test_replacing_rows_keeps_the_scroll_position(self):
        m = widgets.TableModel(tables.HISTORY_COLUMNS, tone_column=1)
        view = widgets.make_table(m)
        widgets.set_table_rows(view, m, self.history(50))
        view.verticalScrollBar().setValue(120)
        self.assertTrue(widgets.set_table_rows(view, m, self.history(51)))
        self.assertEqual(view.verticalScrollBar().value(), 120)

    def test_replacing_rows_keeps_the_selected_row_by_its_key(self):
        m = widgets.TableModel(tables.PROFILE_COLUMNS, tone_column=4)
        view = widgets.make_table(m)
        rows = tables.profile_rows(guifix.profiles(), 1000.0)
        widgets.set_table_rows(view, m, rows, key=lambda r: r.id)
        view.selectRow(1)
        self.assertEqual(widgets.selected_row(view, m).id, "ovpn-us")
        widgets.set_table_rows(view, m, tuple(reversed(rows)), key=lambda r: r.id)        # another order
        self.assertEqual(widgets.selected_row(view, m).id, "ovpn-us")
        self.assertEqual(view.currentIndex().row(), 0)

    def test_the_selection_is_dropped_when_its_row_is_gone(self):
        m = widgets.TableModel(tables.PROFILE_COLUMNS, tone_column=4)
        view = widgets.make_table(m)
        rows = tables.profile_rows(guifix.profiles(), 1000.0)
        widgets.set_table_rows(view, m, rows, key=lambda r: r.id)
        view.selectRow(1)
        widgets.set_table_rows(view, m, rows[:1], key=lambda r: r.id)
        self.assertIsNone(widgets.selected_row(view, m))

    def test_unchanged_rows_change_nothing(self):
        m = widgets.TableModel(tables.HISTORY_COLUMNS, tone_column=1)
        view = widgets.make_table(m)
        widgets.set_table_rows(view, m, self.history(3))
        view.selectRow(0)
        self.assertFalse(widgets.set_table_rows(view, m, self.history(3)))
        self.assertIsNotNone(widgets.selected_row(view, m))

    def test_nothing_selected_means_no_row(self):
        m = widgets.TableModel(tables.HISTORY_COLUMNS, tone_column=1)
        view = widgets.make_table(m)
        widgets.set_table_rows(view, m, self.history(2))
        self.assertIsNone(widgets.selected_row(view, m))


class IconTests(qtcase.QtCase):
    def setUp(self):
        super().setUp()
        widgets._ICONS.clear()

    def test_an_icon_per_tone_is_made_once(self):
        a, b = widgets.status_icon(GOOD), widgets.status_icon(BAD)
        self.assertIsNot(a, b)
        self.assertIs(widgets.status_icon(GOOD), a)

    def test_the_icon_is_painted_as_a_ring_and_the_painter_is_finished(self):
        from fakeqt.gui import QPainter
        made = []

        class Recording(QPainter):
            def __init__(self, device):
                super().__init__(device)
                made.append(self)

        with mock.patch.object(widgets, "QPainter", Recording):
            icon = widgets.status_icon(WARN)
        painter = made[0]
        self.assertFalse(painter.active)                                  # end() was called
        self.assertEqual([c[0] for c in painter.calls], ["hint", "pen", "brush", "ellipse", "brush", "ellipse"])
        self.assertEqual(painter.calls[2][1].color.name(), "#d29922")     # the warning colour
        self.assertEqual(painter.calls[4][1].color.name(), "#0f1419")     # the dark centre
        self.assertIs(icon.pixmap.filled, Qt.GlobalColor.transparent)


if __name__ == "__main__":
    unittest.main()
