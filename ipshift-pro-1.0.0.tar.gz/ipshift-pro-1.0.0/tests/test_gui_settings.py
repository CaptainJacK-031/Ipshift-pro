"""The settings table against the daemon's own rules: the page may never offer what the daemon refuses."""
from __future__ import annotations

import unittest

import helpers  # noqa: F401
from ipshift.config import MIN_INTERVAL, Config
from ipshift.engine import IPC_SETTABLE_KEYS, IPC_SETTABLE_SECTIONS, RESTART_KEYS, ipc_settable
from ipshift.errors import ConfigError
from ipshift.gui import settings_schema as S

# Keys whose limits the daemon enforces on both sides: the table must match them exactly.
EXACT = ("rotation.interval", "rotation.jitter_pct", "vpn.connect_timeout", "vpn.verify_timeout",
         "vpn.wg_keepalive", "privacy.quorum", "privacy.http_timeout", "privacy.history_retention_days",
         "privacy.history_max_rows")


def accepts(key, value) -> bool:
    try:
        Config().set(key, value)
        return True
    except ConfigError:
        return False


class SchemaTests(unittest.TestCase):
    def test_every_key_exists_and_may_be_changed_over_the_socket(self):
        seen = set()
        for s in S.all_settings():
            self.assertNotIn(s.key, seen, "duplicate key")
            seen.add(s.key)
            Config().get(s.key)                                   # raises for an unknown key
            self.assertTrue(ipc_settable(s.key), f"{s.key} is not settable by a client")

    def test_nothing_that_decides_what_root_runs_is_offered(self):
        forbidden = {"vpn.openvpn_bin", "vpn.wg_bin", "vpn.ip_bin", "vpn.openvpn_user", "vpn.interface",
                     "vpn.bootstrap_doh", "killswitch.nft_bin"}
        keys = {s.key for s in S.all_settings()}
        self.assertFalse(keys & forbidden)
        self.assertFalse([k for k in keys if k.startswith("daemon.")])
        self.assertFalse(keys & (set(IPC_SETTABLE_KEYS) & forbidden))
        self.assertTrue({k.split(".")[0] for k in keys} <= IPC_SETTABLE_SECTIONS | {"vpn", "killswitch"})

    def test_each_kind_matches_the_type_the_daemon_stores(self):
        cfg = Config()
        for s in S.all_settings():
            v = cfg.get(s.key)
            if s.kind == "bool":
                self.assertIsInstance(v, bool, s.key)
            elif s.kind == "int":
                self.assertIsInstance(v, int, s.key)
            elif s.kind == "float":
                self.assertIsInstance(v, float, s.key)
            elif s.kind in ("multi", "list"):
                self.assertIsInstance(v, list, s.key)
            elif s.kind == "choice":
                self.assertIn(v, [c for c, _ in s.choices], f"{s.key}: the default must be a listed choice")
            else:
                self.fail(f"{s.key}: unknown kind {s.kind}")

    def test_the_default_of_every_numeric_setting_is_inside_its_range(self):
        cfg = Config()
        for s in S.all_settings():
            if s.kind in ("int", "float"):
                self.assertLessEqual(s.minimum, cfg.get(s.key), s.key)
                self.assertGreaterEqual(s.maximum, cfg.get(s.key), s.key)

    def test_both_ends_of_every_range_are_accepted_by_the_daemon(self):
        for s in S.all_settings():
            if s.kind in ("int", "float"):
                cast = int if s.kind == "int" else float
                self.assertTrue(accepts(s.key, cast(s.minimum)), f"{s.key} minimum {s.minimum}")
                self.assertTrue(accepts(s.key, cast(s.maximum)), f"{s.key} maximum {s.maximum}")

    def test_where_the_daemon_has_limits_the_table_has_the_same_ones(self):
        for key in EXACT:
            s = S.find(key)
            cast = int if s.kind == "int" else float
            below = cast(s.minimum) - (1 if s.kind == "int" else 0.001)
            above = cast(s.maximum) + (1 if s.kind == "int" else 0.001)
            self.assertFalse(accepts(key, below), f"{key}: the daemon should refuse {below}")
            self.assertFalse(accepts(key, above), f"{key}: the daemon should refuse {above}")

    def test_the_rotation_interval_floor_is_the_one_second_minimum(self):
        s = S.find("rotation.interval")
        self.assertEqual((s.minimum, MIN_INTERVAL), (1.0, 1.0))
        self.assertFalse(accepts("rotation.interval", 0.5))
        self.assertFalse(accepts("rotation.interval", 0))

    def test_every_choice_is_accepted(self):
        for s in S.all_settings():
            if s.kind == "choice":
                for value, label in s.choices:
                    self.assertTrue(accepts(s.key, value), f"{s.key} = {value!r}")
                    self.assertTrue(label)

    def test_every_tier_offered_is_accepted(self):
        s = S.find("rotation.tiers")
        self.assertTrue(accepts(s.key, [v for v, _ in s.choices]))
        self.assertTrue(accepts(s.key, []))

    def test_list_settings_accept_what_the_page_sends(self):
        self.assertTrue(accepts("dns.servers", ["1.1.1.1", "9.9.9.9"]))
        self.assertTrue(accepts("dns.servers", []))
        self.assertFalse(accepts("dns.servers", ["not-an-ip"]))

    def test_the_risky_settings_say_why_and_name_the_unsafe_value(self):
        risky = [s for s in S.all_settings() if s.risky_value is not None]
        self.assertGreaterEqual(len(risky), 7)
        for s in risky:
            self.assertEqual(s.kind, "bool", s.key)
            self.assertTrue(s.risk, f"{s.key} needs a risk text")
        unsafe = {s.key: s.risky_value for s in risky}
        self.assertIs(unsafe["killswitch.enabled"], False)
        self.assertIs(unsafe["killswitch.allow_lan"], True)
        self.assertIs(unsafe["privacy.baseline"], True)
        self.assertIs(unsafe["dns.manage"], False)

    def test_restart_flags_match_the_daemon(self):
        flagged = {s.key for s in S.all_settings() if s.restart}
        self.assertEqual(flagged, {"killswitch.arm_on_start", "privacy.history"})
        self.assertTrue({"privacy.history"} <= set(RESTART_KEYS))

    def test_every_setting_has_a_label_and_sits_in_the_section_of_its_key(self):
        prefix = {"Rotation": "rotation", "Kill switch": "killswitch", "VPN": "vpn", "DNS": "dns", "Privacy": "privacy"}
        self.assertEqual([sec.title for sec in S.SECTIONS], list(prefix))
        for sec in S.SECTIONS:
            self.assertTrue(sec.intro)
            for s in sec.settings:
                self.assertTrue(s.label, s.key)
                self.assertEqual(s.key.split(".")[0], prefix[sec.title], s.key)


class HelperTests(unittest.TestCase):
    def test_find(self):
        self.assertEqual(S.find("rotation.strategy").kind, "choice")
        with self.assertRaises(KeyError):
            S.find("daemon.group")

    def test_parse_list_and_list_text(self):
        self.assertEqual(S.parse_list("a, b;c ,, d"), ["a", "b", "c", "d"])
        self.assertEqual(S.parse_list(["x", " y ", ""]), ["x", "y"])
        self.assertEqual(S.parse_list(""), [])
        self.assertEqual(S.parse_list(None), [])
        self.assertEqual(S.list_text(["1.1.1.1", "9.9.9.9"]), "1.1.1.1, 9.9.9.9")
        self.assertEqual(S.list_text(None), "")

    def test_clamp(self):
        s = S.find("rotation.interval")
        self.assertEqual((S.clamp(s, 0.1), S.clamp(s, 5), S.clamp(s, 1e9)), (1.0, 5, 86400.0))
        self.assertEqual(S.clamp(S.find("dns.manage"), 3), 3)

    def test_confirmation_only_before_the_unsafe_value(self):
        kill = S.find("killswitch.enabled")
        self.assertEqual(S.needs_confirmation(kill, True), "")
        self.assertIn("real address is exposed", S.needs_confirmation(kill, False))
        lan = S.find("killswitch.allow_lan")
        self.assertEqual(S.needs_confirmation(lan, False), "")
        self.assertIn("Allow the local network", S.needs_confirmation(lan, True))
        self.assertEqual(S.needs_confirmation(S.find("rotation.strategy"), "random"), "")

    def test_the_words_for_when_a_change_takes_effect(self):
        self.assertEqual(S.applies_text({"applies": "now", "saved": True}), "takes effect now; saved")
        self.assertIn("daemon restart", S.applies_text({"applies": "restart", "saved": True}))
        self.assertEqual(S.applies_text({"applies": "next_connect", "saved": False}),
                         "takes effect at the next connection; not saved to the config file")
        self.assertEqual(S.applies_text(None), "not saved to the config file")


if __name__ == "__main__":
    unittest.main()
