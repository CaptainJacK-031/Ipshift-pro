"""The main window (ipshift.gui.window): what it shows of what the daemon says, navigation, the tray,
polling and closing.  The buttons and the commands they send are in test_gui_window_actions.py."""
from __future__ import annotations

import threading
import unittest

import helpers  # noqa: F401
import fakeqt
import guifix
import qtcase
import wincase
from ipshift import __version__
from ipshift.gui import tables, views
from ipshift.gui.link import Result
from ipshift.gui.model import describe_result
from ipshift.privacy.report import NOT_COVERED


def setUpModule():
    qtcase.install()
    global window, widgets, Qt, QEvent, QSystemTrayIcon
    from PySide6.QtCore import QEvent, Qt
    from PySide6.QtWidgets import QSystemTrayIcon
    from ipshift.gui import widgets, window


def tearDownModule():
    qtcase.uninstall()


def error_event(message="Could not connect to NL 1: auth failed", level="error", kind="connect_failed",
                ts=wincase.WindowCase.NOW + 5, hint="check the login") -> dict:
    return {"ts": ts, "level": level, "kind": kind, "data": {"message": message, "hint": hint}}


class ConstructionTests(wincase.WindowCase):
    def test_the_window_starts_on_the_dashboard_and_waits_for_the_daemon(self):
        w = self.win
        self.assertEqual(w.page_name, "Dashboard")
        self.assertEqual(w.outer.currentIndex(), 1)                      # the "no daemon yet" panel
        self.assertEqual(w.offline.title.text(), "Connecting to the IPShift daemon...")
        self.assertTrue(w.offline.retry.isHidden())
        self.assertEqual(w.link_label.text(), "Daemon not reachable")
        self.assertEqual(w.windowTitle(), "IPShift Pro")

    def test_the_navigation_lists_the_pages_in_order(self):
        w = self.win
        self.assertEqual([w.nav.item(i).text() for i in range(w.nav.count())], list(window.NAV))
        self.assertEqual(w.stack.count(), len(window.NAV))
        self.assertEqual(w.nav.currentRow(), 0)
        for name, page in zip(window.NAV, (w.dashboard, w.privacy, w.history, w.profiles, w.settings)):
            self.assertIs(w.pages[name], page)

    def test_the_sidebar_says_that_closing_the_window_does_not_stop_anything(self):
        self.assertIn("Closing this window does not stop the VPN or the rotation.", self.texts(self.win))

    def test_the_menus(self):
        bar = self.win.menuBar()
        self.assertEqual([m.title_value for m in bar.menus], ["&File", "&Help"])
        self.assertEqual([a.text() for a in bar.menu("&Help").actions_list],
                         ["What this tool cannot do", "&About IPShift Pro"])
        self.assertEqual([a.text() for a in bar.menu("&File").actions_list], ["&Close window"])

    def test_the_interval_box_is_given_the_models_advice(self):
        self.assertEqual(self.win.dashboard.advice_fn(1.0), self.model.advice(1.0))


class DemoWindowTests(wincase.WindowCase):
    demo = True

    def test_a_demo_window_says_so_and_does_not_tell_how_to_start_a_daemon(self):
        self.assertEqual(self.win.windowTitle(), "IPShift Pro (demo)")
        self.assertTrue(self.win.offline.steps_title.isHidden())
        self.connect_daemon()
        self.assertEqual(self.win.windowTitle(), "IPShift Pro - PROTECTED (demo)")


class ConnectionTests(wincase.WindowCase):
    def test_when_the_link_is_down_the_panel_says_why_and_offers_a_retry(self):
        self.win.show()
        self.feed("link_changed", False, "Connection refused", "Start it with: sudo systemctl start ipshiftd")
        w = self.win
        self.assertEqual(w.outer.currentIndex(), 1)
        self.assertEqual(w.offline.title.text(), "The IPShift daemon is not reachable")
        self.assertEqual(w.offline.error.text(), "Connection refused")
        self.assertEqual(w.offline.hint.text(), "Start it with: sudo systemctl start ipshiftd")
        self.assertFalse(w.offline.retry.isHidden())
        self.assertEqual((w.link_label.text(), w.link_label.property("tone")), ("Daemon not reachable", views.WARN))
        w.offline.retry.click()
        self.assertEqual(self.link.refreshes, [True])

    def test_the_panel_shows_how_to_get_a_daemon_unless_it_is_a_demo(self):
        steps = self.texts(self.win.offline)
        self.assertTrue(any("sudo systemctl start ipshiftd" in t for t in steps))
        self.assertTrue(any("usermod -aG ipshift" in t for t in steps))

    def test_when_the_daemon_is_reachable_the_pages_show_and_the_settings_are_requested(self):
        self.win.show()
        self.feed("link_changed", True, "", "")
        self.assertEqual(self.win.outer.currentIndex(), 0)
        self.assertEqual(self.link.names, ["config_get"])
        self.assertEqual((self.win.link_label.text(), self.win.link_label.property("tone")),
                         ("Daemon connected", views.GOOD))

    def test_losing_the_daemon_forgets_the_status_so_that_an_old_one_is_never_shown(self):
        self.connect_daemon()
        self.feed("link_changed", False, "gone", "")
        self.assertIsNone(self.model.status)
        self.assertEqual(self.win.outer.currentIndex(), 1)
        self.assertEqual(self.win.windowTitle(), "IPShift Pro")

    def test_the_interval_the_daemon_has_is_taken_again_after_a_reconnect(self):
        self.connect_daemon()
        self.win.dashboard.interval.setValue(12.0)
        self.feed("link_changed", False, "gone", "")
        self.feed("link_changed", True, "", "")
        self.feed("status_received", guifix.status())          # the daemon rotates every 1.0 s
        self.assertEqual(self.win.dashboard.interval.value(), 1.0)


class WhatTheStatusShowsTests(wincase.WindowCase):
    def test_a_status_fills_the_dashboard_the_title_and_the_tray(self):
        self.connect_daemon()
        w = self.win
        self.assertEqual(w.dashboard.banner.title.text(), "PROTECTED")
        self.assertEqual(w.windowTitle(), "IPShift Pro - PROTECTED")
        self.assertEqual(w.tray.toolTip(), "IPShift Pro: Protected")
        self.assertIs(w.tray.icon(), widgets.status_icon(views.GOOD))
        self.assertIs(w.windowIcon(), widgets.status_icon(views.GOOD))

    def test_the_icons_follow_the_protection_level(self):
        self.connect_daemon()
        self.feed("status_received", guifix.idle("unprotected"))
        self.assertEqual(self.win.windowTitle(), "IPShift Pro - UNPROTECTED")
        self.assertEqual(self.win.tray.toolTip(), "IPShift Pro: Unprotected")
        self.assertIs(self.win.tray.icon(), widgets.status_icon(views.BAD))
        self.feed("status_received", guifix.idle("blocked"))
        self.assertIs(self.win.tray.icon(), widgets.status_icon(views.WARN))
        self.feed("link_changed", False, "gone", "")
        self.assertEqual(self.win.tray.toolTip(), "IPShift Pro")
        self.assertIs(self.win.tray.icon(), widgets.status_icon(views.MUTED))

    def test_a_page_that_is_not_shown_is_not_drawn_until_it_is(self):
        self.win.show()
        self.win.select_page("History")
        self.feed("link_changed", True, "", "")
        self.feed("status_received", guifix.status())
        self.assertEqual(self.win.dashboard.banner.title.text(), "")
        self.win.select_page("Dashboard")
        self.assertEqual(self.win.dashboard.banner.title.text(), "PROTECTED")

    def test_the_busy_commands_lock_the_buttons_that_would_collide(self):
        self.connect_daemon(guifix.idle("unprotected"))
        d = self.win.dashboard
        self.assertTrue(d.start_button.isEnabled())
        self.feed("busy_changed", frozenset({"rotate_start"}))
        self.assertFalse(d.start_button.isEnabled())
        self.feed("busy_changed", frozenset())
        self.assertTrue(d.start_button.isEnabled())

    def test_a_simulated_daemon_is_announced_on_the_dashboard(self):
        st = guifix.status(daemon={"version": "1.0.0", "pid": 1, "uptime": 1, "simulated": True, "root": True})
        self.connect_daemon(st)
        self.assertIn("SIMULATION", self.win.dashboard.banner.extra.text())


class NavigationTests(wincase.WindowCase):
    def setUp(self):
        super().setUp()
        self.connect_daemon()

    def test_choosing_a_page_shows_it_and_tells_the_link_whether_the_history_is_wanted(self):
        self.win.nav.setCurrentRow(2)
        self.assertEqual((self.win.page_name, self.win.stack.currentIndex()), ("History", 2))
        self.assertIs(self.link.history_wanted, True)
        self.win.nav.setCurrentRow(0)
        self.assertEqual(self.win.page_name, "Dashboard")
        self.assertIs(self.link.history_wanted, False)

    def test_profiles_and_settings_ask_for_fresh_data_and_settings_also_load_the_config(self):
        self.win.select_page("Profiles")
        self.assertEqual((self.link.refreshes, self.link.names), ([True], []))
        self.win.select_page("Settings")
        self.assertEqual((self.link.refreshes, self.link.names), ([True, True], ["config_get"]))
        self.win.select_page("Privacy")
        self.assertEqual(len(self.link.refreshes), 2)

    def test_the_details_link_on_the_dashboard_opens_the_privacy_page(self):
        self.win.dashboard.open_privacy.click()
        self.assertEqual(self.win.page_name, "Privacy")
        self.assertEqual(self.win.nav.currentRow(), 1)

    def test_every_page_can_be_selected_by_name(self):
        for name in window.NAV:
            self.win.select_page(name)
            self.assertEqual(self.win.page_name, name)


class DataTests(wincase.WindowCase):
    def test_profiles_fill_the_profiles_page_and_connecting_follows_the_busy_state(self):
        self.connect_daemon(page="Profiles")
        self.feed("data_received", "profiles", guifix.profiles())
        p = self.win.profiles
        self.assertEqual(p.model.rowCount(), 2)
        p.view.selectRow(0)
        self.assertTrue(p.connect_button.isEnabled())
        self.feed("busy_changed", frozenset({"connect"}))
        self.assertFalse(p.connect_button.isEnabled())
        self.assertEqual(p.selected().id, "wg-nl")                       # still selected
        self.feed("busy_changed", frozenset())
        self.assertTrue(p.connect_button.isEnabled())

    def test_history_fills_the_history_page_and_the_filter_applies(self):
        data = guifix.history(3)
        data["rotations"][1]["status"] = "failed"
        self.connect_daemon(page="History")
        self.feed("data_received", "history", data)
        h = self.win.history
        self.assertEqual(h.rotations_model.rowCount(), 3)
        self.assertTrue(h.export_button.isEnabled())
        h.filter.setCurrentIndex(2)                                      # only the failed ones
        self.assertEqual(h.rotations_model.rowCount(), 1)
        h.filter.setCurrentIndex(0)
        self.assertEqual(h.rotations_model.rowCount(), 3)

    def test_a_history_longer_than_what_was_fetched_says_how_much_is_shown(self):
        data = guifix.history(3)
        data["stats"]["total"] = 40
        self.connect_daemon(page="History", history=data)
        self.assertTrue(self.win.history.stats.text().endswith("Showing the newest 3."))

    def test_an_empty_history_cannot_be_exported(self):
        self.connect_daemon(page="History", history={"rotations": [], "stats": {}, "events": []})
        self.assertFalse(self.win.history.export_button.isEnabled())

    def test_the_report_fills_the_privacy_page_and_a_running_check_shows_the_bar(self):
        self.connect_daemon(page="Privacy")
        self.feed("data_received", "report", guifix.report())
        p = self.win.privacy
        self.assertEqual(p.grade.text(), "A")
        self.assertTrue(p.progress.isHidden())
        self.feed("busy_changed", frozenset({"privacy_check"}))
        self.assertFalse(p.progress.isHidden())
        self.assertFalse(p.run_full.isEnabled())
        self.feed("busy_changed", frozenset())
        self.assertTrue(p.progress.isHidden())
        self.assertTrue(p.run_full.isEnabled())

    def test_signals_from_other_threads_arrive_in_the_gui_thread_and_not_before_it_is_ready(self):
        self.connect_daemon()
        worker = threading.Thread(target=lambda: (self.bridge.status_received.emit(guifix.idle("blocked")),
                                                  self.bridge.event_received.emit(error_event())))
        worker.start()
        worker.join()
        self.assertEqual(self.win.dashboard.banner.title.text(), "PROTECTED")     # queued: nothing yet
        self.app.processEvents()
        self.assertEqual(self.win.dashboard.banner.title.text(), "BLOCKED")
        self.assertEqual(self.win.dashboard.alerts.count, 1)
        self.assertEqual(fakeqt.state.violations, [])


class EventTests(wincase.WindowCase):
    def setUp(self):
        super().setUp()
        self.connect_daemon()

    def test_an_error_is_listed_on_the_dashboard_and_shown_as_a_desktop_notification(self):
        self.feed("event_received", error_event())
        self.assertEqual(self.win.tray.messages, [("VPN connection failed", "Could not connect to NL 1: auth failed",
                                                   QSystemTrayIcon.MessageIcon.Critical, 10000)])
        self.assertEqual(self.win.dashboard.alerts.count, 1)
        self.assertIn("Could not connect to NL 1: auth failed", self.texts(self.win.dashboard.alerts))
        self.assertIn("check the login", self.texts(self.win.dashboard.alerts))

    def test_a_critical_event_also_interrupts(self):
        self.feed("event_received", error_event("Kill switch was removed", level="critical",
                                                kind="killswitch_tampered"))
        self.assertEqual([m[0] for m in self.win.tray.messages], ["Kill switch was tampered with"])

    def test_a_warning_is_listed_but_does_not_interrupt(self):
        self.feed("event_received", error_event("Tunnel lost", level="warning", kind="tunnel_lost"))
        self.assertEqual(self.win.tray.messages, [])
        self.assertEqual(self.win.dashboard.alerts.count, 1)

    def test_an_ordinary_event_is_neither(self):
        self.feed("event_received", error_event("Connected to NL 1", level="info", kind="connected"))
        self.assertEqual(self.win.tray.messages, [])
        self.assertEqual(self.win.dashboard.alerts.count, 0)

    def test_an_event_from_before_the_window_opened_is_listed_but_does_not_interrupt(self):
        self.feed("event_received", error_event(ts=self.NOW - 3600))
        self.assertEqual(self.win.tray.messages, [])
        self.assertEqual(self.win.dashboard.alerts.count, 1)

    def test_only_the_newest_alerts_are_shown_on_the_dashboard(self):
        for i in range(window.DASHBOARD_ALERTS + 4):
            self.feed("event_received", error_event(f"failure {i}", ts=self.NOW + 10 + i))
        shown = self.texts(self.win.dashboard.alerts)
        self.assertEqual(self.win.dashboard.alerts.count, window.DASHBOARD_ALERTS)
        self.assertIn(f"failure {window.DASHBOARD_ALERTS + 3}", shown)
        self.assertNotIn("failure 0", shown)


class NoTrayEventTests(wincase.WindowCase):
    def prepare(self):
        fakeqt.state.tray_available = False

    def test_without_a_tray_an_error_is_still_listed_and_nothing_breaks(self):
        self.assertIsNone(self.win.tray)
        self.connect_daemon()
        self.feed("event_received", error_event())
        self.feed("status_received", guifix.idle("unprotected"))
        self.assertEqual(self.win.dashboard.alerts.count, 1)
        self.win.close()


class ResultTests(wincase.WindowCase):
    def setUp(self):
        super().setUp()
        self.connect_daemon()

    def test_a_result_shows_a_toast_with_the_outcome(self):
        res = Result("rotate_start", True, {"interval": 1.0})
        self.feed("result_ready", res)
        t = self.win.toast
        self.assertFalse(t.isHidden())
        self.assertEqual(t.text.text(), describe_result(res).text)
        self.assertTrue(t.text.text().startswith("Rotation started"))
        self.assertEqual(t.frame.property("tone"), views.GOOD)

    def test_a_failed_result_shows_its_message_and_hint_in_red(self):
        self.feed("result_ready", Result("connect", False, None, {"code": "connect_failed", "message": "Could not connect",
                                                                   "hint": "try another profile"}))
        t = self.win.toast
        self.assertEqual((t.text.text(), t.hint.text(), t.frame.property("tone")),
                         ("Could not connect", "try another profile", views.BAD))

    def test_a_busy_daemon_is_explained_in_words(self):
        self.feed("result_ready", Result("connect", False, None, {"code": "busy", "message": "busy"}))
        self.assertEqual(self.win.toast.text.text(), "Another operation is still running. Try again in a moment.")

    def test_quiet_commands_show_nothing_when_they_work_but_do_when_they_fail(self):
        self.feed("result_ready", Result("config_get", True, guifix.config_get()))
        self.feed("result_ready", Result("ip", True, {"public": {"v4": "192.0.2.77", "source": "direct"}}))
        self.assertTrue(self.win.toast.isHidden())
        self.feed("result_ready", Result("config_get", False, None, {"message": "no access"}))
        self.assertFalse(self.win.toast.isHidden())
        self.assertEqual(self.win.toast.text.text(), "no access")

    def test_the_real_address_lookup_is_kept_by_the_model_and_shown_on_the_dashboard(self):
        self.feed("status_received", guifix.idle("unprotected"))
        self.assertEqual(self.win.dashboard.public_value.text(), "hidden")
        self.feed("result_ready", Result("ip", True, {"public": {"v4": "192.0.2.77", "v6": None, "source": "direct"}}))
        self.assertEqual(self.win.dashboard.public_value.text(), "192.0.2.77")

    def test_a_finished_privacy_check_is_kept_for_the_privacy_page(self):
        self.win.select_page("Privacy")
        self.feed("result_ready", Result("privacy_check", True, guifix.report(dns_escape="fail")))
        self.assertEqual(self.win.privacy.dns_tile.word.text(), "LEAK")


class SettingsFlowTests(wincase.WindowCase):
    def setUp(self):
        super().setUp()
        self.connect_daemon(page="Settings")

    def load(self, over=None, **kw):
        self.feed("result_ready", Result("config_get", True, guifix.config_get(over, **kw)))

    def test_the_config_arrives_and_the_settings_page_shows_it(self):
        self.load({"rotation.interval": 7.5, "killswitch.enabled": True}, file="/etc/ipshift/config.toml")
        s = self.win.settings
        self.assertEqual(s.value("rotation.interval"), 7.5)
        self.assertIs(s.value("killswitch.enabled"), True)
        self.assertIn("/etc/ipshift/config.toml", s.note.text())
        self.assertTrue(s.control("rotation.interval").isEnabled())

    def test_a_simulated_daemon_says_that_nothing_is_saved(self):
        self.load(simulated=True)
        self.assertTrue(self.win.settings.note.text().startswith("SIMULATION: changes are not saved to disk."))

    def test_a_change_is_sent_with_its_key_and_value(self):
        self.load()
        self.win.settings.control("killswitch.log_drops").setChecked(True)
        self.assertEqual(self.link.last("config_set"), {"key": "killswitch.log_drops", "value": True})

    def test_a_refused_change_is_put_back_and_not_sent_again(self):
        self.load()
        box = self.win.settings.control("killswitch.log_drops")
        box.setChecked(True)
        self.feed("result_ready", Result("config_set", False, None, {"message": "refused"}))
        self.assertFalse(box.isChecked())
        self.assertEqual(self.link.names.count("config_set"), 1)
        self.assertEqual(self.win.toast.text.text(), "refused")

    def test_an_accepted_change_is_remembered_so_that_a_later_reload_shows_it(self):
        self.load()
        self.win.settings.control("killswitch.log_drops").setChecked(True)
        res = Result("config_set", True, {"key": "killswitch.log_drops", "value": True, "applies": "live", "saved": True})
        self.feed("result_ready", res)
        self.assertIs(self.model.config["config"]["killswitch"]["log_drops"], True)
        self.assertTrue(self.win.toast.text.text().startswith("killswitch.log_drops changed"))
        self.win.settings.load(self.model.config["config"], force=True)
        self.assertTrue(self.win.settings.control("killswitch.log_drops").isChecked())


class ImportResultTests(wincase.WindowCase):
    def test_an_import_result_is_summarised_in_a_message_and_a_toast(self):
        self.connect_daemon(page="Profiles")
        outcomes = [tables.ImportOutcome("/a/x.ovpn", True, "X"), tables.ImportOutcome("/a/y.conf", False, "y", "bad file")]
        self.feed("result_ready", Result("profile_import", True, outcomes))
        self.assertEqual(self.hooks.informs, [("Import finished", tables.import_summary(outcomes))])
        self.assertEqual(self.win.toast.text.text(), "Imported 1 of 2 profile(s)")
        self.assertEqual(self.win.toast.frame.property("tone"), views.WARN)

    def test_other_results_open_no_message(self):
        self.connect_daemon()
        self.feed("result_ready", Result("profile_remove", True, {}))
        self.assertEqual(self.hooks.informs, [])


class TrayAndWindowTests(wincase.WindowCase):
    def test_the_tray_icon_is_shown_with_a_menu_that_shows_and_closes_the_window(self):
        w = self.win
        self.assertTrue(w.tray.isVisible())
        self.assertEqual([a.text() for a in w._tray_menu.actions_list], ["Show window", "Close window"])
        w._tray_menu.action("Show window").trigger()
        self.assertTrue(w.isVisible())
        w._tray_menu.action("Close window").trigger()
        self.assertTrue(self.link.closed)

    def test_the_file_menu_closes_the_window(self):
        self.win.show()
        self.win.menuBar().menu("&File").action("&Close window").trigger()
        self.assertTrue(self.link.closed)
        self.assertFalse(self.win.isVisible())

    def test_the_link_is_polled_quickly_while_the_window_is_shown_and_slowly_while_it_is_not(self):
        w = self.win
        w.show()
        self.assertEqual(self.link.poll, window.FAST_POLL)
        w.hide()
        self.assertEqual(self.link.poll, window.SLOW_POLL)
        w.showNormal()
        self.assertEqual(self.link.poll, window.FAST_POLL)
        w.showMinimized()
        self.assertEqual(self.link.poll, window.SLOW_POLL)
        w.showNormal()
        self.assertEqual(self.link.poll, window.FAST_POLL)

    def test_closing_stops_the_link_the_timer_and_the_tray_and_quits_the_application(self):
        w = self.win
        w.show()
        w.close()
        self.assertTrue(self.link.closed)
        self.assertTrue(self.app.quit_called)
        self.assertFalse(w.tray.isVisible())
        self.assertFalse(w.countdown_timer.isActive())

    def test_the_about_box_names_the_version(self):
        self.win.menuBar().menu("&Help").action("&About IPShift Pro").trigger()
        title, text = self.hooks.informs[-1]
        self.assertEqual(title, "About IPShift Pro")
        self.assertIn(f"IPShift Pro {__version__}", text)
        self.assertIn("ipshiftd", text)

    def test_the_limits_box_is_honest_about_what_a_vpn_cannot_do(self):
        self.win.menuBar().menu("&Help").action("What this tool cannot do").trigger()
        title, text = self.hooks.informs[-1]
        self.assertEqual(title, "What this tool cannot do")
        self.assertIn("No software can promise anonymity", text)
        self.assertIn("free VPNs may log or sell your traffic", text)
        for item in NOT_COVERED:
            self.assertIn(item, text)


class CountdownTests(wincase.WindowCase):
    def test_the_countdown_runs_down_between_status_updates_while_the_dashboard_is_shown(self):
        self.connect_daemon()
        self.assertEqual(self.win.dashboard.countdown.text(), "next change in 0.6 s")
        self.mono += 0.3
        self.pump(0.3)
        self.assertEqual(self.win.dashboard.countdown.text(), "next change in 0.3 s")
        self.mono += 5
        self.pump(0.3)
        self.assertEqual(self.win.dashboard.countdown.text(), "next change in 0.0 s")

    def test_it_does_not_run_while_another_page_is_shown_or_the_daemon_is_away(self):
        self.connect_daemon()
        self.win.select_page("History")
        self.win.select_page("Dashboard")
        shown = self.win.dashboard.countdown.text()
        self.win.select_page("History")
        self.mono += 0.4
        self.pump(0.3)
        self.assertEqual(self.win.dashboard.countdown.text(), shown)
        self.win.select_page("Dashboard")
        self.feed("link_changed", False, "gone", "")
        before = self.win.dashboard.countdown.text()
        self.mono += 0.4
        self.pump(0.3)
        self.assertEqual(self.win.dashboard.countdown.text(), before)


if __name__ == "__main__":
    unittest.main()
