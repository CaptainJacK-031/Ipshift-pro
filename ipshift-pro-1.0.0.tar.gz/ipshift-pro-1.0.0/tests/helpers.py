"""Shared test helpers (stdlib unittest only - the project has no test deps)."""
from __future__ import annotations

import logging
import os
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

SRC = Path(__file__).resolve().parents[1] / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from ipshift.sysutil import CmdResult  # noqa: E402

# Expected warnings (a missing 'ipshift' group, a kill switch left up on purpose...) would otherwise be
# printed by logging's last-resort handler in the middle of the test output.  assertLogs still sees them.
logging.getLogger("ipshift").addHandler(logging.NullHandler())


class FakeRunner:
    """Scriptable stand-in for :class:`ipshift.sysutil.Runner`.

    ``rules`` is a list of ``(predicate, result)``; the first rule whose
    predicate matches the argv wins.  A predicate may be a string (prefix of the
    space-joined argv) or a callable.  ``result`` may be a CmdResult, a
    ``(rc, stdout)`` tuple or a callable returning either.  Unmatched commands
    succeed with empty output, and every call is recorded in ``calls``.
    """

    def __init__(self, rules=None, default_rc: int = 0):
        self.rules = list(rules or [])
        self.calls: list[tuple] = []
        self.inputs: list = []
        self.default_rc = default_rc

    def add(self, predicate, result) -> None:
        self.rules.insert(0, (predicate, result))

    def run(self, args, *, timeout=15.0, input=None, env=None) -> CmdResult:
        args = tuple(str(a) for a in args)
        self.calls.append(args)
        self.inputs.append(input)
        line = " ".join(args)
        for pred, res in self.rules:
            hit = pred(args) if callable(pred) else line.startswith(pred)
            if hit:
                if callable(res):
                    res = res(args)
                if isinstance(res, CmdResult):
                    return res
                rc, out = res[0], (res[1] if len(res) > 1 else "")
                err = res[2] if len(res) > 2 else ""
                return CmdResult(args, rc, out, err)
        return CmdResult(args, self.default_rc, "", "")

    def popen(self, args, **kw):  # pragma: no cover - tests that need it override
        raise NotImplementedError

    def lines(self) -> list[str]:
        return [" ".join(c) for c in self.calls]

    def ran(self, prefix: str) -> bool:
        return any(l.startswith(prefix) for l in self.lines())


class TmpRootCase(unittest.TestCase):
    """Gives each test an isolated IPSHIFT_ROOT tree."""

    def setUp(self) -> None:
        self.tmp = Path(tempfile.mkdtemp(prefix="ipshift-test-"))
        self._old_env = dict(os.environ)
        os.environ["IPSHIFT_ROOT"] = str(self.tmp)
        os.environ.pop("IPSHIFT_SOCKET", None)
        self.addCleanup(self._restore)

    def _restore(self) -> None:
        os.environ.clear()
        os.environ.update(self._old_env)
        shutil.rmtree(self.tmp, ignore_errors=True)
