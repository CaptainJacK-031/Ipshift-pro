"""ipshift doctor: read-only readiness checks."""
from __future__ import annotations

import json
import os
import unittest
from pathlib import Path

from helpers import FakeRunner, TmpRootCase
from simharness import SimStack

from ipshift.config import Config
from ipshift.doctor import os_name, run_doctor
from ipshift.engine import Engine
from ipshift.paths import default_paths
from ipshift.vpn.profile import ProfileStore


def by_id(report):
    return {c["id"]: c for c in report["checks"]}


class DoctorCase(TmpRootCase):
    def setUp(self):
        super().setUp()
        self.cfg = Config()
        self.paths = default_paths()
        self.store = ProfileStore(self.paths.profiles_dir)
        self.os_release = self.tmp / "os-release"
        self.os_release.write_text('PRETTY_NAME="Kali GNU/Linux Rolling"\nID=kali\nID_LIKE=debian\n')
        self.dev_tun = self.tmp / "tun"
        self.dev_tun.write_text("")
        self.proc_sys = self.tmp / "proc_sys"
        (self.proc_sys / "net/ipv6/conf/all").mkdir(parents=True)
        (self.proc_sys / "net/ipv6/conf/all/disable_ipv6").write_text("0\n")
        self.resolv = self.tmp / "resolv.conf"
        self.resolv.write_text("nameserver 1.1.1.1\n")
        self.sys_module = self.tmp / "sys_module"
        (self.sys_module / "wireguard").mkdir(parents=True)
        self.have = {"nft", "ip", "openvpn", "wg", "nmcli", "modinfo"}
        self.runner = FakeRunner()

    def run_real(self, **over):
        kw = dict(runner=self.runner, store=self.store, os_release=self.os_release, dev_tun=self.dev_tun,
                  proc_sys=self.proc_sys, resolv=self.resolv, sys_module=self.sys_module,
                  find=lambda n: f"/usr/bin/{n}" if n in self.have else None)
        kw.update(over)
        return run_doctor(self.cfg, self.paths, **kw)


class SimulationTests(TmpRootCase):
    def test_simulated_engine_skips_system_checks(self):
        eng = Engine(Config(), default_paths(), simulate=True, sim_speed=0.0)
        self.addCleanup(eng.shutdown)
        rep = eng.doctor()
        ids = by_id(rep)
        self.assertTrue(rep["simulated"])
        self.assertIn("simulation", ids)
        self.assertNotIn("nft", ids)
        self.assertNotIn("root", ids)
        self.assertEqual(ids["profiles"]["status"], "ok")
        self.assertIn("free_vpn", ids)
        self.assertTrue(rep["ready"])
        json.dumps(rep)


class HealthyMachineTests(DoctorCase):
    def test_everything_present(self):
        self.store_ok()
        rep = self.run_real()
        ids = by_id(rep)
        for cid in ("os", "python", "clock", "ip", "openvpn", "wireguard", "tun", "resolv", "ipv6", "networkmanager"):
            self.assertIn(ids[cid]["status"], ("ok",), cid)
        self.assertEqual(ids["os"]["detail"], "Kali GNU/Linux Rolling")
        self.assertTrue(rep["ready"])
        self.assertEqual(sum(rep["summary"].values()), len(rep["checks"]))

    def store_ok(self):
        stack = SimStack(self.tmp / "s")
        self.addCleanup(stack.close)
        for p in stack.store.list():
            self.store.add(p, "x")


class ProblemTests(DoctorCase):
    def test_missing_programs(self):
        self.have = set()
        ids = by_id(self.run_real())
        self.assertEqual(ids["nft"]["status"], "fail")
        self.assertIn("apt install nftables", ids["nft"]["hint"])
        self.assertEqual(ids["ip"]["status"], "fail")
        self.assertEqual(ids["openvpn"]["status"], "info")           # no OpenVPN profile needs it yet
        self.assertEqual(ids["networkmanager"]["status"], "info")
        self.assertFalse(self.run_real()["ready"])

    def test_missing_programs_matter_more_when_a_profile_needs_them(self):
        stack = SimStack(self.tmp / "s")
        self.addCleanup(stack.close)
        for p in stack.store.list():
            self.store.add(p, "x")
        self.have = {"nft", "ip"}
        ids = by_id(self.run_real())
        self.assertEqual(ids["openvpn"]["status"], "warn")
        self.assertEqual(ids["wireguard"]["status"], "warn")
        self.assertIn("about a second", ids["wireguard"]["detail"])

    def test_wireguard_tool_without_kernel_support(self):
        for p in (self.sys_module / "wireguard",):
            p.rmdir()
        self.runner.add(lambda a: a[0] == "modinfo", (1, "", "not found"))
        ids = by_id(self.run_real())
        self.assertIn(ids["wireguard"]["status"], ("info", "warn"))
        self.assertIn("kernel", ids["wireguard"]["detail"])

    def test_kernel_firewall_refuses(self):
        self.runner.add(lambda a: a[:2] == ("nft", "list"), (1, "", "Operation not supported"))
        ids = by_id(self.run_real())
        self.assertEqual(ids["nft"]["status"], "fail" if os.geteuid() == 0 else "info")

    def test_wrong_clock(self):
        ids = by_id(self.run_real(clock=lambda: 1_000_000))
        self.assertEqual(ids["clock"]["status"], "fail")
        self.assertIn("timedatectl", ids["clock"]["hint"])

    def test_operating_systems(self):
        self.assertEqual(os_name(self.os_release), ("Kali GNU/Linux Rolling", "kali"))
        self.os_release.write_text('PRETTY_NAME="Debian GNU/Linux 12"\nID=debian\n')
        self.assertEqual(by_id(self.run_real())["os"]["status"], "info")
        self.os_release.write_text('PRETTY_NAME="Fedora 40"\nID=fedora\n')
        self.assertEqual(by_id(self.run_real())["os"]["status"], "warn")
        self.os_release.unlink()
        self.assertEqual(by_id(self.run_real())["os"]["status"], "warn")

    def test_no_tun_device(self):
        self.dev_tun.unlink()
        self.assertEqual(by_id(self.run_real())["tun"]["status"], "warn")

    def test_resolv_conf_variants(self):
        target = self.tmp / "stub-resolv.conf"
        target.write_text("nameserver 127.0.0.53\n")
        self.resolv.unlink()
        self.resolv.symlink_to(target)
        c = by_id(self.run_real())["resolv"]
        self.assertEqual(c["status"], "info")
        self.assertIn("symlink", c["detail"])
        self.resolv.unlink()
        self.assertEqual(by_id(self.run_real(resolv=Path("/nonexistent/dir/resolv.conf")))["resolv"]["status"], "warn")

    def test_ipv6_variants(self):
        self.assertEqual(by_id(self.run_real(proc_sys=self.tmp / "nothing"))["ipv6"]["status"], "info")

    def test_openvpn_user(self):
        self.cfg.vpn.openvpn_user = "no_such_user_xyz"
        self.assertEqual(by_id(self.run_real())["openvpn_user"]["status"], "warn")
        self.cfg.vpn.openvpn_user = ""
        self.assertEqual(by_id(self.run_real())["openvpn_user"]["status"], "warn")
        self.cfg.vpn.openvpn_user = "root"
        self.assertEqual(by_id(self.run_real())["openvpn_user"]["status"], "ok")

    def test_access_group(self):
        self.cfg.daemon.group = "no_such_group_xyz"
        c = by_id(self.run_real())["group"]
        self.assertEqual(c["status"], "warn")
        self.assertIn("groupadd no_such_group_xyz", c["hint"])
        self.cfg.daemon.group = "root"
        self.assertEqual(by_id(self.run_real())["group"]["status"], "ok")

    def test_permissions_of_the_state_directory(self):
        os.chmod(self.paths.state_dir, 0o755)
        os.chmod(self.paths.profiles_dir, 0o700)
        ids = by_id(self.run_real())
        self.assertEqual(ids["perm_var"]["status"], "warn")
        self.assertIn("chmod 700", ids["perm_var"]["hint"])
        self.assertEqual(ids["perm_profiles"]["status"], "ok")

    def test_history_database_permissions(self):
        self.paths.history_db.write_text("")
        os.chmod(self.paths.history_db, 0o644)
        self.assertEqual(by_id(self.run_real())["perm_history"]["status"], "warn")
        os.chmod(self.paths.history_db, 0o600)
        self.assertEqual(by_id(self.run_real())["perm_history"]["status"], "ok")

    def test_profiles(self):
        c = by_id(self.run_real())["profiles"]
        self.assertEqual(c["status"], "warn")
        self.assertIn("ipshift vpn import", c["hint"])

    def test_config_warnings_are_shown(self):
        self.cfg.warnings.append("unknown key ignored: rotation.speed")
        c = by_id(self.run_real())["config_warning"]
        self.assertIn("rotation.speed", c["detail"])


if __name__ == "__main__":
    unittest.main()
