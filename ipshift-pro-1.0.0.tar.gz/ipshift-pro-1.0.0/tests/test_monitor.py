"""The background monitor, driven tick by tick against the simulated world."""
from __future__ import annotations

import threading
import time
import unittest

from helpers import TmpRootCase
from simharness import SimStack

from ipshift.errors import BusyError, KillSwitchError, VpnError
from ipshift.monitor import Monitor, describe_network


class Hooks:
    """What the engine provides to the monitor."""

    def __init__(self, stack: SimStack):
        self.s = stack
        self.protect = True
        self.vpn = True
        self.rot = False
        self.recover_calls = 0
        self.recover_error: Exception | None = None

    def protect_wanted(self) -> bool:
        return self.protect

    def vpn_wanted(self) -> bool:
        return self.vpn

    def rotating(self) -> bool:
        return self.rot

    def recover_tunnel(self):
        self.recover_calls += 1
        if self.recover_error:
            raise self.recover_error
        return self.s.mgr.recover()


class MonitorCase(TmpRootCase):
    def setUp(self):
        super().setUp()
        self.s = SimStack(self.tmp)
        self.addCleanup(self.s.close)
        self.hooks = Hooks(self.s)
        self.mon = Monitor(self.s.cfg, self.s.mgr, self.s.ks, self.s.hardening, self.s.net, self.s.bus, self.hooks)
        self.addCleanup(self.mon.stop)
        self.wg = self.s.profiles("wireguard")
        self.ov = self.s.profiles("openvpn")

    def settle(self) -> None:
        """Wait for background reconnect work started by the monitor."""
        w = self.mon._worker
        if w is not None:
            w.join(10)
            self.assertFalse(w.is_alive(), "monitor worker did not finish")

    def connect(self, profile=None):
        return self.s.mgr.activate((profile or self.wg[0]).id)

    def kinds(self):
        return self.s.kinds()


class NetworkTests(MonitorCase):
    def test_first_tick_only_records_the_network(self):
        self.mon.tick()
        self.assertTrue(self.mon.summary)
        self.assertNotIn("network_changed", self.kinds())

    def test_describe_network(self):
        self.mon.tick()
        text = describe_network(self.mon.summary)
        self.assertIn("(", text)
        self.assertEqual(describe_network({}), "no connection (-)")

    def test_a_new_network_is_reported_as_a_warning_when_connected(self):
        self.connect()
        self.mon.tick()
        self.s.world.switch_network("hotspot")
        self.mon.tick()
        self.settle()                                   # the new network also triggers a reconnect
        ev = self.s.last_event("network_changed")
        self.assertIsNotNone(ev)
        self.assertEqual(ev.level, "warning")
        self.assertIn("hotspot", ev.data["message"].lower() + ev.data["network"].lower())

    def test_a_new_network_is_only_info_when_disconnected(self):
        self.mon.tick()
        self.s.world.switch_network("usb")
        self.mon.tick()
        ev = self.s.last_event("network_changed")
        self.assertEqual(ev.level, "info")

    def test_staying_on_the_same_network_is_silent(self):
        self.mon.tick()
        self.mon.tick()
        self.mon.tick()
        self.assertNotIn("network_changed", self.kinds())

    def test_reconnects_on_a_new_network_when_the_backend_cannot_adapt(self):
        self.connect(self.ov[0])
        self.mon.tick()
        self.s.world.switch_network("hotspot")
        self.mon.tick()
        self.settle()
        self.assertEqual(self.hooks.recover_calls, 1)
        self.assertIn("network_reconnect", self.kinds())
        self.assertIn("recovering", self.kinds())
        self.assertEqual(self.s.mgr.state, "connected")

    def test_no_reconnect_when_the_backend_adapts_itself(self):
        self.connect()
        self.s.backends["wireguard"].on_network_change = lambda: True
        self.mon.tick()
        self.s.world.switch_network("hotspot")
        self.mon.tick()
        self.settle()
        self.assertEqual(self.hooks.recover_calls, 0)
        self.assertNotIn("network_reconnect", self.kinds())

    def test_reconnect_on_network_change_can_be_disabled(self):
        self.s.cfg.vpn.reconnect_on_network_change = False
        self.connect()
        self.mon.tick()
        self.s.world.switch_network("hotspot")
        self.mon.tick()
        self.settle()
        self.assertEqual(self.hooks.recover_calls, 0)

    def test_no_reconnect_when_the_user_did_not_want_a_vpn(self):
        self.connect()
        self.hooks.vpn = False
        self.mon.tick()
        self.s.world.switch_network("hotspot")
        self.mon.tick()
        self.settle()
        self.assertEqual(self.hooks.recover_calls, 0)

    def test_firewall_rules_follow_the_new_network(self):
        self.connect()
        self.mon.tick()
        before = self.s.ks.last_ruleset
        self.s.world.switch_network("hotspot")
        self.mon.tick()
        self.settle()
        self.assertTrue(self.s.ks.armed)
        self.assertTrue(before)


class FirewallTests(MonitorCase):
    def test_removed_rules_are_put_back_and_reported(self):
        self.connect()
        self.s.ks.disarm()
        self.mon._check_firewall()
        self.assertTrue(self.s.ks.armed)
        tampered = self.s.last_event("killswitch_tampered")
        self.assertIsNotNone(tampered)
        self.assertEqual(tampered.level, "critical")
        self.assertIsNotNone(self.s.last_event("killswitch_restored"))

    def test_nothing_happens_while_the_firewall_is_intact(self):
        self.connect()
        n = len(self.s.events)
        self.mon._check_firewall()
        self.assertEqual(len(self.s.events), n)

    def test_not_re_armed_when_protection_is_not_wanted(self):
        self.hooks.protect = False
        self.mon._check_firewall()
        self.assertFalse(self.s.ks.armed)
        self.assertNotIn("killswitch_tampered", self.kinds())

    def test_not_re_armed_when_the_kill_switch_is_turned_off_in_the_config(self):
        self.connect()
        self.s.ks.disarm()
        self.s.cfg.killswitch.enabled = False
        self.mon._check_firewall()
        self.assertFalse(self.s.ks.armed)

    def test_a_failed_re_arm_is_reported_and_not_repeated_as_tampering(self):
        self.connect()
        self.s.ks.disarm()

        def boom(*a, **kw):
            raise KillSwitchError("nft exploded", hint="check nftables")
        self.s.ks.arm = boom
        self.mon._check_firewall()
        self.mon._check_firewall()
        self.assertEqual(self.kinds().count("killswitch_tampered"), 1)
        failed = [e for e in self.s.events if e.kind == "killswitch_failed"]
        self.assertEqual(len(failed), 2)
        self.assertEqual(failed[0].level, "critical")
        self.assertIn("nft exploded", failed[0].data["message"])
        self.assertEqual(failed[0].data["hint"], "check nftables")

    def test_tamper_alert_can_fire_again_after_recovery(self):
        self.connect()
        self.s.ks.disarm()
        self.mon._check_firewall()
        self.s.ks.disarm()
        self.mon._check_firewall()
        self.assertEqual(self.kinds().count("killswitch_tampered"), 2)


class TunnelTests(MonitorCase):
    def test_a_healthy_tunnel_causes_no_events(self):
        self.connect()
        n = len(self.s.events)
        self.mon._check_tunnel()
        self.assertEqual(len(self.s.events), n)
        self.assertEqual(self.hooks.recover_calls, 0)

    def test_a_dropped_tunnel_is_reported_and_reconnected(self):
        a = self.wg[0]
        self.connect(a)
        self.s.world.dead = True
        self.mon._check_tunnel()
        lost = self.s.last_event("tunnel_lost")
        self.assertIsNotNone(lost)
        self.assertEqual(lost.level, "critical")
        self.assertEqual(lost.data["profile"], a.name)
        self.settle()
        self.assertEqual(self.hooks.recover_calls, 1)
        self.assertIn("tunnel_restored", self.kinds())
        self.assertEqual(self.s.mgr.state, "connected")
        self.assertTrue(self.s.mgr.tunnel_alive())
        self.assertFalse(self.mon._lost)

    def test_traffic_stays_blocked_while_the_tunnel_is_down(self):
        self.connect()
        self.s.world.dead = True
        self.assertTrue(self.s.ks.armed)
        self.mon._check_tunnel()
        self.settle()
        self.assertTrue(self.s.ks.armed)

    def test_lost_is_only_announced_once(self):
        self.connect()
        self.hooks.recover_error = VpnError("no luck")
        self.s.world.dead = True
        for _ in range(3):
            self.mon._next_recover = 0.0
            self.mon._check_tunnel()
            self.settle()
        self.assertEqual(self.kinds().count("tunnel_lost"), 1)
        self.assertEqual(self.hooks.recover_calls, 3)

    def test_auto_reconnect_can_be_turned_off(self):
        self.s.cfg.vpn.auto_reconnect = False
        self.connect()
        self.s.world.dead = True
        self.mon._check_tunnel()
        self.settle()
        self.assertIn("tunnel_lost", self.kinds())
        self.assertEqual(self.hooks.recover_calls, 0)

    def test_failures_back_off_and_escalate(self):
        self.connect()
        self.hooks.recover_error = VpnError("server unreachable")
        self.s.world.dead = True
        delays = []
        for n in range(1, 11):
            self.mon._next_recover = 0.0
            self.mon._check_tunnel()
            self.settle()
            delays.append(self.mon._next_recover - time.monotonic())
            self.assertEqual(self.mon._recover_failures, n)
        failing = [e for e in self.s.events if e.kind == "reconnect_failing"]
        self.assertEqual([e.data["attempts"] for e in failing], [3, 10])
        self.assertTrue(all(e.level == "critical" for e in failing))
        self.assertIn("server unreachable", failing[0].data["message"])
        self.assertLess(delays[0], delays[3])
        self.assertLessEqual(max(delays), self.s.cfg.rotation.backoff_max + 0.5)

    def test_no_attempt_before_the_backoff_has_expired(self):
        self.connect()
        self.hooks.recover_error = VpnError("nope")
        self.s.world.dead = True
        self.mon._check_tunnel()
        self.settle()
        calls = self.hooks.recover_calls
        self.mon._check_tunnel()
        self.settle()
        self.assertEqual(self.hooks.recover_calls, calls)

    def test_somebody_else_already_reconnecting_is_not_a_failure(self):
        self.connect()
        self.hooks.recover_error = BusyError("busy")
        self.s.world.dead = True
        self.mon._check_tunnel()
        self.settle()
        self.assertEqual(self.mon._recover_failures, 0)

    def test_unexpected_errors_count_as_failures_and_do_not_kill_the_worker(self):
        self.connect()
        self.hooks.recover_error = RuntimeError("bug")
        self.s.world.dead = True
        with self.assertLogs("ipshift.monitor", level="ERROR"):
            self.mon._check_tunnel()
            self.settle()
        self.assertEqual(self.mon._recover_failures, 1)

    def test_a_tunnel_that_comes_back_by_itself_is_reported(self):
        self.s.cfg.vpn.auto_reconnect = False
        self.connect()
        self.s.world.dead = True
        self.mon._check_tunnel()
        self.s.world.dead = False
        self.mon._check_tunnel()
        self.assertIn("tunnel_restored", self.kinds())
        self.assertFalse(self.mon._lost)

    def test_failed_state_is_recovered_when_nothing_else_is_retrying(self):
        self.connect()
        self.s.mgr.state = "failed"
        self.hooks.rot = False
        self.mon._check_tunnel()
        self.settle()
        self.assertEqual(self.hooks.recover_calls, 1)

    def test_failed_state_is_left_to_the_scheduler_while_rotating(self):
        self.connect()
        self.s.mgr.state = "failed"
        self.hooks.rot = True
        self.mon._check_tunnel()
        self.settle()
        self.assertEqual(self.hooks.recover_calls, 0)

    def test_nothing_is_done_while_a_connection_is_in_progress(self):
        self.s.mgr.state = "connecting"
        self.mon._check_tunnel()
        self.settle()
        self.assertEqual(self.hooks.recover_calls, 0)

    def test_nothing_is_done_when_the_user_stopped_the_vpn(self):
        self.connect()
        self.hooks.vpn = False
        self.s.world.dead = True
        self.mon._lost, self.mon._recover_failures = True, 4
        self.mon._check_tunnel()
        self.settle()
        self.assertEqual(self.hooks.recover_calls, 0)
        self.assertEqual((self.mon._lost, self.mon._recover_failures), (False, 0))

    def test_only_one_reconnect_runs_at_a_time(self):
        gate, started = threading.Event(), threading.Event()
        ran = []

        def slow():
            ran.append("slow")
            started.set()
            gate.wait(5)

        self.mon._spawn(slow)
        self.assertTrue(started.wait(5))
        self.mon._spawn(lambda: ran.append("second"))
        gate.set()
        self.settle()
        self.assertEqual(ran, ["slow"])
        self.mon._spawn(lambda: ran.append("third"))
        self.settle()
        self.assertEqual(ran, ["slow", "third"])


class HardeningTests(MonitorCase):
    def test_dns_rewritten_by_another_program_is_restored(self):
        self.connect()
        self.assertIn("198", self.s.resolv.read_text() + "198")      # sanity: file exists
        self.s.resolv.write_text("nameserver 192.168.1.1\n")
        self.mon._check_hardening()
        text = self.s.resolv.read_text()
        self.assertIn("10.8.0.1", text)
        self.assertNotIn("192.168.1.1", text)
        ev = self.s.last_event("hardening_repaired")
        self.assertIsNotNone(ev)
        self.assertIn("dns", ev.data)

    def test_ipv6_switched_back_on_is_disabled_again(self):
        self.connect()
        self.assertEqual(self.s.knob.read_text().strip(), "1")
        self.s.knob.write_text("0\n")
        self.mon._check_hardening()
        self.assertEqual(self.s.knob.read_text().strip(), "1")
        self.assertIn("hardening_repaired", self.kinds())

    def test_intact_settings_cause_no_event(self):
        self.connect()
        self.mon._check_hardening()
        self.assertNotIn("hardening_repaired", self.kinds())

    def test_nothing_is_touched_while_disconnected(self):
        self.mon._check_hardening()
        self.assertEqual(self.s.resolv.read_text(), "nameserver 192.168.1.1\n")
        self.assertEqual(self.s.knob.read_text().strip(), "0")


class PublicIpTests(MonitorCase):
    def setUp(self):
        super().setUp()
        self.a = self.wg[0]
        self.connect(self.a)
        self.s.mgr.conn.since -= 60                     # established a while ago
        self.probes = []
        orig = self.s.mgr.probe_exit_ip

        def spy(*a, **kw):
            self.probes.append(1)
            return orig(*a, **kw)
        self.s.mgr.probe_exit_ip = spy

    def test_an_unchanged_ip_is_fine(self):
        self.mon._check_public_ip()
        self.assertEqual(len(self.probes), 1)
        self.assertNotIn("ip_changed", self.kinds())

    def test_a_changed_ip_raises_an_alert_and_is_remembered(self):
        self.s.world.servers[self.a.id].exit_ip = "198.51.100.222"
        self.mon._check_public_ip()
        ev = self.s.last_event("ip_changed")
        self.assertIsNotNone(ev)
        self.assertEqual(ev.level, "warning")
        self.assertEqual(ev.data["new"], "198.51.100.222")
        self.assertEqual(self.s.mgr.conn.exit_ip, "198.51.100.222")
        self.mon._last_ip_probe = 0.0
        self.mon._check_public_ip()
        self.assertEqual(self.kinds().count("ip_changed"), 1)

    def test_probing_respects_the_refresh_interval(self):
        self.mon._check_public_ip()
        self.mon._check_public_ip()
        self.mon._check_public_ip()
        self.assertEqual(len(self.probes), 1)

    def test_three_failures_in_a_row_raise_one_alert(self):
        self.s.world.dead = True
        for _ in range(5):
            self.mon._last_ip_probe = 0.0
            self.mon._check_public_ip()
        self.assertEqual(self.kinds().count("ip_unverifiable"), 1)
        self.assertEqual(self.mon._ip_fail, 5)

    def test_a_success_resets_the_failure_count(self):
        self.s.world.dead = True
        for _ in range(2):
            self.mon._last_ip_probe = 0.0
            self.mon._check_public_ip()
        self.s.world.dead = False
        self.mon._last_ip_probe = 0.0
        self.mon._check_public_ip()
        self.assertEqual(self.mon._ip_fail, 0)
        self.assertNotIn("ip_unverifiable", self.kinds())

    def test_a_connection_that_was_just_verified_is_not_probed_again(self):
        self.s.mgr.conn.since = time.time()
        self.mon._check_public_ip()
        self.assertEqual(len(self.probes), 0)

    def test_not_probed_while_an_operation_is_running(self):
        self.s.mgr.status = lambda: {"busy": "connect"}
        self.mon._check_public_ip()
        self.assertEqual(len(self.probes), 0)

    def test_not_probed_when_disconnected(self):
        self.s.mgr.disconnect()
        self.mon._check_public_ip()
        self.assertEqual(len(self.probes), 0)


class LifecycleTests(MonitorCase):
    def test_background_thread_runs_cycles_and_stops(self):
        self.s.cfg.daemon.monitor_interval = 1.0
        self.connect()
        self.mon.start()
        deadline = time.time() + 5
        while not self.mon.summary and time.time() < deadline:
            time.sleep(0.02)
        self.assertTrue(self.mon.summary)
        self.s.ks.disarm()
        self.mon.poke()
        deadline = time.time() + 5
        while not self.s.ks.armed and time.time() < deadline:
            time.sleep(0.02)
        self.assertTrue(self.s.ks.armed, "poke() should have triggered an immediate cycle")
        self.mon.stop()
        self.assertFalse(any(t.name == "monitor" and t.is_alive() for t in threading.enumerate()))

    def test_start_twice_does_not_start_two_threads(self):
        self.mon.start()
        first = self.mon._thread
        self.mon.start()
        self.assertIs(self.mon._thread, first)
        self.mon.stop()

    def test_a_failing_step_does_not_stop_the_others(self):
        self.connect()
        self.s.ks.disarm()

        def boom():
            raise RuntimeError("probe failed")
        self.s.net.summary = boom
        with self.assertLogs("ipshift.monitor", level="ERROR"):
            self.mon.tick()
        self.assertTrue(self.s.ks.armed)

    def test_stop_during_a_tick_returns_promptly(self):
        self.mon.start()
        t0 = time.monotonic()
        self.mon.stop()
        self.assertLess(time.monotonic() - t0, 3)


if __name__ == "__main__":
    unittest.main()
