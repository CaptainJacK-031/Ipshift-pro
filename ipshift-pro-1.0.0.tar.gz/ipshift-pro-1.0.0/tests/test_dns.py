from __future__ import annotations

import socket
import struct
import threading
import unittest

from helpers import TmpRootCase  # noqa: F401

from ipshift.config import VpnConfig
from ipshift.net import dnswire as dw
from ipshift.net.http import HttpError, HttpResponse
from ipshift.net.resolve import BootstrapResolver, ResolveError


def rr(rtype: int, rdata: bytes, ttl: int = 60, name: bytes = b"\xc0\x0c") -> bytes:
    return name + struct.pack("!HHIH", rtype, 1, ttl, len(rdata)) + rdata


def make_response(query: bytes, answers: list[bytes], *, rcode: int = 0, tc: bool = False,
                  txid: int | None = None) -> bytes:
    pos = 12
    while query[pos]:
        pos += query[pos] + 1
    question = query[12:pos + 5]
    flags = 0x8180 | rcode | (0x200 if tc else 0)
    tid = query[:2] if txid is None else struct.pack("!H", txid)
    return tid + struct.pack("!HHHHH", flags, 1, len(answers), 0, 0) + question + b"".join(answers)


class FakeDns:
    """UDP+TCP DNS server on one loopback port; ``handler(query, proto)`` returns bytes or None."""

    def __init__(self, handler):
        self.handler = handler
        for _ in range(20):
            self.udp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.udp.bind(("127.0.0.1", 0))
            self.port = self.udp.getsockname()[1]
            self.tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.tcp.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                self.tcp.bind(("127.0.0.1", self.port))
                break
            except OSError:
                self.udp.close()
                self.tcp.close()
        self.tcp.listen(4)
        self.alive = True
        threading.Thread(target=self._udp, daemon=True).start()
        threading.Thread(target=self._tcp, daemon=True).start()

    def _udp(self):
        self.udp.settimeout(0.2)
        while self.alive:
            try:
                data, addr = self.udp.recvfrom(4096)
            except OSError:
                continue
            for out in _as_list(self.handler(data, "udp")):
                self.udp.sendto(out, addr)

    def _tcp(self):
        self.tcp.settimeout(0.2)
        while self.alive:
            try:
                conn, _ = self.tcp.accept()
            except OSError:
                continue
            with conn:
                n = struct.unpack("!H", conn.recv(2))[0]
                q = conn.recv(n)
                for out in _as_list(self.handler(q, "tcp")):
                    conn.sendall(struct.pack("!H", len(out)) + out)

    def close(self):
        self.alive = False
        self.udp.close()
        self.tcp.close()


def _as_list(x):
    return [] if x is None else (x if isinstance(x, list) else [x])


class WireTests(unittest.TestCase):
    def test_encode_name(self):
        self.assertEqual(dw.encode_name("a.bc."), b"\x01a\x02bc\x00")
        self.assertEqual(dw.encode_name(""), b"\x00")
        with self.assertRaises(dw.DnsError):
            dw.encode_name("a" * 64 + ".com")
        with self.assertRaises(dw.DnsError):
            dw.encode_name("a..b")
        self.assertTrue(dw.encode_name("bücher.example").startswith(b"\x0dxn--bcher-kva"))

    def test_query_shape(self):
        q = dw.build_query("example.com", "AAAA", txid=0x1234)
        self.assertEqual(q[:2], b"\x12\x34")
        self.assertEqual(struct.unpack("!HHHHHH", q[:12])[2:], (1, 0, 0, 1))   # 1 question, 1 EDNS record

    def test_parse_answer_types_and_compression(self):
        q = dw.build_query("x.example.com", "A", txid=7)
        resp = make_response(q, [
            rr(1, bytes([203, 0, 113, 9])),
            rr(28, bytes.fromhex("20010db8000000000000000000000001")),
            rr(16, b"\x05hello\x03abc"),
            rr(5, b"\x03www\xc0\x16"),                      # CNAME www.<com>: pointer at "com" in the question
            rr(99, b"zzz"),                                  # unknown type is skipped
        ])
        m = dw.parse_response(resp)
        self.assertEqual((m.id, m.rcode, m.truncated), (7, 0, False))
        self.assertEqual(m.values("A"), ["203.0.113.9"])
        self.assertEqual(m.values("AAAA"), ["2001:db8::1"])
        self.assertEqual(m.values("TXT"), ["helloabc"])
        self.assertEqual(m.values("CNAME"), ["www.com"])

    def test_hostile_messages_raise_cleanly(self):
        q = dw.build_query("a.b", "A", txid=1)
        good = make_response(q, [rr(1, bytes(4))])
        for bad in (good[:5], good[:-2], b""):
            with self.assertRaises(dw.DnsError):
                dw.parse_response(bad)
        # one answer whose owner name is a compression pointer to itself (offset 19)
        loop = q[:2] + struct.pack("!HHHHH", 0x8180, 1, 1, 0, 0) + b"\x01a\x00\x00\x01\x00\x01" \
            + b"\xc0\x13" + struct.pack("!HHIH", 5, 1, 1, 2) + b"\xc0\x13"
        with self.assertRaises(dw.DnsError):
            dw.parse_response(loop)


class UdpTcpTests(unittest.TestCase):
    def test_udp_ok_and_ignores_wrong_txid(self):
        def h(q, proto):
            tid = struct.unpack("!H", q[:2])[0]
            return [make_response(q, [rr(1, bytes([6, 6, 6, 6]))], txid=(tid + 1) & 0xFFFF),   # spoof
                    make_response(q, [rr(1, bytes([203, 0, 113, 5]))])]

        srv = FakeDns(h)
        self.addCleanup(srv.close)
        m = dw.udp_query("127.0.0.1", "whoami.example", "A", port=srv.port, timeout=2)
        self.assertEqual(m.values("A"), ["203.0.113.5"])

    def test_udp_timeout(self):
        srv = FakeDns(lambda q, p: None)
        self.addCleanup(srv.close)
        with self.assertRaises(dw.DnsError):
            dw.udp_query("127.0.0.1", "x.example", port=srv.port, timeout=0.3)

    def test_truncated_udp_falls_back_to_tcp(self):
        seen = []

        def h(q, proto):
            seen.append(proto)
            if proto == "udp":
                return make_response(q, [], tc=True)
            return make_response(q, [rr(16, b"\x0bfrom-tcp-ok")])

        srv = FakeDns(h)
        self.addCleanup(srv.close)
        m = dw.udp_query("127.0.0.1", "big.example", "TXT", port=srv.port, timeout=2)
        self.assertEqual((seen, m.values("TXT")), (["udp", "tcp"], ["from-tcp-ok"]))

    def test_refused_port_is_dnserror(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]
        s.close()
        with self.assertRaises(dw.DnsError):
            dw.udp_query("127.0.0.1", "x.example", port=port, timeout=0.5)


class BootstrapTests(unittest.TestCase):
    def doh(self, behaviours):
        """behaviours: url -> list of A values | Exception | HttpResponse"""
        calls = []

        def post(url, body, ctype, **kw):
            calls.append(url)
            b = behaviours[url]
            if isinstance(b, Exception):
                raise b
            if isinstance(b, HttpResponse):
                return b
            q = body
            return HttpResponse(200, {}, make_response(q, [rr(1, bytes(map(int, ip.split(".")))) for ip in b]))

        return post, calls

    def cfg(self, urls, plain=False):
        return VpnConfig(bootstrap_doh=urls, allow_plain_bootstrap_dns=plain)

    def test_ip_literal_needs_no_lookup(self):
        post, calls = self.doh({})
        r = BootstrapResolver(self.cfg(["https://9.9.9.9/dns-query"]), post=post)
        self.assertEqual(r.resolve("198.51.100.4"), ["198.51.100.4"])
        self.assertEqual(calls, [])

    def test_falls_through_failed_servers_and_caches(self):
        post, calls = self.doh({"https://9.9.9.9/q": HttpError("down"),
                                "https://1.1.1.1/q": ["203.0.113.1", "203.0.113.2", "203.0.113.1"]})
        r = BootstrapResolver(self.cfg(["https://9.9.9.9/q", "https://1.1.1.1/q"]), post=post)
        self.assertEqual(r.resolve("vpn.example.net"), ["203.0.113.1", "203.0.113.2"])
        n = len(calls)
        self.assertEqual(r.resolve("VPN.example.net"), ["203.0.113.1", "203.0.113.2"])   # cache hit
        self.assertEqual(len(calls), n)
        r.resolve("vpn.example.net", use_cache=False)
        self.assertGreater(len(calls), n)

    def test_no_plain_dns_unless_allowed(self):
        post, _ = self.doh({"https://9.9.9.9/q": HttpError("down")})
        plain_calls = []

        def system(host, *a):
            plain_calls.append(host)
            return [(0, 0, 0, "", ("198.51.100.8", 0))]

        r = BootstrapResolver(self.cfg(["https://9.9.9.9/q"]), post=post, system_resolver=system)
        with self.assertRaises(ResolveError):
            r.resolve("vpn.example.net")
        self.assertEqual(plain_calls, [])                         # the ISP resolver was never asked
        r = BootstrapResolver(self.cfg(["https://9.9.9.9/q"], plain=True), post=post, system_resolver=system)
        self.assertEqual(r.resolve("vpn.example.net"), ["198.51.100.8"])

    def test_http_error_status_and_garbage_are_skipped(self):
        post, _ = self.doh({"https://9.9.9.9/q": HttpResponse(503, {}, b""),
                            "https://1.1.1.1/q": HttpResponse(200, {}, b"garbage")})
        r = BootstrapResolver(self.cfg(["https://9.9.9.9/q", "https://1.1.1.1/q"]), post=post)
        with self.assertRaises(ResolveError):
            r.resolve("vpn.example.net")

    def test_doh_hosts_for_firewall_window(self):
        self.assertEqual(BootstrapResolver.doh_hosts(
            ["https://9.9.9.9/dns-query", "https://dns.example/q", "https://1.1.1.1:443/dns-query"]),
            ["9.9.9.9", "1.1.1.1"])


if __name__ == "__main__":
    unittest.main()
