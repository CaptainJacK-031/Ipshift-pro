"""The Privacy and History pages, run against the stand-in for PySide6."""
from __future__ import annotations

import copy
import unittest

import helpers  # noqa: F401
import guifix
import qtcase
from ipshift.gui import leakviews, tables
from ipshift.gui.theme import tone_color
from ipshift.gui.views import BAD, GOOD, MUTED, WARN
from ipshift.privacy.leaks import FULL
from ipshift.privacy.report import NOT_COVERED


def setUpModule():
    qtcase.install()
    global page_privacy, page_history, Qt, QLabel
    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import QLabel
    from ipshift.gui import page_history, page_privacy


def tearDownModule():
    qtcase.uninstall()


def record(signal) -> list:
    got: list = []
    signal.connect(lambda *args: got.append(args))
    return got


# ---- Privacy -------------------------------------------------------------------------------------------------------
class PrivacyCase(qtcase.QtCase):
    def setUp(self):
        super().setUp()
        self.page = page_privacy.PrivacyPage()
        self.page.show()

    def show(self, rep=None, *, running=False):
        lv = leakviews.leak_view(rep, 2010.0)
        self.page.update_view(lv, running)
        return lv

    def tiles(self):
        return list(self.page._tiles)


class PrivacyBeforeATestTests(PrivacyCase):
    def test_the_page_says_that_nothing_has_been_run(self):
        self.show(None)
        p = self.page
        self.assertEqual((p.grade.text(), p.score.text()), ("-", ""))
        self.assertEqual(p.headline.text(), "No test has been run yet")
        self.assertEqual(p.headline.property("tone"), MUTED)
        self.assertTrue(p.counts.isHidden())
        self.assertTrue(p.simulated.isHidden())
        self.assertTrue(p.progress.isHidden())
        self.assertTrue(p.run_full.isEnabled() and p.run_quick.isEnabled())

    def test_every_check_is_listed_as_not_run_yet(self):
        self.show(None)
        self.assertEqual(len(self.tiles()), len(FULL))
        self.assertEqual({t.word.text() for t in self.tiles()}, {"NOT RUN YET"})
        self.assertEqual((self.page.dns_tile.word.text(), self.page.ipv6_tile.word.text()),
                         ("NOT RUN YET", "NOT RUN YET"))
        self.assertEqual(self.page.dns_tile.title.text(), "DNS leak test")
        self.assertEqual(self.page.ipv6_tile.title.text(), "IPv6 leak test")

    def test_the_list_of_what_a_test_cannot_see_is_always_there(self):
        self.show(None)
        self.assertEqual(self.texts(self.page.not_covered), ["•  " + t for t in NOT_COVERED])
        self.assertGreaterEqual(len(NOT_COVERED), 3)


class PrivacyReportTests(PrivacyCase):
    def test_a_clean_report(self):
        lv = self.show(guifix.report())
        p = self.page
        self.assertEqual((p.grade.text(), p.score.text()), ("A", "100 / 100"))
        self.assertEqual((p.headline.text(), p.headline.property("tone")), (lv.headline, GOOD))
        self.assertEqual(p.grade.property("tone"), GOOD)
        self.assertEqual(p.meta.text(), lv.meta)
        self.assertEqual(p.counts.text(), "10 passed, 0 warnings, 0 failed, 0 not tested")
        self.assertFalse(p.counts.isHidden())
        self.assertEqual({t.word.text() for t in self.tiles()}, {"PASS"})
        self.assertEqual((p.dns_tile.word.text(), p.ipv6_tile.word.text()), ("PASS", "PASS"))
        self.assertEqual(len(self.tiles()), len(FULL))

    def test_every_check_is_one_tile_in_two_columns(self):
        self.show(guifix.report())
        grid = self.page.grid
        self.assertEqual(grid.count(), len(FULL))
        self.assertEqual([grid.itemAt(i).pos for i in range(grid.count())],
                         [(i // 2, i % 2) for i in range(len(FULL))])

    def test_a_dns_leak_is_called_a_leak_and_carries_the_fix(self):
        self.show(guifix.report(dns_escape="fail"))
        tile = self.page.dns_tile
        self.assertEqual((tile.word.text(), tile.word.property("tone")), ("LEAK", BAD))
        self.assertEqual(tile.property("tone"), BAD)
        self.assertEqual(tile.hint.text(), "How to fix it: fix it")
        self.assertFalse(tile.hint.isHidden())
        self.assertIn("dns_escape fail", tile.detail.text())
        self.assertEqual(self.page.ipv6_tile.word.text(), "PASS")
        self.assertEqual(self.page.grade.property("tone"), BAD)

    def test_an_ipv6_leak(self):
        self.show(guifix.report(ipv6="fail"))
        self.assertEqual(self.page.ipv6_tile.word.text(), "LEAK")
        self.assertEqual(self.page.dns_tile.word.text(), "PASS")
        self.assertIn("LEAK", {t.word.text() for t in self.tiles()})

    def test_a_failure_that_is_not_a_leak_is_called_fail(self):
        self.show(guifix.report(tunnel="fail"))
        self.assertIn("FAIL", {t.word.text() for t in self.tiles()})
        self.assertNotIn("LEAK", {t.word.text() for t in self.tiles()})

    def test_a_warning_is_amber_with_a_hint(self):
        self.show(guifix.report(dns_config="warn"))
        tile = self.page.dns_tile
        self.assertEqual((tile.word.text(), tile.word.property("tone")), ("WARNING", WARN))
        self.assertEqual(tile.hint.text(), "How to fix it: fix it")

    def test_a_check_that_could_not_run_is_called_not_tested(self):
        self.show(guifix.report(ipv6="skip"))
        tile = self.page.ipv6_tile
        self.assertEqual((tile.word.text(), tile.word.property("tone")), ("NOT TESTED", MUTED))
        self.assertTrue(tile.hint.isHidden())

    def test_a_passing_check_has_no_fix_to_show(self):
        self.show(guifix.report())
        for tile in self.tiles():
            self.assertTrue(tile.hint.isHidden())
            self.assertEqual(tile.hint.text(), "")
            self.assertFalse(tile.detail.isHidden())

    def test_a_simulated_report_is_marked_and_a_real_one_is_not(self):
        rep = guifix.report()
        rep["simulated"] = True
        self.show(rep)
        self.assertFalse(self.page.simulated.isHidden())
        self.assertIn("SIMULATION", self.page.simulated.text())
        self.show(guifix.report())
        self.assertTrue(self.page.simulated.isHidden())

    def test_text_in_a_report_is_never_taken_for_markup(self):
        rep = guifix.report()
        rep["findings"][0]["detail"] = "<b>bold</b><img src=x>"
        self.show(rep)
        labels = [lab for lab in self.page.findChildren(QLabel) if lab.text() == "<b>bold</b><img src=x>"]
        self.assertEqual(len(labels), 1)
        self.assertIs(labels[0].textFormat(), Qt.TextFormat.PlainText)


class PrivacyGridTests(PrivacyCase):
    def test_the_same_checks_reuse_their_tiles(self):
        self.show(guifix.report())
        before = self.tiles()
        self.show(guifix.report(dns_escape="fail"))
        self.assertTrue(len(before) == len(self.tiles()) and all(a is b for a, b in zip(before, self.tiles())))
        self.assertIn("LEAK", {t.word.text() for t in self.tiles()})

    def test_a_different_set_of_checks_builds_the_grid_again_and_deletes_the_old_tiles(self):
        self.show(guifix.report())
        old = self.tiles()
        rep = guifix.report()
        rep["findings"] = rep["findings"][:3]
        self.show(rep)
        self.app.processEvents()
        self.assertEqual(len(self.tiles()), 3)
        self.assertEqual(self.page.grid.count(), 3)
        for tile in old:
            with self.assertRaises(RuntimeError):
                tile.setObjectName("gone")

    def test_going_back_to_no_report_shows_every_check_pending_again(self):
        self.show(guifix.report())
        self.show(None)
        self.assertEqual({t.word.text() for t in self.tiles()}, {"NOT RUN YET"})
        self.assertEqual(self.page.grade.text(), "-")


class PrivacyRunningTests(PrivacyCase):
    def test_while_a_test_runs_the_bar_moves_and_the_buttons_wait(self):
        self.show(guifix.report(), running=True)
        p = self.page
        self.assertFalse(p.progress.isHidden())
        self.assertEqual((p.progress.minimum(), p.progress.maximum()), (0, 0))       # a bar with no end
        self.assertFalse(p.run_full.isEnabled() or p.run_quick.isEnabled())
        asked = record(p.run_requested)
        p.run_full.click()
        p.run_quick.click()
        self.assertEqual(asked, [])
        self.show(guifix.report(), running=False)
        self.assertTrue(p.progress.isHidden())
        self.assertTrue(p.run_full.isEnabled() and p.run_quick.isEnabled())

    def test_the_two_buttons_ask_for_the_full_and_the_quick_test(self):
        self.show(None)
        asked = record(self.page.run_requested)
        self.page.run_full.click()
        self.page.run_quick.click()
        self.assertEqual(asked, [("full",), ("quick",)])


# ---- History -------------------------------------------------------------------------------------------------------
class HistoryCase(qtcase.QtCase):
    def setUp(self):
        super().setUp()
        self.page = page_history.HistoryPage()
        self.page.show()

    def data(self, n=3, events=()):
        data = guifix.history(n)
        data["events"] = list(events)
        return data

    def show(self, data=None, *, flt="all", can_export=None):
        data = self.data() if data is None else data
        rows, events = tables.history_rows(data, flt), tables.event_rows(data)
        can = bool(data.get("rotations")) if can_export is None else can_export
        self.page.update_view(rows, events, tables.history_stats(data), can)
        return rows, events

    @staticmethod
    def cell(model, row, col):
        return model.data(model.index(row, col))


def an_event(level="error", message="Could not connect to NL 1", ts=1_700_000_100.0):
    return {"ts": ts, "level": level, "kind": "connect_failed", "message": message}


class HistoryFilterTests(HistoryCase):
    def test_the_filter_offers_every_kind_of_result_in_order(self):
        f = self.page.filter
        self.assertEqual([f.itemText(i) for i in range(f.count())], [text for _, text in tables.HISTORY_FILTERS])
        self.assertEqual(self.page.current_filter(), "all")

    def test_choosing_a_filter_is_announced_and_can_be_read_back(self):
        changes = record(self.page.filter_changed)
        self.page.filter.setCurrentIndex(2)
        self.assertEqual(changes, [()])
        self.assertEqual(self.page.current_filter(), "failed")
        self.page.filter.setCurrentIndex(0)
        self.assertEqual((len(changes), self.page.current_filter()), (2, "all"))

    def test_the_filter_belongs_to_the_rotations_tab_only(self):
        self.assertTrue(self.page.filter.isEnabled())
        self.page.tabs.setCurrentIndex(1)
        self.assertFalse(self.page.filter.isEnabled())
        self.page.tabs.setCurrentIndex(0)
        self.assertTrue(self.page.filter.isEnabled())

    def test_the_two_tabs_are_named(self):
        self.assertEqual([self.page.tabs.tabText(i) for i in range(self.page.tabs.count())], ["Rotations", "Alerts"])


class HistoryTableTests(HistoryCase):
    def test_rotations_and_alerts_fill_their_tables(self):
        rows, events = self.show(self.data(3, [an_event(), an_event("warning", "Tunnel lost", 1_700_000_200.0)]))
        rot, ev = self.page.rotations_model, self.page.events_model
        self.assertEqual((rot.rowCount(), rot.columnCount()), (3, len(tables.HISTORY_COLUMNS)))
        self.assertEqual((ev.rowCount(), ev.columnCount()), (2, len(tables.EVENT_COLUMNS)))
        for r, row in enumerate(rows):
            for c, text in enumerate(row.cells()):
                self.assertEqual(self.cell(rot, r, c), text)
        for r, row in enumerate(events):
            for c, text in enumerate(row.cells()):
                self.assertEqual(self.cell(ev, r, c), text)
        self.assertEqual(self.cell(rot, 0, 2), "Server 3")                           # newest first
        self.assertEqual(self.cell(ev, 0, 1), "error")

    def test_the_headers_are_the_column_names(self):
        for model, names in ((self.page.rotations_model, tables.HISTORY_COLUMNS),
                             (self.page.events_model, tables.EVENT_COLUMNS)):
            got = [model.headerData(i, Qt.Orientation.Horizontal) for i in range(model.columnCount())]
            self.assertEqual(got, list(names))

    def test_the_stats_line(self):
        self.show()
        self.assertEqual(self.page.stats.text(), tables.history_stats(guifix.history(3)))
        self.assertTrue(self.page.stats.text().startswith("3 recorded"))
        self.show({"rotations": [], "stats": {}, "events": []})
        self.assertEqual(self.page.stats.text(), "No rotations recorded yet.")

    def test_only_the_result_column_is_coloured(self):
        data = self.data(2)
        data["rotations"][0]["status"] = "failed"
        self.show(data)
        model = self.page.rotations_model
        failed, changed = model.data(model.index(0, 1), Qt.ItemDataRole.ForegroundRole), \
            model.data(model.index(1, 1), Qt.ItemDataRole.ForegroundRole)
        self.assertEqual(failed.color.name(), tone_color(BAD))
        self.assertEqual(changed.color.name(), tone_color(GOOD))
        self.assertIsNone(model.data(model.index(0, 0), Qt.ItemDataRole.ForegroundRole))

    def test_an_identical_refresh_resets_nothing(self):
        self.show()
        model = self.page.rotations_model
        resets = (model.reset_count, self.page.events_model.reset_count)
        self.show()
        self.assertEqual((model.reset_count, self.page.events_model.reset_count), resets)
        self.show(self.data(4))
        self.assertEqual(model.reset_count, resets[0] + 1)
        self.assertEqual(self.page.events_model.reset_count, resets[1])

    def test_a_refresh_keeps_the_scroll_position(self):
        self.show(self.data(3))
        self.page.rotations_view.verticalScrollBar().setValue(40)
        self.show(self.data(4))
        self.assertEqual(self.page.rotations_view.verticalScrollBar().value(), 40)

    def test_filtering_shows_only_those_rows(self):
        data = self.data(3)
        data["rotations"][1]["status"] = "failed"
        self.show(data, flt="failed")
        self.assertEqual(self.page.rotations_model.rowCount(), 1)
        self.assertEqual(self.cell(self.page.rotations_model, 0, 1), "Failed")


class HistoryButtonTests(HistoryCase):
    def test_export_needs_something_to_export_and_clear_also_works_for_alerts_alone(self):
        self.show({"rotations": [], "stats": {}, "events": []})
        self.assertFalse(self.page.export_button.isEnabled() or self.page.clear_button.isEnabled())
        self.show(self.data(2))
        self.assertTrue(self.page.export_button.isEnabled() and self.page.clear_button.isEnabled())
        self.show({"rotations": [], "stats": {}, "events": [an_event()]})
        self.assertFalse(self.page.export_button.isEnabled())
        self.assertTrue(self.page.clear_button.isEnabled())

    def test_the_buttons_announce_themselves_and_disabled_ones_stay_quiet(self):
        exports, clears = record(self.page.export_requested), record(self.page.clear_requested)
        self.show({"rotations": [], "stats": {}, "events": []})
        self.page.export_button.click()
        self.page.clear_button.click()
        self.assertEqual((exports, clears), ([], []))
        self.show(self.data(2))
        self.page.export_button.click()
        self.page.clear_button.click()
        self.assertEqual((exports, clears), ([()], [()]))

    def test_the_page_says_where_the_history_is_kept(self):
        self.assertTrue(any("stored on this computer only" in t for t in self.texts(self.page)))


if __name__ == "__main__":
    unittest.main()
