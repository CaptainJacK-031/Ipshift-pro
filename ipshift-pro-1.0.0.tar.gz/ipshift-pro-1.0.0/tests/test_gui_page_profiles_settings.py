"""The Profiles and Settings pages, run against the stand-in for PySide6."""
from __future__ import annotations

import copy
import unittest

import helpers  # noqa: F401
import guifix
import qtcase
from ipshift.gui import tables
from ipshift.gui.settings_schema import SECTIONS, all_settings


def setUpModule():
    qtcase.install()
    global page_profiles, page_settings, Qt, QLabel, QCheckBox, QSpinBox, QDoubleSpinBox, QComboBox, QLineEdit
    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import QCheckBox, QComboBox, QDoubleSpinBox, QLabel, QLineEdit, QSpinBox
    from ipshift.gui import page_profiles, page_settings


def tearDownModule():
    qtcase.uninstall()


def record(signal) -> list:
    got: list = []
    signal.connect(lambda *args: got.append(args))
    return got


# ---- Profiles ------------------------------------------------------------------------------------------------------
class ProfilesCase(qtcase.QtCase):
    NOW = 2000.0

    def setUp(self):
        super().setUp()
        self.page = page_profiles.ProfilesPage()
        self.page.show()

    def show(self, data=None, *, can_connect=True):
        rows = tables.profile_rows(guifix.profiles() if data is None else data, self.NOW)
        self.page.update_view(rows, can_connect=can_connect)
        return rows

    def select(self, i):
        self.page.view.selectRow(i)

    def enabled(self):
        p = self.page
        return {"connect": p.connect_button.isEnabled(), "toggle": p.toggle_button.isEnabled(),
                "login": p.login_button.isEnabled(), "reuse": p.reuse_button.isEnabled(),
                "remove": p.remove_button.isEnabled()}

    @staticmethod
    def changed(**per_profile):
        """The sample data with fields of the first profile replaced."""
        data = guifix.profiles()
        data["profiles"][0].update(per_profile)
        return data


class ProfilesShowTests(ProfilesCase):
    def test_with_no_profiles_the_page_explains_what_to_do(self):
        self.show({"profiles": [], "current": None, "in_rotation": []})
        p = self.page
        self.assertFalse(p.empty.isHidden())
        self.assertTrue(p.view.isHidden())
        self.assertTrue(p.warning.isHidden())
        self.assertIn("No VPN profiles yet", self.texts(p.empty))
        self.assertTrue(p.import_button.isEnabled())
        self.assertEqual(self.enabled(), dict.fromkeys(("connect", "toggle", "login", "reuse", "remove"), False))
        self.assertEqual(p.detail.text(), "")

    def test_profiles_fill_the_table(self):
        rows = self.show()
        p = self.page
        self.assertTrue(p.empty.isHidden())
        self.assertFalse(p.view.isHidden())
        self.assertEqual(p.model.rowCount(), 2)
        self.assertEqual([p.model.data(p.model.index(0, c)) for c in range(p.model.columnCount())],
                         ["WG NL", "wireguard", "paid", "NL", "Ready", "yes", "5 / 1", "198.51.100.5"])
        self.assertEqual(list(rows[0].cells()), [p.model.data(p.model.index(0, c)) for c in range(8)])
        self.assertEqual(p.model.headerData(0, Qt.Orientation.Horizontal), "Name")

    def test_the_free_provider_warning_is_shown_only_while_a_free_profile_exists(self):
        self.show()
        self.assertFalse(self.page.warning.isHidden())
        self.assertEqual(self.page.warning.text(), tables.FREE_VPN_WARNING)
        data = guifix.profiles()
        data["profiles"] = data["profiles"][:1]
        self.show(data)
        self.assertTrue(self.page.warning.isHidden())

    def test_the_state_column_is_coloured(self):
        self.show()
        from ipshift.gui.theme import tone_color
        brush = self.page.model.data(self.page.model.index(0, 4), Qt.ItemDataRole.ForegroundRole)
        self.assertEqual(brush.color.name(), tone_color("good"))
        self.assertIsNone(self.page.model.data(self.page.model.index(0, 0), Qt.ItemDataRole.ForegroundRole))

    def test_a_profile_name_from_a_file_is_data_not_markup(self):
        self.show(self.changed(name="<b>Evil</b> <img src=x>"))
        self.select(0)
        self.assertEqual(self.page.detail.text(), "<b>Evil</b> <img src=x>: 1 server address(es)")
        self.assertIs(self.page.detail.textFormat(), Qt.TextFormat.PlainText)


class ProfilesSelectionTests(ProfilesCase):
    def test_with_nothing_selected_only_import_is_available(self):
        self.show()
        self.assertEqual(self.enabled(), dict.fromkeys(("connect", "toggle", "login", "reuse", "remove"), False))
        self.assertTrue(self.page.import_button.isEnabled())
        self.assertIsNone(self.page.selected())

    def test_a_ready_profile_can_be_connected_disabled_given_a_login_and_removed(self):
        self.show()
        self.select(0)
        self.assertEqual(self.enabled(), {"connect": True, "toggle": True, "login": True, "reuse": False,
                                          "remove": True})
        self.assertEqual(self.page.toggle_button.text(), "Disable")
        self.assertEqual(self.page.detail.text(), "WG NL: 1 server address(es)")
        self.assertEqual(self.page.selected().id, "wg-nl")

    def test_connecting_waits_while_another_connection_command_is_running(self):
        self.show(can_connect=False)
        self.select(0)
        self.assertFalse(self.page.connect_button.isEnabled())
        self.assertTrue(self.page.remove_button.isEnabled())

    def test_the_connect_button_follows_can_connect_without_losing_the_selection(self):
        self.show(can_connect=False)
        self.select(0)
        self.show(can_connect=True)
        self.assertEqual(self.page.selected().id, "wg-nl")
        self.assertTrue(self.page.connect_button.isEnabled())
        self.show(can_connect=False)
        self.assertFalse(self.page.connect_button.isEnabled())

    def test_a_profile_that_needs_a_login_cannot_be_connected_and_says_so(self):
        self.show()
        self.select(1)
        self.assertFalse(self.page.connect_button.isEnabled())
        self.assertTrue(self.page.login_button.isEnabled())
        self.assertEqual(self.page.detail.text(), "OVPN US needs a username and password: press Set login.")

    def test_the_active_profile_cannot_be_connected_again(self):
        data = guifix.profiles()
        data["current"] = "wg-nl"
        self.show(data)
        self.select(0)
        self.assertFalse(self.page.connect_button.isEnabled())
        self.assertEqual(self.page.model.data(self.page.model.index(0, 4)), "Active")

    def test_a_disabled_profile_offers_enable(self):
        self.show(self.changed(enabled=False))
        self.select(0)
        self.assertEqual(self.page.toggle_button.text(), "Enable")
        self.assertEqual(self.page.model.data(self.page.model.index(0, 4)), "Disabled")
        self.select(1)
        self.assertEqual(self.page.toggle_button.text(), "Disable")

    def test_a_benched_profile_can_be_used_again(self):
        self.show(self.changed(quarantined=True, quarantined_until=self.NOW + 90))
        self.select(0)
        self.assertTrue(self.page.reuse_button.isEnabled())
        self.assertTrue(self.page.model.data(self.page.model.index(0, 4)).startswith("Benched for"))
        self.select(1)
        self.assertFalse(self.page.reuse_button.isEnabled())

    def test_the_last_error_of_a_profile_is_shown(self):
        self.show(self.changed(last_error="TLS handshake failed"))
        self.select(0)
        self.assertEqual(self.page.detail.text(), "WG NL: TLS handshake failed")

    def test_the_selection_survives_a_refresh_with_new_numbers(self):
        self.show()
        self.select(1)
        data = guifix.profiles()
        data["profiles"][1]["ok_count"] = 9
        self.show(data)
        self.assertEqual(self.page.selected().id, "ovpn-us")
        self.assertEqual(self.page.model.data(self.page.model.index(1, 6)), "9 / 0")
        self.assertTrue(self.page.login_button.isEnabled())

    def test_when_the_selected_profile_is_removed_nothing_stays_selected(self):
        self.show()
        self.select(1)
        data = guifix.profiles()
        data["profiles"] = data["profiles"][:1]
        self.show(data)
        self.assertIsNone(self.page.selected())
        self.assertEqual(self.page.detail.text(), "")
        self.assertEqual(self.enabled(), dict.fromkeys(("connect", "toggle", "login", "reuse", "remove"), False))

    def test_an_identical_refresh_does_not_reset_the_table(self):
        self.show()
        resets = self.page.model.reset_count
        self.show()
        self.assertEqual(self.page.model.reset_count, resets)


class ProfilesSignalTests(ProfilesCase):
    def setUp(self):
        super().setUp()
        p = self.page
        self.signals = {name: record(getattr(p, name)) for name in
                        ("import_requested", "connect_requested", "toggle_requested", "login_requested",
                         "reuse_requested", "remove_requested")}

    def test_import_needs_no_selection(self):
        self.show()
        self.page.import_button.click()
        self.assertEqual(self.signals["import_requested"], [()])

    def test_each_button_names_the_selected_profile(self):
        self.show(self.changed(quarantined=True, quarantined_until=self.NOW + 90))
        self.select(0)
        p = self.page
        for button in (p.connect_button, p.login_button, p.reuse_button, p.remove_button, p.toggle_button):
            button.click()
        s = self.signals
        self.assertEqual(s["connect_requested"], [("wg-nl",)])
        self.assertEqual(s["login_requested"], [("wg-nl",)])
        self.assertEqual(s["reuse_requested"], [("wg-nl",)])
        self.assertEqual(s["remove_requested"], [("wg-nl",)])
        self.assertEqual(s["toggle_requested"], [("wg-nl", False)])

    def test_toggling_a_disabled_profile_asks_to_enable_it(self):
        self.show(self.changed(enabled=False))
        self.select(0)
        self.page.toggle_button.click()
        self.assertEqual(self.signals["toggle_requested"], [("wg-nl", True)])

    def test_nothing_is_sent_without_a_selection(self):
        self.show()
        p = self.page
        for button in (p.connect_button, p.login_button, p.reuse_button, p.remove_button, p.toggle_button):
            button.click()
        p._send(p.connect_requested)                       # even when called directly
        p._toggle()
        self.assertEqual([v for k, v in self.signals.items() if k != "import_requested"], [[]] * 5)

    def test_a_disabled_button_sends_nothing(self):
        self.show(can_connect=False)
        self.select(0)
        self.page.connect_button.click()
        self.page.reuse_button.click()
        self.assertEqual((self.signals["connect_requested"], self.signals["reuse_requested"]), ([], []))


# ---- Settings ------------------------------------------------------------------------------------------------------
make_config = guifix.config


class SettingsCase(qtcase.QtCase):
    def setUp(self):
        super().setUp()
        self.page = page_settings.SettingsPage()
        self.page.show()
        self.changes = record(self.page.change_requested)

    def load(self, over=None, **kw):
        cfg = make_config(over)
        self.page.load(cfg, **kw)
        return cfg


class SettingsBuildTests(SettingsCase):
    EXPECTED = {"bool": "QCheckBox", "int": "QSpinBox", "float": "QDoubleSpinBox", "choice": "QComboBox",
                "list": "QLineEdit"}

    def test_every_setting_of_the_schema_has_one_control_of_the_right_kind(self):
        for s in all_settings():
            control = self.page.control(s.key)
            if s.kind == "multi":
                self.assertEqual(list(control.boxes), [value for value, _ in s.choices], s.key)
            else:
                self.assertEqual(type(control).__name__, self.EXPECTED[s.kind], s.key)

    def test_number_boxes_have_the_limits_of_the_schema(self):
        for s in all_settings():
            if s.kind not in ("int", "float"):
                continue
            box = self.page.control(s.key)
            self.assertEqual((box.minimum(), box.maximum(), box.singleStep()), (s.minimum, s.maximum, s.step), s.key)
            self.assertEqual(box.suffix(), f" {s.unit}" if s.unit else "", s.key)
            self.assertFalse(box.keyboardTracking(), s.key)
            if s.kind == "float":
                self.assertEqual(box.decimals(), s.decimals, s.key)

    def test_the_interval_box_cannot_go_below_one_second(self):
        box = self.page.control("rotation.interval")
        self.assertEqual(box.minimum(), 1.0)
        box.setValue(0.1)
        self.assertEqual(box.value(), 1.0)

    def test_choice_boxes_list_the_choices_in_order(self):
        for s in all_settings():
            if s.kind == "choice":
                box = self.page.control(s.key)
                self.assertEqual([box.itemText(i) for i in range(box.count())], [t for _, t in s.choices], s.key)
                self.assertEqual([box._items[i][1] for i in range(box.count())], [v for v, _ in s.choices], s.key)

    def test_every_section_is_a_card_with_its_title(self):
        shown = self.texts(self.page)
        for section in SECTIONS:
            self.assertIn(section.title.upper(), shown)
            self.assertIn(section.intro, shown)

    def test_the_restart_note_appears_exactly_for_the_settings_that_need_a_restart(self):
        note = "Takes effect after the daemon restarts."
        needing = [s for s in all_settings() if s.restart]
        self.assertTrue(needing)
        self.assertEqual(sum(note in t for t in self.texts(self.page)), len(needing))

    def test_before_the_daemon_answers_everything_is_disabled(self):
        self.assertEqual(self.page.note.text(), "Waiting for the daemon...")
        for s in all_settings():
            self.assertFalse(self.page.control(s.key).isEnabled(), s.key)


class SettingsLoadTests(SettingsCase):
    def test_a_config_fills_every_control(self):
        over = {"rotation.interval": 5.0, "rotation.strategy": "random", "killswitch.enabled": True,
                "rotation.tiers": ["paid", "free"], "dns.servers": ["1.1.1.1", "9.9.9.9"], "vpn.mtu": 1420,
                "rotation.max_failures": 7, "privacy.history_max_rows": 25_000}
        self.load(over, info="Changes apply at once; saved.")
        p = self.page
        self.assertEqual(p.value("rotation.interval"), 5.0)
        self.assertEqual(p.value("rotation.strategy"), "random")
        self.assertIs(p.value("killswitch.enabled"), True)
        self.assertEqual(p.value("rotation.tiers"), ["free", "paid"])        # schema order, not the daemon's
        self.assertEqual(p.value("dns.servers"), "1.1.1.1, 9.9.9.9")
        self.assertEqual(p.value("vpn.mtu"), 1420)
        self.assertEqual(p.value("rotation.max_failures"), 7)
        self.assertEqual(p.value("privacy.history_max_rows"), 25_000)
        self.assertEqual(p.note.text(), "Changes apply at once; saved.")
        for s in all_settings():
            self.assertTrue(p.control(s.key).isEnabled(), s.key)

    def test_loading_announces_nothing_even_when_the_values_differ_from_the_defaults(self):
        self.load({"rotation.interval": 5.0, "killswitch.enabled": True, "dns.servers": ["1.1.1.1"]})
        self.load({"rotation.interval": 9.0, "killswitch.enabled": False, "rotation.tiers": ["paid"]})
        self.pump(5)
        self.assertEqual(self.changes, [])
        self.assertFalse(self.page._timer.isActive())

    def test_a_setting_the_daemon_did_not_send_is_disabled_and_the_others_are_not(self):
        cfg = make_config()
        del cfg["vpn"]["mtu"]
        cfg["dns"] = None
        self.page.load(cfg)
        self.assertFalse(self.page.control("vpn.mtu").isEnabled())
        self.assertTrue(self.page.control("vpn.fast_switch").isEnabled())
        for s in all_settings():
            if s.key.startswith("dns."):
                self.assertFalse(self.page.control(s.key).isEnabled(), s.key)

    def test_going_back_to_no_config_disables_everything_again(self):
        self.load()
        self.page.load(None)
        self.assertEqual(self.page.note.text(), "Waiting for the daemon...")
        self.assertFalse(self.page.control("rotation.interval").isEnabled())

    def test_a_value_the_choice_does_not_know_is_added_and_shown_without_announcing(self):
        self.load({"rotation.strategy": "custom"})
        box = self.page.control("rotation.strategy")
        self.assertEqual((box.currentData(), box.currentText(), box.count()), ("custom", "custom (current)", 5))
        self.load({"rotation.strategy": "custom"})
        self.assertEqual(box.count(), 5)
        self.assertEqual(self.changes, [])

    def test_a_box_with_the_focus_is_left_alone_unless_the_load_is_forced(self):
        self.load({"rotation.max_failures": 3})
        box = self.page.control("rotation.max_failures")
        box.setFocus()
        self.load({"rotation.max_failures": 50})
        self.assertEqual(box.value(), 3)
        self.load({"rotation.max_failures": 50}, force=True)
        self.assertEqual(box.value(), 50)
        self.pump(5)
        self.assertEqual(self.changes, [])

    def test_a_whole_number_sent_as_a_float_is_shown_in_an_int_box(self):
        self.load({"rotation.max_failures": 5.0})
        self.assertEqual(self.page.value("rotation.max_failures"), 5)

    def test_a_value_a_box_cannot_show_disables_the_box_instead_of_failing(self):
        self.load({"rotation.max_failures": "many", "vpn.wg_keepalive": None, "rotation.interval": float("nan"),
                   "rotation.backoff_max": float("inf")})
        for key in ("rotation.max_failures", "vpn.wg_keepalive", "rotation.interval", "rotation.backoff_max"):
            self.assertFalse(self.page.control(key).isEnabled(), key)
        self.assertTrue(self.page.control("vpn.connect_timeout").isEnabled())
        self.load({"rotation.max_failures": 4})                # a usable value brings the box back
        self.assertTrue(self.page.control("rotation.max_failures").isEnabled())
        self.assertEqual(self.page.value("rotation.max_failures"), 4)


class SettingsChangeTests(SettingsCase):
    def setUp(self):
        super().setUp()
        self.load()
        self.pump(0)

    def sent(self):
        return [(s.key, v) for s, v in (c for c in self.changes)]

    def test_ticking_a_box_is_announced_at_once_and_only_when_it_changes(self):
        box = self.page.control("killswitch.log_drops")
        box.setChecked(True)
        self.assertEqual(self.sent(), [("killswitch.log_drops", True)])
        box.setChecked(True)
        self.assertEqual(len(self.changes), 1)
        box.setChecked(False)
        self.assertEqual(self.sent()[-1], ("killswitch.log_drops", False))

    def test_a_number_is_announced_once_after_the_typing_stops(self):
        self.page.control("rotation.max_failures").setValue(10)
        self.pump(0.5)
        self.assertEqual(self.changes, [])
        self.pump(0.25)
        self.assertEqual(self.sent(), [("rotation.max_failures", 10)])
        self.pump(5)
        self.assertEqual(len(self.changes), 1)

    def test_several_edits_of_one_box_send_only_the_last_value(self):
        box = self.page.control("rotation.max_failures")
        box.setValue(10)
        self.pump(0.4)
        box.setValue(11)
        self.pump(0.4)
        box.setValue(12)
        self.pump(0.5)
        self.assertEqual(self.changes, [])
        self.pump(0.3)
        self.assertEqual(self.sent(), [("rotation.max_failures", 12)])

    def test_edits_of_two_boxes_are_both_sent_in_the_order_they_were_made(self):
        self.page.control("rotation.max_failures").setValue(10)
        self.page.control("vpn.wg_keepalive").setValue(25)
        self.pump(1.0)
        self.assertEqual(self.sent(), [("rotation.max_failures", 10), ("vpn.wg_keepalive", 25)])

    def test_a_float_box_sends_a_float(self):
        self.page.control("rotation.interval").setValue(2.5)
        self.pump(1.0)
        (_, value), = self.sent()
        self.assertEqual(value, 2.5)
        self.assertIsInstance(value, float)

    def test_editing_back_to_the_value_the_daemon_has_sends_nothing(self):
        box = self.page.control("rotation.max_failures")
        box.setValue(5)
        box.setValue(1)
        self.pump(2)
        self.assertEqual(self.changes, [])

    def test_a_choice_is_announced_with_its_value_not_its_text(self):
        self.page.control("rotation.strategy").setCurrentIndex(2)
        self.page.control("vpn.mtu").setCurrentIndex(3)
        self.assertEqual(self.sent(), [("rotation.strategy", "random"), ("vpn.mtu", 1420)])
        self.assertIsInstance(self.sent()[1][1], int)

    def test_ticking_tiers_announces_the_ticked_ones_in_schema_order(self):
        boxes = self.page.control("rotation.tiers").boxes
        boxes["paid"].setChecked(True)
        boxes["free"].setChecked(True)
        self.assertEqual(self.sent(), [("rotation.tiers", ["paid"]), ("rotation.tiers", ["free", "paid"])])
        boxes["free"].setChecked(False)
        boxes["paid"].setChecked(False)
        self.assertEqual(self.sent()[-1], ("rotation.tiers", []))

    def test_a_list_box_is_announced_when_editing_finishes_not_while_typing(self):
        edit = self.page.control("dns.servers")
        edit.setText("1.1.1.1, 9.9.9.9")
        self.pump(2)
        self.assertEqual(self.changes, [])
        edit.editingFinished.emit()
        self.assertEqual(self.sent(), [("dns.servers", "1.1.1.1, 9.9.9.9")])
        edit.editingFinished.emit()                            # focus left again: nothing changed
        self.assertEqual(len(self.changes), 1)

    def test_leaving_a_list_box_unchanged_or_only_re_spaced_sends_nothing(self):
        self.load({"dns.servers": ["1.1.1.1", "9.9.9.9"]})
        edit = self.page.control("dns.servers")
        edit.editingFinished.emit()
        edit.setText("1.1.1.1,9.9.9.9 ;")
        edit.editingFinished.emit()
        self.assertEqual(self.changes, [])

    def test_clearing_a_list_box_is_a_change(self):
        self.load({"dns.servers": ["1.1.1.1"]})
        edit = self.page.control("dns.servers")
        edit.setText("")
        edit.editingFinished.emit()
        self.assertEqual(self.sent(), [("dns.servers", "")])

    def test_a_refused_change_is_put_back_and_can_be_tried_again(self):
        box = self.page.control("killswitch.allow_lan")
        box.setChecked(True)
        self.assertEqual(len(self.changes), 1)
        self.page.load(make_config({"killswitch.allow_lan": False}), force=True)      # what the window does on a refusal
        self.assertFalse(box.isChecked())
        self.assertEqual(len(self.changes), 1)
        box.setChecked(True)
        self.assertEqual(len(self.changes), 2)

    def test_the_setting_in_the_announcement_is_the_schema_entry(self):
        self.page.control("killswitch.enabled").setChecked(True)
        setting, value = self.changes[0]
        self.assertIs(setting, next(s for s in all_settings() if s.key == "killswitch.enabled"))
        self.assertIs(value, True)

    def test_a_disabled_box_announces_nothing(self):
        self.page.load(None)
        self.page.control("killswitch.log_drops").click()
        self.assertEqual(self.changes, [])


if __name__ == "__main__":
    unittest.main()
