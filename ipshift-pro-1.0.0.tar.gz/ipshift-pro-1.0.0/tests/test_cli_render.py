"""Terminal output: helpers, renderers (pure functions with fixed data) and the command-line grammar."""
from __future__ import annotations

import io
import os
import unittest
from contextlib import redirect_stderr, redirect_stdout
from unittest import mock

from ipshift.cli import main
from ipshift.cli import render, reports, ui
from ipshift.cli.parser import build_parser, interval_arg
from ipshift.net.local import KIND_NAMES

PLAIN = ui.Style(color=False, unicode=False)
FANCY = ui.Style(color=False, unicode=True)
COLOR = ui.Style(color=True, unicode=True)
NOW = 10_000.0


def merge(base: dict, over: dict) -> dict:
    out = dict(base)
    for k, v in over.items():
        out[k] = merge(out[k], v) if isinstance(v, dict) and isinstance(out.get(k), dict) else v
    return out


def status(**over) -> dict:
    base = {
        "daemon": {"version": "1.0.0", "pid": 42, "uptime": 125, "simulated": False, "root": True},
        "protection": {"level": "protected", "message": "Traffic goes through the VPN; the kill switch is armed"},
        "vpn": {"state": "connected", "connected": True, "busy": None, "last_error": None,
                "profile": {"id": "nl-1", "name": "Amsterdam", "tier": "paid", "protocol": "wireguard", "country": "NL"},
                "server": "203.0.113.9:51820/udp", "backend": "wireguard", "iface": "ipshift0",
                "exit_ip": "198.51.100.7", "exit_ipv6": None, "since": NOW - 95, "uptime": 95, "via": "connect",
                "dns": ["10.2.0.1"], "health": {"handshake_age": 12}},
        "rotation": {"running": False, "interval": 30.0, "strategy": "diverse", "next_in": None, "ticks": 0, "ok": 0,
                     "failed": 0, "unchanged": 0, "skipped": 0, "consecutive_failures": 0, "stalled": False,
                     "last": {}, "minimum_interval": 1.0},
        "killswitch": {"armed": True, "lockdown": False, "dry_run": False, "endpoints": ["203.0.113.9:51820/udp"],
                       "allow_lan": False, "enabled": True, "blocked_packets": 0, "blocked_bytes": 0},
        "network": {"default_iface": "wlan0", "gateway": "192.168.1.1", "kind": "wifi", "hotspot": None,
                    "description": "wifi (wlan0, 192.168.1.23)",
                    "private_ips": [{"iface": "wlan0", "ip": "192.168.1.23", "prefix": 24, "family": 4, "scope": "private",
                                     "kind": "wifi", "primary": True},
                                    {"iface": "ipshift0", "ip": "10.2.0.2", "prefix": 32, "family": 4, "scope": "private",
                                     "kind": "tunnel", "primary": False}]},
        "public": {"v4": "198.51.100.7", "v6": None, "source": "tunnel", "verified_at": NOW - 3},
        "hardening": {"dns_locked": True, "dns_servers": ["10.2.0.1"], "dns_intact": True, "ipv6_guard": True,
                      "ipv6_intact": True, "mac_nm_policy": False, "mac_overrides": []},
        "alerts": [], "privacy": None, "wanted": {"vpn": True, "protect": True},
        "profiles": {"total": 4, "usable": 3},
    }
    return merge(base, over)


class UiTests(unittest.TestCase):
    def test_durations(self):
        f = ui.fmt_duration
        self.assertEqual([f(None), f(0), f(59), f(61), f(3661), f(200_000)],
                         ["-", "0 s", "59 s", "1 min 01 s", "1 h 01 min", "2 d 7 h"])

    def test_milliseconds_and_ago(self):
        self.assertEqual([ui.fmt_ms(None), ui.fmt_ms(5), ui.fmt_ms(1500)], ["-", "5 ms", "1.5 s"])
        self.assertEqual(ui.fmt_ago(None), "never")
        self.assertEqual(ui.fmt_ago(NOW - 0.4, NOW), "just now")
        self.assertEqual(ui.fmt_ago(NOW - 10, NOW), "10 s ago")

    def test_times_handle_missing_values(self):
        self.assertEqual(ui.fmt_clock(None), "--:--:--")
        self.assertEqual(ui.fmt_datetime(None), "-")
        self.assertRegex(ui.fmt_clock(1_700_000_000), r"^\d\d:\d\d:\d\d$")

    def test_symbols_have_ascii_fallbacks(self):
        self.assertEqual([PLAIN.ok, PLAIN.warn, PLAIN.fail, PLAIN.skip], ["[ok]", "[!!]", "[XX]", "[--]"])
        self.assertEqual([FANCY.ok, FANCY.fail], ["✔", "✖"])
        self.assertEqual(PLAIN.arrow, "->")
        self.assertEqual(PLAIN.status_symbol("pass"), PLAIN.ok)
        self.assertEqual(PLAIN.status_symbol("nonsense"), PLAIN.skip)

    def test_colour_is_only_added_when_enabled(self):
        self.assertEqual(PLAIN.paint("x", "red"), "x")
        self.assertEqual(COLOR.paint("x", "red"), "\x1b[31mx\x1b[0m")
        self.assertEqual(COLOR.paint("x"), "x")
        self.assertEqual(ui.strip_ansi(COLOR.paint("hello", "red", "bold")), "hello")
        self.assertEqual(ui.visible_len(COLOR.paint("hello", "red")), 5)

    def test_make_style_follows_the_terminal_and_the_environment(self):
        class Stream:
            def __init__(self, tty, enc):
                self._tty, self.encoding = tty, enc

            def isatty(self):
                return self._tty

        with mock.patch.dict(os.environ, {"TERM": "xterm"}, clear=False):
            os.environ.pop("NO_COLOR", None)
            tty = ui.make_style(Stream(True, "utf-8"))
            self.assertTrue(tty.color and tty.unicode)
            self.assertFalse(ui.make_style(Stream(False, "utf-8")).color)
            self.assertFalse(ui.make_style(Stream(True, "utf-8"), no_color=True).color)
            self.assertFalse(ui.make_style(Stream(True, "utf-8"), ascii_only=True).unicode)
            self.assertFalse(ui.make_style(Stream(True, "latin-1")).unicode)
            with mock.patch.dict(os.environ, {"NO_COLOR": "1"}):
                self.assertFalse(ui.make_style(Stream(True, "utf-8")).color)
            with mock.patch.dict(os.environ, {"TERM": "dumb"}):
                self.assertFalse(ui.make_style(Stream(True, "utf-8")).color)

    def test_table_aligns_columns_even_with_colour(self):
        rows = [["a", ("ok", "green"), "x"], ["longer", ("failed", "red"), "y"]]
        plain = ui.table(rows, ["NAME", "STATE", "Z"], PLAIN).splitlines()
        painted = [ui.strip_ansi(l) for l in ui.table(rows, ["NAME", "STATE", "Z"], COLOR).splitlines()]
        self.assertEqual(plain, painted)
        offsets = {l.index(l.split()[-1]) for l in plain[1:]}
        self.assertEqual(len(offsets), 1, plain)

    def test_wrap_never_splits_long_words(self):
        path = "/very/long/" + "x" * 80 + "/path"
        out = ui.wrap(f"see {path} now", 40, "  ")
        self.assertIn(path, out)
        self.assertTrue(all(l.startswith("  ") for l in out.splitlines()))
        bullet = ui.wrap("one two three four five six seven eight nine ten", 24, "    ", first=" *  ")
        self.assertTrue(bullet.splitlines()[0].startswith(" *  "))
        self.assertTrue(all(l.startswith("    ") for l in bullet.splitlines()[1:]))


class StatusViewTests(unittest.TestCase):
    def view(self, st=None, style=PLAIN) -> str:
        return render.render_status(st or status(), style, now=NOW)

    def test_a_protected_connection(self):
        out = self.view()
        for needle in ("IPShift Pro 1.0.0", "daemon pid 42", "PROTECTED", "connected to Amsterdam (wireguard, paid, NL)",
                       "server 203.0.113.9:51820/udp", "interface ipshift0", "handshake 12 s ago", "198.51.100.7",
                       "verified 3 s ago", "192.168.1.23", "default route", "10.2.0.2", "VPN tunnel",
                       "Wi-Fi on wlan0, gateway 192.168.1.1", "armed", "LAN blocked", "locked to 10.2.0.2".replace("2.0.2", "2.0.1"),
                       "3 usable of 4", "not tested yet"):
            self.assertIn(needle, out)
        self.assertNotIn("SIMULATION", out)
        self.assertIn("Public IPv6", out)

    def test_labels_never_run_into_their_values(self):
        for line in self.view().splitlines():
            if line.startswith("  ") and not line.startswith("   "):
                label, _, rest = line[2:].partition("  ")
                self.assertTrue(rest.strip(), line)

    def test_simulation_is_announced(self):
        out = self.view(status(daemon={"simulated": True}))
        self.assertIn("SIMULATION", out)
        self.assertIn("fake", out)

    def test_not_connected_and_exposed(self):
        st = status(protection={"level": "unprotected", "message": "Not connected - your real IP address is exposed"},
                    vpn={"state": "disconnected", "connected": False, "profile": None, "server": None, "uptime": None},
                    public={"v4": None, "v6": None, "source": None, "verified_at": None},
                    killswitch={"armed": False, "endpoints": []})
        out = self.view(st)
        self.assertIn("UNPROTECTED", out)
        self.assertIn("not connected", out)
        self.assertIn("ipshift ip --direct", out)
        self.assertNotIn("Public IPv6", out)
        self.assertIn("not armed", out)

    def test_blocked_by_the_kill_switch(self):
        st = status(protection={"level": "blocked", "message": "Not connected - the kill switch is blocking all traffic"},
                    vpn={"state": "disconnected", "connected": False, "profile": None},
                    public={"v4": None, "v6": None, "source": None, "verified_at": None})
        out = self.view(st)
        self.assertIn("BLOCKED", out)
        self.assertIn("none", out)
        self.assertIn("blocking all traffic", out)

    def test_lockdown_and_blocked_packets(self):
        out = self.view(status(killswitch={"lockdown": True, "blocked_packets": 1, "endpoints": []}))
        self.assertIn("LOCKDOWN", out)
        self.assertIn("1 packet blocked", out)
        self.assertIn("2 packets blocked", self.view(status(killswitch={"blocked_packets": 2})))

    def test_failed_and_connecting_states(self):
        failed = self.view(status(vpn={"state": "failed", "connected": False, "profile": None, "last_error": "handshake timed out"}))
        self.assertIn("failed: handshake timed out", failed)
        busy = self.view(status(vpn={"state": "connecting", "connected": False, "profile": None, "busy": "connect"}))
        self.assertIn("connecting (connect)", busy)

    def test_rotation_running_with_counts_and_last_result(self):
        rot = {"running": True, "interval": 1.0, "strategy": "diverse", "next_in": 0.4, "ticks": 5, "ok": 4, "failed": 1,
               "unchanged": 0, "skipped": 2, "consecutive_failures": 0,
               "last": {"status": "success", "profile": "Zurich", "ip": "198.51.100.9", "ms": 1200}}
        out = self.view(status(rotation=rot))
        for needle in ("running: every 1 s (diverse), next in 0.4 s", "4 changed, 1 failed, 0 unchanged, 2 skipped",
                       "last: [ok] success Zurich 198.51.100.9 in 1.2 s"):
            self.assertIn(needle, out)

    def test_rotation_trouble_is_loud(self):
        rot = {"running": True, "interval": 1.0, "ticks": 9, "stalled": True, "consecutive_failures": 3,
               "last": {"status": "failed", "profile": "X", "error": "no route"}}
        out = self.view(status(rotation=rot))
        self.assertIn("STALLED: 3 failures in a row", out)
        self.assertIn("[XX] failed X", out)
        self.assertIn("no route", out)
        self.assertIn("2 failure(s) in a row", self.view(status(rotation={"consecutive_failures": 2})))

    def test_dns_and_ipv6_tampering_is_called_out(self):
        out = self.view(status(hardening={"dns_intact": False, "ipv6_intact": False}))
        self.assertEqual(out.count("changed by another program!"), 2)

    def test_mac_row_only_appears_when_something_is_set(self):
        self.assertNotIn("MAC address", self.view())
        self.assertIn("random MAC", self.view(status(hardening={"mac_nm_policy": True})))
        self.assertIn("changed by hand on wlan0", self.view(status(hardening={"mac_overrides": ["wlan0"]})))

    def test_privacy_summary(self):
        pr = {"score": 97, "grade": "A", "verdict": "protected-with-warnings", "ts": NOW - 60}
        out = self.view(status(privacy=pr))
        self.assertIn("grade A (97/100)", out)
        self.assertIn("checked 1 min 00 s ago", out)

    def test_no_profiles_points_at_import(self):
        out = self.view(status(profiles={"total": 0, "usable": 0}))
        self.assertIn("none imported", out)
        self.assertIn("ipshift vpn import", out)

    def test_recent_alerts_are_listed_with_hints(self):
        alerts = [{"kind": "tunnel_lost", "level": "critical", "ts": 1_700_000_000, "data": {"message": "The VPN dropped", "hint": "wait"}},
                  {"kind": "network_changed", "level": "warning", "ts": 1_700_000_100, "data": {"message": "Network changed"}}]
        out = self.view(status(alerts=alerts))
        self.assertIn("Recent alerts", out)
        self.assertIn("The VPN dropped", out)
        self.assertIn("hint: wait", out)
        self.assertIn("[XX]", out)
        self.assertIn("[!!] Network changed", out)

    def test_only_the_last_five_alerts_are_shown(self):
        alerts = [{"kind": "x", "level": "warning", "ts": 1_700_000_000 + i, "data": {"message": f"alert-{i}"}} for i in range(9)]
        out = self.view(status(alerts=alerts))
        self.assertNotIn("alert-3", out)
        self.assertIn("alert-4", out)
        self.assertIn("alert-8", out)

    def test_unicode_and_colour_variants_render_the_same_text(self):
        plain = self.view(style=FANCY)
        painted = ui.strip_ansi(self.view(style=COLOR))
        self.assertEqual(plain, painted)
        self.assertIn("\x1b[", self.view(style=COLOR))

    def test_ip_view_distinguishes_tunnel_and_direct(self):
        info = {"private": status()["network"]["private_ips"], "network": "Wi-Fi (wlan0)", "state": "connected",
                "protection": "protected", "public": {"v4": "198.51.100.7", "v6": "2001:db8::7", "source": "tunnel",
                                                      "verified_at": NOW - 1}, "note": None}
        out = render.render_ip(info, PLAIN, now=NOW)
        self.assertIn("198.51.100.7", out)
        self.assertIn("2001:db8::7", out)
        self.assertIn("PROTECTED", out)
        direct = dict(info, protection="unprotected", public={"v4": "192.0.2.5", "v6": None, "source": "direct", "verified_at": NOW},
                      note="This is your real, unprotected address")
        out = render.render_ip(direct, PLAIN, now=NOW)
        self.assertIn("your real, unprotected address", out)
        self.assertIn("192.0.2.5", out)

    def test_network_names(self):
        self.assertEqual(render.network_name({}), "no connection")
        self.assertEqual(render.network_name({"kind": "usb-tether", "default_iface": "usb0"}), "USB tethering on usb0")
        self.assertEqual(render.network_name({"hotspot": "Android hotspot", "kind": "wifi", "default_iface": "wlan0",
                                              "gateway": "192.168.43.1"}), "Android hotspot on wlan0, gateway 192.168.43.1")
        self.assertIn("wifi", KIND_NAMES)


class ConnectViewTests(unittest.TestCase):
    RES = {"profile_id": "nl-1", "profile_name": "Amsterdam", "backend": "wireguard", "server": "203.0.113.9:51820/udp",
           "exit_ip": "198.51.100.7", "exit_ipv6": "2001:db8::7", "previous_ip": "198.51.100.1", "changed": True,
           "via": "connect", "duration_ms": 1234, "dns": ["10.2.0.1"]}

    def test_a_good_connection(self):
        out = render.render_connect(self.RES, PLAIN)
        for needle in ("Connected to Amsterdam (wireguard) in 1.2 s", "198.51.100.7", "was 198.51.100.1",
                       "2001:db8::7", "203.0.113.9:51820/udp", "10.2.0.1"):
            self.assertIn(needle, out)
        self.assertNotIn("did not change", out)

    def test_hot_swap_and_unchanged_and_paused_rotation(self):
        res = dict(self.RES, via="hot-swap", changed=False, rotation_stopped=True)
        out = render.render_connect(res, PLAIN)
        self.assertIn("hot-swapped", out)
        self.assertIn("did not change", out)
        self.assertIn("Rotation was running and has been paused", out)

    def test_rotation_started_explains_the_one_second_rule(self):
        fast = render.render_rotation_started({"interval": 1.0, "strategy": "diverse", "profiles_in_rotation": 6}, PLAIN)
        self.assertIn("every 1 s", fast)
        self.assertIn("new public IP is verified", fast)
        slow = render.render_rotation_started({"interval": 30.0, "strategy": "random", "profiles_in_rotation": 2}, PLAIN)
        self.assertNotIn("verified", slow)
        warned = render.render_rotation_started({"interval": 30.0, "profiles_in_rotation": 1,
                                                 "warning": "only one usable profile"}, PLAIN)
        self.assertIn("only one usable profile", warned)

    def test_stop_messages_say_what_the_network_is_now(self):
        self.assertIn("normal networking is back", reports.render_stop({"stopped": "all", "released": True}, PLAIN))
        self.assertIn("keeps blocking", reports.render_stop({"stopped": "all", "released": False}, PLAIN))
        self.assertIn("stays up", reports.render_stop({"stopped": "rotation", "connected": True}, PLAIN))
        self.assertNotIn("stays up", reports.render_stop({"stopped": "rotation", "connected": False}, PLAIN))


class EventTextTests(unittest.TestCase):
    def text(self, kind, **data) -> str:
        return render.event_text({"kind": kind, "level": "info", "data": data, "ts": 0})

    def test_known_events_read_as_sentences(self):
        self.assertEqual(self.text("connecting", name="A"), "Connecting to A")
        self.assertEqual(self.text("connected", name="A", ip="1.2.3.4", previous="1.2.3.3", ms=1500, via="hot-swap"),
                         "Connected to A: public IP 1.2.3.4 (was 1.2.3.3) in 1.5 s [hot-swap]")
        self.assertEqual(self.text("connected", name="A", ip="1.2.3.4"), "Connected to A: public IP 1.2.3.4")
        self.assertIn("same public IP", self.text("unchanged", name="A", ip="1.2.3.4"))
        self.assertEqual(self.text("cancelled", name="A"), "Connecting to A was cancelled")
        self.assertEqual(self.text("connect_failed", name="A", error="boom"), "Could not connect to A: boom")
        self.assertIn("still blocking", self.text("disconnected", name="A", released=False))
        self.assertEqual(self.text("disconnected", name="A", released=True), "Disconnected from A")
        self.assertEqual(self.text("rotation_started", interval=1.0, strategy="diverse"),
                         "Rotation started: every 1 s, strategy diverse")
        self.assertEqual(self.text("rotation_stopped"), "Rotation stopped")
        self.assertEqual(self.text("interval_changed", interval=2.5), "Rotation interval is now 2.5 s")
        self.assertIn("3 failed", self.text("rotation_recovered", after_failures=3))
        self.assertIn("skipped 2", self.text("rotation_overrun", took=2.1, skipped=2))

    def test_a_message_wins_and_unknown_kinds_still_read_well(self):
        self.assertEqual(self.text("tunnel_lost", message="The VPN dropped"), "The VPN dropped")
        self.assertEqual(self.text("some_new_event"), "some new event")
        self.assertEqual(self.text("connecting"), "Connecting to ?")

    def test_event_lines_have_time_symbol_and_hint(self):
        ev = {"kind": "x", "level": "warning", "ts": 1_700_000_000, "data": {"message": "m", "hint": "do this"}}
        lines = render.render_event(ev, PLAIN).splitlines()
        self.assertRegex(lines[0], r"^\d\d:\d\d:\d\d  \[!!\] m$")
        self.assertTrue(lines[1].strip().startswith("hint: do this"))
        crit = render.render_event(dict(ev, level="critical"), COLOR)
        self.assertIn("\x1b[31;1m", crit)
        self.assertIn("[i]", render.render_event(dict(ev, level="info"), PLAIN))


def finding(fid, status, detail="", hint=None, leak=False, evidence=None):
    return {"id": fid, "title": fid.replace("_", " ").title(), "status": status, "detail": detail, "hint": hint,
            "leak": leak, "weight": 10, "evidence": evidence or {}}


def report(verdict="protected", findings=None, **over) -> dict:
    base = {"verdict": verdict, "headline": "PROTECTED - every check this tool can run passed", "score": 100, "grade": "A",
            "counts": {}, "mode": "full", "ts": NOW, "duration_ms": 2300, "simulated": False,
            "findings": findings if findings is not None else [finding("tunnel", "pass", "up")],
            "not_covered": ["Browser leaks (WebRTC) - use a hardened browser", "What your VPN provider logs"]}
    base.update(over)
    return base


class ReportViewTests(unittest.TestCase):
    def test_groups_come_in_order_of_urgency(self):
        rep = report("exposed", [finding("a_pass", "pass", "fine"), finding("b_warn", "warn", "meh", "fix warn"),
                                 finding("c_leak", "fail", "DNS leaks", "fix leak", leak=True),
                                 finding("d_fail", "fail", "broken", "fix fail"), finding("e_skip", "skip", "n/a")],
                     headline="EXPOSED - traffic or DNS can leave outside the VPN", score=39, grade="F")
        out = reports.render_report(rep, PLAIN)
        order = [out.index(h) for h in ("Leaks", "Problems", "Warnings", "Passed", "Not tested", "What this check cannot see")]
        self.assertEqual(order, sorted(order))
        for needle in ("EXPOSED", "Score 39/100, grade F", "fix: fix leak", "fix: fix fail", "fix: fix warn",
                       "[XX] C Leak", "[!!] B Warn", "[ok] A Pass", "[--] E Skip"):
            self.assertIn(needle, out)
        self.assertNotIn("fix:", out.split("Passed")[1])           # passing checks need no advice

    def test_empty_groups_are_left_out(self):
        out = reports.render_report(report(), PLAIN)
        for absent in ("Leaks", "Problems", "Warnings", "Not tested"):
            self.assertNotIn(f"  {absent}\n", out)
        self.assertIn("Passed", out)

    def test_the_limits_of_the_check_are_always_shown(self):
        out = reports.render_report(report(), PLAIN)
        self.assertIn("What this check cannot see", out)
        self.assertIn("Browser leaks", out)
        self.assertIn("not a guarantee of anonymity", out)

    def test_simulated_results_are_labelled(self):
        self.assertIn("SIMULATION", reports.render_report(report(simulated=True), PLAIN))
        self.assertNotIn("SIMULATION", reports.render_report(report(), PLAIN))

    def test_evidence_only_with_verbose(self):
        rep = report(findings=[finding("tunnel", "pass", "up", evidence={"exit": "1.2.3.4"})])
        self.assertNotIn("exit: 1.2.3.4", reports.render_report(rep, PLAIN))
        self.assertIn("exit: 1.2.3.4", reports.render_report(rep, PLAIN, verbose=True))

    def test_wrapping_respects_the_width(self):
        rep = report(findings=[finding("x", "fail", "word " * 60, "hint " * 30, leak=True)])
        out = reports.render_report(rep, PLAIN, width=60)
        self.assertLessEqual(max(len(l) for l in out.splitlines()), 60)
        self.assertTrue([l for l in out.splitlines() if l.startswith("       ")])

    def test_bullets_hang_correctly(self):
        out = reports.render_report(report(not_covered=["x " * 60]), PLAIN, width=50)
        tail = out.split("What this check cannot see")[1].splitlines()[1:]
        self.assertTrue(tail[0].startswith("   * "))
        self.assertTrue(all(l.startswith("     ") for l in tail[1:] if l.strip()))


class DoctorViewTests(unittest.TestCase):
    def test_columns_line_up_in_both_symbol_sets(self):
        checks = [{"id": "a", "title": "Short", "status": "ok", "detail": "fine", "hint": None},
                  {"id": "b", "title": "A much longer title", "status": "info", "detail": "note " * 30, "hint": "do this"},
                  {"id": "c", "title": "Mid", "status": "fail", "detail": "bad", "hint": None}]
        d = {"checks": checks, "summary": {"ok": 1, "info": 1, "warn": 0, "fail": 1}, "ready": False}
        for style in (PLAIN, FANCY):
            lines = reports.render_doctor(d, style, width=70).splitlines()
            detail_cols = set()
            body = lines[2:lines.index("", 2)]
            for l in body:
                for word in ("fine", "note", "bad"):
                    if word in l:
                        detail_cols.add(l.index(word))
            self.assertEqual(len(detail_cols), 1, lines)
            self.assertTrue(any(style.arrow + " do this" in l for l in lines))
        self.assertIn("Not ready", reports.render_doctor(d, PLAIN))
        self.assertIn("1 ok, 1 notes, 0 warnings, 1 problems", reports.render_doctor(d, PLAIN))
        ready = dict(d, ready=True)
        self.assertIn("Ready to use.", reports.render_doctor(ready, PLAIN))


class HistoryViewTests(unittest.TestCase):
    def rows(self):
        return [{"id": 3, "ts": 1_700_000_300, "status": "failed", "profile_name": "C", "old_ip": "1.1.1.2", "new_ip": None,
                 "duration_ms": 900, "reason": "rotate", "error": "handshake timed out"},
                {"id": 2, "ts": 1_700_000_200, "status": "success", "profile_name": "B", "old_ip": "1.1.1.1", "new_ip": "1.1.1.2",
                 "duration_ms": 1500, "reason": "rotate", "error": None},
                {"id": 1, "ts": 1_700_000_100, "status": "unchanged", "profile_name": "A", "old_ip": "1.1.1.1", "new_ip": "1.1.1.1",
                 "duration_ms": None, "reason": "manual", "error": None}]

    def test_newest_row_is_at_the_bottom(self):
        out = reports.render_history({"rotations": self.rows(), "stats": {}, "events": []}, PLAIN)
        body = [l for l in out.splitlines() if l.strip()]
        self.assertTrue(body[0].lstrip().startswith("TIME"))
        self.assertIn(" A ", body[1])
        self.assertIn(" C ", body[3])
        self.assertIn("handshake timed out", body[3])
        self.assertIn("manual", body[1])

    def test_summary_line_and_alerts(self):
        data = {"rotations": self.rows(), "stats": {"total": 3, "success": 1, "failed": 1, "unchanged": 1, "unique_ips": 2,
                                                   "avg_duration_ms": 1500},
                "events": [{"ts": 1_700_000_400, "level": "critical", "kind": "tunnel_lost", "message": "The VPN dropped"}]}
        out = reports.render_history(data, PLAIN)
        self.assertIn("3 recorded: 1 changed the address, 1 failed, 1 unchanged; 2 different addresses, average 1.5 s", out)
        self.assertIn("Recent alerts", out)
        self.assertIn("[XX] The VPN dropped", out)

    def test_empty_history(self):
        out = reports.render_history({"rotations": [], "stats": {"total": 0}, "events": []}, PLAIN)
        self.assertIn("No rotations recorded yet", out)


class ProfileViewTests(unittest.TestCase):
    def profile(self, pid, **kw):
        base = {"id": pid, "name": pid.upper(), "protocol": "wireguard", "tier": "paid", "country": "NL", "enabled": True,
                "needs_auth": False, "has_auth": False, "ok_count": 2, "fail_count": 1, "quarantined": False,
                "quarantined_until": 0.0, "usable": True}
        base.update(kw)
        return base

    def test_states(self):
        data = {"profiles": [self.profile("a"), self.profile("b", enabled=False, usable=False),
                             self.profile("c", quarantined=True, quarantined_until=NOW + 90, usable=False),
                             self.profile("d", protocol="openvpn", needs_auth=True, usable=False),
                             self.profile("e", needs_auth=True, has_auth=True)],
                "current": "a", "in_rotation": ["a", "e"]}
        out = reports.render_profiles(data, PLAIN, now=NOW)
        rows = {l.split()[0]: l for l in out.splitlines() if l.strip() and not l.strip().startswith(("ID", "Free", "use"))}
        self.assertIn("active", rows["a"])
        self.assertIn("disabled", rows["b"])
        self.assertIn("benched 1 min 30 s", rows["c"])
        self.assertIn("needs login", rows["d"])
        self.assertIn("ready", rows["e"])
        self.assertIn("2/1", rows["a"])
        self.assertTrue(rows["a"].split()[-2] == "yes" and rows["b"].split()[-2] == "-")

    def test_free_profiles_get_the_caution(self):
        data = {"profiles": [self.profile("a", tier="free")], "current": None, "in_rotation": []}
        self.assertIn("Free VPNs can log", reports.render_profiles(data, PLAIN, now=NOW))
        data["profiles"][0]["tier"] = "paid"
        self.assertNotIn("Free VPNs", reports.render_profiles(data, PLAIN, now=NOW))

    def test_empty_list_explains_how_to_import(self):
        out = reports.render_profiles({"profiles": [], "current": None, "in_rotation": []}, PLAIN)
        self.assertIn("ipshift vpn import", out)

    def test_import_results(self):
        p = self.profile("new", endpoints=[{"host": "h", "port": 1}] * 2, needs_auth=True, tier="free")
        out = reports.render_import({"profile": p, "warnings": ["resolve later"], "removed": ["up"]}, PLAIN)
        for needle in ("Imported NEW (wireguard, free, NL), id new, 2 servers", "needs a username and password",
                       "resolve later", "replaced up", "Free VPNs can log"):
            self.assertIn(needle, out)
        one = reports.render_import({"profile": self.profile("x", endpoints=[{}]), "warnings": [], "removed": []}, PLAIN)
        self.assertIn("1 server\n", one + "\n")


class ConfigAndRestoreViewTests(unittest.TestCase):
    def test_values_are_readable(self):
        f = reports.fmt_value
        self.assertEqual([f(True), f(False), f(None), f([]), f(["a", "b"]), f(""), f(5.0), f("x")],
                         ["true", "false", "null", "[]", "a, b", '""', "5.0", "x"])

    def test_config_listing_by_section(self):
        data = {"config": {"rotation": {"interval": 30.0, "tiers": []}, "vpn": {"mtu": 1380}}, "file": "/etc/ipshift/config.json",
                "warnings": ["unknown key ignored"], "simulated": True}
        out = reports.render_config(data, PLAIN)
        for needle in ("[rotation]", "[vpn]", "interval", "30.0", "mtu", "1380", "unknown key ignored", "changes are not saved"):
            self.assertIn(needle, out)
        only = reports.render_config(data, PLAIN, section="vpn")
        self.assertIn("[vpn]", only)
        self.assertNotIn("[rotation]", only)

    def test_set_result_says_when_it_applies(self):
        res = {"key": "rotation.interval", "old": 30.0, "value": 5.0, "applies": "now", "saved": True}
        out = reports.render_config_set(res, PLAIN)
        self.assertIn("rotation.interval: 30.0 -> 5.0", out)
        self.assertIn("takes effect now; saved to the config file", out)
        self.assertIn("daemon restart", reports.render_config_set(dict(res, applies="restart", saved=False), PLAIN))
        self.assertIn("not saved", reports.render_config_set(dict(res, saved=False), PLAIN))

    def test_restore_report(self):
        good = reports.render_restore({"killswitch": "removed", "dns": True, "ipv6": ["wlan0"], "mac": [],
                                       "openvpn_stopped": 2, "tunnel_interface_removed": True}, PLAIN)
        for needle in ("kill switch rules removed", "original DNS settings put back", "switched back on for wlan0",
                       "MAC address   nothing to restore", "stopped 2 leftover OpenVPN processes", "removed the tunnel interface"):
            self.assertIn(needle, good)
        bad = reports.render_restore({"killswitch": "FAILED: nft said no", "dns": False, "ipv6": []}, PLAIN)
        self.assertIn("[XX]", bad)
        self.assertIn("sudo nft delete table inet ipshift", bad)
        self.assertNotIn("MAC address", bad)                      # not part of this restore


class ParserTests(unittest.TestCase):
    def parse(self, *argv):
        return build_parser().parse_args(list(argv))

    def code(self, *argv) -> tuple[int, str, str]:
        out, err = io.StringIO(), io.StringIO()
        return main(list(argv), out=out, err=err), out.getvalue(), err.getvalue()

    def test_global_options_work_before_and_after_the_command(self):
        self.assertTrue(self.parse("--json", "status").json)
        self.assertTrue(self.parse("status", "--json").json)
        self.assertFalse(self.parse("status").json)
        self.assertEqual(self.parse("--socket", "/a", "status").socket, "/a")
        self.assertEqual(self.parse("status", "--socket", "/b").socket, "/b")
        self.assertEqual(self.parse("vpn", "list", "--socket", "/c").socket, "/c")
        self.assertIsNone(self.parse("status").socket)
        a = self.parse("--no-color", "--ascii", "doctor")
        self.assertTrue(a.no_color and a.ascii)

    def test_the_spec_commands_all_exist(self):
        for argv in (["status"], ["ip"], ["vpn", "connect"], ["rotate", "--interval", "1"], ["stop"], ["privacy-check"]):
            self.assertIsNotNone(self.parse(*argv).func, argv)

    def test_rotation_interval_rules(self):
        self.assertEqual(self.parse("rotate", "--interval", "1").interval, 1.0)
        self.assertEqual(self.parse("rotate", "-i", "2.5").interval, 2.5)
        self.assertIsNone(self.parse("rotate").interval)
        for bad in ("0.99", "0", "-1", "abc", "nan", "inf", ""):
            code, _, err = self.code("rotate", "--interval", bad)
            self.assertEqual(code, 2, bad)
            self.assertIn("error", err.lower(), bad)
        code, _, err = self.code("rotate", "--interval", "0.5")
        self.assertIn("shortest interval is 1 second", err)
        self.assertEqual(interval_arg("1"), 1.0)

    def test_aliases(self):
        self.assertIs(self.parse("check").func, self.parse("privacy-check").func)
        self.assertIs(self.parse("vpn", "ls").func, self.parse("vpn", "list").func)
        self.assertIs(self.parse("vpn", "rm", "x").func, self.parse("vpn", "remove", "x").func)

    def test_conflicting_or_missing_arguments_exit_with_two(self):
        for argv in (["ip", "--public", "--private"], ["vpn"], ["vpn", "import"], ["history", "-n", "0"],
                     ["status", "--count", "x"], ["killswitch", "explode"], ["events", "--level", "loud"],
                     ["vpn", "import", "f", "--tier", "gold"], ["nonsense"]):
            code, _, err = self.code(*argv)
            self.assertEqual(code, 2, argv)
            self.assertTrue(err, argv)

    def test_watch_takes_an_optional_number(self):
        self.assertIsNone(self.parse("status").watch)
        self.assertEqual(self.parse("status", "--watch").watch, 2.0)
        self.assertEqual(self.parse("status", "-w", "5").watch, 5.0)

    def test_help_and_version_do_not_need_a_daemon(self):
        code, out, _ = self.code("--help")
        self.assertEqual(code, 0)
        for needle in ("status", "rotate", "privacy-check", "exit codes", "does not make you anonymous"):
            self.assertIn(needle, out)
        code, out, _ = self.code("--version")
        self.assertEqual((code, out.strip()), (0, "ipshift 1.0.0"))
        code, out, _ = self.code("vpn", "--help")
        self.assertEqual(code, 0)
        self.assertIn("import", out)

    def test_no_command_shows_the_help(self):
        code, out, _ = self.code()
        self.assertEqual(code, 0)
        self.assertIn("COMMAND", out)

    def test_every_command_has_a_handler(self):
        parser = build_parser()
        subs = next(a for a in parser._actions if getattr(a, "choices", None))          # noqa: SLF001
        for name, sub in subs.choices.items():
            if name == "vpn":
                continue
            self.assertIsNotNone(sub.get_default("func"), name)


if __name__ == "__main__":  # pragma: no cover
    unittest.main()
