"""The ``ipshift`` command against a real (simulated) daemon on a real Unix socket."""
from __future__ import annotations

import base64
import csv
import io
import json
import os
import stat
import unittest
from pathlib import Path

from helpers import TmpRootCase

from ipshift.cli import main
from ipshift.config import Config
from ipshift.daemon import Daemon
from ipshift.paths import default_paths

CERT = "-----BEGIN CERTIFICATE-----\nMIIBkTCB+wIJAK\nAAAAAAAAAAA=\n-----END CERTIFICATE-----"


def wgkey() -> str:
    return base64.b64encode(os.urandom(32)).decode()


class TTY(io.StringIO):
    """A stand-in for a terminal: prompts are allowed."""

    def isatty(self) -> bool:
        return True


class CliCase(TmpRootCase):
    def setUp(self):
        super().setUp()
        self.cfg = Config()
        self.cfg.vpn.connect_timeout = 5.0
        self.cfg.vpn.verify_timeout = 3.0
        self.paths = default_paths()
        self.sock = self.tmp / "run" / "ipshift.sock"
        self.daemon = Daemon(self.cfg, self.paths, simulate=True, sim_speed=0.0, socket_path=self.sock)
        self.daemon.start()
        self.addCleanup(self.daemon.stop)
        self.engine = self.daemon.engine
        self.wg = self.engine.store.list(protocol="wireguard")
        self.ovpn = self.engine.store.list(protocol="openvpn")
        self.sleeps: list[float] = []

    # ---- running the command ------------------------------------------------------------------------
    def cli(self, *argv, stdin: str = "") -> tuple[int, str, str]:
        out, err = io.StringIO(), io.StringIO()
        code = main(["--socket", str(self.sock), *argv], out=out, err=err, inp=io.StringIO(stdin),
                    sleep=self.sleeps.append)
        return code, out.getvalue(), err.getvalue()

    def tty(self, *argv, stdin: str = "") -> tuple[int, str, str]:
        out, err = io.StringIO(), TTY()
        code = main(["--no-color", "--socket", str(self.sock), *argv], out=out, err=err, inp=TTY(stdin),
                    sleep=self.sleeps.append, secret_reader=lambda prompt: "typed-secret")
        return code, out.getvalue(), err.getvalue()

    def ok(self, *argv, stdin: str = "") -> str:
        code, out, err = self.cli(*argv, stdin=stdin)
        self.assertEqual(code, 0, f"{argv}: {err or out}")
        return out

    def js(self, *argv):
        return json.loads(self.ok("--json", *argv))

    def connect(self, profile=None) -> str:
        return self.ok("vpn", "connect", *( [profile.id] if profile else [] ))

    def write_wg(self, name="my-server", ip="203.0.113.50") -> Path:
        d = self.tmp / "vpn"
        d.mkdir(exist_ok=True)
        p = d / f"{name}.conf"
        p.write_text(f"[Interface]\nPrivateKey = {wgkey()}\nAddress = 10.2.0.2/32\nDNS = 10.2.0.1\n\n"
                     f"[Peer]\nPublicKey = {wgkey()}\nAllowedIPs = 0.0.0.0/0, ::/0\nEndpoint = {ip}:51820\n")
        return p

    def write_ovpn(self, name="free-us-1", ip="203.0.113.61") -> Path:
        d = self.tmp / "vpn"
        d.mkdir(exist_ok=True)
        p = d / f"{name}.ovpn"
        p.write_text(f"client\ndev tun\nproto udp\nremote {ip} 1194\nremote-cert-tls server\nauth-user-pass\n"
                     f"cipher AES-256-GCM\n<ca>\n{CERT}\n</ca>\n")
        return p


class StatusTests(CliCase):
    def test_before_connecting_the_real_address_is_exposed(self):
        out = self.ok("status")
        for needle in ("UNPROTECTED", "not connected", "SIMULATION", "ipshift ip --direct", "192.168.1.23",
                       "8 usable of 8"):
            self.assertIn(needle, out)

    def test_after_connecting_it_shows_the_tunnel(self):
        self.connect(self.wg[0])
        out = self.ok("status")
        self.assertIn("PROTECTED", out)
        self.assertIn(self.wg[0].name, out)
        self.assertIn(self.engine.status()["public"]["v4"], out)
        self.assertIn("armed", out)

    def test_check_flag_turns_protection_into_an_exit_code(self):
        self.assertEqual(self.cli("status", "--check")[0], 1)
        self.connect()
        self.assertEqual(self.cli("status", "--check")[0], 0)

    def test_json_is_the_daemons_own_data(self):
        data = self.js("status")
        self.assertEqual(data["protection"]["level"], "unprotected")
        self.assertTrue(data["daemon"]["simulated"])
        self.assertEqual(data["profiles"], {"total": 8, "usable": 8})

    def test_watch_repeats_and_stops_after_count(self):
        out = self.ok("status", "--watch", "--count", "3")
        self.assertEqual(out.count("Protection"), 3)
        self.assertEqual(out.count("Refreshing every 2 s"), 3)
        self.assertEqual(self.sleeps, [2.0, 2.0])
        self.assertNotIn("\x1b[", out)

    def test_watch_with_json_prints_one_object_per_line(self):
        out = self.ok("--json", "status", "--watch", "0.5", "--count", "2")
        lines = out.strip().splitlines()
        self.assertEqual(len(lines), 2)
        self.assertEqual({json.loads(l)["protection"]["level"] for l in lines}, {"unprotected"})
        self.assertEqual(self.sleeps, [0.5])

    def test_fresh_rereads_the_network(self):
        self.assertIn("UNPROTECTED", self.ok("status", "--fresh"))


class IpTests(CliCase):
    def test_private_addresses_are_shown_and_the_public_one_is_not_looked_up(self):
        out = self.ok("ip")
        self.assertIn("192.168.1.23", out)
        self.assertIn("not looked up while unprotected", out)
        self.assertIn("UNPROTECTED", out)

    def test_public_flag_without_a_tunnel_fails_with_a_reason(self):
        code, out, err = self.cli("ip", "--public")
        self.assertEqual((code, out), (1, ""))
        self.assertIn("no public address", err)

    def test_direct_looks_up_the_real_address_when_nothing_blocks_it(self):
        out = self.ok("ip", "--direct")
        self.assertIn("your real, unprotected address", out)
        self.assertIn("192.0.2.77", out)

    def test_direct_is_refused_while_the_kill_switch_blocks_everything(self):
        self.ok("killswitch", "on")
        out = self.ok("ip", "--direct")
        self.assertNotIn("192.0.2.77", out)
        self.assertIn("kill switch is blocking", out)

    def test_public_and_private_flags_print_bare_addresses(self):
        self.connect()
        exit_ip = self.engine.status()["public"]["v4"]
        self.assertEqual(self.ok("ip", "--public"), exit_ip + "\n")
        private = self.ok("ip", "--private").split()
        self.assertEqual(private, ["192.168.1.23"])                  # the tunnel's own address is not "yours"

    def test_json_and_refresh(self):
        self.connect()
        data = self.js("ip", "--refresh")
        self.assertEqual(data["protection"], "protected")
        self.assertEqual(data["public"]["source"], "tunnel")
        self.assertTrue(data["public"]["v4"])


class ConnectTests(CliCase):
    def test_default_connection_shows_the_new_address(self):
        out = self.connect()
        self.assertIn("Connected to", out)
        st = self.engine.status()
        self.assertIn(st["public"]["v4"], out)
        self.assertTrue(st["vpn"]["connected"])

    def test_a_profile_can_be_named_by_id_or_by_name(self):
        out = self.ok("vpn", "connect", self.wg[0].id)
        self.assertIn(self.wg[0].name, out)
        out = self.ok("vpn", "connect", self.wg[1].name)
        self.assertIn(self.wg[1].name, out)
        self.assertEqual(self.engine.status()["vpn"]["profile"]["id"], self.wg[1].id)

    def test_unknown_profile_explains_where_to_look(self):
        code, out, err = self.cli("vpn", "connect", "nonesuch")
        self.assertEqual((code, out), (1, ""))
        self.assertIn("no such VPN profile", err)
        self.assertIn("ipshift vpn list", err)

    def test_connecting_pauses_a_running_rotation_and_says_so(self):
        self.ok("rotate", "--interval", "30", "--no-follow", "--no-immediate")
        out = self.connect(self.wg[0])
        self.assertIn("Rotation was running and has been paused", out)
        self.assertFalse(self.engine.status()["rotation"]["running"])

    def test_keep_rotation_leaves_it_running(self):
        self.ok("rotate", "--interval", "30", "--no-follow", "--no-immediate")
        self.ok("vpn", "connect", self.wg[0].id, "--keep-rotation")
        self.assertTrue(self.engine.status()["rotation"]["running"])

    def test_json(self):
        data = self.js("vpn", "connect", self.wg[0].id)
        self.assertEqual(data["profile_id"], self.wg[0].id)
        self.assertTrue(data["exit_ip"])

    def test_disconnect_is_the_same_as_stop(self):
        self.connect()
        out = self.ok("vpn", "disconnect")
        self.assertIn("normal networking is back", out)
        self.assertFalse(self.engine.status()["vpn"]["connected"])
        self.connect()
        self.ok("vpn", "disconnect", "--keep-blocking")
        self.assertEqual(self.engine.status()["protection"]["level"], "blocked")

    def test_cancel_when_nothing_is_running_is_harmless(self):
        self.assertIn("cancel", self.ok("vpn", "cancel"))


class RotateTests(CliCase):
    def test_start_with_the_one_second_minimum(self):
        out = self.ok("rotate", "--interval", "1", "--no-follow")
        self.assertIn("Rotation started: a new address every 1 s", out)
        self.assertIn("new public IP is verified", out)
        rot = self.engine.status()["rotation"]
        self.assertTrue(rot["running"])
        self.assertEqual(rot["interval"], 1.0)
        self.assertIn("running: every 1 s", self.ok("status"))

    def test_below_the_minimum_nothing_starts(self):
        code, out, err = self.cli("rotate", "--interval", "0.5", "--no-follow")
        self.assertEqual(code, 2)
        self.assertIn("shortest interval is 1 second", err)
        self.assertFalse(self.engine.status()["rotation"]["running"])

    def test_the_interval_is_per_run_and_not_saved(self):
        before = self.engine.cfg.rotation.interval
        self.ok("rotate", "--interval", "7", "--no-follow")
        self.ok("rotate", "--stop")
        self.assertFalse((self.tmp / "etc" / "config.json").exists())
        self.assertEqual(self.engine.cfg.rotation.interval, 7.0)         # the daemon keeps it in memory only
        self.assertNotEqual(before, 7.0)

    def test_stop_keeps_the_vpn_up(self):
        self.ok("rotate", "--interval", "30", "--no-follow")
        self.assertIn("Rotation stopped", self.ok("rotate", "--stop"))
        st = self.engine.status()
        self.assertFalse(st["rotation"]["running"])
        self.assertTrue(st["vpn"]["connected"])

    def test_now_changes_the_address_once(self):
        self.connect(self.wg[0])
        first = self.engine.status()["public"]["v4"]
        out = self.ok("rotate", "--now")
        self.assertIn("Connected to", out)
        self.assertNotEqual(self.engine.status()["public"]["v4"], first)
        self.assertFalse(self.engine.status()["rotation"]["running"])

    def test_openvpn_profiles_get_an_honest_note_at_short_intervals(self):
        out = self.ok("rotate", "--interval", "2", "--no-follow")
        self.assertIn("OpenVPN needs several seconds", out)
        self.assertIn("WireGuard profiles can switch in about a second", out)
        self.ok("rotate", "--stop")
        self.assertNotIn("OpenVPN needs", self.ok("rotate", "--interval", "30", "--no-follow"))

    def test_the_note_is_left_out_when_only_wireguard_rotates(self):
        for p in self.ovpn:
            self.ok("vpn", "disable", p.id)
        self.assertNotIn("OpenVPN needs", self.ok("rotate", "--interval", "2", "--no-follow"))

    def test_json_output_is_one_document(self):
        data = self.js("rotate", "--interval", "30", "--no-follow")
        self.assertTrue(data["running"])
        self.assertEqual(data["profiles_in_rotation"], 8)

    def test_a_single_profile_cannot_change_the_address_and_says_so(self):
        for p in self.engine.store.list()[1:]:
            self.ok("vpn", "disable", p.id)
        out = self.ok("rotate", "--interval", "30", "--no-follow")
        self.assertIn("only one usable profile", out)

    def test_no_profiles_means_a_clear_error(self):
        for p in self.engine.store.list():
            self.ok("vpn", "remove", p.id, "--yes")
        code, _, err = self.cli("rotate", "--no-follow")
        self.assertEqual(code, 1)
        self.assertIn("no usable VPN profile", err)
        self.assertIn("ipshift vpn import", err)


class StopTests(CliCase):
    def test_stop_gives_the_normal_network_back(self):
        self.connect()
        out = self.ok("stop")
        self.assertIn("normal networking is back", out)
        st = self.engine.status()
        self.assertEqual(st["protection"]["level"], "unprotected")
        self.assertFalse(st["rotation"]["running"])

    def test_stop_ends_the_rotation_too(self):
        self.ok("rotate", "--interval", "30", "--no-follow")
        self.ok("stop")
        self.assertFalse(self.engine.status()["rotation"]["running"])

    def test_keep_blocking_stays_fail_closed(self):
        self.connect()
        out = self.ok("stop", "--keep-blocking")
        self.assertIn("keeps blocking", out)
        self.assertEqual(self.engine.status()["protection"]["level"], "blocked")
        self.assertIn("BLOCKED", self.ok("status"))

    def test_rotation_only_keeps_the_connection(self):
        self.ok("rotate", "--interval", "30", "--no-follow")
        out = self.ok("stop", "--rotation-only")
        self.assertIn("Rotation stopped", out)
        self.assertTrue(self.engine.status()["vpn"]["connected"])

    def test_stop_when_nothing_runs_is_fine(self):
        self.assertIn("Stopped", self.ok("stop"))

    def test_json(self):
        self.connect()
        self.assertEqual(self.js("stop"), {"stopped": "all", "released": True})


class PrivacyCheckTests(CliCase):
    def test_without_protection_the_exit_code_says_so(self):
        code, out, _ = self.cli("privacy-check")
        self.assertEqual(code, 4)
        self.assertIn("NOT PROTECTED", out)
        self.assertIn("What this check cannot see", out)

    def test_protected_with_warnings_passes_unless_strict(self):
        self.connect()
        code, out, _ = self.cli("privacy-check")
        self.assertEqual(code, 0, out)
        self.assertIn("Score", out)
        self.assertIn("SIMULATION", out)
        code, _, _ = self.cli("privacy-check", "--strict")
        self.assertEqual(code, 4)

    def test_blocked_by_design_is_not_a_failure(self):
        self.ok("killswitch", "on")
        code, out, _ = self.cli("privacy-check")
        self.assertEqual(code, 0, out)
        self.assertIn("OFFLINE BY DESIGN", out)
        self.assertEqual(self.cli("check", "--strict")[0], 4)

    def test_json_report_carries_the_limits(self):
        self.connect()
        rep = self.js("privacy-check")
        self.assertEqual(rep["mode"], "full")
        self.assertTrue(rep["not_covered"])
        self.assertIn(rep["verdict"], ("protected", "protected-with-warnings"))
        self.assertTrue(rep["findings"])

    def test_quick_and_only(self):
        self.connect()
        self.assertEqual(self.js("privacy-check", "--quick")["mode"], "quick")
        ids = [f["id"] for f in self.js("privacy-check")["findings"]]
        picked = self.js("privacy-check", "--only", f"{ids[0]},{ids[1]}")
        self.assertEqual([f["id"] for f in picked["findings"]], ids[:2])
        picked = self.js("privacy-check", "--only", ids[0], "--only", ids[2])
        self.assertEqual([f["id"] for f in picked["findings"]], [ids[0], ids[2]])

    def test_an_unknown_check_is_an_error_not_a_pass(self):
        self.connect()
        code, out, err = self.cli("privacy-check", "--only", "nonesuch")
        self.assertEqual(code, 1)
        self.assertEqual(out, "")
        self.assertIn("nonesuch", err)

    def test_the_result_shows_up_in_status_afterwards(self):
        self.connect()
        self.ok("privacy-check")
        self.assertIn("grade", self.ok("status"))


class KillSwitchTests(CliCase):
    def test_status_on_off(self):
        self.assertIn("not armed", self.ok("killswitch"))
        self.assertIn("armed", self.ok("killswitch", "on"))
        self.assertIn("armed", self.ok("killswitch", "status"))
        self.assertIn("released", self.ok("killswitch", "off"))
        self.assertIn("not armed", self.ok("killswitch", "status"))

    def test_lockdown_blocks_everything_and_says_how_to_leave(self):
        out = self.ok("killswitch", "lockdown")
        self.assertIn("LOCKDOWN", out)
        self.assertIn("ipshift stop", out)
        self.assertIn("LOCKDOWN", self.ok("killswitch", "status"))
        self.ok("stop")
        self.assertIn("not armed", self.ok("killswitch", "status"))

    def test_releasing_asks_a_person_but_not_a_script(self):
        self.ok("killswitch", "on")
        code, _, err = self.tty("killswitch", "off", stdin="n\n")
        self.assertEqual(code, 1)
        self.assertIn("left as it was", err)
        self.assertTrue(self.engine.ks.is_armed())
        code, _, _ = self.tty("killswitch", "off", stdin="y\n")
        self.assertEqual(code, 0)
        self.assertFalse(self.engine.ks.is_armed())
        self.ok("killswitch", "on")
        self.assertEqual(self.cli("killswitch", "off")[0], 0)           # no terminal: a script means it
        self.ok("killswitch", "on")
        self.assertEqual(self.cli("killswitch", "off", "-y")[0], 0)


class ProfileTests(CliCase):
    def test_list(self):
        out = self.ok("vpn", "list")
        for p in self.engine.store.list():
            self.assertIn(p.id, out)
        self.assertIn("Free VPNs can log", out)
        self.assertEqual(len(self.js("vpn", "list")["profiles"]), 8)
        self.assertEqual(self.ok("vpn", "ls"), out)

    def test_import_a_wireguard_file(self):
        path = self.write_wg("my-server-nl")
        out = self.ok("vpn", "import", str(path), "--tier", "self-hosted", "--provider", "mine")
        self.assertIn("Imported my-server-nl (wireguard, self-hosted, NL)", out)
        prof = next(p for p in self.engine.store.list() if p.name == "my-server-nl")
        self.assertEqual((prof.tier, prof.provider, prof.country), ("self-hosted", "mine", "NL"))
        self.assertNotIn("Free VPNs", out)

    def test_importing_twice_is_refused_unless_replacing(self):
        path = self.write_wg()
        self.ok("vpn", "import", str(path))
        code, out, _ = self.cli("vpn", "import", str(path))
        self.assertEqual(code, 1)
        self.assertIn("already imported", out)
        self.assertEqual(self.cli("vpn", "import", str(path), "--replace")[0], 0)

    def test_name_override_and_country(self):
        path = self.write_wg("anything")
        self.ok("vpn", "import", str(path), "--name", "Home box", "--country", "se", "--notes", "my vps")
        prof = next(p for p in self.engine.store.list() if p.name == "Home box")
        self.assertEqual((prof.country, prof.notes), ("SE", "my vps"))

    def test_a_folder_imports_every_config_and_reports_the_rest(self):
        self.write_wg("home-nl")
        self.write_ovpn("free-us-1")
        self.write_ovpn("free-de-2", "203.0.113.62")
        (self.tmp / "vpn" / "broken.conf").write_text("this is not a vpn\n")
        (self.tmp / "vpn" / "notes.txt").write_text("ignored\n")
        code, out, _ = self.cli("vpn", "import", str(self.tmp / "vpn"), "--tier", "free")
        self.assertEqual(code, 0)
        self.assertIn("Imported 3 of 4 profile(s). 1 failed.", out)
        self.assertIn("broken.conf", out)
        self.assertNotIn("notes.txt", out)
        self.assertIn("Free VPNs can log", out)
        self.assertIn("2 profile(s) still need a login", out)
        names = {p.name for p in self.engine.store.list()}
        self.assertTrue({"home-nl", "free-us-1", "free-de-2"} <= names)

    def test_when_nothing_imports_the_exit_code_says_so(self):
        bad = self.tmp / "bad.conf"
        bad.write_text("nope\n")
        self.assertEqual(self.cli("vpn", "import", str(bad))[0], 1)

    def test_bad_paths_are_usage_errors(self):
        code, _, err = self.cli("vpn", "import", str(self.tmp / "missing.conf"))
        self.assertEqual(code, 2)
        self.assertIn("no such file or folder", err)
        empty = self.tmp / "empty"
        empty.mkdir()
        code, _, err = self.cli("vpn", "import", str(empty))
        self.assertEqual(code, 2)
        self.assertIn("no .ovpn or .conf files", err)

    def test_one_name_for_many_files_is_refused(self):
        self.write_wg("a")
        self.write_wg("b", "203.0.113.51")
        code, _, err = self.cli("vpn", "import", str(self.tmp / "vpn"), "--name", "x")
        self.assertEqual(code, 2)
        self.assertIn("--name works with a single file", err)

    def test_tier_is_asked_for_on_a_terminal_and_defaults_to_unknown_in_a_script(self):
        path = self.write_wg("ask-me")
        code, out, err = self.tty("vpn", "import", str(path), stdin="2\n")
        self.assertEqual(code, 0, err)
        self.assertIn("Where does this VPN server come from?", err)
        self.assertEqual(next(p for p in self.engine.store.list() if p.name == "ask-me").tier, "free")
        self.assertIn("Free VPNs can log", out)
        self.write_wg("silent", "203.0.113.52")
        self.ok("vpn", "import", str(self.tmp / "vpn" / "silent.conf"))
        self.assertEqual(next(p for p in self.engine.store.list() if p.name == "silent").tier, "unknown")

    def test_login_given_at_import_time(self):
        path = self.write_ovpn("provider-1")
        self.ok("vpn", "import", str(path), "--tier", "paid", "--username", "alice", "--password-stdin", stdin="pw\n")
        prof = next(p for p in self.engine.store.list() if p.name == "provider-1")
        self.assertTrue(prof.has_auth)
        self.assertTrue(prof.usable)

    def test_auth_from_stdin_and_from_a_terminal(self):
        self.ok("vpn", "import", str(self.write_ovpn("needs-login")), "--tier", "paid")
        prof = next(p for p in self.engine.store.list() if p.name == "needs-login")
        self.assertFalse(prof.has_auth)
        self.ok("vpn", "auth", prof.id, "--username", "alice", "--password-stdin", stdin="s3cret\n")
        self.assertTrue(self.engine.store.get(prof.id).has_auth)
        out = self.tty("vpn", "auth", prof.id, stdin="bob\n")
        self.assertEqual(out[0], 0)
        self.assertIn("Saved the login", out[1])

    def test_auth_without_a_terminal_or_stdin_is_a_clear_usage_error(self):
        code, _, err = self.cli("vpn", "auth", self.ovpn[0].id)
        self.assertEqual(code, 2)
        self.assertIn("--username", err)
        code, _, err = self.cli("vpn", "auth", self.ovpn[0].id, "--username", "a")
        self.assertEqual(code, 2)
        self.assertIn("--password-stdin", err)

    def test_set_and_nothing_to_set(self):
        out = self.ok("vpn", "set", self.ovpn[0].id, "--tier", "paid", "--notes", "bought")
        self.assertIn("tier=paid", out)
        self.assertEqual(self.engine.store.get(self.ovpn[0].id).tier, "paid")
        code, _, err = self.cli("vpn", "set", self.ovpn[0].id)
        self.assertEqual(code, 2)
        self.assertIn("nothing to change", err)

    def test_disable_and_enable_change_who_takes_part_in_rotation(self):
        pid = self.wg[0].id
        self.assertIn("disabled", self.ok("vpn", "disable", pid))
        self.assertNotIn(pid, self.engine.profiles()["in_rotation"])
        self.assertIn("disabled", [l for l in self.ok("vpn", "list").splitlines() if pid in l][0])
        self.assertIn("enabled", self.ok("vpn", "enable", pid))
        self.assertIn(pid, self.engine.profiles()["in_rotation"])

    def test_reset_clears_benched_profiles(self):
        self.engine.store.update(self.wg[0].id, enabled=True)
        for _ in range(3):
            self.engine.store.record_result(self.wg[0].id, False, None, None, "boom")
        self.assertTrue(self.engine.store.get(self.wg[0].id).quarantined)
        self.assertIn("benched", self.ok("vpn", "list"))
        self.assertIn("1 profile(s) are available again", self.ok("vpn", "reset", self.wg[0].id))
        self.assertFalse(self.engine.store.get(self.wg[0].id).quarantined)

    def test_remove_asks_first(self):
        pid = self.wg[0].id
        code, _, err = self.cli("vpn", "remove", pid)
        self.assertEqual(code, 2)
        self.assertIn("--yes", err)
        code, _, err = self.tty("vpn", "remove", pid, stdin="n\n")
        self.assertEqual(code, 1)
        self.assertIn("nothing removed", err)
        self.assertEqual(self.tty("vpn", "remove", pid, stdin="y\n")[0], 0)
        self.assertNotIn(pid, [p.id for p in self.engine.store.list()])
        code, _, err = self.cli("vpn", "remove", self.wg[1].id, "-y")
        self.assertEqual(code, 0)

    def test_the_active_profile_cannot_be_removed(self):
        self.connect(self.wg[0])
        code, _, err = self.cli("vpn", "remove", self.wg[0].id, "-y")
        self.assertEqual(code, 1)
        self.assertIn("active connection", err)


class ConfigTests(CliCase):
    def test_show_get_set_reload(self):
        out = self.ok("config")
        self.assertIn("[rotation]", out)
        self.assertIn("[killswitch]", out)
        self.assertNotIn("[vpn]\n", self.ok("config", "show", "rotation"))
        self.assertEqual(self.ok("config", "get", "rotation.strategy").strip(), "diverse")
        out = self.ok("config", "set", "rotation.interval", "5")
        self.assertIn("rotation.interval: 30.0 -> 5.0", out.replace("→", "->"))
        self.assertEqual(self.engine.cfg.rotation.interval, 5.0)
        self.assertEqual(self.ok("config", "get", "rotation.interval").strip(), "5.0")
        self.assertIn("Settings reloaded", self.ok("config", "reload"))

    def test_booleans_and_lists_are_understood(self):
        self.ok("config", "set", "killswitch.allow_lan", "yes")
        self.assertTrue(self.engine.cfg.killswitch.allow_lan)
        self.ok("config", "set", "rotation.tiers", "paid,self-hosted")
        self.assertEqual(self.engine.cfg.rotation.tiers, ["paid", "self-hosted"])

    def test_settings_that_decide_what_root_runs_cannot_be_changed_here(self):
        code, _, err = self.cli("config", "set", "vpn.openvpn_bin", "/bin/true")
        self.assertEqual(code, 1)
        self.assertIn("can only be changed by editing", err)
        self.assertNotEqual(self.engine.cfg.vpn.openvpn_bin, "/bin/true")

    def test_invalid_values_and_names_are_errors(self):
        code, _, err = self.cli("config", "set", "rotation.interval", "0.2")
        self.assertEqual(code, 1)
        self.assertIn("between 1", err)
        self.assertEqual(self.engine.cfg.rotation.interval, 30.0)
        code, _, err = self.cli("config", "set", "nonsense.key", "1")
        self.assertEqual(code, 1)
        self.assertIn("unknown section", err)
        self.assertEqual(self.cli("config", "set", "rotation.interval", "fast")[0], 1)

    def test_missing_arguments_are_usage_errors(self):
        self.assertEqual(self.cli("config", "get")[0], 2)
        self.assertEqual(self.cli("config", "set", "rotation.interval")[0], 2)

    def test_json(self):
        self.assertIn("rotation", self.js("config")["config"])
        self.assertEqual(self.js("config", "get", "rotation.interval")["value"], 30.0)


class HistoryTests(CliCase):
    def rotate_twice(self):
        self.connect(self.wg[0])
        self.ok("rotate", "--now")
        self.ok("rotate", "--now")

    def test_empty_then_filled(self):
        self.assertIn("No rotations recorded yet", self.ok("history"))
        self.rotate_twice()
        out = self.ok("history")
        self.assertIn("TIME", out)
        self.assertIn("success", out)
        self.assertRegex(out, r"3 recorded: 3 changed the address")

    def test_limit_and_json(self):
        self.rotate_twice()
        data = self.js("history", "-n", "2")
        self.assertEqual(len(data["rotations"]), 2)
        self.assertEqual(data["stats"]["total"], 3)

    def test_export_to_the_terminal_and_to_a_private_file(self):
        self.rotate_twice()
        out = self.ok("history", "--export", "-")
        rows = list(csv.reader(io.StringIO(out)))
        self.assertEqual(rows[0][:4], ["id", "ts", "profile_id", "profile_name"])
        self.assertEqual(len(rows), 4)
        dest = self.tmp / "history.csv"
        text = self.ok("history", "--export", str(dest))
        self.assertIn("Wrote 3 row(s)", text)
        self.assertEqual(stat.S_IMODE(dest.stat().st_mode), 0o600)
        with dest.open() as f:
            self.assertEqual(len(list(csv.reader(f))), 4)

    def test_export_never_overwrites(self):
        dest = self.tmp / "keep.csv"
        dest.write_text("precious")
        code, _, err = self.cli("history", "--export", str(dest))
        self.assertEqual(code, 2)
        self.assertIn("already exists", err)
        self.assertEqual(dest.read_text(), "precious")
        code, _, err = self.cli("history", "--export", str(self.tmp / "no" / "such" / "dir.csv"))
        self.assertEqual(code, 2)

    def test_clear_needs_a_yes(self):
        self.rotate_twice()
        code, _, err = self.cli("history", "--clear")
        self.assertEqual(code, 2)
        self.assertIn("--yes", err)
        self.assertEqual(self.engine.history.stats()["total"], 3)
        code, _, err = self.tty("history", "--clear", stdin="n\n")
        self.assertEqual(code, 1)
        self.assertEqual(self.engine.history.stats()["total"], 3)
        self.assertEqual(self.cli("history", "--clear", "--yes")[0], 0)
        self.assertEqual(self.engine.history.stats()["total"], 0)


class HardenRestoreTests(CliCase):
    def test_harden_status_and_mac_policy(self):
        out = self.ok("harden")
        self.assertIn("DNS", out)
        self.assertIn("IPv6", out)
        self.assertIn("MAC address", out)
        self.assertIn("NetworkManager", self.ok("harden", "mac", "enable"))
        self.assertIn("random MAC", self.ok("harden"))
        self.assertIn("switched off", self.ok("harden", "mac", "disable"))
        self.assertIn("was not on", self.ok("harden", "mac", "disable"))

    def test_randomize_needs_an_interface(self):
        code, _, err = self.cli("harden", "mac", "randomize")
        self.assertEqual(code, 2)
        self.assertIn("interface", err)
        out = self.ok("harden", "mac", "randomize", "wlan0")
        self.assertRegex(out, r"wlan0 now uses [0-9a-f]{2}(:[0-9a-f]{2}){5}")
        self.assertIn("Original MAC address put back", self.ok("harden", "mac", "restore"))

    def test_restore_undoes_everything(self):
        self.connect()
        out = self.ok("restore")
        for needle in ("Firewall", "kill switch rules removed", "DNS", "IPv6", "MAC address", "Leftovers"):
            self.assertIn(needle, out)
        st = self.engine.status()
        self.assertFalse(st["vpn"]["connected"])
        self.assertFalse(st["killswitch"]["armed"])
        self.assertNotIn("MAC address", self.ok("restore", "--keep-mac"))

    def test_restore_json(self):
        rep = self.js("restore")
        self.assertEqual(rep["killswitch"], "removed")


class DoctorEventsVersionTests(CliCase):
    def test_doctor_through_the_daemon(self):
        out = self.ok("doctor")
        self.assertIn("IPShift doctor", out)
        self.assertIn("Simulation mode", out)
        self.assertIn("VPN profiles", out)
        self.assertIn("Ready to use.", out)
        rep = self.js("doctor")
        self.assertTrue(rep["ready"])
        self.assertTrue(rep["simulated"])

    def test_doctor_exit_code_follows_readiness(self):
        for p in self.engine.store.list():
            self.engine.store.remove(p.id)
        code, out, _ = self.cli("doctor")
        self.assertEqual(code, 0)                               # no profiles is a warning, not a failure
        self.assertIn("no VPN profile has been imported yet", out)

    def test_events(self):
        self.connect()
        self.ok("rotate", "--now")
        out = self.ok("events", "--level", "debug", "-n", "50")
        self.assertIn("Connected to", out)
        recent = self.js("events", "-n", "5")
        self.assertLessEqual(len(recent), 5)
        self.assertTrue(all("kind" in e for e in recent))

    def test_alerts_only_with_a_higher_level(self):
        self.ok("killswitch", "on")
        self.ok("killswitch", "off")
        warnings = self.js("events", "--level", "warning")
        self.assertTrue(warnings)
        self.assertTrue(all(e["level"] in ("warning", "error", "critical") for e in warnings))

    def test_version_shows_both_sides(self):
        out = self.ok("version")
        self.assertIn("ipshift 1.0.0", out)
        self.assertIn("ipshiftd 1.0.0", out)
        data = self.js("version")
        self.assertEqual(data, {"ipshift": "1.0.0", "daemon": "1.0.0"})


if __name__ == "__main__":  # pragma: no cover
    unittest.main()
