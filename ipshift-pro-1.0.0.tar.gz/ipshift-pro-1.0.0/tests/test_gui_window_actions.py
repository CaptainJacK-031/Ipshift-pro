"""Every button of the main window: the question it asks first, and the exact command it sends."""
from __future__ import annotations

import os
import stat
import tempfile
import unittest
from unittest import mock

import helpers  # noqa: F401
import guifix
import qtcase
import wincase
from ipshift.gui import tables, views
from ipshift.gui.link import Result


def setUpModule():
    qtcase.install()
    global window, QMessageBox
    from PySide6.QtWidgets import QMessageBox
    from ipshift.gui import window


def tearDownModule():
    qtcase.uninstall()


def connecting() -> dict:
    st = guifix.idle("blocked")
    st["vpn"] = dict(st["vpn"], state="connecting", busy="Connecting")
    return st


class DashboardButtonTests(wincase.WindowCase):
    def test_start_sends_the_interval_in_the_box_and_nothing_about_it_before(self):
        self.connect_daemon(guifix.idle("unprotected"), page="Dashboard")
        d = self.win.dashboard
        d.interval.setValue(2.0)
        d.start_button.click()
        self.assertEqual(self.link.last("rotate_start"), {"interval": 2.0})
        self.pump(2)
        self.assertNotIn("set_interval", self.link.names)             # not running: the box is kept for Start

    def test_an_interval_below_the_floor_is_raised_before_it_is_sent(self):
        self.connect_daemon(guifix.idle("unprotected"))
        self.win.dashboard.start_requested.emit(0.2)
        self.assertEqual(self.link.last("rotate_start"), {"interval": 1.0})

    def test_a_running_rotation_gets_the_new_interval_once_the_typing_has_stopped(self):
        self.connect_daemon(guifix.status())
        self.win.dashboard.interval.setValue(3.0)
        self.pump(0.3)
        self.assertEqual(self.link.names, [])
        self.pump(0.3)
        self.assertEqual(self.link.calls, [("set_interval", {"value": 3.0})])

    def test_start_does_nothing_while_the_rotation_runs(self):
        self.connect_daemon(guifix.status())
        self.win.dashboard.start_button.click()
        self.assertEqual(self.link.names, [])

    def test_rotate_now(self):
        self.connect_daemon(guifix.status())
        self.win.dashboard.now_button.click()
        self.assertEqual(self.link.calls, [("rotate_now", {})])

    def test_cancel_abandons_a_connection_attempt(self):
        self.connect_daemon(connecting())
        self.win.dashboard.cancel_button.click()
        self.assertEqual(self.link.calls, [("cancel", {})])

    def test_the_privacy_check_buttons(self):
        self.connect_daemon(guifix.status())
        self.win.dashboard.check_button.click()
        self.win.select_page("Privacy")
        self.link.clear()
        self.win.privacy.run_quick.click()
        self.win.privacy.run_full.click()
        self.assertEqual(self.link.calls, [("privacy_check", {"mode": "quick"}), ("privacy_check", {"mode": "full"})])

    def test_the_dashboard_check_button_runs_the_full_test(self):
        self.connect_daemon(guifix.status())
        self.win.dashboard.check_button.click()
        self.assertEqual(self.link.calls, [("privacy_check", {"mode": "full"})])

    def test_the_real_address_is_looked_up_only_when_the_button_is_pressed(self):
        self.connect_daemon(guifix.idle("unprotected"))
        self.assertEqual(self.link.names, [])
        self.win.dashboard.lookup_button.click()
        self.assertEqual(self.link.calls, [("ip", {"direct": True})])


class StopTests(wincase.WindowCase):
    def choose(self, key):
        def script(dialog):
            dialog.radios[key].setChecked(True)
            self.press(dialog, "ok")
        self.script(script)

    def test_each_way_to_stop_sends_its_own_arguments(self):
        for key, expected in (("rotation", {"keep_vpn": True}), ("block", {"keep_blocking": True}), ("release", {})):
            self.link.clear()
            self.connect_daemon(guifix.status())
            self.choose(key)
            self.win.dashboard.stop_button.click()
            self.assertEqual(self.link.calls, [("stop", expected)], key)

    def test_the_first_way_is_the_one_that_never_exposes_the_real_address(self):
        self.connect_daemon(guifix.status())
        self.script(lambda dialog: self.press(dialog, "ok"))          # the user just presses Stop
        self.win.dashboard.stop_button.click()
        self.assertEqual(self.link.calls, [("stop", {"keep_vpn": True})])

    def test_cancelling_the_question_sends_nothing(self):
        self.connect_daemon(guifix.status())
        self.script(lambda dialog: self.press(dialog, "cancel"))
        self.win.dashboard.stop_button.click()
        self.assertEqual(self.link.calls, [])

    def test_an_unanswered_question_is_a_cancel(self):
        self.connect_daemon(guifix.status())
        self.win.dashboard.stop_button.click()
        self.assertEqual((self.link.calls, self.unscripted()), ([], ["StopDialog"]))

    def test_when_only_one_way_makes_sense_the_user_confirms_it(self):
        self.connect_daemon(guifix.idle("blocked"))
        shown = self.confirms(True)
        self.win.dashboard.stop_button.click()
        self.assertEqual(self.link.calls, [("stop", {})])
        box = shown[0]
        option = views.STOP_OPTIONS[2]
        self.assertEqual((box.windowTitle(), box.text_value, box.informative),
                         ("Stop", option.label + "?", option.detail))
        self.assertEqual([b.text() for b, _ in box._buttons], ["Stop", "Cancel"])
        self.assertIs(box.icon_value, QMessageBox.Icon.Warning)         # it exposes the real address

    def test_declining_that_confirmation_sends_nothing(self):
        self.connect_daemon(guifix.idle("blocked"))
        self.confirms(False)
        self.win.dashboard.stop_button.click()
        self.assertEqual(self.link.calls, [])

    def test_with_nothing_to_stop_the_window_says_so_and_asks_nothing(self):
        self.win.on_stop()                                           # no status at all
        self.assertEqual(self.win.toast.text.text(), "There is nothing to stop.")
        self.assertEqual((self.link.calls, self.unscripted()), ([], []))


class KillSwitchTests(wincase.WindowCase):
    def test_arming_needs_no_question_because_it_only_adds_protection(self):
        self.connect_daemon(guifix.idle("unprotected"))
        self.win.dashboard.arm_button.click()
        self.assertEqual(self.link.calls, [("killswitch_on", {})])
        self.assertEqual(self.unscripted(), [])

    def test_releasing_asks_first(self):
        self.connect_daemon(guifix.status())
        shown = self.confirms(True)
        self.win.dashboard.release_button.click()
        self.assertEqual(self.link.calls, [("killswitch_off", {})])
        box = shown[0]
        self.assertEqual((box.windowTitle(), box.text_value), ("Release the kill switch?",
                                                              "Traffic will be able to leave this computer outside the VPN."))
        self.assertEqual([b.text() for b, _ in box._buttons], ["Release", "Cancel"])
        self.assertIs(box.icon_value, QMessageBox.Icon.Warning)

    def test_declining_the_release_changes_nothing(self):
        self.connect_daemon(guifix.status())
        self.confirms(False)
        self.win.dashboard.release_button.click()
        self.assertEqual(self.link.calls, [])

    def test_lockdown_asks_first_and_is_sent_when_confirmed(self):
        self.connect_daemon(guifix.status())
        shown = self.confirms(True)
        self.win.dashboard.lockdown_button.click()
        self.assertEqual(self.link.calls, [("lockdown", {})])
        self.assertEqual(shown[0].windowTitle(), "Lock everything down?")
        self.assertEqual([b.text() for b, _ in shown[0]._buttons], ["Lock down", "Cancel"])

    def test_declining_the_lockdown_changes_nothing(self):
        self.connect_daemon(guifix.status())
        self.confirms(False)
        self.win.dashboard.lockdown_button.click()
        self.assertEqual(self.link.calls, [])


class ProfileButtonTests(wincase.WindowCase):
    def setUp(self):
        super().setUp()
        self.data = guifix.profiles()

    def open(self, data=None, row=0):
        self.connect_daemon(page="Profiles", profiles=data or self.data)
        self.win.profiles.view.selectRow(row)

    def test_connect(self):
        self.open()
        self.win.profiles.connect_button.click()
        self.assertEqual(self.link.calls, [("connect", {"profile": "wg-nl"})])

    def test_disabling_and_enabling(self):
        self.open()
        self.win.profiles.toggle_button.click()
        self.assertEqual(self.link.calls, [("profile_update", {"ref": "wg-nl", "enabled": False})])
        self.link.clear()
        self.data["profiles"][0]["enabled"] = False
        self.open(self.data)
        self.win.profiles.toggle_button.click()
        self.assertEqual(self.link.calls, [("profile_update", {"ref": "wg-nl", "enabled": True})])

    def test_use_again_for_a_benched_profile(self):
        self.data["profiles"][0].update(quarantined=True, quarantined_until=self.NOW + 600)
        self.open()
        self.win.profiles.reuse_button.click()
        self.assertEqual(self.link.calls, [("profile_clear_quarantine", {"ref": "wg-nl"})])

    def test_the_login_dialog_names_the_profile_and_sends_what_was_typed(self):
        self.open(row=1)
        seen = []

        def fill(dialog):
            seen.extend(self.texts(dialog))
            dialog.username.setText("alice")
            dialog.password.setText("s3cret")
            self.press(dialog, "ok")

        self.script(fill)
        self.win.profiles.login_button.click()
        self.assertIn("Username and password for OVPN US", seen)
        self.assertEqual(self.link.calls, [("profile_auth", {"ref": "ovpn-us", "username": "alice",
                                                             "password": "s3cret"})])

    def test_an_incomplete_or_cancelled_login_sends_nothing(self):
        self.open(row=1)
        self.script(lambda dialog: (dialog.username.setText("alice"), self.press(dialog, "ok")))
        self.win.profiles.login_button.click()
        self.script(lambda dialog: self.press(dialog, "cancel"))
        self.win.profiles.login_button.click()
        self.assertEqual(self.link.calls, [])

    def test_removing_asks_by_name_and_sends_the_id(self):
        self.open()
        shown = self.confirms(True)
        self.win.profiles.remove_button.click()
        self.assertEqual(self.link.calls, [("profile_remove", {"ref": "wg-nl"})])
        self.assertEqual(shown[0].text_value, "Remove WG NL?")
        self.assertEqual([b.text() for b, _ in shown[0]._buttons], ["Remove", "Cancel"])

    def test_declining_the_removal_sends_nothing(self):
        self.open()
        self.confirms(False)
        self.win.profiles.remove_button.click()
        self.assertEqual(self.link.calls, [])

    def test_import_hands_the_files_and_the_choices_to_the_importer(self):
        self.open()

        def pick(dialog):
            dialog.add_paths(["/a/one.ovpn", "/a/two.conf"])
            dialog.tier.setCurrentIndex(dialog.tier.findData("free"))
            dialog.username.setText("alice")
            dialog.password.setText("pw")
            dialog.replace.setChecked(True)
            self.press(dialog, "ok")

        self.script(pick)
        self.win.profiles.import_button.click()
        job = self.link.last("profile_import")["job"]
        with mock.patch.object(tables, "import_files", return_value=[]) as importer:
            job("the client")
        importer.assert_called_once_with("the client", ["/a/one.ovpn", "/a/two.conf"], tier="free", username="alice",
                                         password="pw", replace=True)
        self.assertEqual(self.win.toast.text.text(), "Importing...")

    def test_an_import_without_login_sends_none_for_both(self):
        self.open()
        self.script(lambda dialog: (dialog.add_paths(["/a/one.ovpn"]), self.press(dialog, "ok")))
        self.win.profiles.import_button.click()
        with mock.patch.object(tables, "import_files", return_value=[]) as importer:
            self.link.last("profile_import")["job"]("c")
        importer.assert_called_once_with("c", ["/a/one.ovpn"], tier="unknown", username=None, password=None,
                                         replace=False)

    def test_cancelling_the_import_sends_nothing(self):
        self.open()
        self.script(lambda dialog: self.press(dialog, "cancel"))
        self.win.profiles.import_button.click()
        self.assertEqual(self.link.calls, [])
        self.assertTrue(self.win.toast.isHidden())


class HistoryButtonTests(wincase.WindowCase):
    class Client:
        def __init__(self):
            self.limits = []

        def history_export(self, limit):
            self.limits.append(limit)
            return {"csv": "time,result\n1,success\n", "rows": 1, "truncated": False}

    def setUp(self):
        super().setUp()
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.dir = tmp.name
        self.connect_daemon(page="History", history=guifix.history(3))

    def test_export_writes_the_file_readable_only_by_its_owner(self):
        path = os.path.join(self.dir, "out.csv")
        self.hooks.save_path = path
        self.win.history.export_button.click()
        client = self.Client()
        result = self.link.last("history_export")["job"](client)
        self.assertEqual(client.limits, [100_000])
        self.assertEqual(result, {"path": path, "rows": 1, "truncated": False})
        with open(path) as f:
            self.assertEqual(f.read(), "time,result\n1,success\n")
        self.assertEqual(stat.S_IMODE(os.stat(path).st_mode), 0o600)

    def test_cancelling_the_save_dialog_sends_nothing(self):
        self.hooks.save_path = ""
        self.win.history.export_button.click()
        self.assertEqual(self.link.calls, [])

    def test_an_existing_file_is_replaced_only_after_a_question(self):
        path = os.path.join(self.dir, "old.csv")
        with open(path, "w") as f:
            f.write("old")
        self.hooks.save_path = path
        self.confirms(False)
        self.win.history.export_button.click()
        self.assertEqual(self.link.calls, [])
        self.confirms(True)
        self.win.history.export_button.click()
        self.link.last("history_export")["job"](self.Client())
        with open(path) as f:
            self.assertEqual(f.read(), "time,result\n1,success\n")

    def test_clearing_the_history_asks_first(self):
        shown = self.confirms(True)
        self.win.history.clear_button.click()
        self.assertEqual(self.link.calls, [("history_clear", {})])
        self.assertEqual(shown[0].windowTitle(), "Delete the history?")
        self.assertEqual([b.text() for b, _ in shown[0]._buttons], ["Delete", "Cancel"])
        self.assertIs(shown[0].icon_value, QMessageBox.Icon.Warning)

    def test_declining_keeps_the_history(self):
        self.confirms(False)
        self.win.history.clear_button.click()
        self.assertEqual(self.link.calls, [])


class SettingsButtonTests(wincase.WindowCase):
    def setUp(self):
        super().setUp()
        self.connect_daemon(page="Settings")
        self.load()

    def load(self, over=None):
        self.feed("result_ready", Result("config_get", True, guifix.config_get(over)))
        self.link.clear()

    def test_an_ordinary_change_is_sent_at_once_without_a_question(self):
        self.win.settings.control("killswitch.log_drops").setChecked(True)
        self.assertEqual(self.link.calls, [("config_set", {"key": "killswitch.log_drops", "value": True})])
        self.assertEqual(self.unscripted(), [])

    def test_a_number_is_sent_after_the_typing_stops(self):
        self.win.settings.control("rotation.interval").setValue(2.5)
        self.pump(1.0)
        self.assertEqual(self.link.calls, [("config_set", {"key": "rotation.interval", "value": 2.5})])

    def test_a_list_is_sent_as_a_list(self):
        edit = self.win.settings.control("dns.servers")
        edit.setText("1.1.1.1, 9.9.9.9")
        edit.editingFinished.emit()
        self.assertEqual(self.link.calls, [("config_set", {"key": "dns.servers", "value": ["1.1.1.1", "9.9.9.9"]})])

    def test_the_ticked_tiers_are_sent_as_a_list(self):
        self.win.settings.control("rotation.tiers").boxes["paid"].setChecked(True)
        self.assertEqual(self.link.calls, [("config_set", {"key": "rotation.tiers", "value": ["paid"]})])

    def test_a_choice_is_sent_as_its_value(self):
        self.win.settings.control("vpn.mtu").setCurrentIndex(3)
        self.assertEqual(self.link.calls, [("config_set", {"key": "vpn.mtu", "value": 1420})])

    def test_lowering_protection_asks_first_and_is_sent_when_the_user_agrees(self):
        self.load({"killswitch.enabled": True})
        shown = self.confirms(True)
        self.win.settings.control("killswitch.enabled").setChecked(False)
        self.assertEqual(self.link.calls, [("config_set", {"key": "killswitch.enabled", "value": False})])
        box = shown[0]
        self.assertEqual(box.windowTitle(), "Lower your protection?")
        self.assertEqual(box.text_value, "Kill switch: Without the kill switch your real address is exposed if the VPN drops.")
        self.assertEqual([b.text() for b, _ in box._buttons], ["Change it", "Cancel"])
        self.assertIs(box.icon_value, QMessageBox.Icon.Warning)

    def test_declining_puts_the_control_back_and_the_daemon_never_hears_of_it(self):
        self.load({"killswitch.enabled": True})
        self.confirms(False)
        box = self.win.settings.control("killswitch.enabled")
        box.setChecked(False)
        self.assertTrue(box.isChecked())
        self.assertEqual(self.link.calls, [])

    def test_raising_protection_needs_no_question(self):
        self.load({"killswitch.enabled": False})
        self.win.settings.control("killswitch.enabled").setChecked(True)
        self.assertEqual(self.link.calls, [("config_set", {"key": "killswitch.enabled", "value": True})])
        self.assertEqual(self.unscripted(), [])

    def test_contacting_an_outside_service_is_explained_before_it_is_allowed(self):
        shown = self.confirms(False)
        self.win.settings.control("privacy.baseline").setChecked(True)
        self.assertIn("WITHOUT the VPN", shown[0].text_value)
        self.assertEqual(self.link.calls, [])

    def test_every_setting_that_lowers_protection_has_a_question(self):
        from ipshift.gui.settings_schema import all_settings, needs_confirmation
        risky = [s for s in all_settings() if s.risky_value is not None]
        self.assertGreaterEqual(len(risky), 6)
        for s in risky:
            self.assertTrue(needs_confirmation(s, s.risky_value), s.key)
            self.assertEqual(needs_confirmation(s, not s.risky_value), "", s.key)


if __name__ == "__main__":
    unittest.main()
