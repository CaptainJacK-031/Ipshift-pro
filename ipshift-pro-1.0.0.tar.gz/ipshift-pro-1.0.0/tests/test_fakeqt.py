"""The stand-in for PySide6 must be strict, or the GUI tests prove nothing.  These tests check the stand-in."""
from __future__ import annotations

import threading
import unittest

import helpers  # noqa: F401
import fakeqt
import qtcase


def setUpModule():
    qtcase.install()


def tearDownModule():
    qtcase.uninstall()


class Strictness(qtcase.QtCase):
    def setUp(self):
        super().setUp()
        from PySide6 import QtCore, QtGui, QtWidgets
        self.core, self.gui, self.w = QtCore, QtGui, QtWidgets

    def test_a_misspelt_method_is_an_error(self):
        label = self.w.QLabel("x")
        with self.assertRaises(AttributeError):
            label.setTooltip("typo")                      # the real one is setToolTip

    def test_names_that_do_not_exist_cannot_be_imported(self):
        with self.assertRaises(ImportError):
            from PySide6.QtWidgets import QNoSuchWidget   # noqa: F401
        with self.assertRaises(ImportError):
            from PySide6.QtWidgets import QEvent          # noqa: F401  (it lives in QtCore)

    def test_enums_are_fully_qualified_and_checked(self):
        with self.assertRaises(AttributeError):
            self.core.Qt.AlignTop                         # PySide6 >= 6.5 wants Qt.AlignmentFlag.AlignTop
        label = self.w.QLabel("x")
        with self.assertRaises(TypeError):
            label.setTextFormat("plain")

    def test_wrong_argument_kinds_are_refused_like_pyside_does(self):
        spin = self.w.QSpinBox()
        with self.assertRaises(TypeError):
            spin.setValue(2.5)                            # an int box does not take a float
        button = self.w.QPushButton("x")
        with self.assertRaises(TypeError):
            button.setEnabled(None)
        with self.assertRaises(TypeError):
            button.setEnabled(1)
        with self.assertRaises(TypeError):
            self.w.QLabel("x").setText(5)

    def test_a_layout_only_takes_what_it_should(self):
        lay = self.w.QVBoxLayout()
        with self.assertRaises(TypeError):
            lay.addWidget(self.w.QVBoxLayout())
        with self.assertRaises(TypeError):
            lay.addLayout(self.w.QLabel("x"))
        with self.assertRaises(TypeError):
            lay.addStretch("1")

    def test_a_widget_gets_one_layout(self):
        box = self.w.QWidget()
        box.setLayout(self.w.QVBoxLayout())
        with self.assertRaises(RuntimeError):
            box.setLayout(self.w.QHBoxLayout())


class Signals(qtcase.QtCase):
    def setUp(self):
        super().setUp()
        from PySide6.QtCore import QObject, Qt, Signal

        class Thing(QObject):
            changed = Signal(float)
            named = Signal(str, object)
            ping = Signal()

        self.Thing, self.Qt = Thing, Qt

    def test_emit_checks_the_number_and_kind_of_arguments(self):
        t = self.Thing()
        with self.assertRaises(TypeError):
            t.changed.emit()
        with self.assertRaises(TypeError):
            t.changed.emit("1.0")
        with self.assertRaises(TypeError):
            t.ping.emit(1)
        t.changed.emit(1)                                  # an int is fine for a float signal and arrives as float
        got = []
        t.changed.connect(got.append)
        t.changed.emit(3)
        self.assertEqual(got, [3.0])
        self.assertIsInstance(got[0], float)

    def test_a_slot_gets_as_many_arguments_as_it_accepts(self):
        t = self.Thing()
        seen = []
        t.named.connect(lambda: seen.append("none"))
        t.named.connect(lambda a: seen.append(("one", a)))
        t.named.connect(lambda a, b: seen.append(("two", a, b)))
        t.named.connect(lambda *a: seen.append(("all", a)))
        t.named.emit("x", {"k": 1})
        self.assertEqual(seen, ["none", ("one", "x"), ("two", "x", {"k": 1}), ("all", ("x", {"k": 1}))])

    def test_a_slot_that_wants_more_than_the_signal_sends_is_an_error(self):
        t = self.Thing()
        t.changed.connect(lambda a, b: None)
        with self.assertRaises(TypeError):
            t.changed.emit(1.0)

    def test_blocked_signals_are_not_delivered(self):
        t = self.Thing()
        got = []
        t.ping.connect(lambda: got.append(1))
        t.blockSignals(True)
        t.ping.emit()
        t.blockSignals(False)
        t.ping.emit()
        self.assertEqual(got, [1])

    def test_queued_connections_wait_for_process_events_and_run_in_the_gui_thread(self):
        t = self.Thing()
        where = []

        class Receiver(self.Thing):
            def slot(self):
                where.append(threading.current_thread() is threading.main_thread())

        r = Receiver()
        t.ping.connect(r.slot, self.Qt.ConnectionType.QueuedConnection)
        worker = threading.Thread(target=t.ping.emit)
        worker.start()
        worker.join()
        self.assertEqual(where, [])                         # nothing yet: it is queued
        self.app.processEvents()
        self.assertEqual(where, [True])

    def test_an_auto_connection_from_another_thread_to_a_gui_object_is_queued(self):
        t = self.Thing()
        got = []

        class Receiver(self.Thing):
            def slot(self):
                got.append(1)

        r = Receiver()
        t.ping.connect(r.slot)                              # no explicit type: Qt decides by thread
        threading.Thread(target=t.ping.emit).start()
        for _ in range(100):
            if not fakeqt.state.events.empty():
                break
            threading.Event().wait(0.01)
        self.assertEqual(got, [])
        self.app.processEvents()
        self.assertEqual(got, [1])

    def test_an_auto_connection_to_a_plain_function_runs_in_the_emitting_thread(self):
        """... which is exactly why the window connects with QueuedConnection and to its own methods."""
        t = self.Thing()
        who = []
        t.ping.connect(lambda: who.append(threading.current_thread().name))
        w = threading.Thread(target=t.ping.emit, name="worker")
        w.start()
        w.join()
        self.assertEqual(who, ["worker"])

    def test_a_connection_to_a_deleted_receiver_is_dropped(self):
        t = self.Thing()
        got = []

        class Receiver(self.Thing):
            def slot(self):
                got.append(1)

        r = Receiver()
        t.ping.connect(r.slot, self.Qt.ConnectionType.QueuedConnection)
        t.ping.emit()                                       # queued before the receiver goes: it is delivered first
        r.deleteLater()
        self.app.processEvents()
        self.assertEqual(got, [1])
        t.ping.emit()                                       # queued after it went: dropped
        self.app.processEvents()
        self.assertEqual(got, [1])


class Threads(qtcase.QtCase):
    def test_touching_a_widget_from_another_thread_is_recorded_and_refused(self):
        from PySide6.QtWidgets import QLabel
        label = QLabel("x")
        errors = []

        def work():
            try:
                label.setText("y")
            except AssertionError as e:
                errors.append(str(e))

        t = threading.Thread(target=work)
        t.start()
        t.join()
        self.assertEqual(label.text(), "x")
        self.assertEqual(len(errors), 1)
        self.assertEqual(len(fakeqt.state.violations), 1)
        fakeqt.state.violations.clear()                     # expected here: do not fail the clean-up check

    def test_process_events_from_another_thread_is_refused(self):
        errors = []

        def work():
            try:
                self.app.processEvents()
            except AssertionError as e:
                errors.append(e)

        t = threading.Thread(target=work)
        t.start()
        t.join()
        self.assertEqual(len(errors), 1)


class Lifetime(qtcase.QtCase):
    def test_delete_later_takes_effect_at_the_next_event_loop_pass(self):
        from PySide6.QtWidgets import QLabel, QWidget, QVBoxLayout
        parent = QWidget()
        parent.setLayout(QVBoxLayout())
        child = QLabel("x")
        parent.layout().addWidget(child)
        child.deleteLater()
        child.setText("still alive")                        # as in Qt: not gone yet
        self.app.processEvents()
        with self.assertRaises(RuntimeError):
            child.setText("too late")

    def test_deleting_a_parent_deletes_its_children(self):
        from PySide6.QtWidgets import QLabel, QWidget, QVBoxLayout
        parent = QWidget()
        parent.setLayout(QVBoxLayout())
        child = QLabel("x")
        parent.layout().addWidget(child)
        parent.deleteLater()
        self.app.processEvents()
        with self.assertRaises(RuntimeError):
            child.setText("y")

    def test_a_deleted_timer_never_fires(self):
        from PySide6.QtCore import QTimer
        t = QTimer()
        hits = []
        t.timeout.connect(lambda: hits.append(1))
        t.start(10)
        t.deleteLater()
        self.app.processEvents()
        fakeqt.advance(1.0)
        self.assertEqual(hits, [])


class Timers(qtcase.QtCase):
    def test_single_shot_fires_once_at_its_time(self):
        from PySide6.QtCore import QTimer
        t = QTimer()
        t.setSingleShot(True)
        hits = []
        t.timeout.connect(lambda: hits.append(1))
        t.start(500)
        fakeqt.advance(0.4)
        self.assertEqual(hits, [])
        fakeqt.advance(0.2)
        self.assertEqual(hits, [1])
        fakeqt.advance(5)
        self.assertEqual(hits, [1])
        self.assertFalse(t.isActive())

    def test_a_repeating_timer_keeps_going_until_stopped(self):
        from PySide6.QtCore import QTimer
        t = QTimer()
        hits = []
        t.timeout.connect(lambda: hits.append(1))
        t.setInterval(100)
        t.start()
        for _ in range(3):
            fakeqt.advance(0.15)
        t.stop()
        fakeqt.advance(1)
        self.assertEqual(len(hits), 3)

    def test_restarting_a_timer_postpones_it(self):
        from PySide6.QtCore import QTimer
        t = QTimer()
        t.setSingleShot(True)
        hits = []
        t.timeout.connect(lambda: hits.append(1))
        t.start(500)
        fakeqt.advance(0.4)
        t.start(500)
        fakeqt.advance(0.4)
        self.assertEqual(hits, [])
        fakeqt.advance(0.2)
        self.assertEqual(hits, [1])


class Widgets(qtcase.QtCase):
    def setUp(self):
        super().setUp()
        from PySide6 import QtWidgets
        self.w = QtWidgets

    def test_a_disabled_button_does_nothing_when_clicked(self):
        b = self.w.QPushButton("go")
        hits = []
        b.clicked.connect(lambda: hits.append(1))
        b.setEnabled(False)
        b.click()
        self.assertEqual(hits, [])
        b.setEnabled(True)
        b.click()
        self.assertEqual(hits, [1])

    def test_a_disabled_parent_disables_its_children(self):
        parent, child = self.w.QWidget(), self.w.QPushButton("x")
        parent.setLayout(self.w.QVBoxLayout())
        parent.layout().addWidget(child)
        parent.setEnabled(False)
        self.assertFalse(child.isEnabled())

    def test_spin_boxes_clamp_round_and_announce_changes_once(self):
        s = self.w.QDoubleSpinBox()
        s.setDecimals(1)
        s.setRange(1.0, 100.0)
        seen = []
        s.valueChanged.connect(seen.append)
        s.setValue(0.2)                                     # clamped to 1.0, which it already is: no signal
        self.assertEqual(s.value(), 1.0)
        s.setValue(1.0)
        s.setValue(2.26)                                    # rounded to the one decimal it shows
        self.assertEqual(s.value(), 2.3)
        s.setValue(2.3)
        self.assertEqual(seen, [2.3])

    def test_check_boxes_announce_only_real_changes(self):
        c = self.w.QCheckBox("x")
        seen = []
        c.toggled.connect(seen.append)
        c.setChecked(False)
        c.setChecked(True)
        c.setChecked(True)
        c.click()
        self.assertEqual(seen, [True, False])

    def test_radio_buttons_are_exclusive_among_siblings(self):
        box = self.w.QWidget()
        box.setLayout(self.w.QVBoxLayout())
        a, b = self.w.QRadioButton("a"), self.w.QRadioButton("b")
        box.layout().addWidget(a)
        box.layout().addWidget(b)
        a.setChecked(True)
        b.setChecked(True)
        self.assertEqual((a.isChecked(), b.isChecked()), (False, True))

    def test_a_combo_box_selects_its_first_item_and_finds_data_by_type_and_value(self):
        c = self.w.QComboBox()
        seen = []
        c.currentIndexChanged.connect(seen.append)
        c.addItem("auto", 0)
        c.addItem("1280", 1280)
        self.assertEqual((c.currentIndex(), c.currentData(), seen), (0, 0, [0]))
        self.assertEqual(c.findData(1280), 1)
        self.assertEqual(c.findData("1280"), -1)
        c.setCurrentIndex(1)
        self.assertEqual((c.currentData(), seen), (1280, [0, 1]))

    def test_visibility_follows_the_parents_and_the_stack(self):
        win = self.w.QMainWindow()
        stack = self.w.QStackedWidget()
        one, two = self.w.QLabel("1"), self.w.QLabel("2")
        stack.addWidget(one)
        stack.addWidget(two)
        win.setCentralWidget(stack)
        self.assertFalse(one.isVisible())                   # the window is not shown yet
        win.show()
        self.assertTrue(one.isVisible())
        self.assertFalse(two.isVisible())                   # not the current page
        stack.setCurrentIndex(1)
        self.assertTrue(two.isVisible() and not one.isVisible())
        two.hide()
        self.assertTrue(two.isHidden())

    def test_a_table_model_reset_forgets_the_selection_and_the_scroll_position(self):
        from PySide6.QtCore import QAbstractTableModel, QModelIndex

        class M(QAbstractTableModel):
            rows = 3

            def rowCount(self, parent=QModelIndex()):
                return self.rows

            def columnCount(self, parent=QModelIndex()):
                return 2

            def data(self, index, role=0):
                return "x"

        m = M()
        view = self.w.QTableView()
        view.setModel(m)
        view.selectRow(1)
        view.verticalScrollBar().setValue(40)
        self.assertTrue(view.selectionModel().hasSelection())
        m.beginResetModel()
        m.endResetModel()
        self.assertFalse(view.selectionModel().hasSelection())
        self.assertEqual(view.verticalScrollBar().value(), 0)

    def test_the_message_box_without_a_scripted_answer_cancels_and_says_so(self):
        box = self.w.QMessageBox()
        box.setText("sure?")
        cancel = box.addButton("Cancel", self.w.QMessageBox.ButtonRole.RejectRole)
        box.setEscapeButton(cancel)
        box.exec()
        self.assertIs(box.clickedButton(), cancel)
        self.assertEqual(fakeqt.state.hooks.unscripted, ["QMessageBox: sure?"])


class Installing(unittest.TestCase):
    def test_find_spec_sees_the_stand_in_and_uninstall_removes_it(self):
        import importlib.util
        import sys
        self.assertIsNotNone(importlib.util.find_spec("PySide6"))
        fakeqt.uninstall()
        try:
            self.assertNotIn("PySide6", sys.modules)
        finally:
            fakeqt.install()


if __name__ == "__main__":
    unittest.main()
