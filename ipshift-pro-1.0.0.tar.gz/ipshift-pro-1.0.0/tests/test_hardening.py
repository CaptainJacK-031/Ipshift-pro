"""IPv6 guard, MAC policy, the hardening facade and the daemon-less restore."""
from __future__ import annotations

import subprocess
import sys
import threading
import unittest
from pathlib import Path

from helpers import FakeRunner, TmpRootCase

from ipshift.config import Config
from ipshift.errors import DependencyError, HardeningError
from ipshift.net.local import Iface
from ipshift.paths import default_paths
from ipshift.privacy.hardening import Hardening, find_stray_openvpn, restore_all
from ipshift.privacy.ipv6 import Ipv6Guard
from ipshift.privacy.mac import NM_HEADER, MacPolicy, random_mac, valid_mac
from ipshift.privacy.state import StateStore
from ipshift.sysutil import CmdResult


def iface(name, physical=True, mac="aa:bb:cc:dd:ee:01"):
    return Iface(name, "wifi" if physical else "tunnel", True, mac, [], [], physical)


class FakeNet:
    def __init__(self, *ifaces):
        self.ifaces = list(ifaces)

    def physical_ifaces(self):
        return [i.name for i in self.ifaces if i.physical]

    def interfaces(self):
        return list(self.ifaces)


class Base(TmpRootCase):
    def setUp(self):
        super().setUp()
        self.paths = default_paths()
        self.store = StateStore(self.paths.backup_dir)
        self.sysctl = self.tmp / "proc_sys"
        self.runner = FakeRunner()

    def knob(self, name, value=None):
        p = self.sysctl / "net" / "ipv6" / "conf" / name / "disable_ipv6"
        if value is not None:
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(f"{value}\n")
        return p

    def value(self, name):
        return self.knob(name).read_text().strip()


class Ipv6GuardTests(Base):
    def make(self, *ifaces):
        self.net = FakeNet(*ifaces)
        return Ipv6Guard(self.store, self.net, sysctl_root=self.sysctl)

    def test_disables_physical_interfaces_and_restores_them(self):
        self.knob("wlan0", 0)
        self.knob("eth0", 1)                                   # the user already disabled this one
        self.knob("ipshift0", 0)
        g = self.make(iface("wlan0"), iface("eth0"), iface("ipshift0", physical=False))
        self.assertEqual(g.apply(), ["wlan0"])
        self.assertEqual(self.value("wlan0"), "1")
        self.assertEqual(self.value("ipshift0"), "0")          # the tunnel is never touched
        self.assertEqual(g.disabled(), ["wlan0"])
        self.assertTrue(g.intact())
        self.assertEqual(g.restore(), ["wlan0"])
        self.assertEqual(self.value("wlan0"), "0")
        self.assertEqual(self.value("eth0"), "1")              # not ours, left as it was
        self.assertEqual(g.disabled(), [])

    def test_second_apply_changes_nothing_and_keeps_the_original(self):
        self.knob("wlan0", 0)
        g = self.make(iface("wlan0"))
        g.apply()
        self.assertEqual(g.apply(), [])
        g.restore()
        self.assertEqual(self.value("wlan0"), "0")

    def test_new_interface_is_picked_up_later(self):
        self.knob("wlan0", 0)
        g = self.make(iface("wlan0"))
        g.apply()
        self.knob("usb0", 0)
        self.net.ifaces.append(iface("usb0"))                  # a phone was tethered
        self.assertEqual(g.apply(), ["usb0"])
        self.assertEqual(g.disabled(), ["usb0", "wlan0"])

    def test_reenabled_ipv6_is_noticed(self):
        self.knob("wlan0", 0)
        g = self.make(iface("wlan0"))
        g.apply()
        self.knob("wlan0", 0)                                  # NetworkManager turned it back on
        self.assertFalse(g.intact())
        self.assertEqual(g.apply(), ["wlan0"])
        self.assertTrue(g.intact())

    def test_kernel_without_ipv6_is_skipped(self):
        g = self.make(iface("wlan0"))
        self.assertEqual(g.apply(), [])

    def test_hostile_interface_names_are_ignored(self):
        outside = self.tmp / "outside"
        outside.mkdir()
        (outside / "disable_ipv6").write_text("0")
        g = self.make(iface("../../../outside"), iface("a/b"), iface(".."))
        self.assertEqual(g.apply(), [])
        self.assertEqual((outside / "disable_ipv6").read_text(), "0")

    def test_restore_skips_vanished_interfaces(self):
        self.knob("usb0", 0)
        g = self.make(iface("usb0"))
        g.apply()
        (self.knob("usb0")).unlink()
        (self.knob("usb0")).parent.rmdir()
        self.assertEqual(g.restore(), [])
        self.assertEqual(g.disabled(), [])


class MacTests(Base):
    def make(self, *ifaces, **kw):
        self.net = FakeNet(*ifaces)
        self.dropin = self.tmp / "nm" / "conf.d" / "90-ipshift-mac.conf"
        return MacPolicy(self.store, self.runner, self.net, nm_dropin=self.dropin, **kw)

    def test_random_mac_is_unicast_and_locally_administered(self):
        seen = set()
        for _ in range(300):
            m = random_mac()
            self.assertTrue(valid_mac(m), m)
            first = int(m[:2], 16)
            self.assertEqual(first & 1, 0)
            self.assertEqual(first & 2, 2)
            seen.add(m)
        self.assertGreater(len(seen), 290)

    def test_valid_mac(self):
        self.assertTrue(valid_mac("02:aa:bb:cc:dd:ee"))
        for bad in ("01:aa:bb:cc:dd:ee", "02:aa:bb:cc:dd", "zz:aa:bb:cc:dd:ee", "02-aa-bb-cc-dd-ee", "", "02:AA:bb:cc:dd:ee "):
            self.assertFalse(valid_mac(bad), bad)

    def test_randomize_and_restore(self):
        m = self.make(iface("wlan0", mac="aa:bb:cc:dd:ee:01"))
        new = m.randomize("wlan0", "02:11:22:33:44:55")
        self.assertEqual(new, "02:11:22:33:44:55")
        self.assertEqual(self.runner.lines(), ["ip link set dev wlan0 down",
                                               "ip link set dev wlan0 address 02:11:22:33:44:55",
                                               "ip link set dev wlan0 up"])
        self.assertEqual(self.store.get("mac"), {"wlan0": "aa:bb:cc:dd:ee:01"})
        self.net.ifaces = [iface("wlan0", mac="02:11:22:33:44:55")]
        m.randomize("wlan0")                                   # a second change must not lose the real address
        self.assertEqual(self.store.get("mac"), {"wlan0": "aa:bb:cc:dd:ee:01"})
        self.runner.calls.clear()
        self.assertEqual(m.restore(), ["wlan0"])
        self.assertIn("ip link set dev wlan0 address aa:bb:cc:dd:ee:01", self.runner.lines())
        self.assertIsNone(self.store.get("mac"))

    def test_link_is_brought_back_up_when_the_change_fails(self):
        self.runner.add("ip link set dev wlan0 address", (2, "", "RTNETLINK answers: Operation not supported"))
        m = self.make(iface("wlan0"))
        with self.assertRaises(HardeningError):
            m.randomize("wlan0")
        self.assertEqual(self.runner.lines()[-1], "ip link set dev wlan0 up")

    def test_refuses_bad_requests(self):
        m = self.make(iface("wlan0"), iface("ipshift0", physical=False))
        for name in ("ipshift0", "nope", "../x", "a b", ""):
            with self.assertRaises(HardeningError, msg=name):
                m.randomize(name)
        with self.assertRaises(HardeningError):
            m.randomize("wlan0", "01:00:5e:00:00:01")          # multicast
        with self.assertRaises(HardeningError):
            m.randomize("wlan0", "garbage")
        self.assertEqual(self.runner.calls, [])

    def test_networkmanager_policy(self):
        m = self.make()
        with self.assertRaises(DependencyError):
            m.enable_nm()                                      # no NetworkManager directory here
        self.dropin.parent.mkdir(parents=True)
        self.assertFalse(m.nm_enabled())
        m.enable_nm()
        text = self.dropin.read_text()
        self.assertTrue(text.startswith(NM_HEADER))
        self.assertIn("wifi.cloned-mac-address=random", text)
        self.assertIn("ethernet.cloned-mac-address=random", text)
        self.assertIn("wifi.scan-rand-mac-address=yes", text)
        self.assertTrue(m.nm_enabled())
        self.assertTrue(self.runner.ran("nmcli general reload conf"))
        self.assertTrue(m.disable_nm())
        self.assertFalse(self.dropin.exists())
        self.assertFalse(m.disable_nm())

    def test_a_foreign_file_with_the_same_name_is_not_deleted(self):
        m = self.make()
        self.dropin.parent.mkdir(parents=True)
        self.dropin.write_text("[connection]\nsomething=else\n")
        self.assertFalse(m.disable_nm())
        self.assertTrue(self.dropin.exists())


class FacadeTests(Base):
    def setUp(self):
        super().setUp()
        self.resolv = self.tmp / "resolv.conf"
        self.resolv.write_text("nameserver 192.168.1.1\n")
        self.cfg = Config()
        self.knob("wlan0", 0)
        self.net = FakeNet(iface("wlan0"))

    def make(self):
        return Hardening(self.cfg, self.runner, self.net, self.paths, resolv=self.resolv,
                         sysctl_root=self.sysctl, nm_dropin=self.tmp / "nm.conf")

    def test_tunnel_up_applies_dns_and_ipv6(self):
        h = self.make()
        rep = h.on_tunnel_up(["10.8.0.1"], tunnel_ipv6=False)
        self.assertEqual(rep, {"dns": ["10.8.0.1"], "ipv6_disabled": ["wlan0"]})
        self.assertEqual(h.dns.current(), ["10.8.0.1"])
        self.assertEqual(self.value("wlan0"), "1")
        st = h.status()
        self.assertTrue(st["dns_locked"] and st["dns_intact"])
        self.assertEqual(st["ipv6_guard"], ["wlan0"])
        self.assertTrue(st["ipv6_intact"])

    def test_config_can_switch_each_part_off(self):
        self.cfg.dns.manage = False
        self.cfg.privacy.disable_ipv6_on_physical = False
        h = self.make()
        self.assertEqual(h.on_tunnel_up(["10.8.0.1"]), {"dns": [], "ipv6_disabled": []})
        self.assertEqual(self.resolv.read_text(), "nameserver 192.168.1.1\n")
        self.assertEqual(self.value("wlan0"), "0")

    def test_ipv6_servers_are_not_used_without_tunnel_ipv6(self):
        rep = self.make().on_tunnel_up(["2620:fe::fe", "10.8.0.1"], tunnel_ipv6=False)
        self.assertEqual(rep["dns"], ["10.8.0.1"])

    def test_refresh_repairs_a_rewritten_resolver_file_and_new_interfaces(self):
        h = self.make()
        h.on_tunnel_up(["10.8.0.1"])
        self.assertEqual(h.refresh(), {})                      # nothing to repair
        self.resolv.write_text("nameserver 172.20.10.1\n")
        self.knob("usb0", 0)
        self.net.ifaces.append(iface("usb0"))
        fixed = h.refresh()
        self.assertEqual(fixed["dns"], ["10.8.0.1"])
        self.assertEqual(fixed["ipv6"], ["usb0"])
        self.assertEqual(h.dns.current(), ["10.8.0.1"])
        self.assertEqual(self.value("usb0"), "1")

    def test_restore_puts_everything_back_but_leaves_mac_unless_asked(self):
        h = self.make()
        h.on_tunnel_up(["10.8.0.1"])
        self.store.put("mac", {"wlan0": "aa:bb:cc:dd:ee:01"})
        out = h.restore()
        self.assertEqual(out, {"dns": True, "ipv6": ["wlan0"]})
        self.assertEqual(self.resolv.read_text(), "nameserver 192.168.1.1\n")
        self.assertEqual(self.value("wlan0"), "0")
        self.assertEqual(self.store.get("mac"), {"wlan0": "aa:bb:cc:dd:ee:01"})
        self.assertEqual(h.restore(include_mac=True)["mac"], ["wlan0"])


class StrayProcessTests(Base):
    def fake_proc(self, entries):
        root = self.tmp / "fakeproc"
        for pid, argv in entries.items():
            d = root / str(pid)
            d.mkdir(parents=True)
            (d / "cmdline").write_bytes(b"\0".join(a.encode() for a in argv) + b"\0")
        (root / "self").mkdir(parents=True, exist_ok=True)
        return root

    def test_only_processes_with_our_exact_runtime_config_match(self):
        conf = str(self.paths.runtime_dir / "ovpn.conf")
        root = self.fake_proc({
            101: ["openvpn", "--config", conf],
            102: ["openvpn", "--config", conf + ".bak"],
            103: ["openvpn", "--config", "/etc/openvpn/client.conf"],
            104: ["/usr/sbin/openvpn", "--config", conf, "--verb", "3"],
        })
        self.assertEqual(sorted(find_stray_openvpn(self.paths.runtime_dir, root)), [101, 104])

    def test_missing_proc_is_harmless(self):
        self.assertEqual(find_stray_openvpn(self.paths.runtime_dir, self.tmp / "nope"), [])


class RestoreAllTests(Base):
    def setUp(self):
        super().setUp()
        self.resolv = self.tmp / "resolv.conf"
        self.resolv.write_text("nameserver 192.168.1.1\n")
        self.cfg = Config()
        self.knob("wlan0", 0)
        self.net = FakeNet(iface("wlan0"))

    def run_restore(self, **kw):
        return restore_all(self.cfg, self.runner, self.net, self.paths, resolv=self.resolv, sysctl_root=self.sysctl,
                           nm_dropin=self.tmp / "nm.conf", proc=self.tmp / "no-proc", **kw)

    def test_everything_is_undone_without_a_daemon(self):
        h = Hardening(self.cfg, self.runner, self.net, self.paths, resolv=self.resolv, sysctl_root=self.sysctl)
        h.on_tunnel_up(["10.8.0.1"])
        self.paths.runtime_dir.mkdir(parents=True)
        (self.paths.runtime_dir / "ovpn.conf").write_text("secret")
        rep = self.run_restore()
        self.assertEqual(self.resolv.read_text(), "nameserver 192.168.1.1\n")
        self.assertEqual(self.value("wlan0"), "0")
        self.assertEqual(rep["killswitch"], "removed")
        self.assertTrue(rep["tunnel_interface_removed"])
        self.assertTrue(rep["dns"])
        self.assertEqual(rep["ipv6"], ["wlan0"])
        self.assertEqual(list(self.paths.runtime_dir.iterdir()), [])
        lines = self.runner.lines()
        self.assertIn("ip link del dev ipshift0", lines)
        self.assertEqual(lines[-1], "nft delete table inet ipshift")       # the firewall goes last

    def test_firewall_failure_is_reported_not_raised(self):
        self.runner.add("nft delete", (1, "", "Error: Operation not permitted"))
        rep = self.run_restore()
        self.assertTrue(rep["killswitch"].startswith("FAILED"))
        self.assertIn("dns", rep)

    def test_a_stray_openvpn_process_is_stopped(self):
        conf = self.paths.runtime_dir / "ovpn.conf"
        child = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(60)", "--config", str(conf)])
        threading.Thread(target=child.wait, daemon=True).start()
        self.addCleanup(lambda: child.poll() is None and child.kill())
        self.assertEqual(find_stray_openvpn(self.paths.runtime_dir), [child.pid])
        rep = restore_all(self.cfg, self.runner, self.net, self.paths, resolv=self.resolv, sysctl_root=self.sysctl,
                          nm_dropin=self.tmp / "nm.conf")
        self.assertEqual(rep["openvpn_stopped"], 1)
        self.assertIsNotNone(child.wait(timeout=10))
        self.assertEqual(find_stray_openvpn(self.paths.runtime_dir), [])


if __name__ == "__main__":
    unittest.main()
