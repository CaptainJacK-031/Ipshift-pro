"""What the window remembers and says: the app model, the interval box rule, and the wording of outcomes."""
from __future__ import annotations

import unittest

import helpers  # noqa: F401
import guifix
from ipshift.errors import BusyError
from ipshift.gui import views
from ipshift.gui.link import Result
from ipshift.gui.model import DIRECT_LOOKUP_TTL, MAX_EVENTS, AppModel, IntervalSync, describe_result
from ipshift.gui.views import BAD, GOOD, INFO, WARN


class Clock:
    def __init__(self, t=1000.0):
        self.t = t

    def __call__(self):
        return self.t


def make():
    clock = Clock()
    return AppModel(clock=clock, mono=clock), clock


class StateTests(unittest.TestCase):
    def test_a_new_model_shows_a_window_that_is_waiting_for_the_daemon(self):
        m, _ = make()
        d = m.dashboard()
        self.assertEqual(d.banner.level, "offline")
        self.assertFalse(d.controls.can_start)
        self.assertFalse(m.leaks().has_report)
        self.assertEqual((m.history_rows(), m.profile_rows(), m.alerts()), ((), (), ()))
        self.assertEqual((m.countdown(), m.level), ("", "offline"))

    def test_a_status_makes_the_dashboard_live(self):
        m, _ = make()
        m.apply_link(True)
        m.apply_status(guifix.status())
        self.assertEqual((m.dashboard().banner.title, m.level), ("PROTECTED", "protected"))

    def test_losing_the_daemon_drops_the_old_status_so_it_cannot_pass_for_live(self):
        m, _ = make()
        m.apply_status(guifix.status())
        m.apply_link(False, "the daemon is not running", "start it")
        d = m.dashboard()
        self.assertEqual((d.banner.level, d.banner.detail), ("offline", "the daemon is not running"))
        self.assertEqual((m.link_up, m.link_hint), (False, "start it"))
        m.apply_link(True)
        self.assertIsNone(m.status, "coming back does not resurrect the old status")

    def test_the_countdown_runs_on_the_models_clock(self):
        m, clock = make()
        m.apply_status(guifix.status())                         # next change in 0.6 s
        clock.t += 0.2
        self.assertEqual(m.countdown(), "next change in 0.4 s")

    def test_data_for_the_pages(self):
        m, _ = make()
        m.apply_data("profiles", guifix.profiles())
        m.apply_data("history", guifix.history(2))
        m.apply_data("report", guifix.report())
        m.apply_data("nonsense", {"x": 1})
        self.assertEqual(len(m.profile_rows()), 2)
        self.assertEqual(len(m.history_rows()), 2)
        self.assertEqual(len(m.history_rows("failed")), 0)
        self.assertEqual(m.leaks().verdict, "protected")
        self.assertFalse(hasattr(m, "nonsense"))

    def test_busy_commands_reach_the_controls(self):
        m, _ = make()
        m.apply_status(guifix.idle())
        self.assertTrue(m.dashboard().controls.can_start)
        m.apply_busy({"connect"})
        self.assertFalse(m.dashboard().controls.can_start)
        m.apply_busy(set())
        self.assertTrue(m.dashboard().controls.can_start)

    def test_the_advice_uses_the_known_profiles(self):
        m, _ = make()
        self.assertEqual(m.advice(1.0), "")
        m.apply_data("profiles", {"profiles": [{"id": "o", "protocol": "openvpn"}], "in_rotation": ["o"]})
        self.assertIn("OpenVPN", m.advice(1.0))
        self.assertEqual(m.advice(30.0), "")


class RealAddressTests(unittest.TestCase):
    LOOKUP = Result("ip", True, {"public": {"v4": "192.0.2.77", "v6": None, "source": "direct"}, "private": []})

    def test_a_requested_lookup_is_shown_while_unprotected(self):
        m, _ = make()
        m.apply_status(guifix.idle("unprotected"))
        m.apply_result(self.LOOKUP)
        p = m.dashboard().public
        self.assertEqual((p.value, p.tone), ("192.0.2.77", BAD))

    def test_it_is_forgotten_the_moment_the_protection_changes(self):
        m, _ = make()
        m.apply_status(guifix.idle("unprotected"))
        m.apply_result(self.LOOKUP)
        m.apply_status(guifix.idle("unprotected"))
        self.assertEqual(m.dashboard().public.value, "192.0.2.77", "an unchanged state keeps it")
        m.apply_status(guifix.status())
        self.assertIsNone(m.direct)
        m.apply_status(guifix.idle("unprotected"))
        self.assertEqual(m.dashboard().public.value, "hidden", "it must not come back by itself")

    def test_it_is_forgotten_after_a_while(self):
        m, clock = make()
        m.apply_status(guifix.idle("unprotected"))
        m.apply_result(self.LOOKUP)
        clock.t += DIRECT_LOOKUP_TTL - 1
        self.assertEqual(m.dashboard().public.value, "192.0.2.77")
        clock.t += 2
        self.assertEqual(m.dashboard().public.value, "hidden")

    def test_a_failed_lookup_changes_nothing(self):
        m, _ = make()
        m.apply_status(guifix.idle("unprotected"))
        out = m.apply_result(Result("ip", False, None, {"code": "error", "message": "no route"}))
        self.assertIsNone(m.direct)
        self.assertEqual((out.text, out.tone), ("no route", BAD))


class EventTests(unittest.TestCase):
    def ev(self, kind, level, ts, **data):
        return {"kind": kind, "level": level, "ts": ts, "data": data}

    def test_only_new_errors_and_criticals_deserve_a_notification(self):
        m, clock = make()                                      # the window opened at t = 1000
        self.assertIsNone(m.apply_event(self.ev("connected", "info", 1001.0, name="A", ip="x")))
        self.assertIsNone(m.apply_event(self.ev("network_changed", "warning", 1001.0, message="w")))
        self.assertEqual(m.apply_event(self.ev("tunnel_lost", "critical", 1001.0, message="gone")),
                         ("VPN connection lost", "gone"))

    def test_events_replayed_from_before_the_window_opened_are_listed_but_not_announced(self):
        m, _ = make()
        old = self.ev("tunnel_lost", "critical", 900.0, message="from yesterday")
        self.assertIsNone(m.apply_event(old))
        self.assertEqual([a.text for a in m.alerts()], ["from yesterday"])

    def test_the_event_list_is_capped(self):
        m, _ = make()
        for i in range(MAX_EVENTS + 50):
            m.apply_event(self.ev("network_changed", "warning", 1001.0, message=str(i)))
        self.assertEqual(len(m.events), MAX_EVENTS)
        self.assertEqual(m.events[-1]["data"]["message"], str(MAX_EVENTS + 49))
        self.assertEqual(m.alerts()[0].text, str(MAX_EVENTS + 49))


class IntervalSyncTests(unittest.TestCase):
    def test_the_first_daemon_value_fills_the_box(self):
        s = IntervalSync()
        self.assertEqual(s.on_daemon(30.0), 30.0)

    def test_an_unchanged_daemon_value_leaves_the_users_box_alone(self):
        s = IntervalSync()
        s.on_daemon(30.0)
        self.assertIsNone(s.on_daemon(30.0))
        self.assertIsNone(s.on_daemon(30.0))

    def test_a_value_changed_elsewhere_overwrites_the_box(self):
        s = IntervalSync()
        s.on_daemon(30.0)
        self.assertEqual(s.on_daemon(5.0), 5.0)
        self.assertIsNone(s.on_daemon(5.0))

    def test_while_the_user_is_typing_the_box_is_not_touched(self):
        s = IntervalSync()
        s.on_daemon(30.0)
        self.assertIsNone(s.on_daemon(5.0, editing=True))
        self.assertIsNone(s.on_daemon(5.0), "and the change is not applied afterwards either")
        self.assertEqual(s.on_daemon(7.0), 7.0)

    def test_the_first_value_is_taken_even_if_the_user_is_already_in_the_box(self):
        self.assertEqual(IntervalSync().on_daemon(30.0, editing=True), 30.0)

    def test_reset_forgets_what_was_seen(self):
        s = IntervalSync()
        s.on_daemon(30.0)
        s.reset()
        self.assertEqual(s.on_daemon(30.0), 30.0)

    def test_a_tiny_float_difference_is_not_a_change(self):
        s = IntervalSync()
        s.on_daemon(1.0)
        self.assertIsNone(s.on_daemon(1.0 + 1e-12))


def ok(name, **data):
    return Result(name, True, data)


class OutcomeTests(unittest.TestCase):
    def test_a_connection(self):
        o = describe_result(ok("connect", profile_name="NL 1", exit_ip="198.51.100.7", changed=True))
        self.assertEqual((o.text, o.tone), ("Connected to NL 1: 198.51.100.7", GOOD))

    def test_a_rotation_that_gave_the_same_address_is_a_warning(self):
        o = describe_result(ok("rotate_now", profile_name="NL 1", exit_ip="198.51.100.7", previous_ip="198.51.100.7",
                               changed=False))
        self.assertEqual(o.tone, WARN)
        self.assertIn("the same address as before", o.text)

    def test_starting_and_stopping(self):
        self.assertEqual(describe_result(ok("rotate_start", interval=1.0)).text,
                         "Rotation started: a new address every 1 s")
        self.assertEqual(describe_result(ok("rotate_start", interval=1.0, warning="slow")).hint, "slow")
        self.assertEqual(describe_result(ok("rotate_stop")).text, "Rotation stopped")
        self.assertIn("VPN stays connected", describe_result(ok("stop", stopped="rotation")).text)
        released = describe_result(ok("stop", released=True))
        self.assertEqual(released.tone, WARN)
        self.assertIn("real address is visible", released.text)
        blocked = describe_result(ok("stop", released=False))
        self.assertIn("keeps blocking", blocked.text)

    def test_the_privacy_check_names_the_grade_and_takes_the_verdict_colour(self):
        o = describe_result(Result("privacy_check", True, guifix.report(ipv6="fail")))
        self.assertEqual(o.tone, BAD)
        self.assertIn("grade F", o.text)
        o = describe_result(Result("privacy_check", True, guifix.report()))
        self.assertEqual((o.tone, o.text), (GOOD, "Privacy check finished: grade A (100/100)"))

    def test_kill_switch_outcomes(self):
        self.assertEqual(describe_result(ok("killswitch_on")).tone, GOOD)
        self.assertEqual(describe_result(ok("killswitch_off")).tone, WARN)
        self.assertEqual(describe_result(ok("lockdown")).tone, BAD)

    def test_settings(self):
        o = describe_result(ok("config_set", key="rotation.strategy", value="random", applies="now", saved=True))
        self.assertEqual((o.text, o.tone), ("rotation.strategy changed (takes effect now; saved)", GOOD))
        self.assertEqual(describe_result(ok("set_interval", interval=2.0)).text, "Interval is now 2 s")

    def test_history_export_says_where_and_warns_when_cut(self):
        o = describe_result(ok("history_export", path="/tmp/h.csv", rows=12, truncated=False))
        self.assertEqual((o.text, o.tone), ("Wrote 12 row(s) to /tmp/h.csv (readable only by you)", GOOD))
        cut = describe_result(ok("history_export", path="/tmp/h.csv", rows=12, truncated=True))
        self.assertEqual(cut.tone, WARN)
        self.assertIn("oldest rows are missing", cut.hint)

    def test_import_results(self):
        from ipshift.gui.tables import ImportOutcome
        good = describe_result(Result("profile_import", True, [ImportOutcome("a", True), ImportOutcome("b", True)]))
        self.assertEqual((good.text, good.tone), ("Imported 2 of 2 profile(s)", GOOD))
        mixed = describe_result(Result("profile_import", True, [ImportOutcome("a", True), ImportOutcome("b", False)]))
        self.assertEqual((mixed.text, mixed.tone), ("Imported 1 of 2 profile(s)", WARN))
        none = describe_result(Result("profile_import", True, []))
        self.assertEqual((none.text, none.tone), ("No profile files found", WARN))

    def test_profile_edits_and_history_clear(self):
        for name in ("profile_remove", "profile_update", "profile_auth", "profile_clear_quarantine"):
            self.assertEqual(describe_result(ok(name)).tone, GOOD)
        self.assertEqual(describe_result(ok("history_clear")).text, "History deleted")

    def test_an_unlisted_command_still_gets_a_polite_word(self):
        self.assertEqual(describe_result(ok("doctor")).text, "Done")

    def test_failures_carry_the_daemons_message_and_hint(self):
        o = describe_result(Result("connect", False, None, {"code": "vpn", "message": "handshake timed out",
                                                           "hint": "try another server"}))
        self.assertEqual((o.text, o.tone, o.hint), ("handshake timed out", BAD, "try another server"))

    def test_a_busy_daemon_gets_a_friendly_message(self):
        res = Result("connect", False, None, BusyError("x", hint="h").to_dict())
        o = describe_result(res)
        self.assertEqual(o.text, "Another operation is still running. Try again in a moment.")
        self.assertEqual(o.tone, BAD)

    def test_a_failure_without_a_message_is_still_a_sentence(self):
        self.assertEqual(describe_result(Result("connect", False, None, {})).text, "The command failed.")

    def test_settings_results_update_the_models_copy(self):
        m, _ = make()
        cfg = {"config": {"rotation": {"strategy": "diverse", "interval": 30.0}}, "file": "/x", "warnings": [],
               "simulated": False}
        m.apply_result(Result("config_get", True, cfg))
        m.apply_result(ok("config_set", key="rotation.strategy", value="random", applies="now", saved=True))
        self.assertEqual(m.config["config"]["rotation"]["strategy"], "random")
        m.apply_result(ok("config_set", key="rotation.nonexistent", value=1))
        self.assertNotIn("nonexistent", m.config["config"]["rotation"])


if __name__ == "__main__":
    unittest.main()
