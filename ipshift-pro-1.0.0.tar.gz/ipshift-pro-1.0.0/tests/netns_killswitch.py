#!/usr/bin/env python3
"""Kernel-level kill-switch verification.  Run inside a throw-away network namespace
(``unshare -n``): builds a fake physical link and a fake tunnel out of TUN devices,
applies the real nftables ruleset, then checks which packets *actually leave* which
interface by reading them from the TUN file descriptors.  Prints a JSON report."""
import errno
import json
import os
import select
import socket
import struct
import sys
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
import nlutil as nl  # noqa: E402
from ipshift.config import KillSwitchConfig, VpnConfig  # noqa: E402
from ipshift.firewall.killswitch import KillSwitch  # noqa: E402
from ipshift.sysutil import Runner  # noqa: E402
from ipshift.vpn.backend import Target  # noqa: E402

R = {}
PHY, TUN = "eth0x", "ipshift0"


def check(name, cond, detail=""):
    R[name] = {"ok": bool(cond), "detail": str(detail)}


class Net:
    def physical_ifaces(self):
        return [PHY]


nl.lo_up()
fd_phy, fd_tun = nl.add_tun(PHY), nl.add_tun(TUN)
for n, addr in ((PHY, "192.0.2.2/24"), (TUN, "10.8.0.2/24")):
    nl.set_up(n)
    nl.add_addr(n, addr)
nl.add_route("0.0.0.0/1", TUN)
nl.add_route("128.0.0.0/1", TUN)
nl.add_route("203.0.113.7/32", PHY, "192.0.2.1")        # pinned VPN server
nl.add_route("198.51.100.0/24", PHY, "192.0.2.1")       # a stale / leaky route
nl.add_route("192.168.50.0/24", PHY, "192.0.2.1")       # a LAN reachable over the physical link
nl.add_route("203.0.113.9/32", PHY, "192.0.2.1")        # a second VPN server

ksc, vc = KillSwitchConfig(), VpnConfig()
ks = KillSwitch(ksc, vc, Runner(), Net())


def drain(fd):
    out = []
    while True:
        try:
            p = os.read(fd, 4096)
        except BlockingIOError:
            return out
        ihl = (p[0] & 0xF) * 4
        proto = p[9]
        dport = struct.unpack("!H", p[ihl + 2:ihl + 4])[0] if proto in (6, 17) else None
        out.append((proto, socket.inet_ntoa(p[16:20]), dport))


def udp(dst, port, dev=None, sport=None, broadcast=False):
    """-> 'sent' or an errno name"""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        if dev:
            s.setsockopt(socket.SOL_SOCKET, 25, dev.encode() + b"\0")
        if broadcast:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        if sport:
            s.bind(("", sport))
        s.sendto(b"probe", (dst, port))
        return "sent"
    except OSError as e:
        return errno.errorcode.get(e.errno, str(e.errno))
    finally:
        s.close()


def tcp(dst, port):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setblocking(False)
    try:
        s.connect((dst, port))
        return "sent"
    except BlockingIOError:
        return "sent"
    except OSError as e:
        return errno.errorcode.get(e.errno, str(e.errno))
    finally:
        s.close()


def seen(fd, proto, dst, port):
    time.sleep(0.03)
    return (proto, dst, port) in drain(fd)


def flush():
    drain(fd_phy), drain(fd_tun)


def tcp_on(fd, dst, port):
    """Did a SYN to dst:port actually leave through the interface behind ``fd``?
    (A dropped SYN does not make a non-blocking connect() fail - the kernel just retries -
    so we look at the wire, not at the return code.)"""
    flush()
    tcp(dst, port)
    ok = seen(fd, 6, dst, port)
    flush()
    return ok


server = Target("203.0.113.7", 51820, "udp")
ks.set_endpoints([server])
ks.arm()
check("armed_in_kernel", ks.is_armed())
flush()

# ---- tunnel traffic flows, and only through the tunnel
r = udp("8.8.8.8", 53)
check("tunnel_traffic_allowed", r == "sent" and seen(fd_tun, 17, "8.8.8.8", 53), r)
check("tunnel_traffic_not_on_physical", not seen(fd_phy, 17, "8.8.8.8", 53))
flush()

# ---- the VPN server (and only exactly it) may use the physical link
r = udp("203.0.113.7", 51820)
check("server_endpoint_allowed_on_physical", r == "sent" and seen(fd_phy, 17, "203.0.113.7", 51820), r)
flush()
check("server_wrong_port_blocked", udp("203.0.113.7", 51821) == "EPERM")
check("server_wrong_proto_blocked", not tcp_on(fd_phy, "203.0.113.7", 51820))
check("other_server_blocked", udp("203.0.113.9", 51820) == "EPERM")
check("stale_physical_route_blocked", udp("198.51.100.5", 9) == "EPERM")
check("nothing_leaked_so_far", not drain(fd_phy))

# ---- physical-path probes (what privacy-check does)
check("bind_to_physical_blocked", udp("8.8.8.8", 53, dev=PHY) == "EPERM")
r = udp("8.8.8.8", 53, dev=TUN)
check("bind_to_tunnel_allowed", r == "sent" and seen(fd_tun, 17, "8.8.8.8", 53), r)
flush()
check("tcp_leak_blocked", not tcp_on(fd_phy, "198.51.100.5", 443))
r = tcp("8.8.8.8", 443)
check("tcp_via_tunnel_allowed", r == "sent" and seen(fd_tun, 6, "8.8.8.8", 443), r)
flush()

# ---- the real leak-check probes (privacy/probes.py), pinned to the physical NIC, against the real firewall
from ipshift.privacy.probes import NetProbes  # noqa: E402
probes = NetProbes(timeout=0.6)
t = probes.tcp("198.51.100.5", 443, device=PHY)
check("probe_tcp_blocked_by_killswitch", t in ("blocked", "timeout") and not seen(fd_phy, 6, "198.51.100.5", 443), t)
d = probes.resolver_identity("198.51.100.5", device=PHY)
check("probe_dns_blocked_by_killswitch", d.status == "blocked" and not seen(fd_phy, 17, "198.51.100.5", 53), d.status)
flush()
r = udp("127.0.0.1", 9)
check("loopback_allowed", r == "sent", r)

# ---- DHCP renewals on the physical link
r = udp("255.255.255.255", 67, dev=PHY, sport=68, broadcast=True)
check("dhcp_allowed_by_default", r == "sent" and seen(fd_phy, 17, "255.255.255.255", 67), r)
flush()
check("dhcp_other_source_port_blocked", udp("255.255.255.255", 67, dev=PHY, sport=4000, broadcast=True) == "EPERM")
ksc.allow_dhcp = False
ks.refresh()
check("dhcp_blocked_when_disabled", udp("255.255.255.255", 67, dev=PHY, sport=68, broadcast=True) == "EPERM")
ksc.allow_dhcp = True

# ---- LAN access is off by default, and never reaches LAN resolvers
check("lan_blocked_by_default", udp("192.168.50.7", 9999) == "EPERM")
ksc.allow_lan = True
ks.refresh()
r = udp("192.168.50.7", 9999)
check("lan_allowed_when_enabled", r == "sent" and seen(fd_phy, 17, "192.168.50.7", 9999), r)
flush()
check("lan_dns_still_blocked", udp("192.168.50.7", 53) == "EPERM" and not tcp_on(fd_phy, "192.168.50.7", 853))
check("lan_tcp_allowed_when_enabled", tcp_on(fd_phy, "192.168.50.7", 22))
ksc.allow_lan = False
ks.refresh()
check("lan_blocked_again", udp("192.168.50.7", 9999) == "EPERM")

# ---- switching servers: the old one is closed, the new one open, atomically
ks.set_endpoints([Target("203.0.113.9", 443, "tcp")])
check("old_server_closed_after_switch", udp("203.0.113.7", 51820) == "EPERM")
check("new_server_open_after_switch", tcp_on(fd_phy, "203.0.113.9", 443))
flush()
ks.set_endpoints([server])

# ---- DoH bootstrap window opens only on request
check("bootstrap_closed_by_default", not tcp_on(fd_phy, "198.51.100.5", 443))
ks.open_bootstrap(["198.51.100.5"])
check("bootstrap_open_during_lookup", tcp_on(fd_phy, "198.51.100.5", 443))
ks.close_bootstrap()
check("bootstrap_closed_after_lookup", not tcp_on(fd_phy, "198.51.100.5", 443))
flush()

# ---- no leak window while the ruleset is being replaced (the atomicity claim)
leaks, sent, stop = [], [0], threading.Event()


def hammer():
    while not stop.is_set():
        sent[0] += 1
        if udp("198.51.100.5", 9) == "sent":
            leaks.append(time.time())


t = threading.Thread(target=hammer)
t.start()
for i in range(150):
    ks.set_endpoints([server] if i % 2 else [server, Target("203.0.113.9", 443, "tcp")])
stop.set()
t.join()
check("no_leak_during_150_ruleset_replacements", not leaks and sent[0] > 100, f"attempts={sent[0]} leaks={len(leaks)}")
check("nothing_on_physical_after_hammering", not [p for p in drain(fd_phy) if p[1] == "198.51.100.5"])

# ---- unsolicited inbound is dropped
rx = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
rx.bind(("0.0.0.0", 5000))
rx.setblocking(False)


def inject(fd, src, dst, sport, dport, payload=b"hello"):
    udp_len = 8 + len(payload)
    hdr = struct.pack("!BBHHHBBH4s4s", 0x45, 0, 20 + udp_len, 0x1234, 0, 64, 17, 0, socket.inet_aton(src), socket.inet_aton(dst))
    s = sum(struct.unpack("!10H", hdr))
    s = (s & 0xFFFF) + (s >> 16)
    s = (s & 0xFFFF) + (s >> 16)
    hdr = hdr[:10] + struct.pack("!H", ~s & 0xFFFF) + hdr[12:]
    os.write(fd, hdr + struct.pack("!HHHH", sport, dport, udp_len, 0) + payload)


def delivered():
    time.sleep(0.05)
    try:
        rx.recvfrom(100)
        return True
    except BlockingIOError:
        return False


inject(fd_phy, "192.0.2.99", "192.0.2.2", 4444, 5000)
check("unsolicited_inbound_dropped", not delivered())

# ---- forwarded traffic (VMs/containers behind this host) cannot bypass the tunnel
open("/proc/sys/net/ipv4/ip_forward", "w").write("1")
flush()
inject(fd_phy, "192.0.2.99", "8.8.8.8", 4444, 53)
check("forward_via_tunnel_allowed", seen(fd_tun, 17, "8.8.8.8", 53))
flush()
inject(fd_phy, "192.0.2.99", "198.51.100.5", 4444, 53)
check("forward_via_physical_blocked", not seen(fd_phy, 17, "198.51.100.5", 53))
open("/proc/sys/net/ipv4/ip_forward", "w").write("0")

# ---- counters see the blocked packets
c = ks.counters()
check("blocked_counter_counts", c["blocked_packets"] > 20, c)

# ---- lockdown blocks even the VPN server and DHCP, but not loopback
ks.lockdown()
flush()
check("lockdown_blocks_server", udp("203.0.113.7", 51820) == "EPERM")
check("lockdown_blocks_tunnel_less_dhcp", udp("255.255.255.255", 67, dev=PHY, sport=68, broadcast=True) == "EPERM")
check("lockdown_keeps_loopback", udp("127.0.0.1", 9) == "sent")
ks.arm()
check("arm_leaves_lockdown", udp("203.0.113.7", 51820) == "sent")
flush()

# ---- disarm restores normal networking
ks.disarm()
check("disarmed_in_kernel", not ks.is_armed())
r = udp("198.51.100.5", 9)
check("traffic_flows_after_disarm", r == "sent" and seen(fd_phy, 17, "198.51.100.5", 9), r)

# ---- without the kill switch the same probes DO reach the wire, so a pass above really proves something
flush()
t = probes.tcp("198.51.100.5", 443, device=PHY)
check("probe_tcp_reaches_wire_when_disarmed", seen(fd_phy, 6, "198.51.100.5", 443), t)
flush()
d = probes.resolver_identity("198.51.100.5", device=PHY)
check("probe_dns_reaches_wire_when_disarmed", seen(fd_phy, 17, "198.51.100.5", 53), d.status)

print(json.dumps(R))
