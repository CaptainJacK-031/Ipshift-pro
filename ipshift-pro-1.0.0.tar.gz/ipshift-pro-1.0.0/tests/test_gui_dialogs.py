"""The questions the window asks (ipshift.gui.dialogs), run against the stand-in for PySide6."""
from __future__ import annotations

import os
import tempfile
import unittest

import helpers  # noqa: F401
import fakeqt
import guifix
import qtcase
from ipshift.gui import tables, views
from ipshift.gui.views import WARN


def setUpModule():
    qtcase.install()
    global dialogs, Qt, QDialogButtonBox, QFileDialog, QLabel, QLineEdit, QMessageBox
    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import QDialogButtonBox, QFileDialog, QLabel, QLineEdit, QMessageBox
    from ipshift.gui import dialogs


def tearDownModule():
    qtcase.uninstall()


class DialogCase(qtcase.QtCase):
    @property
    def hooks(self):
        return fakeqt.state.hooks

    def click(self, dialog, which):
        dialog.buttons.button(which).click()


OK, CANCEL = None, None


def _buttons():
    global OK, CANCEL
    OK, CANCEL = QDialogButtonBox.StandardButton.Ok, QDialogButtonBox.StandardButton.Cancel


class ConfirmTests(DialogCase):
    def ask(self, click: int, **kw):
        """Run ``confirm`` with a scripted click (0 = the accept button, 1 = Cancel); returns (answer, the box)."""
        seen = {}

        def hook(box):
            seen["box"] = box
            return box._buttons[click][0]

        self.hooks.message_box = hook
        return dialogs.confirm(None, "Title", "Do the thing?", **kw), seen["box"]

    def test_the_accept_button_answers_yes_and_cancel_answers_no(self):
        self.assertTrue(self.ask(0)[0])
        self.assertFalse(self.ask(1)[0])

    def test_cancel_is_the_default_and_the_escape_button(self):
        _, box = self.ask(1)
        cancel = box._buttons[1][0]
        self.assertEqual(cancel.text(), "Cancel")
        self.assertIs(box._default, cancel)
        self.assertIs(box._escape, cancel)

    def test_without_an_answer_the_dialog_counts_as_cancelled(self):
        self.hooks.message_box = None
        self.assertFalse(dialogs.confirm(None, "Title", "Text"))
        self.assertEqual(self.hooks.unscripted, ["QMessageBox: Text"])

    def test_the_texts_and_the_accept_label(self):
        _, box = self.ask(0, accept="Replace", detail="It cannot be undone.")
        self.assertEqual((box.windowTitle(), box.text_value, box.informative), ("Title", "Do the thing?",
                                                                               "It cannot be undone."))
        self.assertEqual([b.text() for b, _ in box._buttons], ["Replace", "Cancel"])

    def test_the_default_accept_label_is_ok_and_no_detail_leaves_the_informative_text_empty(self):
        _, box = self.ask(0)
        self.assertEqual(box._buttons[0][0].text(), "OK")
        self.assertEqual(box.informative, "")

    def test_a_dangerous_question_has_a_warning_icon(self):
        self.assertIs(self.ask(0, danger=True)[1].icon_value, QMessageBox.Icon.Warning)
        self.assertIs(self.ask(0)[1].icon_value, QMessageBox.Icon.Question)

    def test_inform_shows_a_message_and_waits_for_nothing(self):
        dialogs.inform(None, "Imported", "3 profiles added.")
        self.assertEqual(self.hooks.informs, [("Imported", "3 profiles added.")])


class StopDialogTests(DialogCase):
    def setUp(self):
        super().setUp()
        _buttons()
        self.options = views.stop_choices(guifix.status())

    def test_every_way_to_stop_is_a_radio_button_and_the_safest_is_chosen(self):
        self.assertEqual([o.key for o in self.options], ["rotation", "block", "release"])
        dialog = dialogs.StopDialog(None, self.options)
        self.assertEqual(list(dialog.radios), ["rotation", "block", "release"])
        self.assertEqual([r.isChecked() for r in dialog.radios.values()], [True, False, False])
        self.assertEqual(dialog.choice(), "rotation")
        self.assertEqual([r.text() for r in dialog.radios.values()], [o.label for o in self.options])

    def test_the_radio_buttons_exclude_each_other(self):
        dialog = dialogs.StopDialog(None, self.options)
        dialog.radios["release"].setChecked(True)
        self.assertEqual(dialog.choice(), "release")
        self.assertEqual([r.isChecked() for r in dialog.radios.values()], [False, False, True])

    def test_the_ok_button_says_stop_and_the_risky_choice_is_explained_in_amber(self):
        dialog = dialogs.StopDialog(None, self.options)
        self.assertEqual(dialog.buttons.button(OK).text(), "Stop")
        details = {lab.text(): lab for lab in dialog.findChildren(QLabel)}
        risky = next(o for o in self.options if o.risky)
        safe = next(o for o in self.options if not o.risky)
        self.assertEqual(details[risky.detail].property("tone"), WARN)
        self.assertIsNone(details[safe.detail].property("tone"))

    def test_only_the_choices_that_make_sense_are_offered(self):
        idle = views.stop_choices(guifix.idle("blocked"))
        dialog = dialogs.StopDialog(None, idle)
        self.assertEqual(list(dialog.radios), ["release"])
        self.assertEqual(dialog.choice(), "release")

    def test_ask_stop_returns_the_chosen_key(self):
        def script(dialog):
            dialog.radios["block"].setChecked(True)
            self.click(dialog, OK)

        self.hooks.dialog = script
        self.assertEqual(dialogs.ask_stop(None, self.options), "block")

    def test_ask_stop_returns_none_when_cancelled(self):
        self.hooks.dialog = lambda dialog: self.click(dialog, CANCEL)
        self.assertIsNone(dialogs.ask_stop(None, self.options))

    def test_ask_stop_without_an_answer_is_a_cancel(self):
        self.hooks.dialog = None
        self.assertIsNone(dialogs.ask_stop(None, self.options))
        self.assertEqual(self.hooks.unscripted, ["StopDialog"])

    def test_ask_stop_with_nothing_to_choose_does_not_open_a_dialog(self):
        self.assertIsNone(dialogs.ask_stop(None, ()))
        self.assertEqual(self.hooks.unscripted, [])


class ImportDialogTests(DialogCase):
    def setUp(self):
        super().setUp()
        _buttons()
        self.dialog = dialogs.ImportDialog(None)

    def test_a_new_dialog_cannot_import_anything_yet(self):
        d = self.dialog
        self.assertFalse(d.ok.isEnabled())
        self.assertEqual(d.ok.text(), "Import")
        self.assertEqual(d.paths(), [])
        self.assertEqual(d.tier.currentData(), "unknown")
        self.assertTrue(d.warning.isHidden())
        self.assertFalse(d.replace.isChecked())
        self.assertIs(d.password.echoMode(), QLineEdit.EchoMode.Password)
        self.assertEqual([d.tier.itemText(i) for i in range(d.tier.count())], [t for _, t in tables.TIER_CHOICES])

    def test_choosing_free_shows_the_warning_and_choosing_something_else_hides_it(self):
        d = self.dialog
        d.tier.setCurrentIndex(d.tier.findData("free"))
        self.assertFalse(d.warning.isHidden())
        self.assertEqual(d.warning.text(), tables.FREE_VPN_WARNING)
        d.tier.setCurrentIndex(d.tier.findData("paid"))
        self.assertTrue(d.warning.isHidden())

    def test_added_paths_are_listed_once_and_enable_the_import_button(self):
        d = self.dialog
        d.add_paths(["/a/one.ovpn", "", "/a/two.conf"])
        d.add_paths(["/a/one.ovpn", "/a/three.ovpn"])
        self.assertEqual(d.paths(), ["/a/one.ovpn", "/a/two.conf", "/a/three.ovpn"])
        self.assertTrue(d.ok.isEnabled())

    def test_adding_nothing_leaves_the_button_disabled(self):
        self.dialog.add_paths([])
        self.dialog.add_paths([""])
        self.assertFalse(self.dialog.ok.isEnabled())

    def test_the_add_files_button_asks_the_file_dialog(self):
        self.hooks.open_files = [["/x/a.ovpn", "/x/b.conf"]]
        self.dialog.add_files_button.click()
        self.assertEqual(self.dialog.paths(), ["/x/a.ovpn", "/x/b.conf"])
        self.assertIn(("getOpenFileNames", "Choose VPN files"), self.hooks.calls)

    def test_cancelling_the_file_dialog_adds_nothing(self):
        self.hooks.open_files = []
        self.dialog.add_files_button.click()
        self.assertEqual(self.dialog.paths(), [])
        self.assertFalse(self.dialog.ok.isEnabled())

    def test_the_add_folder_button_adds_the_folder(self):
        self.hooks.directory = "/x/vpn"
        self.dialog.add_folder_button.click()
        self.assertEqual(self.dialog.paths(), ["/x/vpn"])
        self.hooks.directory = ""
        self.dialog.add_folder_button.click()
        self.assertEqual(self.dialog.paths(), ["/x/vpn"])

    def test_the_request_carries_what_was_entered(self):
        d = self.dialog
        d.add_paths(["/a/one.ovpn"])
        d.tier.setCurrentIndex(d.tier.findData("self-hosted"))
        d.username.setText("  alice  ")
        d.password.setText(" s3cret ")
        d.replace.setChecked(True)
        req = d.request()
        self.assertEqual(req.paths, ("/a/one.ovpn",))
        self.assertEqual((req.tier, req.username, req.password, req.replace), ("self-hosted", "alice", " s3cret ", True))

    def test_the_password_does_not_appear_in_the_text_of_a_request(self):
        d = self.dialog
        d.add_paths(["/a/one.ovpn"])
        d.password.setText("hunter2")
        self.assertNotIn("hunter2", repr(d.request()))
        self.assertNotIn("hunter2", str(d.request()))

    def test_ask_import_returns_the_request_or_none(self):
        def accept(dialog):
            dialog.add_paths(["/a/one.ovpn"])
            self.click(dialog, OK)

        self.hooks.dialog = accept
        req = dialogs.ask_import(None)
        self.assertEqual((req.paths, req.tier), (("/a/one.ovpn",), "unknown"))
        self.hooks.dialog = lambda dialog: self.click(dialog, CANCEL)
        self.assertIsNone(dialogs.ask_import(None))
        self.hooks.dialog = None
        self.assertIsNone(dialogs.ask_import(None))

    def test_the_import_button_cannot_be_pressed_before_a_file_is_added(self):
        self.hooks.dialog = lambda dialog: self.click(dialog, OK)          # a disabled button does nothing
        self.assertIsNone(dialogs.ask_import(None))


class LoginDialogTests(DialogCase):
    def setUp(self):
        super().setUp()
        _buttons()

    def fill(self, user, password, click=None):
        def script(dialog):
            dialog.username.setText(user)
            dialog.password.setText(password)
            self.click(dialog, OK if click is None else click)

        self.hooks.dialog = script

    def test_the_dialog_names_the_profile_and_hides_the_password(self):
        d = dialogs.LoginDialog(None, "NL 1")
        self.assertIn("Username and password for NL 1", self.texts(d))
        self.assertIs(d.password.echoMode(), QLineEdit.EchoMode.Password)

    def test_a_profile_name_is_never_taken_for_markup(self):
        d = dialogs.LoginDialog(None, "<b>NL</b>")
        titles = [w for w in d.findChildren(QLabel) if "NL" in w.text()]
        self.assertEqual([w.text() for w in titles], ["Username and password for <b>NL</b>"])
        self.assertIs(titles[0].textFormat(), Qt.TextFormat.PlainText)

    def test_a_login_is_returned_with_the_username_trimmed_and_the_password_kept_as_typed(self):
        self.fill("  alice ", " pass word ")
        self.assertEqual(dialogs.ask_login(None, "NL 1"), ("alice", " pass word "))

    def test_an_incomplete_login_is_nothing(self):
        for user, password in (("", "secret"), ("alice", ""), ("   ", "secret"), ("", "")):
            self.fill(user, password)
            self.assertIsNone(dialogs.ask_login(None, "NL 1"), (user, password))

    def test_cancelling_gives_nothing(self):
        self.fill("alice", "secret", click=CANCEL)
        self.assertIsNone(dialogs.ask_login(None, "NL 1"))
        self.hooks.dialog = None
        self.assertIsNone(dialogs.ask_login(None, "NL 1"))


class SaveCsvTests(DialogCase):
    def setUp(self):
        super().setUp()
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.dir = tmp.name

    def answer(self, click: int):
        seen = []

        def hook(box):
            seen.append(box)
            return box._buttons[click][0]

        self.hooks.message_box = hook
        return seen

    def test_cancelling_the_file_dialog_gives_nothing(self):
        self.hooks.save_path = ""
        self.assertIsNone(dialogs.ask_save_csv(None, "history.csv"))

    def test_the_file_dialog_starts_at_the_default_name_and_does_not_ask_about_overwriting_itself(self):
        self.hooks.save_path = ""
        dialogs.ask_save_csv(None, "ipshift-history-x.csv")
        name, caption, start, options = self.hooks.calls[-1]
        self.assertEqual(name, "getSaveFileName")
        self.assertTrue(start.endswith("ipshift-history-x.csv"))
        self.assertEqual(options, QFileDialog.Option.DontConfirmOverwrite)

    def test_a_new_file_is_saved_without_asking_again(self):
        path = os.path.join(self.dir, "new.csv")
        self.hooks.save_path = path
        seen = self.answer(0)
        self.assertEqual(dialogs.ask_save_csv(None, "x.csv"), (path, False))
        self.assertEqual(seen, [])

    def test_an_existing_file_is_replaced_only_when_the_user_agrees(self):
        path = os.path.join(self.dir, "old.csv")
        open(path, "w").close()
        self.hooks.save_path = path
        seen = self.answer(0)
        self.assertEqual(dialogs.ask_save_csv(None, "x.csv"), (path, True))
        box = seen[0]
        self.assertEqual(box.text_value, "old.csv already exists. Replace it?")
        self.assertEqual([b.text() for b, _ in box._buttons], ["Replace", "Cancel"])
        self.answer(1)
        self.assertIsNone(dialogs.ask_save_csv(None, "x.csv"))

    def test_a_dangling_symlink_counts_as_existing(self):
        path = os.path.join(self.dir, "link.csv")
        os.symlink(os.path.join(self.dir, "nowhere"), path)
        self.hooks.save_path = path
        seen = self.answer(1)
        self.assertIsNone(dialogs.ask_save_csv(None, "x.csv"))
        self.assertEqual(len(seen), 1)


if __name__ == "__main__":
    unittest.main()
