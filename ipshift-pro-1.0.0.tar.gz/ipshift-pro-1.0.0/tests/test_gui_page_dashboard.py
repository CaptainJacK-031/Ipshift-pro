"""The Dashboard page (ipshift.gui.page_dashboard), run against the stand-in for PySide6."""
from __future__ import annotations

import unittest

import helpers  # noqa: F401
import guifix
import qtcase
from ipshift.gui import views
from ipshift.gui.views import BAD, GOOD, INFO, MUTED, WARN


def setUpModule():
    qtcase.install()
    global page_dashboard, Qt, QLabel
    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import QLabel
    from ipshift.gui import page_dashboard


def tearDownModule():
    qtcase.uninstall()


def record(signal) -> list:
    """Everything a signal is emitted with, as tuples."""
    got: list = []
    signal.connect(lambda *args: got.append(args))
    return got


def event(level: str, kind: str, message: str, hint: str = "", ts: float = 1_700_000_000.0) -> dict:
    return {"ts": ts, "level": level, "kind": kind, "data": {"message": message, "hint": hint}}


class DashboardCase(qtcase.QtCase):
    def setUp(self):
        super().setUp()
        self.page = page_dashboard.DashboardPage()
        self.page.show()

    def show(self, st, *, alerts=(), **kw):
        d = views.dashboard_view(st, **kw)
        self.page.update_view(d, alerts)
        return d

    def tone(self, widget):
        return widget.property("tone")


class BuildTests(DashboardCase):
    def test_the_interval_box_has_the_one_second_floor_and_a_day_as_the_ceiling(self):
        box = self.page.interval
        self.assertEqual((box.minimum(), box.maximum()), (1.0, 86400.0))
        self.assertEqual((box.decimals(), box.suffix(), box.value()), (1, " s", 30.0))
        self.assertFalse(box.keyboardTracking())          # a half-typed number is never sent

    def test_a_value_below_the_floor_is_raised_to_one_second(self):
        self.page.interval.setValue(0.2)
        self.assertEqual(self.page.interval.value(), 1.0)
        self.page.interval.setValue(-5.0)
        self.assertEqual(self.page.interval.value(), 1.0)

    def test_the_page_is_called_page_so_that_the_style_sheet_paints_it(self):
        self.assertEqual(self.page.objectName(), "page")

    def test_before_the_first_update_nothing_that_could_act_is_visible_but_the_always_there_controls(self):
        self.assertTrue(self.page.problems_card.isHidden())
        self.assertTrue(self.page.lookup_button.isHidden())
        for w in (self.page.rotation_counts, self.page.rotation_last, self.page.rotation_problem,
                  self.page.rotation_hint, self.page.rotation_advice):
            self.assertTrue(w.isHidden(), w.text())


class BannerAndProblemsTests(DashboardCase):
    def test_a_protected_connection(self):
        d = self.show(guifix.status())
        self.assertEqual(self.page.banner.title.text(), "PROTECTED")
        self.assertEqual(self.page.banner.detail.text(), "Traffic goes through the VPN; the kill switch is armed")
        self.assertEqual((self.tone(self.page.banner), self.tone(self.page.banner.title)), (GOOD, GOOD))
        self.assertEqual(self.page.banner.extra.text(), d.daemon)
        self.assertIn("IPShift Pro 1.0.0", d.daemon)
        self.assertNotIn("SIMULATION", self.page.banner.extra.text())

    def test_an_exposed_computer_is_red(self):
        self.show(guifix.idle("unprotected"))
        self.assertEqual(self.page.banner.title.text(), "UNPROTECTED")
        self.assertEqual(self.tone(self.page.banner), BAD)

    def test_a_blocked_computer_is_a_warning(self):
        self.show(guifix.idle("blocked"))
        self.assertEqual((self.page.banner.title.text(), self.tone(self.page.banner)), ("BLOCKED", WARN))

    def test_the_banner_says_so_when_nothing_real_is_touched(self):
        st = guifix.status(daemon={"version": "1.0.0", "pid": 42, "uptime": 5, "simulated": True, "root": True})
        self.show(st)
        self.assertIn("SIMULATION: no real network is touched", self.page.banner.extra.text())

    def test_without_the_daemon_the_banner_says_why(self):
        self.show(None, link_error="Connection refused")
        self.assertEqual(self.page.banner.title.text(), "DAEMON NOT REACHABLE")
        self.assertEqual(self.page.banner.detail.text(), "Connection refused")
        self.assertEqual(self.tone(self.page.banner), WARN)

    def test_no_problems_means_no_problems_card(self):
        self.show(guifix.status())
        self.assertTrue(self.page.problems_card.isHidden())
        self.assertEqual(self.page.problems.count, 0)

    def test_a_problem_shows_its_text_and_its_hint_and_goes_away_with_its_cause(self):
        st = guifix.status()
        st["profiles"] = {"total": 0, "usable": 0}
        self.show(st)
        self.assertFalse(self.page.problems_card.isHidden())
        self.assertEqual(self.page.problems.count, 1)
        shown = self.texts(self.page.problems)
        self.assertIn("No VPN profiles yet.", shown)
        self.assertTrue(any("Import one on the Profiles page" in t for t in shown))
        self.show(guifix.status())
        self.assertTrue(self.page.problems_card.isHidden())
        self.assertEqual(self.page.problems.count, 0)

    def test_a_stalled_rotation_is_reported_twice_as_a_problem_and_next_to_the_rotation(self):
        st = guifix.status()
        st["rotation"] = dict(st["rotation"], stalled=True, consecutive_failures=5)
        self.show(st)
        self.assertTrue(self.page.rotation_problem.text().startswith("STALLED: 5 failures in a row"))
        self.assertEqual(self.tone(self.page.rotation_problem), BAD)
        self.assertFalse(self.page.rotation_problem.isHidden())
        self.assertTrue(any(t.startswith("Rotation stalled after 5 failures") for t in self.texts(self.page.problems)))


class VpnCardTests(DashboardCase):
    def test_a_connected_tunnel(self):
        d = self.show(guifix.status())
        page = self.page
        self.assertEqual((page.vpn_badge.text(), self.tone(page.vpn_badge)), ("CONNECTED", GOOD))
        self.assertEqual(page.vpn_profile.text(), "NL 1")
        self.assertEqual(page.vpn_facts.text("Type"), "wireguard, paid, NL")
        self.assertEqual(page.vpn_facts.text("Server"), "203.0.113.9:51820/udp")
        self.assertEqual(page.vpn_facts.text("Interface"), "ipshift0")
        self.assertEqual(page.vpn_facts.text("Connected for"), d.vpn.uptime)
        self.assertEqual(page.vpn_facts.text("Last handshake"), d.vpn.handshake)
        self.assertTrue(page.vpn_facts.text("Last handshake").endswith(" ago"))
        self.assertTrue(page.vpn_note.isHidden())

    def test_a_disconnected_computer_shows_dashes_not_stale_facts(self):
        self.show(guifix.status())
        self.show(guifix.idle())
        page = self.page
        self.assertEqual((page.vpn_badge.text(), self.tone(page.vpn_badge)), ("DISCONNECTED", MUTED))
        self.assertEqual(page.vpn_profile.text(), "-")
        for key in ("Type", "Server", "Interface", "Connected for", "Last handshake"):
            self.assertEqual(page.vpn_facts.text(key), "-", key)

    def test_a_failed_connection_shows_the_error_in_red(self):
        st = guifix.idle("blocked")
        st["vpn"] = dict(st["vpn"], state="failed", last_error="authentication failed")
        self.show(st)
        self.assertEqual((self.page.vpn_badge.text(), self.tone(self.page.vpn_badge)), ("FAILED", BAD))
        self.assertEqual(self.page.vpn_note.text(), "Last error: authentication failed")
        self.assertEqual(self.tone(self.page.vpn_note), BAD)
        self.assertFalse(self.page.vpn_note.isHidden())

    def test_what_the_daemon_is_doing_is_shown_while_it_works(self):
        st = guifix.idle("blocked")
        st["vpn"] = dict(st["vpn"], state="connecting", busy="Resolving the server")
        self.show(st)
        self.assertEqual(self.page.vpn_badge.text(), "CONNECTING")
        self.assertEqual(self.page.vpn_note.text(), "Resolving the server ...")
        self.assertEqual(self.tone(self.page.vpn_note), INFO)

    def test_text_from_a_profile_file_is_never_taken_for_markup(self):
        st = guifix.status()
        st["vpn"] = dict(st["vpn"], profile=dict(st["vpn"]["profile"], name="<b>Evil</b> <img src=x>"))
        self.show(st)
        self.assertEqual(self.page.vpn_profile.text(), "<b>Evil</b> <img src=x>")
        self.assertIs(self.page.vpn_profile.textFormat(), Qt.TextFormat.PlainText)


class AddressCardTests(DashboardCase):
    def test_the_public_address_seen_through_the_tunnel(self):
        self.show(guifix.status())
        page = self.page
        self.assertEqual((page.public_value.text(), self.tone(page.public_value)), ("198.51.100.7", GOOD))
        self.assertIn("seen through the tunnel", page.public_note.text())
        self.assertEqual(page.public_v6.text("IPv6"), "none (the tunnel carries no IPv6)")
        self.assertTrue(page.lookup_button.isHidden())

    def test_while_unprotected_the_real_address_is_not_looked_up_unless_asked(self):
        self.show(guifix.idle("unprotected"))
        page = self.page
        self.assertEqual((page.public_value.text(), self.tone(page.public_value)), ("hidden", MUTED))
        self.assertEqual(page.public_note.text(), "Not looked up while you are unprotected.")
        self.assertFalse(page.lookup_button.isHidden())
        asked = record(page.lookup_requested)
        page.lookup_button.click()
        self.assertEqual(asked, [()])

    def test_a_looked_up_real_address_is_shown_in_red_and_the_button_goes_away(self):
        direct = {"public": {"v4": "192.0.2.77", "v6": None, "source": "direct"}}
        self.show(guifix.idle("unprotected"), direct=direct)
        page = self.page
        self.assertEqual((page.public_value.text(), self.tone(page.public_value)), ("192.0.2.77", BAD))
        self.assertEqual(page.public_note.text(), "your real, unprotected address")
        self.assertTrue(page.lookup_button.isHidden())

    def test_a_blocked_computer_has_no_public_address(self):
        self.show(guifix.idle("blocked"))
        self.assertEqual(self.page.public_value.text(), "none")
        self.assertEqual(self.page.public_note.text(), "The kill switch is blocking all traffic.")

    def test_the_address_labels_can_be_selected_with_the_mouse_for_copying(self):
        self.assertEqual(self.page.public_value.textInteractionFlags(), Qt.TextInteractionFlag.TextSelectableByMouse)
        self.assertEqual(self.page.vpn_profile.textInteractionFlags(), Qt.TextInteractionFlag.TextSelectableByMouse)

    def test_private_addresses_list_the_ipv4_ones_with_the_tunnel_marked(self):
        d = self.show(guifix.status())
        self.assertEqual(self.page.private_ips.count, 2)
        shown = self.texts(self.page.private_ips)
        self.assertIn("192.168.1.23", shown)
        self.assertIn("10.2.0.2", shown)
        self.assertNotIn("fd00::23", shown)
        self.assertTrue(any("default route" in t for t in shown))
        self.assertTrue(any("VPN tunnel" in t for t in shown))
        tunnel = [lab for lab in self.page.private_ips.findChildren(QLabel) if lab.text() == "10.2.0.2"][0]
        plain = [lab for lab in self.page.private_ips.findChildren(QLabel) if lab.text() == "192.168.1.23"][0]
        self.assertEqual((tunnel.property("tone"), plain.property("tone")), (INFO, None))
        self.assertEqual(self.page.network.text(), d.network)

    def test_no_private_address_says_so(self):
        st = guifix.status()
        st["network"] = dict(st["network"], private_ips=[])
        self.show(st)
        self.assertEqual(self.texts(self.page.private_ips), ["No network address found."])


class KillSwitchCardTests(DashboardCase):
    def test_an_armed_kill_switch(self):
        self.show(guifix.status())
        page = self.page
        self.assertEqual((page.ks_badge.text(), self.tone(page.ks_badge)), ("ARMED", GOOD))
        self.assertEqual(page.ks_detail.text(), "LAN blocked, 12 packets blocked")
        self.assertEqual(page.ks_endpoints.text(), "Allowed to leave: only the VPN server 203.0.113.9:51820/udp")
        self.assertFalse(page.ks_endpoints.isHidden())
        self.assertEqual([b.isEnabled() for b in (page.arm_button, page.release_button, page.lockdown_button)],
                         [False, True, True])

    def test_a_kill_switch_that_is_not_armed_can_be_armed_but_not_released(self):
        self.show(guifix.idle("unprotected"))
        page = self.page
        self.assertEqual((page.ks_badge.text(), self.tone(page.ks_badge)), ("NOT ARMED", WARN))
        self.assertTrue(page.ks_endpoints.isHidden())
        self.assertEqual([b.isEnabled() for b in (page.arm_button, page.release_button, page.lockdown_button)],
                         [True, False, True])

    def test_lockdown_is_shown_in_red_and_cannot_be_pressed_again(self):
        st = guifix.idle("blocked")
        st["killswitch"] = dict(st["killswitch"], lockdown=True)
        self.show(st)
        page = self.page
        self.assertEqual((page.ks_badge.text(), self.tone(page.ks_badge)), ("LOCKDOWN", BAD))
        self.assertEqual(page.ks_detail.text(), "Everything is blocked, including the VPN.")
        self.assertFalse(page.lockdown_button.isEnabled())
        self.assertTrue(page.release_button.isEnabled())

    def test_a_kill_switch_switched_off_in_the_settings_cannot_be_armed_from_here(self):
        st = guifix.idle("unprotected")
        st["killswitch"] = dict(st["killswitch"], enabled=False)
        self.show(st)
        self.assertEqual(self.page.ks_badge.text(), "OFF")
        self.assertFalse(self.page.arm_button.isEnabled())

    def test_the_three_buttons_announce_what_they_mean(self):
        self.show(guifix.status())
        asked = record(self.page.killswitch_requested)
        self.page.release_button.click()
        self.page.lockdown_button.click()
        self.page.arm_button.click()                 # disabled: armed already
        self.assertEqual(asked, [("off",), ("lockdown",)])
        self.show(guifix.idle("unprotected"))
        self.page.arm_button.click()
        self.assertEqual(asked[-1], ("on",))
        self.assertEqual(len(asked), 3)

    def test_while_a_connection_attempt_runs_arming_and_releasing_wait_but_lockdown_does_not(self):
        self.show(guifix.status(), busy=frozenset({"connect"}))
        page = self.page
        self.assertEqual([b.isEnabled() for b in (page.arm_button, page.release_button, page.lockdown_button)],
                         [False, False, True])

    def test_the_hardening_rows(self):
        self.show(guifix.status())
        h = self.page.hardening
        self.assertEqual(h.text("DNS"), "Locked to 10.0.0.1")
        self.assertEqual(h.text("IPv6"), "Switched off on the physical interfaces")
        self.assertEqual(h.text("MAC address"), "Unchanged")
        self.assertEqual(h._values["DNS"].property("tone"), GOOD)
        self.assertEqual(h._values["MAC address"].property("tone"), MUTED)

    def test_a_program_that_changed_the_dns_behind_our_back_is_flagged(self):
        st = guifix.status()
        st["hardening"] = dict(st["hardening"], dns_intact=False)
        self.show(st)
        self.assertEqual(self.page.hardening.text("DNS"), "Locked to 10.0.0.1 - changed by another program!")
        self.assertEqual(self.page.hardening._values["DNS"].property("tone"), BAD)


class RotationCardTests(DashboardCase):
    def test_a_running_rotation(self):
        d = self.show(guifix.status())
        page = self.page
        self.assertEqual((page.rotation_state.text(), self.tone(page.rotation_state)), (d.rotation.state, GOOD))
        self.assertTrue(page.rotation_state.text().startswith("Running: a new address every"))
        self.assertEqual(page.rotation_counts.text(), "8 changed, 1 failed, 1 unchanged, 0 skipped")
        self.assertIn("198.51.100.7", page.rotation_last.text())
        self.assertEqual(self.tone(page.rotation_last), GOOD)
        self.assertEqual([b.isEnabled() for b in (page.start_button, page.now_button, page.stop_button,
                                                  page.cancel_button)], [False, True, True, False])
        self.assertTrue(page.rotation_hint.isHidden())          # "already running" would only be noise

    def test_a_stopped_rotation_with_profiles_can_be_started(self):
        self.show(guifix.idle("unprotected"))
        page = self.page
        self.assertEqual((page.rotation_state.text(), self.tone(page.rotation_state)), ("Stopped", MUTED))
        self.assertTrue(page.rotation_counts.isHidden())
        self.assertTrue(page.rotation_last.isHidden())
        self.assertTrue(page.rotation_problem.isHidden())
        self.assertTrue(page.rotation_hint.isHidden())
        self.assertEqual([b.isEnabled() for b in (page.start_button, page.now_button, page.stop_button,
                                                  page.cancel_button)], [True, True, False, False])

    def test_nothing_can_start_without_a_usable_profile_and_the_page_says_why(self):
        st = guifix.idle("unprotected")
        st["profiles"] = {"total": 3, "usable": 0}
        self.show(st)
        page = self.page
        self.assertFalse(page.start_button.isEnabled())
        self.assertFalse(page.now_button.isEnabled())
        self.assertFalse(page.rotation_hint.isHidden())
        self.assertEqual(page.rotation_hint.text(), "No usable VPN profile: import one on the Profiles page.")

    def test_while_connecting_only_cancel_and_stop_are_offered(self):
        st = guifix.idle("blocked")
        st["vpn"] = dict(st["vpn"], state="connecting", busy="Connecting")
        self.show(st)
        page = self.page
        self.assertEqual([b.isEnabled() for b in (page.start_button, page.now_button, page.stop_button,
                                                  page.cancel_button)], [False, False, True, True])
        self.assertEqual(page.rotation_hint.text(), "Busy: wait for the current operation to finish.")

    def test_a_command_in_flight_locks_the_start_button_until_it_is_answered(self):
        self.show(guifix.idle("unprotected"), busy=frozenset({"rotate_start"}))
        self.assertFalse(self.page.start_button.isEnabled())
        self.show(guifix.idle("unprotected"))
        self.assertTrue(self.page.start_button.isEnabled())

    def test_the_daemon_being_unreachable_disables_every_button_that_acts(self):
        self.show(None)
        page = self.page
        for b in (page.start_button, page.now_button, page.stop_button, page.cancel_button, page.arm_button,
                  page.release_button, page.lockdown_button):
            self.assertFalse(b.isEnabled(), b.text())

    def test_start_sends_the_interval_in_the_box(self):
        self.show(guifix.idle("unprotected"))
        starts = record(self.page.start_requested)
        self.page.interval.setValue(2.5)
        self.page.start_button.click()
        self.assertEqual(starts, [(2.5,)])

    def test_a_disabled_start_sends_nothing(self):
        self.show(guifix.status())
        starts = record(self.page.start_requested)
        self.page.start_button.click()
        self.assertEqual(starts, [])

    def test_the_other_buttons_announce_themselves(self):
        st = guifix.idle("blocked")
        st["vpn"] = dict(st["vpn"], state="connecting", busy="Connecting")
        self.show(st)
        stops, nows, cancels = (record(s) for s in (self.page.stop_requested, self.page.rotate_now_requested,
                                                    self.page.cancel_requested))
        self.page.stop_button.click()
        self.page.cancel_button.click()
        self.page.now_button.click()                   # disabled while connecting
        self.assertEqual((stops, nows, cancels), ([()], [], [()]))
        self.show(guifix.status())
        self.page.now_button.click()
        self.assertEqual(nows, [()])

    def test_the_countdown_changes_only_its_own_label(self):
        self.show(guifix.status())
        before = self.texts(self.page.rotation_state.parent())
        self.page.set_countdown("next change in 0.6 s")
        self.assertEqual(self.page.countdown.text(), "next change in 0.6 s")
        self.assertEqual(self.texts(self.page.rotation_state.parent())[:1], before[:1])


class IntervalBoxTests(DashboardCase):
    def test_the_box_takes_the_daemons_interval_the_first_time_and_when_the_daemon_changes_it(self):
        self.show(guifix.idle("unprotected"))
        self.assertEqual(self.page.interval.value(), 30.0)
        self.show(guifix.status())                         # started from the CLI with --interval 1
        self.assertEqual(self.page.interval.value(), 1.0)

    def test_what_the_user_typed_survives_the_next_status_update(self):
        self.show(guifix.idle("unprotected"))
        self.page.interval.setValue(12.0)
        self.show(guifix.idle("unprotected"))              # the daemon still says 30
        self.assertEqual(self.page.interval.value(), 12.0)

    def test_a_box_being_edited_is_left_alone_when_the_daemon_changes_its_mind(self):
        self.show(guifix.idle("unprotected"))
        self.page.interval.setFocus()
        self.page.interval.setValue(12.0)
        self.show(guifix.status())                         # the daemon now says 1.0
        self.assertEqual(self.page.interval.value(), 12.0)

    def test_after_forget_interval_the_next_update_takes_the_daemons_value_again(self):
        self.show(guifix.idle("unprotected"))
        self.page.interval.setValue(12.0)
        self.page.forget_interval()
        self.show(guifix.idle("unprotected"))
        self.assertEqual(self.page.interval.value(), 30.0)

    def test_showing_the_daemons_interval_is_not_an_edit(self):
        sent = record(self.page.interval_changed)
        self.show(guifix.status())
        self.pump(5)
        self.assertEqual(sent, [])
        self.assertFalse(self.page._interval_timer.isActive())

    def test_set_interval_is_silent_and_starts_no_timer(self):
        sent = record(self.page.interval_changed)
        self.page.set_interval(7.0)
        self.assertEqual(self.page.interval.value(), 7.0)
        self.pump(5)
        self.assertEqual(sent, [])

    def test_an_edit_is_announced_once_when_the_typing_has_stopped(self):
        sent = record(self.page.interval_changed)
        self.page.interval.setValue(2.0)
        self.pump(0.3)
        self.page.interval.setValue(3.0)
        self.pump(0.45)
        self.assertEqual(sent, [])
        self.pump(0.1)
        self.assertEqual(sent, [(3.0,)])
        self.pump(5)
        self.assertEqual(sent, [(3.0,)])

    def test_the_advice_follows_the_box(self):
        self.page.advice_fn = lambda v: "slow: OpenVPN is in the rotation" if v < 5 else ""
        self.page.interval.setValue(3.0)
        self.assertEqual(self.page.rotation_advice.text(), "slow: OpenVPN is in the rotation")
        self.assertFalse(self.page.rotation_advice.isHidden())
        self.page.interval.setValue(10.0)
        self.assertTrue(self.page.rotation_advice.isHidden())

    def test_the_advice_is_also_shown_when_the_daemons_interval_arrives(self):
        self.page.advice_fn = lambda v: "slow" if v < 5 else ""
        self.show(guifix.status())                         # the daemon rotates every 1 s
        self.assertEqual(self.page.rotation_advice.text(), "slow")
        self.assertFalse(self.page.rotation_advice.isHidden())


class PrivacyAndAlertsTests(DashboardCase):
    def test_the_privacy_line_says_when_nothing_was_tested(self):
        d = self.show(guifix.status())
        self.assertEqual(self.page.privacy_line.text(), d.privacy)
        self.assertEqual(self.page.privacy_line.text(), "Not tested yet. Run the privacy check on the Privacy page.")
        self.assertEqual(self.tone(self.page.privacy_line), MUTED)

    def test_the_privacy_line_shows_the_grade_in_its_colour(self):
        st = guifix.status()
        st["privacy"] = {"grade": "D", "score": 41, "verdict": "at-risk", "ts": 1990.0}
        d = self.show(st, now=2000.0)
        self.assertTrue(self.page.privacy_line.text().startswith("Grade D (41/100): at-risk"))
        self.assertEqual(self.page.privacy_line.text(), d.privacy)
        self.assertEqual(self.tone(self.page.privacy_line), BAD)

    def test_the_privacy_buttons(self):
        self.show(guifix.status())
        runs, gone = record(self.page.privacy_requested), record(self.page.goto)
        self.page.check_button.click()
        self.page.open_privacy.click()
        self.assertEqual((runs, gone), ([("full",)], [("Privacy",)]))

    def test_alerts_show_the_newest_first_with_their_hints(self):
        events = [event("error", "connect_failed", "first failure", "try another", ts=1000.0),
                  event("info", "connected", "not an alert", ts=1001.0),
                  event("warning", "tunnel_lost", "second warning", ts=1002.0)]
        self.show(guifix.status(), alerts=views.alert_rows(events))
        self.assertEqual(self.page.alerts.count, 2)
        shown = self.texts(self.page.alerts)
        self.assertLess(shown.index("second warning"), shown.index("first failure"))
        self.assertIn("try another", shown)
        self.assertNotIn("not an alert", shown)

    def test_no_alerts_says_so(self):
        self.show(guifix.status())
        self.assertEqual(self.texts(self.page.alerts), ["No warnings or errors."])

    def test_alert_text_from_the_network_is_never_taken_for_markup(self):
        events = [event("error", "connect_failed", "<a href='http://evil'>click</a>")]
        self.show(guifix.status(), alerts=views.alert_rows(events))
        labels = [lab for lab in self.page.alerts.findChildren(QLabel) if "evil" in lab.text()]
        self.assertEqual(len(labels), 1)
        self.assertIs(labels[0].textFormat(), Qt.TextFormat.PlainText)


class RefreshTests(DashboardCase):
    def test_an_identical_update_rebuilds_no_row(self):
        events = views.alert_rows([event("error", "connect_failed", "x")])
        st = guifix.status()
        st["profiles"] = {"total": 0, "usable": 0}
        self.show(st, alerts=events)
        before = {name: list(getattr(self.page, name).findChildren(QLabel))
                  for name in ("problems", "private_ips", "alerts")}
        self.show(st, alerts=events)
        self.app.processEvents()
        for name, labels in before.items():
            now = list(getattr(self.page, name).findChildren(QLabel))
            self.assertTrue(all(a is b for a, b in zip(labels, now)) and len(labels) == len(now), name)

    def test_the_tone_is_applied_again_only_when_it_changes(self):
        self.show(guifix.status())
        log = len(self.page.banner.title._polish_log)
        self.show(guifix.status())
        self.assertEqual(len(self.page.banner.title._polish_log), log)
        self.show(guifix.idle("unprotected"))
        self.assertGreater(len(self.page.banner.title._polish_log), log)


if __name__ == "__main__":
    unittest.main()
