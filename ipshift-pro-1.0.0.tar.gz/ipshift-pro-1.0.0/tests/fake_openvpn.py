#!/usr/bin/env python3
"""Stands in for the openvpn binary in the test-suite.

Reads --config like the real thing and prints realistic log lines.  The last
octet of the remote address picks the behaviour:
  .66 authentication failure   .67 hangs forever   .68 fatal error then exit
  .69 exits silently           anything else: connects and stays up
If FAKE_OVPN_COPY is set the config text and file mode are copied there so the
test can inspect what the backend generated (the backend deletes the original).
"""
import os
import re
import signal
import stat
import sys
import time

conf = sys.argv[sys.argv.index("--config") + 1]
text = open(conf).read()
if os.environ.get("FAKE_OVPN_COPY"):
    with open(os.environ["FAKE_OVPN_COPY"], "w") as fh:
        fh.write(oct(stat.S_IMODE(os.stat(conf).st_mode)) + "\n" + text)
ip = re.search(r"^remote (\S+) (\d+) (\S+)", text, re.M).group(1)


def term(*_):
    print("SIGTERM[hard,] received, process exiting", flush=True)
    sys.exit(0)


signal.signal(signal.SIGTERM, term)
print("OpenVPN 2.6.12 (fake) starting", flush=True)
mode = ip.rsplit(".", 1)[-1]
if mode == "66":
    print("AUTH: Received control message: AUTH_FAILED", flush=True)
    time.sleep(60)
elif mode == "67":
    time.sleep(120)
elif mode == "68":
    print("Options error: Unrecognized option or missing parameter(s)", flush=True)
    print("Exiting due to fatal error", flush=True)
    sys.exit(1)
elif mode == "69":
    sys.exit(0)
else:
    time.sleep(0.15)
    print("PUSH: Received control message: 'PUSH_REPLY,route-gateway 10.8.0.1,dhcp-option DNS 10.8.0.1,"
          "dhcp-option DNS 10.8.0.2,ifconfig 10.8.0.6 255.255.255.0'", flush=True)
    print("Initialization Sequence Completed", flush=True)
    while True:
        time.sleep(0.2)
