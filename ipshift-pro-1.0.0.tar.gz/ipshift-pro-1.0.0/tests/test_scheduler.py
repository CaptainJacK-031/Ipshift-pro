"""Rotation scheduler: interval floor, strategies, timing, retries, alerts."""
from __future__ import annotations

import random
import time
import unittest

from helpers import TmpRootCase
from simharness import SimStack

from ipshift.config import Config, RotationConfig
from ipshift.errors import BusyError, ConfigError
from ipshift.paths import default_paths
from ipshift.scheduler import RotationScheduler, Selector, check_interval
from ipshift.vpn.profile import Endpoint, Profile, ProfileStore, make_id


class FakeClock:
    def __init__(self, now=1000.0):
        self.now = now

    def __call__(self):
        return self.now


def add_profile(store, name, *, provider="", country="", tier="paid", protocol="wireguard", ip=None):
    p = Profile(make_id(name, "x"), name, protocol, tier=tier, provider=provider, country=country)
    p.endpoints = [Endpoint(f"{p.id}.example", 51820, "udp", [ip or "203.0.113.9"])]
    store.add(p, "x")
    return p


class IntervalTests(unittest.TestCase):
    def test_floor(self):
        self.assertEqual(check_interval(1), 1.0)
        self.assertEqual(check_interval("2.5"), 2.5)
        for bad in (0, 0.5, 0.999, -1, "abc", None, float("nan"), float("inf"), float("-inf")):
            with self.assertRaises(ConfigError, msg=repr(bad)):
                check_interval(bad)


class SelectorTests(TmpRootCase):
    def setUp(self):
        super().setUp()
        self.store = ProfileStore(default_paths().profiles_dir)
        self.cfg = RotationConfig()

    def sel(self, **kw):
        for k, v in kw.items():
            setattr(self.cfg, k, v)
        return Selector(self.store, self.cfg, random.Random(7))

    def test_round_robin_cycles_through_everything(self):
        ps = [add_profile(self.store, n) for n in ("a", "b", "c", "d")]
        sel = self.sel(strategy="round-robin")
        seen, cur = [], None
        for _ in range(8):
            cur = sel.pick(cur)
            seen.append(cur.id)
        ids = sorted(p.id for p in ps)
        self.assertEqual(sorted(set(seen)), ids)
        self.assertTrue(all(seen[i] != seen[i + 1] for i in range(len(seen) - 1)))
        self.assertEqual(seen[:4], seen[4:])                          # a full lap repeats

    def test_random_never_returns_the_current_profile(self):
        ps = [add_profile(self.store, n) for n in ("a", "b", "c")]
        sel = self.sel(strategy="random")
        for _ in range(60):
            self.assertNotEqual(sel.pick(ps[0]).id, ps[0].id)

    def test_lru_prefers_unused_then_oldest(self):
        ps = [add_profile(self.store, n) for n in ("a", "b", "c")]
        self.store.record_result(ps[1].id, True, 10, "1.1.1.1")
        time.sleep(0.01)
        self.store.record_result(ps[2].id, True, 10, "1.1.1.2")
        sel = self.sel(strategy="lru")
        self.assertEqual(sel.pick(None).id, ps[0].id)                  # never used
        self.assertEqual(sel.pick(ps[0]).id, ps[1].id)                 # oldest of the used ones

    def test_diverse_changes_provider_and_country(self):
        cur = add_profile(self.store, "cur", provider="Acme", country="DE")
        same_country = add_profile(self.store, "samecc", provider="Other", country="DE")
        same_provider = add_profile(self.store, "sameprov", provider="Acme", country="NL")
        different = add_profile(self.store, "different", provider="Other", country="SE")
        sel = self.sel(strategy="diverse")
        self.assertEqual(sel.pick(cur).id, different.id)
        self.store.update(different.id, enabled=False)
        self.assertEqual(sel.pick(cur).id, same_provider.id)           # same provider (+1) beats same country (+2)
        self.assertNotEqual(sel.pick(cur).id, same_country.id)

    def test_filters(self):
        a = add_profile(self.store, "a", tier="free")
        b = add_profile(self.store, "b", tier="paid")
        c = add_profile(self.store, "c", tier="self-hosted")
        self.assertEqual({p.id for p in self.sel(tiers=["free", "self-hosted"]).candidates()}, {a.id, c.id})
        self.cfg.tiers = []
        self.assertEqual({p.id for p in self.sel(profiles=["B", c.id, "does-not-exist"]).candidates()}, {b.id, c.id})

    def test_unusable_profiles_are_never_picked(self):
        a, b, c = (add_profile(self.store, n) for n in ("a", "b", "c"))
        self.store.update(b.id, enabled=False)
        for _ in range(3):
            self.store.record_result(c.id, False, error="down")        # quarantined
        sel = self.sel(strategy="random")
        self.assertEqual([p.id for p in sel.candidates()], [a.id])

    def test_tried_profiles_are_skipped_until_none_is_left(self):
        ps = [add_profile(self.store, n) for n in ("a", "b", "c")]
        sel = self.sel(strategy="random")
        self.assertEqual(sel.pick(None, {ps[0].id, ps[1].id}).id, ps[2].id)
        self.assertIn(sel.pick(None, {p.id for p in ps}).id, {p.id for p in ps})   # all tried: start over

    def test_nowhere_to_go(self):
        sel = self.sel()
        self.assertIsNone(sel.pick(None))
        a = add_profile(self.store, "a")
        self.assertIsNone(sel.pick(a))                                  # only the current one
        self.assertEqual(sel.pick(None).id, a.id)                       # but fine when nothing is connected


class StepCase(TmpRootCase):
    """Drives ``step()`` directly with a fake clock: fast and fully deterministic."""

    def setUp(self):
        super().setUp()
        self.s = SimStack(self.tmp)
        self.addCleanup(self.s.close)
        self.clock = FakeClock()
        self.cfg = self.s.cfg
        self.cfg.rotation.interval = 1.0
        self.cfg.rotation.strategy = "round-robin"
        self.sched = RotationScheduler(self.cfg, self.s.mgr, self.s.store, self.s.bus, clock=self.clock,
                                       rng=random.Random(3))

    def takes(self, seconds):
        orig = self.s.mgr.activate

        def wrapped(ref, reason="manual"):
            try:
                return orig(ref, reason=reason)
            finally:
                self.clock.now += seconds
        self.s.mgr.activate = wrapped


class TimingTests(StepCase):
    def test_start_to_start_schedule(self):
        self.assertEqual(self.sched.step(), 1.0)                       # instant rotation: wait the whole interval
        self.takes(0.4)
        self.assertAlmostEqual(self.sched.step(), 0.6, places=6)       # the 0.4 s of work counts against the interval
        self.assertEqual(self.sched.skipped, 0)

    def test_overrunning_rotation_skips_ticks_instead_of_overlapping(self):
        self.takes(2.3)
        self.assertAlmostEqual(self.sched.step(), 0.7, places=6)       # next start on the 3.0 s grid
        self.assertEqual(self.sched.skipped, 2)
        ev = self.s.last_event("rotation_overrun")
        self.assertEqual(ev.data["skipped"], 2)

    def test_larger_interval(self):
        self.cfg.rotation.interval = 30.0
        self.takes(1.5)
        self.assertAlmostEqual(self.sched.step(), 28.5, places=6)

    def test_jitter_stays_within_bounds_and_above_the_floor(self):
        self.cfg.rotation.jitter_pct = 90.0
        vals = [self.sched._cycle_interval() for _ in range(400)]
        self.assertGreaterEqual(min(vals), 1.0)
        self.assertLessEqual(max(vals), 1.9 + 1e-9)
        self.assertGreater(len(set(vals)), 100)

    def test_no_jitter_by_default(self):
        self.assertEqual({self.sched._cycle_interval() for _ in range(20)}, {1.0})

    def test_floor_is_enforced_when_starting_and_changing(self):
        with self.assertRaises(ConfigError):
            self.sched.start(0.5)
        self.assertFalse(self.sched.running)
        self.assertEqual(self.cfg.rotation.interval, 1.0)
        with self.assertRaises(ConfigError):
            self.sched.set_interval(0.99)
        self.cfg.rotation.interval = 0.2                              # a bad value that slipped in some other way
        with self.assertRaises(ConfigError):
            self.sched.start()
        self.assertEqual(self.sched._cycle_interval(), 1.0)           # and the timer still never goes below 1 s


class OutcomeTests(StepCase):
    def test_success_records_the_rotation(self):
        self.sched.step()
        self.sched.step()
        self.assertEqual((self.sched.ticks, self.sched.ok, self.sched.failed), (2, 2, 0))
        self.assertEqual(self.sched.last["status"], "success")
        self.assertIn(self.sched.last["via"], ("connect", "hot-swap"))
        rows = self.s.history.recent_rotations()
        self.assertEqual([r["reason"] for r in rows], ["rotate", "start"])
        self.assertNotEqual(rows[0]["new_ip"], rows[1]["new_ip"])

    def test_failures_retry_quickly_with_backoff_and_a_different_profile_each_time(self):
        self.cfg.rotation.interval = 30.0
        self.cfg.rotation.max_failures = 3
        for p in self.s.profiles():
            self.s.world.fail[p.id] = "simulated outage"
        waits, tried = [], []
        orig = self.s.mgr.activate
        self.s.mgr.activate = lambda ref, reason="manual": (tried.append(ref), orig(ref, reason=reason))[1]
        for _ in range(6):
            waits.append(self.sched.step())
        self.assertEqual(waits, [1.0, 2.0, 4.0, 8.0, 16.0, 30.0])        # doubles, never longer than the interval
        self.assertEqual(len(set(tried)), 6)                               # no hammering of one dead server
        self.assertEqual(self.sched.consecutive_failures, 6)
        stalled = [e for e in self.s.events if e.kind == "rotation_stalled"]
        self.assertEqual(len(stalled), 1)                                  # one alert per streak, not one per failure
        self.assertEqual(stalled[0].level, "critical")
        self.assertEqual(stalled[0].data["failures"], 3)

    def test_backoff_is_capped(self):
        self.cfg.rotation.interval = 300.0
        self.cfg.rotation.backoff_max = 5.0
        for p in self.s.profiles():
            self.s.world.fail[p.id] = "down"
        self.assertEqual([self.sched.step() for _ in range(5)], [1.0, 2.0, 4.0, 5.0, 5.0])

    def test_recovery_after_a_stall_is_announced(self):
        self.cfg.rotation.max_failures = 2
        for p in self.s.profiles():
            self.s.world.fail[p.id] = "down"
        for _ in range(3):
            self.sched.step()
        self.assertTrue(self.sched.status()["stalled"])
        self.s.world.fail.clear()
        self.assertEqual(self.sched.step(), 1.0)
        self.assertFalse(self.sched.status()["stalled"])
        self.assertEqual(self.sched.consecutive_failures, 0)
        self.assertEqual(self.s.last_event("rotation_recovered").data["after_failures"], 3)

    def test_unchanged_exit_address_is_not_a_failure_but_is_reported_after_three(self):
        profiles = self.s.profiles()
        same = self.s.world.server_for(profiles[0]).exit_ip
        for p in profiles:
            self.s.world.server_for(p).exit_ip = same                    # every server exits from the same address
        for _ in range(5):
            self.sched.step()
        self.assertEqual(self.sched.failed, 0)
        self.assertEqual(self.sched.unchanged, 4)                         # the first one is the initial connect
        self.assertEqual(self.sched.last["status"], "unchanged")
        self.assertEqual(len([e for e in self.s.events if e.kind == "rotation_unchanged_streak"]), 1)

    def test_a_single_profile_means_idle_not_failure(self):
        for p in self.s.profiles()[1:]:
            self.s.store.remove(p.id)
        self.assertEqual(self.sched.step(), 1.0)                           # connects
        self.assertEqual(self.sched.step(), 1.0)                           # nothing to rotate to
        self.assertEqual(self.sched.step(), 1.0)
        self.assertEqual((self.sched.failed, self.sched.ok, self.sched.ticks), (0, 1, 1))
        self.assertEqual(len([e for e in self.s.events if e.kind == "rotation_idle"]), 1)   # warned once
        self.assertEqual(self.s.mgr.state, "connected")

    def test_a_busy_manager_means_a_skipped_tick(self):
        self.s.mgr._op.acquire()
        try:
            self.sched.step()
        finally:
            self.s.mgr._op.release()
        self.assertEqual((self.sched.skipped, self.sched.failed, self.sched.ticks), (1, 0, 0))

    def test_unexpected_exception_does_not_escape(self):
        def boom(ref, reason="manual"):
            raise RuntimeError("bug")
        self.s.mgr.activate = boom
        with self.assertLogs("ipshift.scheduler", "ERROR"):
            self.assertEqual(self.sched.step(), 1.0)
        self.assertEqual(self.sched.failed, 1)
        self.assertIn("bug", self.sched.last["error"])

    def test_rotate_now_without_the_timer_and_while_busy(self):
        res = self.sched.rotate_now()
        self.assertTrue(self.s.mgr.status()["connected"])
        self.assertEqual(res.profile_id, self.s.mgr.status()["profile"]["id"])
        self.assertFalse(self.sched.running)
        self.sched._attempt_lock.acquire()
        try:
            with self.assertRaises(BusyError):
                self.sched.rotate_now()
        finally:
            self.sched._attempt_lock.release()


class ThreadTests(TmpRootCase):
    def setUp(self):
        super().setUp()
        self.s = SimStack(self.tmp)
        self.addCleanup(self.s.close)
        self.cfg = self.s.cfg
        self.cfg.rotation.strategy = "round-robin"
        self.sched = RotationScheduler(self.cfg, self.s.mgr, self.s.store, self.s.bus)
        self.addCleanup(self.sched.stop)

    def wait_for(self, cond, timeout):
        end = time.monotonic() + timeout
        while time.monotonic() < end:
            if cond():
                return True
            time.sleep(0.02)
        return cond()

    def test_one_second_rotation_runs_for_real(self):
        t0 = time.monotonic()
        self.sched.start(1.0)
        self.assertTrue(self.wait_for(lambda: self.sched.ok >= 3, 6))
        elapsed = time.monotonic() - t0
        self.assertGreaterEqual(elapsed, 2.0)                           # three rotations need two full intervals
        self.assertLess(elapsed, 4.5)
        self.assertEqual(self.sched.failed, 0)
        ips = [r["new_ip"] for r in self.s.history.recent_rotations()]
        self.assertEqual(len(set(ips[:3])), 3)                          # every rotation really changed the exit IP
        st = self.sched.status()
        self.assertTrue(st["running"] and st["interval"] == 1.0)
        self.assertLessEqual(st["next_in"], 1.0)
        self.assertEqual(self.s.last_event("rotation_started").data["interval"], 1.0)

    def test_stop_interrupts_a_hanging_connection_quickly(self):
        for p in self.s.profiles():
            self.s.world.stuck.add(p.id)
        self.cfg.vpn.connect_timeout = 30.0
        self.sched.start(5.0)
        self.assertTrue(self.wait_for(lambda: self.s.mgr.state == "connecting", 3))
        t0 = time.monotonic()
        self.sched.stop()
        self.assertLess(time.monotonic() - t0, 3)
        self.assertFalse(self.sched.running)
        self.assertEqual(self.s.last_event("rotation_stopped").kind, "rotation_stopped")

    def test_changing_the_interval_while_running(self):
        self.sched.start(60.0)
        self.assertTrue(self.wait_for(lambda: self.sched.ok >= 1, 3))
        self.assertGreater(self.sched.status()["next_in"], 50)
        self.sched.set_interval(1.0)
        self.assertTrue(self.wait_for(lambda: self.sched.ok >= 2, 4))
        with self.assertRaises(ConfigError):
            self.sched.set_interval(0.5)
        self.assertEqual(self.sched.interval, 1.0)

    def test_starting_twice_only_updates_the_interval(self):
        self.sched.start(60.0, immediate=False)
        first = self.sched._thread
        self.sched.start(30.0)
        self.assertIs(self.sched._thread, first)
        self.assertEqual(self.sched.interval, 30.0)


if __name__ == "__main__":
    unittest.main()
