from __future__ import annotations

import base64
import json
import os
import subprocess
import threading
import time
import unittest
from pathlib import Path
from unittest import mock

from helpers import FakeRunner, TmpRootCase

from ipshift.config import VpnConfig
from ipshift.errors import DependencyError, ProfileError, VpnError, VpnTimeout
from ipshift.net.local import NetInfo
from ipshift.paths import default_paths
from ipshift.sysutil import CmdResult
from ipshift.vpn import wgconf
from ipshift.vpn.backend import ConnectRequest, Target
from ipshift.vpn.openvpn import OpenVPNBackend
from ipshift.vpn.profile import Profile
from ipshift.vpn.wireguard import WireGuardBackend, route_set

FAKE_OVPN = str(Path(__file__).with_name("fake_openvpn.py"))
CERT = "-----BEGIN CERTIFICATE-----\nMIIBkTCB+wIJAK\n-----END CERTIFICATE-----"


def key() -> str:
    return base64.b64encode(os.urandom(32)).decode()


class HybridRunner(FakeRunner):
    """Records/answers ``run`` like FakeRunner but launches real processes for ``popen``."""

    def popen(self, args, **kw):
        return subprocess.Popen([str(a) for a in args], **kw)


def route_reply(dev="wlan0", gw="192.168.1.1"):
    return (0, json.dumps([{"dst": "x", "gateway": gw, "dev": dev, "prefsrc": "192.168.1.23"}]))


class WgBase(TmpRootCase):
    def setUp(self):
        super().setUp()
        self.runner = FakeRunner()
        self.pub = key()
        self.handshake_ok = True
        self.runner.add("ip -j -4 route get", route_reply())
        self.runner.add("ip -j -4 route show default", (0, json.dumps([{"dev": "wlan0", "gateway": "192.168.1.1"}])))
        self.runner.add(lambda a: a[:2] == ("wg", "show"), lambda a: (0, f"{self.pub}\t{int(time.time()) if self.handshake_ok else 0}\n"))
        self.cfg = VpnConfig()
        self.paths = default_paths()
        self.net = NetInfo(self.runner, sysroot=self.tmp / "sys", procroot=self.tmp / "proc")
        self.backend = WireGuardBackend(self.cfg, self.runner, self.paths, self.net)
        self.priv = key()

    def conf(self, endpoint="vpn.example.net:51820", allowed="0.0.0.0/0, ::/0", extra=""):
        return (f"[Interface]\nPrivateKey = {self.priv}\nAddress = 10.2.0.2/32, fd00::2/128\nDNS = 10.2.0.1\n{extra}"
                f"[Peer]\nPublicKey = {self.pub}\nAllowedIPs = {allowed}\nEndpoint = {endpoint}\n")

    def req(self, ip="203.0.113.7", port=51820, timeout=2.0, conf=None, cancel=None):
        return ConnectRequest(Profile(id="p", name="p", protocol="wireguard"), conf or self.conf(),
                              Target(ip, port, "udp"), timeout=timeout, cancel=cancel or threading.Event())


class WireGuardTests(WgBase):
    def test_connect_issues_the_right_commands_in_a_safe_order(self):
        info = self.backend.connect(self.req())
        lines = self.runner.lines()
        order = [next(i for i, l in enumerate(lines) if l.startswith(p)) for p in (
            "ip -4 route replace 203.0.113.7/32 via 192.168.1.1 dev wlan0",   # server pinned first
            "ip link add dev ipshift0 type wireguard", "wg setconf ipshift0 /dev/stdin",
            "ip -4 address add 10.2.0.2/32 dev ipshift0", "ip link set dev ipshift0 mtu 1420 up",
            "ip -4 route replace 0.0.0.0/1 dev ipshift0")]
        self.assertEqual(order, sorted(order))
        self.assertTrue(self.runner.ran("ip -4 route replace 128.0.0.0/1 dev ipshift0"))
        self.assertTrue(self.runner.ran("ip -6 route replace ::/1 dev ipshift0"))
        self.assertTrue(self.runner.ran("ip -6 route replace 8000::/1 dev ipshift0"))
        self.assertFalse(any("route del default" in l or "route replace default" in l for l in self.runner.lines()))  # physical default route untouched
        setconf = [self.runner.inputs[i] for i, l in enumerate(lines) if l.startswith("wg setconf")][0]
        self.assertIn("Endpoint = 203.0.113.7:51820", setconf)                    # resolved address, not the hostname
        self.assertIn(f"PrivateKey = {self.priv}", setconf)
        self.assertEqual((info.backend, info.iface, info.dns, info.target.ip, info.ipv6),
                         ("wireguard", "ipshift0", ["10.2.0.1"], "203.0.113.7", True))
        self.assertEqual(info.local_ips, ["10.2.0.2", "fd00::2"])

    def test_private_key_never_appears_on_a_command_line(self):
        self.backend.connect(self.req())
        self.assertFalse(any(self.priv in " ".join(c) for c in self.runner.calls))

    def test_mtu_precedence(self):
        self.backend.connect(self.req(conf=self.conf(extra="MTU = 1300\n")))
        self.assertTrue(self.runner.ran("ip link set dev ipshift0 mtu 1300 up"))

    def test_missing_kernel_support_is_a_dependency_error_and_cleans_up(self):
        self.runner.add("ip link add", (2, "", "RTNETLINK answers: Operation not supported"))
        with self.assertRaises(DependencyError):
            self.backend.connect(self.req())
        self.assertTrue(self.runner.ran("ip link del dev ipshift0"))
        self.assertTrue(self.runner.ran("ip -4 route del 203.0.113.7/32"))             # pin removed again

    def test_handshake_timeout_tears_everything_down(self):
        self.handshake_ok = False
        t0 = time.time()
        with self.assertRaises(VpnTimeout):
            self.backend.connect(self.req(timeout=0.5))
        self.assertLess(time.time() - t0, 3)
        self.assertTrue(self.runner.ran("ip link del dev ipshift0"))
        self.assertFalse(self.backend.alive())

    def test_cancel_aborts_promptly(self):
        self.handshake_ok = False
        cancel = threading.Event()
        threading.Timer(0.3, cancel.set).start()
        t0 = time.time()
        with self.assertRaises(VpnError) as cm:
            self.backend.connect(self.req(timeout=20, cancel=cancel))
        self.assertIn("cancelled", str(cm.exception))
        self.assertLess(time.time() - t0, 3)

    def test_no_route_to_server_is_reported(self):
        self.runner.add("ip -j -4 route get", (1, "", "Network is unreachable"))
        self.runner.add("ip -j -4 route show default", (0, "[]"))
        with self.assertRaises(VpnError) as cm:
            self.backend.connect(self.req())
        self.assertIn("no network route", str(cm.exception))

    def test_hot_swap_retargets_without_touching_the_interface(self):
        self.backend.connect(self.req(ip="203.0.113.7"))
        self.runner.calls.clear()
        self.runner.inputs.clear()
        self.priv = key()                                                             # a different profile's key
        info = self.backend.hot_swap(self.req(ip="198.51.100.9", conf=self.conf(endpoint="b.example.net:443")))
        lines = self.runner.lines()
        self.assertTrue(any(l.startswith("wg syncconf ipshift0 /dev/stdin") for l in lines))
        self.assertFalse(any(l.startswith("ip link add") or l.startswith("ip link del") for l in lines))
        self.assertTrue(any(l.startswith("ip -4 route replace 198.51.100.9/32") for l in lines))
        self.assertTrue(any(l.startswith("ip -4 route del 203.0.113.7/32") for l in lines))     # old server unpinned
        i_pin = next(i for i, l in enumerate(lines) if "198.51.100.9/32" in l)
        i_sync = next(i for i, l in enumerate(lines) if l.startswith("wg syncconf"))
        self.assertLess(i_pin, i_sync)                                                # new server reachable first
        self.assertEqual(info.target.ip, "198.51.100.9")
        self.assertTrue(self.backend.alive())

    def test_hot_swap_removes_routes_the_new_profile_does_not_need(self):
        self.backend.connect(self.req())
        self.runner.calls.clear()
        self.backend.hot_swap(self.req(ip="198.51.100.9", conf=self.conf(allowed="0.0.0.0/0")))
        self.assertTrue(self.runner.ran("ip -6 route del ::/1 dev ipshift0"))
        self.assertTrue(self.runner.ran("ip -6 route del 8000::/1 dev ipshift0"))

    def test_hot_swap_requires_an_active_tunnel(self):
        with self.assertRaises(VpnError):
            self.backend.hot_swap(self.req())

    def test_disconnect_and_alive_and_health(self):
        self.backend.connect(self.req())
        self.assertTrue(self.backend.alive())
        self.assertIn("handshake_age", self.backend.health())
        self.backend.disconnect()
        self.assertTrue(self.runner.ran("ip link del dev ipshift0"))
        self.assertFalse(self.backend.alive())
        self.assertEqual(self.backend.health(), {})

    def test_stale_handshake_means_dead(self):
        self.backend.connect(self.req())
        self.runner.add(lambda a: a[:2] == ("wg", "show"), lambda a: (0, f"{self.pub}\t{int(time.time()) - 400}\n"))
        self.assertFalse(self.backend.alive())

    def test_network_change_repins_and_pokes_the_peer(self):
        self.backend.connect(self.req())
        self.runner.add("ip -j -4 route get", route_reply("usb0", "172.20.10.1"))
        self.runner.calls.clear()
        self.assertTrue(self.backend.on_network_change())
        self.assertTrue(self.runner.ran("ip -4 route replace 203.0.113.7/32 via 172.20.10.1 dev usb0"))
        self.assertTrue(self.runner.ran(f"wg set ipshift0 peer {self.pub} persistent-keepalive 25"))

    def test_route_set(self):
        cfg = wgconf.parse(self.conf(allowed="0.0.0.0/0, ::/0, 10.9.0.0/16"))
        self.assertEqual(route_set(cfg), {"0.0.0.0/1", "128.0.0.0/1", "::/1", "8000::/1", "10.9.0.0/16"})

    def test_available_reports_missing_tools(self):
        with mock.patch("ipshift.vpn.wireguard.which", lambda n: None):
            self.assertIn("wireguard-tools", self.backend.available())
        with mock.patch("ipshift.vpn.wireguard.which", lambda n: "/usr/bin/" + n):
            self.assertIsNone(self.backend.available())


class OpenVpnTests(TmpRootCase):
    def setUp(self):
        super().setUp()
        self.runner = HybridRunner()
        self.runner.add("ip -j addr show", (0, json.dumps([{"ifname": "ipshift0", "flags": ["UP"], "operstate": "UNKNOWN",
                                                          "addr_info": [{"family": "inet", "local": "10.8.0.6", "prefixlen": 24}]}])))
        self.cfg = VpnConfig(openvpn_bin=FAKE_OVPN, openvpn_user="nobody")
        self.paths = default_paths()
        self.net = NetInfo(self.runner, sysroot=self.tmp / "sys", procroot=self.tmp / "proc")
        self.backend = OpenVPNBackend(self.cfg, self.runner, self.paths, self.net)
        self.addCleanup(self.backend.disconnect)
        self.copy = self.tmp / "copy.txt"
        os.environ["FAKE_OVPN_COPY"] = str(self.copy)
        self.body = "client\nremote-cert-tls server\n<ca>\n" + CERT + "\n</ca>\n"

    def req(self, ip="203.0.113.9", timeout=5.0, auth=None, cancel=None):
        return ConnectRequest(Profile(id="o", name="o", protocol="openvpn"), self.body, Target(ip, 1194, "udp"),
                              auth=auth, timeout=timeout, cancel=cancel or threading.Event())

    def test_connect_parses_dns_and_addresses_and_cleans_up_secrets(self):
        info = self.backend.connect(self.req(auth=("alice", "s3cret")))
        self.assertEqual((info.backend, info.iface, info.dns, info.local_ips), ("openvpn", "ipshift0", ["10.8.0.1", "10.8.0.2"], ["10.8.0.6"]))
        self.assertTrue(self.backend.alive())
        mode, _, text = self.copy.read_text().partition("\n")
        self.assertEqual(mode, "0o600")                                              # secret-bearing file was private
        for needle in ("dev ipshift0", "remote 203.0.113.9 1194 udp", "redirect-gateway def1", "script-security 1",
                       "auth-user-pass ", "user nobody", "-----BEGIN CERTIFICATE-----"):
            self.assertIn(needle, text)
        run = self.paths.runtime_dir
        self.assertEqual(list(run.iterdir()), [])                                    # config + credentials deleted once up
        self.assertTrue(self.runner.ran("ip -4 route del 203.0.113.9/32") is False)     # not until disconnect
        self.backend.disconnect()
        self.assertFalse(self.backend.alive())
        self.assertTrue(self.runner.ran("ip -4 route del 203.0.113.9/32"))              # OpenVPN's host route removed
        self.assertTrue(self.runner.ran("ip link del dev ipshift0"))

    def test_disconnect_terminates_the_process_group(self):
        self.backend.connect(self.req())
        pid = self.backend._proc.pid
        self.backend.disconnect()
        with self.assertRaises(ProcessLookupError):
            os.kill(pid, 0)

    def test_authentication_failure(self):
        with self.assertRaises(VpnError) as cm:
            self.backend.connect(self.req(ip="203.0.113.66"))
        self.assertIn("authentication failed", str(cm.exception))
        self.assertEqual(list(self.paths.runtime_dir.iterdir()), [])                 # secrets scrubbed on failure too
        self.assertFalse(self.backend.alive())

    def test_hang_times_out_and_is_killed(self):
        t0 = time.time()
        with self.assertRaises(VpnTimeout):
            self.backend.connect(self.req(ip="203.0.113.67", timeout=1.0))
        self.assertLess(time.time() - t0, 8)
        self.assertFalse(self.backend.alive())

    def test_fatal_error_and_silent_exit(self):
        with self.assertRaises(VpnError) as cm:
            self.backend.connect(self.req(ip="203.0.113.68"))
        self.assertIn("rejected the configuration", str(cm.exception))
        with self.assertRaises(VpnError) as cm:
            self.backend.connect(self.req(ip="203.0.113.69"))
        self.assertIn("stopped before the tunnel came up", str(cm.exception))

    def test_cancel(self):
        cancel = threading.Event()
        threading.Timer(0.4, cancel.set).start()
        with self.assertRaises(VpnError) as cm:
            self.backend.connect(self.req(ip="203.0.113.67", timeout=30, cancel=cancel))
        self.assertIn("cancelled", str(cm.exception))
        self.assertFalse(self.backend.alive())

    def test_process_death_is_noticed(self):
        self.backend.connect(self.req())
        os.killpg(self.backend._proc.pid, 9)
        self.backend._proc.wait(3)
        self.assertFalse(self.backend.alive())

    def test_unknown_drop_user_falls_back_without_crashing(self):
        self.backend.cfg.openvpn_user = "no-such-user-xyz"
        self.backend.connect(self.req())
        self.assertNotIn("\nuser ", self.copy.read_text())

    def test_missing_binary(self):
        self.backend.cfg.openvpn_bin = str(self.tmp / "nope")
        with self.assertRaises(DependencyError):
            self.backend.connect(self.req())
        with mock.patch("ipshift.vpn.openvpn.which", lambda n: None):
            self.assertIn("not installed", self.backend.available())

    def test_reconnect_replaces_the_old_process(self):
        self.backend.connect(self.req(ip="203.0.113.9"))
        first = self.backend._proc.pid
        self.backend.connect(self.req(ip="203.0.113.10"))
        with self.assertRaises(ProcessLookupError):
            os.kill(first, 0)
        self.assertTrue(self.backend.alive())


if __name__ == "__main__":
    unittest.main()
