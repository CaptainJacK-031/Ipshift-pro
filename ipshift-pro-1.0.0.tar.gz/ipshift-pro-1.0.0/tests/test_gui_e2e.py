"""The GUI's logic layer against a real (simulated) daemon on a real socket: link, model and actions together."""
from __future__ import annotations

import os
import stat
import tempfile
import threading
import time
import unittest
from pathlib import Path

import helpers  # noqa: F401
from ipshift.gui import settings_schema as S
from ipshift.gui import views
from ipshift.gui.actions import Actions
from ipshift.gui.demo import DemoDaemon
from ipshift.gui.link import DaemonLink, Listener, Timing
from ipshift.gui.model import AppModel, IntervalSync
from ipshift.ipc.client import Client

WG_CONF = """[Interface]
PrivateKey = eJQLMQyDD9U2w+yRXIZRDqMwK6qgezuqHt5Gj/+f+4M=
Address = 10.2.0.2/32
DNS = 10.2.0.1

[Peer]
PublicKey = beXOeTLbYSUJa6BKlnJq8xaCzm9wj73i1lleYRlcRYs=
AllowedIPs = 0.0.0.0/0, ::/0
Endpoint = 203.0.113.50:51820
"""
OVPN_CONF = """client
dev tun
proto udp
remote 203.0.113.61 1194
remote-cert-tls server
auth-user-pass
cipher AES-256-GCM
<ca>
-----BEGIN CERTIFICATE-----
MIIBkTCB+wIJAK
AAAAAAAAAAA=
-----END CERTIFICATE-----
</ca>
"""
TIMING = Timing(poll=0.1, min_gap=0.02, profiles_every=0.5, profiles_gap=0.05, history_every=0.5, history_gap=0.05,
                reconnect=0.05, reconnect_max=0.1)


class Feed(Listener):
    """Does what the real window does: everything the link says goes into the model."""

    def __init__(self, model: AppModel):
        self.m = model
        self.notes, self.results, self.outcomes, self.links = [], [], [], []

    def on_link(self, up, error, hint):
        self.m.apply_link(up, error, hint)
        self.links.append(up)

    def on_status(self, status): self.m.apply_status(status)

    def on_event(self, event):
        note = self.m.apply_event(event)
        if note:
            self.notes.append(note)

    def on_data(self, name, data): self.m.apply_data(name, data)
    def on_busy(self, busy): self.m.apply_busy(busy)

    def on_result(self, result):
        self.results.append(result)
        self.outcomes.append(self.m.apply_result(result))


def wait(pred, timeout=15.0):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        try:
            if pred():
                return True
        except (TypeError, KeyError, AttributeError):
            pass                                              # not there yet
        time.sleep(0.02)
    return False


class E2E(unittest.TestCase):
    def setUp(self):
        self.demo = DemoDaemon(speed=0.0)
        self.demo.start()
        self.addCleanup(self.demo.stop)
        self.client = Client(self.demo.socket)
        self.model = AppModel()
        self.feed = Feed(self.model)
        self.link = DaemonLink(self.feed, lambda: Client(self.demo.socket), timing=TIMING).start()
        self.addCleanup(self.link.close)
        self.act = Actions(self.link, self.model)
        self.tmp = Path(tempfile.mkdtemp(prefix="ipshift-gui-test-"))
        self.addCleanup(lambda: __import__("shutil").rmtree(self.tmp, ignore_errors=True))
        self.assertTrue(wait(lambda: self.model.status is not None and self.model.profiles is not None), "no data")

    # ---- helpers ------------------------------------------------------------------------------------
    def result(self, name, since=0):
        self.assertTrue(wait(lambda: any(r.name == name for r in self.feed.results[since:])), f"no result for {name}")
        return next(r for r in self.feed.results[since:] if r.name == name)

    def run_and_wait(self, name, call):
        n = len(self.feed.results)
        call()
        return self.result(name, n)

    def profile(self, name):
        return next(r for r in self.model.profile_rows() if r.name == name)

    def level(self):
        return self.model.level

    # ---- the first look --------------------------------------------------------------------------------
    def test_the_first_look_at_an_idle_simulated_daemon(self):
        d = self.model.dashboard()
        self.assertEqual((d.banner.title, d.simulated), ("UNPROTECTED", True))
        self.assertTrue(d.controls.can_start)
        self.assertFalse(d.controls.can_stop)
        self.assertEqual(d.public.value, "hidden")
        self.assertTrue(d.public.offer_direct)
        self.assertEqual(d.profiles, "8 usable of 8")
        self.assertEqual(len(self.model.profile_rows()), 8)
        self.assertTrue(all(r.rotating for r in self.model.profile_rows()))
        self.assertEqual(d.rotation.interval, 30.0)
        self.assertGreaterEqual(len(d.private), 1)
        self.assertEqual(self.feed.links[0], True)

    # ---- rotation, with the 1-second minimum --------------------------------------------------------------
    def test_start_rotates_at_one_second_and_the_dashboard_follows(self):
        r = self.run_and_wait("rotate_start", lambda: self.act.start(1.0))
        self.assertTrue(r.ok, r.error)
        snap = {}

        def settled():                                   # a rotation can be mid-switch at any instant: take a
            d = self.model.dashboard()                   # consistent picture of a moment when it is not
            if d.banner.level == "protected" and d.vpn.connected and any(p.tunnel for p in d.private) \
                    and self.model.status["rotation"]["ok"] >= 3:
                snap["d"] = d
                return True
            return False
        self.assertTrue(wait(settled), "never saw a settled, protected moment after three rotations")
        d = snap["d"]
        self.assertEqual(d.banner.title, "PROTECTED")
        self.assertTrue(d.rotation.running)
        self.assertEqual(d.rotation.interval, 1.0)
        self.assertEqual(d.rotation.state, "Running: a new address every 1 s")
        self.assertEqual(d.public.tone, views.GOOD)
        self.assertTrue(d.public.value.startswith("198.51.100."), d.public.value)
        self.assertTrue(d.controls.can_stop and not d.controls.can_start)
        self.assertTrue(d.killswitch.armed)

    def test_the_gui_never_asks_for_less_than_one_second(self):
        for asked in (0.2, 0, -3, "x"):
            self.assertGreaterEqual(views.clean_interval(asked), 1.0)
        r = self.run_and_wait("rotate_start", lambda: self.act.start(0.2))
        self.assertTrue(r.ok, r.error)
        self.assertTrue(wait(lambda: self.model.status["rotation"]["running"]))
        self.assertEqual(self.model.status["rotation"]["interval"], 1.0)

    def test_the_daemon_refuses_a_shorter_interval_even_if_the_window_is_bypassed(self):
        r = self.run_and_wait("rotate_start", lambda: self.link.run("rotate_start", interval=0.5))
        self.assertFalse(r.ok)
        self.assertIn("1", r.message)
        self.assertFalse(self.client.status()["rotation"]["running"])
        r = self.run_and_wait("set_interval", lambda: self.link.run("set_interval", value=0.5))
        self.assertFalse(r.ok)

    def test_the_interval_can_be_changed_while_it_runs_and_the_box_follows_the_daemon(self):
        self.run_and_wait("rotate_start", lambda: self.act.start(5.0))
        self.assertTrue(wait(lambda: self.model.status["rotation"]["running"]
                             and self.model.status["rotation"]["interval"] == 5.0))
        sync = IntervalSync()
        self.assertEqual(sync.on_daemon(self.model.status["rotation"]["interval"]), 5.0)
        r = self.run_and_wait("set_interval", lambda: self.act.apply_interval(2.0))
        self.assertTrue(r.ok, r.error)
        self.assertTrue(wait(lambda: self.model.status["rotation"]["interval"] == 2.0))
        self.assertEqual(sync.on_daemon(self.model.status["rotation"]["interval"]), 2.0)

    def test_the_interval_is_only_kept_for_the_next_start_while_stopped(self):
        before = len(self.feed.results)
        self.assertEqual(self.act.apply_interval(7.0), 7.0)
        self.assertEqual(self.act.apply_interval(0.1), 1.0)
        time.sleep(0.3)
        self.assertEqual(len(self.feed.results), before, "nothing is sent to the daemon while stopped")

    def test_rotate_now(self):
        r = self.run_and_wait("rotate_now", self.act.rotate_now)
        self.assertTrue(r.ok, r.error)
        self.assertTrue(wait(lambda: self.level() == "protected"))
        self.assertIn("Connected to", self.feed.outcomes[-1].text)

    def test_the_slow_protocol_advice_appears_for_openvpn_at_one_second(self):
        self.assertIn("OpenVPN", self.model.advice(1.0))
        self.assertEqual(self.model.advice(30.0), "")

    # ---- the three ways to stop --------------------------------------------------------------------------
    def test_stop_rotation_only_keeps_the_vpn_and_the_kill_switch(self):
        self.run_and_wait("rotate_start", lambda: self.act.start(5.0))
        self.assertTrue(wait(lambda: self.level() == "protected"))
        r = self.run_and_wait("stop", lambda: self.act.stop("rotation"))
        self.assertTrue(r.ok, r.error)
        self.assertTrue(wait(lambda: not self.model.status["rotation"]["running"]))
        self.assertEqual(self.level(), "protected")
        self.assertIn("VPN stays connected", self.feed.outcomes[-1].text)

    def test_stop_and_keep_blocking(self):
        self.run_and_wait("rotate_start", lambda: self.act.start(5.0))
        self.assertTrue(wait(lambda: self.level() == "protected"))
        self.run_and_wait("stop", lambda: self.act.stop("block"))
        self.assertTrue(wait(lambda: self.level() == "blocked"))
        d = self.model.dashboard()
        self.assertEqual((d.banner.title, d.public.value, d.killswitch.armed), ("BLOCKED", "none", True))
        self.assertTrue(d.controls.can_stop, "a blocking firewall can still be released with Stop")

    def test_stop_and_restore_networking(self):
        self.run_and_wait("rotate_start", lambda: self.act.start(5.0))
        self.assertTrue(wait(lambda: self.level() == "protected"))
        self.run_and_wait("stop", lambda: self.act.stop("release"))
        self.assertTrue(wait(lambda: self.level() == "unprotected"))
        d = self.model.dashboard()
        self.assertEqual((d.banner.title, d.rotation.running, d.controls.can_stop), ("UNPROTECTED", False, False))
        self.assertIn("real address is visible", self.feed.outcomes[-1].text)

    # ---- the real address, only on request ---------------------------------------------------------------
    def test_the_real_address_is_looked_up_only_when_asked_and_forgotten_after_connecting(self):
        self.assertEqual(self.model.dashboard().public.value, "hidden")
        r = self.run_and_wait("ip", self.act.lookup_real_ip)
        self.assertTrue(r.ok, r.error)
        p = self.model.dashboard().public
        self.assertEqual((p.value, p.tone, p.offer_direct), ("192.0.2.77", views.BAD, False))
        self.run_and_wait("connect", lambda: self.act.connect_profile(self.profile("Demo WG Amsterdam").id))
        self.assertTrue(wait(lambda: self.level() == "protected"))
        self.assertIsNone(self.model.direct)
        self.assertNotEqual(self.model.dashboard().public.value, "192.0.2.77")

    # ---- profiles ----------------------------------------------------------------------------------------
    def test_connect_to_one_chosen_profile(self):
        ams = self.profile("Demo WG Amsterdam")
        r = self.run_and_wait("connect", lambda: self.act.connect_profile(ams.id))
        self.assertTrue(r.ok, r.error)
        self.assertEqual(self.feed.outcomes[-1].tone, views.GOOD)
        self.assertTrue(wait(lambda: self.profile("Demo WG Amsterdam").active))
        self.assertEqual(self.profile("Demo WG Amsterdam").state, "Active")
        self.assertEqual(self.model.dashboard().vpn.profile, "Demo WG Amsterdam")

    def test_connecting_to_a_profile_that_does_not_exist_is_a_readable_failure(self):
        r = self.run_and_wait("connect", lambda: self.act.connect_profile("no-such-profile"))
        self.assertFalse(r.ok)
        self.assertEqual(self.feed.outcomes[-1].tone, views.BAD)
        self.assertTrue(self.feed.outcomes[-1].text)

    def test_disabling_and_removing_a_profile(self):
        tokyo = self.profile("Demo OVPN Tokyo")
        self.run_and_wait("profile_update", lambda: self.act.set_enabled(tokyo.id, False))
        self.assertTrue(wait(lambda: self.profile("Demo OVPN Tokyo").state == "Disabled"))
        self.assertFalse(self.profile("Demo OVPN Tokyo").rotating)
        self.assertEqual(self.model.dashboard().profiles, "7 usable of 8")
        self.run_and_wait("profile_update", lambda: self.act.set_enabled(tokyo.id, True))
        self.assertTrue(wait(lambda: self.profile("Demo OVPN Tokyo").state == "Ready"))
        self.run_and_wait("profile_remove", lambda: self.act.remove_profile(tokyo.id))
        self.assertTrue(wait(lambda: len(self.model.profile_rows()) == 7))

    def test_importing_files_and_giving_a_login(self):
        (self.tmp / "my-nl.conf").write_text(WG_CONF)
        (self.tmp / "free-us.ovpn").write_text(OVPN_CONF)
        (self.tmp / "broken.conf").write_text("this is not a vpn config")
        (self.tmp / "readme.txt").write_text("ignore me")
        r = self.run_and_wait("profile_import", lambda: self.act.import_profiles([self.tmp], tier="free"))
        self.assertTrue(r.ok, r.error)
        outcomes = {o.name: o for o in r.data}
        self.assertEqual(set(outcomes), {"broken", "free-us", "my-nl"})
        self.assertTrue(outcomes["my-nl"].ok and outcomes["free-us"].ok)
        self.assertFalse(outcomes["broken"].ok)
        self.assertTrue(outcomes["free-us"].needs_login)
        self.assertEqual(self.feed.outcomes[-1].tone, views.WARN, "one file failed")
        self.assertTrue(wait(lambda: len(self.model.profile_rows()) == 10))
        us = self.profile("free-us")
        self.assertEqual((us.state, us.needs_login, us.can_connect, us.tier), ("Needs login", True, False, "free"))
        self.run_and_wait("profile_auth", lambda: self.act.set_login(us.id, "alice", "s3cret"))
        self.assertTrue(wait(lambda: self.profile("free-us").state == "Ready"))
        self.assertTrue(self.profile("free-us").can_connect)

    def test_the_login_is_not_visible_anywhere_the_window_can_read(self):
        (self.tmp / "free-us.ovpn").write_text(OVPN_CONF)
        self.run_and_wait("profile_import", lambda: self.act.import_profiles(
            [self.tmp / "free-us.ovpn"], tier="free", username="alice", password="hunter2-very-secret"))
        self.assertTrue(wait(lambda: any(r.name == "free-us" for r in self.model.profile_rows())))
        pid = self.profile("free-us").id
        data = self.client.profiles()
        self.assertNotIn("hunter2-very-secret", repr(data))
        self.assertNotIn("hunter2-very-secret", repr(self.client.config_get()))
        self.assertTrue(next(p for p in data["profiles"] if p["id"] == pid)["has_auth"])

    # ---- privacy -----------------------------------------------------------------------------------------
    def test_a_protected_connection_passes_the_dns_and_ipv6_tests(self):
        self.run_and_wait("rotate_start", lambda: self.act.start(30.0))
        self.assertTrue(wait(lambda: self.level() == "protected"))
        r = self.run_and_wait("privacy_check", self.act.privacy_check)
        self.assertTrue(r.ok, r.error)
        v = self.model.leaks()
        self.assertTrue(v.has_report)
        self.assertEqual((v.dns.status, v.ipv6.status), ("pass", "pass"))
        self.assertIn(v.verdict, ("protected", "protected-with-warnings"))
        self.assertEqual(len(v.tiles), 10)
        self.assertTrue(v.simulated)
        self.assertTrue(wait(lambda: self.model.status["privacy"] is not None))
        self.assertIn("Grade", self.model.dashboard().privacy)

    def test_an_unprotected_machine_is_called_unprotected(self):
        self.run_and_wait("privacy_check", lambda: self.act.privacy_check("quick"))
        v = self.model.leaks()
        self.assertIn(v.verdict, ("unprotected", "exposed"))
        self.assertEqual(v.tone, views.BAD)
        tunnel = next(t for t in v.tiles if t.id == "tunnel")
        self.assertEqual(tunnel.status, "fail")

    def test_the_last_report_is_there_when_the_window_is_opened_later(self):
        self.run_and_wait("privacy_check", self.act.privacy_check)
        model2 = AppModel()
        link2 = DaemonLink(Feed(model2), lambda: Client(self.demo.socket), timing=TIMING).start()
        self.addCleanup(link2.close)
        self.assertTrue(wait(lambda: model2.report is not None), "a new window did not get the last report")
        self.assertTrue(model2.leaks().has_report)

    # ---- the kill switch -------------------------------------------------------------------------------
    def test_kill_switch_buttons(self):
        self.run_and_wait("killswitch_on", lambda: self.act.killswitch("on"))
        self.assertTrue(wait(lambda: self.level() == "blocked"))
        self.assertEqual(self.model.dashboard().killswitch.badge, "ARMED")
        self.run_and_wait("lockdown", lambda: self.act.killswitch("lockdown"))
        self.assertTrue(wait(lambda: self.model.dashboard().killswitch.badge == "LOCKDOWN"))
        self.assertTrue(self.model.dashboard().killswitch.lockdown)
        self.run_and_wait("killswitch_off", lambda: self.act.killswitch("off"))
        self.assertTrue(wait(lambda: self.level() == "unprotected"))
        with self.assertRaises(ValueError):
            self.act.killswitch("explode")

    def test_a_lockdown_raises_a_critical_alert_and_a_notification(self):
        self.run_and_wait("lockdown", lambda: self.act.killswitch("lockdown"))
        self.assertTrue(wait(lambda: any(a.kind == "lockdown" for a in self.model.alerts())))
        alert = next(a for a in self.model.alerts() if a.kind == "lockdown")
        self.assertEqual((alert.tone, alert.level), (views.BAD, "critical"))
        self.assertTrue(wait(lambda: ("Lockdown", "LOCKDOWN: all network traffic is blocked") in self.feed.notes))

    # ---- history ---------------------------------------------------------------------------------------
    def test_the_history_fills_while_it_is_shown_and_can_be_filtered_exported_and_cleared(self):
        self.link.want_history(True)
        for _ in range(3):
            r = self.run_and_wait("rotate_now", self.act.rotate_now)
            self.assertTrue(r.ok, r.error)
        self.assertTrue(wait(lambda: len(self.model.history_rows()) >= 3))
        rows = self.model.history_rows()
        self.assertTrue(all(r.result in ("Changed", "Same address") for r in rows))
        self.assertEqual(len(self.model.history_rows("failed")), 0)
        self.assertGreaterEqual(len(self.model.history_rows("success")), 1)
        self.assertIn("recorded", tables_stats(self.model))
        # export: private, complete, never overwrites unless told to
        path = self.tmp / "out.csv"
        r = self.run_and_wait("history_export", lambda: self.act.export_history(path))
        self.assertTrue(r.ok, r.error)
        self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o600)
        lines = path.read_text().splitlines()
        self.assertEqual(lines[0].split(",")[:3], ["id", "ts", "profile_id"])
        self.assertGreaterEqual(len(lines) - 1, 3)
        r = self.run_and_wait("history_export", lambda: self.act.export_history(path))
        self.assertFalse(r.ok)
        self.assertIn("already exists", r.message)
        r = self.run_and_wait("history_export", lambda: self.act.export_history(path, overwrite=True))
        self.assertTrue(r.ok, r.error)
        # clear
        r = self.run_and_wait("history_clear", self.act.clear_history)
        self.assertTrue(r.ok, r.error)
        self.assertTrue(wait(lambda: len(self.model.history_rows()) == 0))

    def test_the_history_is_not_fetched_while_the_page_is_not_shown(self):
        self.run_and_wait("rotate_now", self.act.rotate_now)
        time.sleep(0.6)
        self.assertIsNone(self.model.history)

    # ---- settings --------------------------------------------------------------------------------------
    def test_settings_load_change_and_are_checked_by_the_daemon(self):
        self.run_and_wait("config_get", self.act.load_settings)
        cfg = self.model.config["config"]
        for sec in S.SECTIONS:
            for s in sec.settings:
                self.assertIn(s.key.split(".")[1], cfg[s.key.split(".")[0]], s.key)
        strategy = S.find("rotation.strategy")
        r = self.run_and_wait("config_set", lambda: self.act.change_setting(strategy, "random"))
        self.assertTrue(r.ok, r.error)
        self.assertEqual(self.model.config["config"]["rotation"]["strategy"], "random")
        self.assertEqual(self.client.config_get("rotation.strategy")["value"], "random")
        self.assertIn("takes effect now", self.feed.outcomes[-1].text)

    def test_list_and_multi_settings_are_sent_in_the_form_the_daemon_wants(self):
        dns = S.find("dns.servers")
        self.run_and_wait("config_set", lambda: self.act.change_setting(dns, "1.1.1.1, 9.9.9.9"))
        self.assertEqual(self.client.config_get("dns.servers")["value"], ["1.1.1.1", "9.9.9.9"])
        tiers = S.find("rotation.tiers")
        self.run_and_wait("config_set", lambda: self.act.change_setting(tiers, ("paid", "self-hosted")))
        self.assertEqual(self.client.config_get("rotation.tiers")["value"], ["paid", "self-hosted"])
        prof = self.client.profiles()
        allowed = {p["id"] for p in prof["profiles"] if p["tier"] in ("paid", "self-hosted")}
        self.assertEqual(set(prof["in_rotation"]), allowed, "the rotation is limited to the chosen kinds of server")

    def test_a_value_the_daemon_refuses_comes_back_as_an_error_with_its_reason(self):
        dns = S.find("dns.servers")
        r = self.run_and_wait("config_set", lambda: self.act.change_setting(dns, "not-an-address"))
        self.assertFalse(r.ok)
        self.assertIn("not an IP address", r.message)
        self.assertEqual(self.feed.outcomes[-1].tone, views.BAD)

    def test_settings_the_window_must_never_change_are_refused_by_the_daemon_too(self):
        for key in ("vpn.openvpn_bin", "killswitch.nft_bin", "daemon.group", "vpn.interface"):
            r = self.run_and_wait("config_set", lambda key=key: self.link.run("config_set", key=key, value="x"))
            self.assertFalse(r.ok, key)

    # ---- the link --------------------------------------------------------------------------------------
    def test_a_stopped_daemon_is_noticed_and_the_status_is_dropped(self):
        self.demo.daemon.server.stop()
        self.assertTrue(wait(lambda: self.model.link_up is False), "the loss was not noticed")
        d = self.model.dashboard()
        self.assertEqual(d.banner.level, "offline")
        self.assertFalse(d.controls.can_start)
        self.assertTrue(self.model.link_error)


class SlowE2E(unittest.TestCase):
    """A simulated daemon with realistic delays, so a command is visibly 'in flight'."""

    def test_a_command_in_flight_is_reflected_in_the_busy_set_and_the_controls(self):
        slow = DemoDaemon(speed=0.5)
        slow.start()
        self.addCleanup(slow.stop)
        model = AppModel()
        feed = Feed(model)
        link = DaemonLink(feed, lambda: Client(slow.socket), timing=TIMING).start()
        self.addCleanup(link.close)
        self.assertTrue(wait(lambda: model.status is not None and model.profiles is not None))
        wg = next(p["id"] for p in model.profiles["profiles"] if p["protocol"] == "wireguard")
        Actions(link, model).connect_profile(wg)
        self.assertTrue(wait(lambda: "connect" in model.busy), "busy never showed")
        self.assertFalse(model.dashboard().controls.can_start)
        self.assertTrue(wait(lambda: "connect" not in model.busy and any(r.name == "connect" for r in feed.results)))
        self.assertTrue(wait(lambda: model.level == "protected"))


def tables_stats(model: AppModel) -> str:
    from ipshift.gui import tables
    return tables.history_stats(model.history)


class ThreadHygiene(unittest.TestCase):
    def test_nothing_is_left_running_after_everything_is_closed(self):
        before = {t.ident for t in threading.enumerate()}
        with DemoDaemon(speed=0.0) as demo:
            model = AppModel()
            link = DaemonLink(Feed(model), lambda: Client(demo.socket), timing=TIMING).start()
            Actions(link, model).start(5.0)
            self.assertTrue(wait(lambda: model.level == "protected"))
            link.close()
        time.sleep(0.3)
        leftovers = [t.name for t in threading.enumerate() if t.ident not in before and t.is_alive()]
        self.assertEqual(leftovers, [])


if __name__ == "__main__":
    unittest.main()
