"""Privacy-page tiles, history and profile tables, CSV export and profile import (no Qt, no daemon)."""
from __future__ import annotations

import os
import stat
import tempfile
import unittest
from pathlib import Path

import helpers  # noqa: F401
import guifix
from ipshift.errors import DaemonUnavailable, ProfileError
from ipshift.gui import leakviews, tables
from ipshift.gui.views import BAD, GOOD, INFO, MUTED, PLAIN, WARN
from ipshift.privacy.leaks import FULL


class LeakTileTests(unittest.TestCase):
    def test_before_any_test_everything_is_pending(self):
        v = leakviews.leak_view(None)
        self.assertFalse(v.has_report)
        self.assertEqual((v.score, v.grade, v.tone), ("-", "-", MUTED))
        self.assertEqual([t.id for t in v.tiles], list(FULL))
        self.assertTrue(all(t.status == "pending" and t.word == "NOT RUN YET" for t in v.tiles))
        self.assertEqual((v.dns.status, v.ipv6.status), ("pending", "pending"))
        self.assertGreaterEqual(len(v.not_covered), 4, "the limits of the test are always shown")

    def test_everything_passing(self):
        v = leakviews.leak_view(guifix.report(), now=2010.0)
        self.assertEqual((v.verdict, v.tone, v.grade, v.score), ("protected", GOOD, "A", "100"))
        self.assertEqual((v.dns.status, v.dns.tone, v.ipv6.status, v.ipv6.tone), ("pass", GOOD, "pass", GOOD))
        self.assertEqual(v.counts, "10 passed, 0 warnings, 0 failed, 0 not tested")
        self.assertEqual(v.meta, "full test, 3.2 s, checked 10 s ago")
        self.assertEqual([t.id for t in v.tiles], list(FULL))

    def test_a_dns_leak_is_one_red_tile_naming_the_check_that_found_it(self):
        v = leakviews.leak_view(guifix.report(dns_escape="fail"))
        self.assertEqual((v.dns.status, v.dns.tone, v.dns.leak, v.dns.word), ("fail", BAD, True, "FAIL"))
        self.assertTrue(v.dns.detail.startswith("DNS escape test: "))
        self.assertEqual(v.dns.hint, "fix it")
        self.assertEqual((v.verdict, v.tone), ("exposed", BAD))
        self.assertEqual(v.ipv6.status, "pass", "the IPv6 tile is not affected by a DNS finding")

    def test_an_ipv6_leak_is_its_own_red_tile(self):
        v = leakviews.leak_view(guifix.report(ipv6="fail"))
        self.assertEqual((v.ipv6.status, v.ipv6.leak, v.ipv6.tone), ("fail", True, BAD))
        self.assertEqual(v.dns.status, "pass")

    def test_the_dns_tile_shows_the_worst_of_its_three_checks(self):
        v = leakviews.leak_view(guifix.report(dns_config="warn", dns_path="pass", dns_escape="pass"))
        self.assertEqual((v.dns.status, v.dns.leak), ("warn", False))
        v = leakviews.leak_view(guifix.report(dns_config="warn", dns_path="fail"))
        self.assertEqual(v.dns.status, "fail")

    def test_a_pass_names_what_was_checked(self):
        v = leakviews.leak_view(guifix.report())
        self.assertIn("No DNS leak found", v.dns.detail)
        for title in ("DNS configuration", "DNS resolution path", "DNS escape test"):
            self.assertIn(title, v.dns.detail)

    def test_skipped_dns_checks_are_not_called_a_pass(self):
        v = leakviews.leak_view(guifix.report(dns_config="skip", dns_path="skip", dns_escape="skip"))
        self.assertEqual((v.dns.status, v.dns.tone), ("skip", MUTED))

    def test_a_custom_run_without_dns_checks_leaves_the_dns_tile_pending(self):
        rep = guifix.report()
        rep["findings"] = [f for f in rep["findings"] if f["id"] not in ("dns_config", "dns_path", "dns_escape")]
        v = leakviews.leak_view(rep)
        self.assertEqual(v.dns.status, "pending")
        self.assertEqual(len(v.tiles), 7)

    def test_a_custom_run_without_the_ipv6_check_leaves_it_pending(self):
        rep = guifix.report()
        rep["findings"] = [f for f in rep["findings"] if f["id"] != "ipv6"]
        self.assertEqual(leakviews.leak_view(rep).ipv6.status, "pending")

    def test_a_check_this_version_does_not_know_is_still_listed_last(self):
        rep = guifix.report()
        rep["findings"].append({"id": "future_check", "title": "Future check", "status": "warn", "detail": "d",
                                "hint": "h", "leak": False, "weight": 5, "evidence": {}})
        tiles = leakviews.leak_view(rep).tiles
        self.assertEqual(tiles[-1].id, "future_check")
        self.assertEqual((tiles[-1].title, tiles[-1].tone, tiles[-1].hint), ("Future check", WARN, "h"))

    def test_hints_only_come_with_problems(self):
        v = leakviews.leak_view(guifix.report(lan="warn"))
        by_id = {t.id: t for t in v.tiles}
        self.assertEqual(by_id["lan"].hint, "fix it")
        self.assertEqual(by_id["tunnel"].hint, "")

    def test_warnings_headline_and_counts(self):
        v = leakviews.leak_view(guifix.report(mac="warn", lan="warn"))
        self.assertEqual((v.verdict, v.tone), ("protected-with-warnings", WARN))
        self.assertEqual(v.counts, "8 passed, 2 warnings, 0 failed, 0 not tested")

    def test_a_blocked_machine_is_not_alarming_red(self):
        rep = guifix.report(tunnel="fail", public_ip="skip", dns_path="skip", dns_escape="skip", ipv6="skip",
                            escape="skip")
        v = leakviews.leak_view(rep)
        self.assertEqual((v.verdict, v.tone), ("blocked", WARN))

    def test_simulation_is_flagged(self):
        rep = guifix.report()
        rep["simulated"] = True
        self.assertTrue(leakviews.leak_view(rep).simulated)

    def test_tile_glyphs_are_distinct_per_status(self):
        glyphs = {leakviews.make_tile("x", "X", s).glyph for s in ("pass", "warn", "fail", "skip", "pending")}
        self.assertEqual(len(glyphs), 5)

    def test_a_leak_flag_without_a_failure_is_ignored(self):
        self.assertFalse(leakviews.make_tile("x", "X", "pass", leak=True).leak)
        self.assertTrue(leakviews.make_tile("x", "X", "fail", leak=True).leak)


class HistoryTableTests(unittest.TestCase):
    def test_rows_keep_the_daemons_newest_first_order(self):
        rows = tables.history_rows(guifix.history(3))
        self.assertEqual([r.profile for r in rows], ["Server 3", "Server 2", "Server 1"])

    def test_one_row_in_words(self):
        r = tables.history_rows(guifix.history(1))[0]
        self.assertEqual((r.result, r.tone, r.old_ip, r.new_ip, r.took, r.note),
                         ("Changed", GOOD, "198.51.100.1", "198.51.100.2", "801 ms", "rotate"))
        self.assertEqual(len(r.cells()), len(tables.HISTORY_COLUMNS))

    def test_failures_show_the_error_and_no_new_address(self):
        data = {"rotations": [{"ts": 1.0, "status": "failed", "profile_name": "X", "old_ip": "a", "new_ip": None,
                               "duration_ms": None, "reason": "rotate", "error": "handshake timeout"}]}
        r = tables.history_rows(data)[0]
        self.assertEqual((r.result, r.tone, r.new_ip, r.took, r.note), ("Failed", BAD, "-", "-", "handshake timeout"))

    def test_same_address_cancelled_and_unknown_results(self):
        for status, word, tone in (("unchanged", "Same address", WARN), ("cancelled", "Cancelled", MUTED),
                                   ("odd", "odd", PLAIN)):
            r = tables.history_row({"ts": 1.0, "status": status})
            self.assertEqual((r.result, r.tone), (word, tone))

    def test_filters(self):
        data = {"rotations": [{"ts": 3.0, "status": "success"}, {"ts": 2.0, "status": "failed"},
                              {"ts": 1.0, "status": "unchanged"}]}
        self.assertEqual(len(tables.history_rows(data, "all")), 3)
        self.assertEqual([r.status for r in tables.history_rows(data, "failed")], ["failed"])
        self.assertEqual([r.status for r in tables.history_rows(data, "success")], ["success"])
        self.assertEqual([r.status for r in tables.history_rows(data, "unchanged")], ["unchanged"])
        self.assertEqual([k for k, _ in tables.HISTORY_FILTERS], ["all", "success", "failed", "unchanged"])

    def test_the_table_is_capped_and_empty_data_is_fine(self):
        data = {"rotations": [{"ts": float(i), "status": "success"} for i in range(50)]}
        self.assertEqual(len(tables.history_rows(data, limit=10)), 10)
        self.assertEqual(tables.history_rows(None), ())
        self.assertEqual(tables.history_rows({}), ())

    def test_stats_line(self):
        self.assertEqual(tables.history_stats(None), "No rotations recorded yet.")
        self.assertEqual(tables.history_stats({"stats": {"total": 0}}), "No rotations recorded yet.")
        text = tables.history_stats(guifix.history(3))
        self.assertEqual(text, "3 recorded: 3 changed the address, 0 failed, 0 kept the same address; "
                               "3 different addresses, average 801 ms")

    def test_stored_alerts(self):
        data = {"events": [{"ts": 5.0, "level": "critical", "kind": "tunnel_lost", "message": "The VPN dropped"},
                           {"ts": 4.0, "level": "warning", "kind": "network_changed", "message": None}]}
        rows = tables.event_rows(data)
        self.assertEqual([(r.level, r.tone, r.text) for r in rows],
                         [("critical", BAD, "The VPN dropped"), ("warning", WARN, "network_changed")])
        self.assertEqual(tables.event_rows(None), ())


class ExportTests(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())
        self.addCleanup(lambda: __import__("shutil").rmtree(self.dir, ignore_errors=True))

    def test_the_file_is_private_and_holds_the_text_unchanged(self):
        p = self.dir / "h.csv"
        tables.export_csv(p, "a,b\r\n1,2\r\n")
        self.assertEqual(p.read_bytes(), b"a,b\r\n1,2\r\n")
        self.assertEqual(stat.S_IMODE(p.stat().st_mode), 0o600)

    def test_an_existing_file_is_never_replaced_by_default(self):
        p = self.dir / "h.csv"
        p.write_text("keep me")
        with self.assertRaises(FileExistsError):
            tables.export_csv(p, "new")
        self.assertEqual(p.read_text(), "keep me")

    def test_overwriting_must_be_asked_for_and_tightens_the_mode(self):
        p = self.dir / "h.csv"
        p.write_text("old old old")
        os.chmod(p, 0o644)
        tables.export_csv(p, "new", overwrite=True)
        self.assertEqual(p.read_text(), "new")
        self.assertEqual(stat.S_IMODE(p.stat().st_mode), 0o600)

    def test_a_symlink_is_not_followed(self):
        target = self.dir / "target"
        target.write_text("precious")
        link = self.dir / "link.csv"
        link.symlink_to(target)
        for overwrite in (False, True):
            with self.assertRaises(OSError):
                tables.export_csv(link, "x", overwrite=overwrite)
        self.assertEqual(target.read_text(), "precious")

    def test_the_default_name_is_dated(self):
        name = tables.default_export_name(1_700_000_000.0)
        self.assertRegex(name, r"^ipshift-history-\d{8}-\d{6}\.csv$")


class ProfileTableTests(unittest.TestCase):
    NOW = 5000.0

    def state(self, **p):
        base = {"id": "x", "enabled": True, "needs_auth": False, "has_auth": False, "quarantined": False,
                "quarantined_until": 0.0}
        return tables.profile_state({**base, **p}, None, self.NOW)

    def test_states(self):
        self.assertEqual(self.state(), ("Ready", GOOD))
        self.assertEqual(self.state(enabled=False), ("Disabled", MUTED))
        self.assertEqual(self.state(needs_auth=True), ("Needs login", WARN))
        self.assertEqual(self.state(needs_auth=True, has_auth=True), ("Ready", GOOD))
        self.assertEqual(self.state(quarantined=True, quarantined_until=self.NOW + 90), ("Benched for 1 min 30 s", BAD))
        self.assertEqual(tables.profile_state({"id": "x"}, "x", self.NOW), ("Active", GOOD))

    def test_a_disabled_profile_beats_a_benched_one(self):
        self.assertEqual(self.state(enabled=False, quarantined=True, quarantined_until=self.NOW + 5)[0], "Disabled")

    def test_rows(self):
        rows = tables.profile_rows(guifix.profiles(current="wg-nl"), self.NOW)
        wg, ovpn = rows
        self.assertEqual((wg.name, wg.protocol, wg.tier, wg.country, wg.state, wg.rotating, wg.record, wg.last_ip),
                         ("WG NL", "wireguard", "paid", "NL", "Active", True, "5 / 1", "198.51.100.5"))
        self.assertEqual((wg.active, wg.can_connect), (True, False))
        self.assertEqual((ovpn.state, ovpn.needs_login, ovpn.usable, ovpn.can_connect, ovpn.rotating, ovpn.last_ip),
                         ("Needs login", True, False, False, False, "-"))
        self.assertEqual(len(wg.cells()), len(tables.PROFILE_COLUMNS))

    def test_a_ready_profile_can_be_connected(self):
        wg = tables.profile_rows(guifix.profiles(), self.NOW)[0]
        self.assertEqual((wg.state, wg.can_connect), ("Ready", True))

    def test_empty(self):
        self.assertEqual(tables.profile_rows(None), ())
        self.assertEqual(tables.profile_rows({}), ())

    def test_free_profiles_trigger_the_warning(self):
        self.assertTrue(tables.has_free_profiles(tables.profile_rows(guifix.profiles())))
        self.assertFalse(tables.has_free_profiles(tables.profile_rows(None)))
        self.assertIn("log your traffic", tables.FREE_VPN_WARNING)


class StubImportClient:
    def __init__(self, fail=(), lost_on=None):
        self.calls, self.fail, self.lost_on = [], set(fail), lost_on

    def profile_import(self, **kw):
        self.calls.append(kw)
        if kw["name"] == self.lost_on:
            raise DaemonUnavailable("gone")
        if kw["name"] in self.fail:
            raise ProfileError(f"{kw['name']} is not a VPN configuration")
        return {"profile": {"name": kw["name"], "needs_auth": kw["name"] == "needy", "has_auth": False},
                "warnings": ["a note"] if kw["name"] == "noted" else [], "removed": []}


WG = "[Interface]\nPrivateKey = aGVsbG8gd29ybGQgaGVsbG8gd29ybGQgaGVsbG8gd29ybGQ=\nAddress = 10.0.0.2/32\n" \
     "[Peer]\nPublicKey = aGVsbG8gd29ybGQgaGVsbG8gd29ybGQgaGVsbG8gd29ybGQ=\nEndpoint = 203.0.113.9:51820\n" \
     "AllowedIPs = 0.0.0.0/0\n"


class ImportTests(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())
        self.addCleanup(lambda: __import__("shutil").rmtree(self.dir, ignore_errors=True))
        for n in ("b.conf", "a.ovpn", "needy.conf", "notes.txt", "bad.conf"):
            (self.dir / n).write_text(WG)
        (self.dir / "sub").mkdir()
        (self.dir / "sub" / "deep.conf").write_text(WG)

    def test_a_folder_contributes_its_vpn_files_sorted_and_not_its_subfolders(self):
        got = [p.name for p in tables.expand_import_paths([self.dir])]
        self.assertEqual(got, ["a.ovpn", "b.conf", "bad.conf", "needy.conf"])

    def test_files_as_given_and_missing_ones_skipped(self):
        got = tables.expand_import_paths([self.dir / "b.conf", self.dir / "missing.conf", self.dir / "notes.txt"])
        self.assertEqual([p.name for p in got], ["b.conf", "notes.txt"])

    def test_every_file_is_read_here_and_sent_with_the_chosen_tier(self):
        c = StubImportClient()
        out = tables.import_files(c, [self.dir / "a.ovpn", self.dir / "b.conf"], tier="paid", replace=True)
        self.assertEqual([(o.name, o.ok) for o in out], [("a", True), ("b", True)])
        self.assertEqual([k["name"] for k in c.calls], ["a", "b"])
        self.assertTrue(all(k["tier"] == "paid" and k["replace"] is True and k["text"] == WG for k in c.calls))
        self.assertTrue(all("username" not in k and "password" not in k for k in c.calls))

    def test_one_login_can_be_given_for_all_of_them(self):
        c = StubImportClient()
        tables.import_files(c, [self.dir / "a.ovpn"], username="alice", password="s3cret")
        self.assertEqual((c.calls[0]["username"], c.calls[0]["password"]), ("alice", "s3cret"))

    def test_one_bad_file_does_not_stop_the_rest(self):
        c = StubImportClient(fail={"bad"})
        out = tables.import_files(c, [self.dir / "bad.conf", self.dir / "b.conf"])
        self.assertEqual([(o.name, o.ok) for o in out], [("bad", False), ("b", True)])
        self.assertIn("is not a VPN configuration", out[0].message)

    def test_a_lost_daemon_stops_the_import(self):
        c = StubImportClient(lost_on="a")
        with self.assertRaises(DaemonUnavailable):
            tables.import_files(c, [self.dir / "a.ovpn", self.dir / "b.conf"])
        self.assertEqual(len(c.calls), 1)

    def test_a_file_that_cannot_be_read_is_a_failure_not_a_crash(self):
        out = tables.import_files(StubImportClient(), [self.dir / "b.conf"])
        os.remove(self.dir / "b.conf")
        # the path no longer exists: it is skipped by expand_import_paths, so nothing is attempted
        self.assertEqual(tables.import_files(StubImportClient(), [self.dir / "b.conf"]), [])
        self.assertTrue(out[0].ok)

    def test_the_summary_says_what_needs_attention(self):
        out = [tables.ImportOutcome("/x/a.conf", True, "a"), tables.ImportOutcome("/x/needy.conf", True, "needy",
                                                                                  "", True),
               tables.ImportOutcome("/x/bad.conf", False, "bad", "not a VPN configuration")]
        text = tables.import_summary(out)
        self.assertIn("Imported 2 of 3 profile(s).", text)
        self.assertIn("bad.conf: not a VPN configuration", text)
        self.assertIn("1 profile(s) still need a username and password", text)
        self.assertEqual(tables.import_summary([]), "No .ovpn or .conf files were found.")

    def test_a_long_failure_list_is_cut(self):
        out = [tables.ImportOutcome(f"/x/{i}.conf", False, str(i), "nope") for i in range(12)]
        self.assertIn("... and 4 more", tables.import_summary(out))


if __name__ == "__main__":
    unittest.main()
