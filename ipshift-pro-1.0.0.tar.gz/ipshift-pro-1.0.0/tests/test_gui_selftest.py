"""``ipshift-gui`` itself: the command line, the missing-PySide6 message, the demo mode and the scripted self-test,
run with the stand-in for PySide6 against the in-process simulated daemon (no real network is touched)."""
from __future__ import annotations

import contextlib
import io
import logging
import os
import signal
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import helpers  # noqa: F401
import fakeqt
import qtcase
from ipshift import __version__


def setUpModule():
    qtcase.install()
    global guiapp, selftest, demo_module, dialogs
    from ipshift.gui import app as guiapp
    from ipshift.gui import demo as demo_module
    from ipshift.gui import dialogs, selftest


def tearDownModule():
    qtcase.uninstall()


class MainCase(qtcase.QtCase):
    """Keeps what ``main()`` does to the process (logging, signals, environment) out of the other tests."""

    def setUp(self):
        super().setUp()
        logger = logging.getLogger("ipshift")
        saved = (logger.level, logger.propagate, list(logger.handlers))

        def restore_logging():
            for h in list(logger.handlers):
                if h not in saved[2]:
                    logger.removeHandler(h)
                    h.close()
            logger.setLevel(saved[0])
            logger.propagate = saved[1]

        self.addCleanup(restore_logging)
        env = mock.patch.dict(os.environ)
        env.start()
        self.addCleanup(env.stop)
        old = {s: signal.getsignal(s) for s in (signal.SIGINT, signal.SIGTERM)}
        self.addCleanup(lambda: [signal.signal(s, h) for s, h in old.items() if h is not None])
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.tmp = Path(tmp.name)

    def run_main(self, argv):
        out, err = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            rc = guiapp.main(argv)
        return rc, out.getvalue(), err.getvalue()


class ArgumentTests(unittest.TestCase):
    def test_the_defaults(self):
        a = guiapp.parse_args([])
        self.assertEqual((a.demo, a.selftest, a.screenshots, a.socket, a.version), (False, False, None, None, False))

    def test_every_option(self):
        a = guiapp.parse_args(["--demo", "--selftest", "--screenshots", "/x", "--socket", "/s", "--version"])
        self.assertEqual((a.demo, a.selftest, a.screenshots, a.socket, a.version), (True, True, "/x", "/s", True))

    def test_an_unknown_option_is_refused(self):
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit) as cm:
            guiapp.parse_args(["--delete-everything"])
        self.assertEqual(cm.exception.code, 2)


class VersionAndMissingQtTests(MainCase):
    def test_version_needs_no_qt_and_no_daemon(self):
        rc, out, err = self.run_main(["--version"])
        self.assertEqual((rc, out.strip(), err), (0, f"ipshift-gui {__version__}", ""))

    def test_without_pyside6_the_program_explains_what_to_install_and_that_the_cli_works(self):
        from ipshift.gui import qt_available
        with mock.patch.dict(sys.modules, {"PySide6": None}):         # what a missing package looks like
            self.assertFalse(qt_available())
            rc, out, err = self.run_main([])
        self.assertEqual((rc, out), (2, ""))
        self.assertIn("sudo apt install python3-pyside6.qtwidgets", err)      # the Kali / Debian package
        self.assertIn("pip install --user 'PySide6>=6.5'", err)
        self.assertIn("ipshift status", err)

    def test_with_pyside6_present_it_is_found(self):
        from ipshift.gui import qt_available
        self.assertTrue(qt_available())


class BuildTests(MainCase):
    def test_build_returns_a_window_wired_to_the_model_and_the_actions(self):
        window, bridge, model, actions = guiapp.build(self.app, str(self.tmp / "none.sock"), demo=True)
        self.assertIs(window.bridge, bridge)
        self.assertIs(window.model, model)
        self.assertIs(window.commands, actions)
        self.assertIs(actions.link, bridge.link)
        self.assertEqual(window.windowTitle(), "IPShift Pro (demo)")
        self.assertFalse(bridge.link.closed)
        bridge.close()
        self.assertTrue(bridge.link.closed)


class MainRunTests(MainCase):
    def test_the_window_opens_and_the_program_returns_when_the_event_loop_ends(self):
        rc, out, err = self.run_main(["--socket", str(self.tmp / "none.sock")])
        self.assertEqual(rc, 0)
        self.assertEqual(self.app.app_name, "IPShift Pro")
        self.assertEqual(self.app.desktop_file, "ipshift-pro")       # the name of packaging/desktop/ipshift-pro.desktop
        self.assertEqual(self.app.style_name, "Fusion")
        self.assertIn("QPushButton", self.app.stylesheet)

    def test_ctrl_c_and_terminate_close_the_window_cleanly(self):
        self.run_main(["--socket", str(self.tmp / "none.sock")])
        for sig in (signal.SIGINT, signal.SIGTERM):
            self.app.quit_called = False
            signal.getsignal(sig)(sig, None)
            self.assertTrue(self.app.quit_called, sig)

    def test_demo_mode_runs_a_private_daemon_and_removes_it_afterwards(self):
        made = []

        class Spy(demo_module.DemoDaemon):
            def __init__(self, *a, **k):
                super().__init__(*a, **k)
                made.append(self)

        with mock.patch.object(demo_module, "DemoDaemon", Spy):
            rc, out, err = self.run_main(["--demo"])
        self.assertEqual(rc, 0)
        self.assertEqual(len(made), 1)
        self.assertEqual(made[0].speed, 1.0)
        self.assertIsNone(made[0].daemon)                       # stopped
        self.assertFalse(made[0].socket.exists())               # and its files are gone

    def test_the_selftest_uses_the_offscreen_platform_and_an_instant_simulator(self):
        os.environ.pop("QT_QPA_PLATFORM", None)
        made = []

        class Spy(demo_module.DemoDaemon):
            def __init__(self, *a, **k):
                super().__init__(*a, **k)
                made.append(self)

        with mock.patch.object(demo_module, "DemoDaemon", Spy), \
                mock.patch.object(selftest, "run", return_value=0) as run:
            rc, out, err = self.run_main(["--selftest"])
        self.assertEqual(rc, 0)
        self.assertEqual(os.environ["QT_QPA_PLATFORM"], "offscreen")
        self.assertEqual(made[0].speed, 0.0)
        run.assert_called_once()
        self.assertIsNone(run.call_args.kwargs["shots"])

    def test_a_user_chosen_platform_is_not_overridden(self):
        os.environ["QT_QPA_PLATFORM"] = "xcb"
        with mock.patch.object(selftest, "run", return_value=0):
            self.run_main(["--selftest"])
        self.assertEqual(os.environ["QT_QPA_PLATFORM"], "xcb")

    def test_the_exit_status_of_the_selftest_is_the_exit_status_of_the_program(self):
        with mock.patch.object(selftest, "run", return_value=1):
            rc, _, _ = self.run_main(["--selftest"])
        self.assertEqual(rc, 1)


class ScriptedRunTests(MainCase):
    """The whole scripted scenario: the real window, the real link and daemon code, a simulated network."""

    def test_the_scripted_run_passes_and_saves_a_picture_of_every_page(self):
        before = (dialogs.confirm, dialogs.ask_stop, dialogs.inform)
        shots = self.tmp / "shots"
        rc, out, err = self.run_main(["--selftest", "--screenshots", str(shots)])
        self.assertEqual(rc, 0, out)
        self.assertNotIn("[FAIL]", out)
        self.assertGreaterEqual(out.count("[ok]"), 35)
        self.assertRegex(out, r"(\d+) of \1 checks passed")
        self.assertEqual(sorted(p.name for p in shots.iterdir()),
                         ["dashboard-rotating.png", "dashboard-start.png", "dashboard-stopped.png", "history.png",
                          "privacy.png", "profiles.png", "settings.png"])
        self.assertEqual(fakeqt.state.hooks.unscripted, [])      # every question the window asked was answered
        self.assertEqual((dialogs.confirm, dialogs.ask_stop, dialogs.inform), before)

    def test_every_claim_the_scripted_run_makes_is_one_the_task_asked_for(self):
        rc, out, err = self.run_main(["--selftest"])
        self.assertEqual(rc, 0, out)
        for claim in ("the smallest interval is 1 second", "an interval below 1 second is not accepted",
                      "the banner shows a protection level", "the kill switch shows ARMED",
                      "the address changes at the 1-second interval (two changes)",
                      "the DNS leak test shows a result", "the IPv6 leak test shows a result",
                      "rotations appear in the table", "a risky change that is not confirmed is put back",
                      "'disconnect but keep blocking' stops the rotation and leaves the firewall up",
                      "the real address is hidden until asked for"):
            self.assertIn(claim, out)


class RunObjectTests(MainCase):
    """The checking machinery itself: a failing check must fail the run."""

    def make_run(self, lines):
        class Win:
            pass

        return selftest.Run(self.app, Win(), None, None, echo=lines.append)

    def test_a_failed_check_is_reported_and_makes_the_run_fail(self):
        lines = []
        run = self.make_run(lines)
        run.check("fine", True)
        run.check("broken", False, "because")
        self.assertEqual(lines, ["  [ok] fine", "  [FAIL] broken   (because)"])
        self.assertEqual([r[1] for r in run.results], [True, False])

    def test_a_step_that_raises_is_a_failure_and_does_not_stop_the_other_steps(self):
        lines = []
        run = self.make_run(lines)
        ran = []

        def connect():                                          # the run names a failing step by its function name
            raise RuntimeError("step broke")

        run.connect = connect
        for name in ("interval_floor", "rotation", "history", "privacy", "profiles", "settings", "stopping", "lookup"):
            setattr(run, name, lambda name=name: ran.append(name))
        run.finish = lambda: ran.append("finish")
        self.assertEqual(run.run(), 1)
        self.assertEqual(len(ran), 9)                           # all the other steps still ran
        self.assertTrue(any("connect ran without an error" in line and "FAIL" in line for line in lines))
        self.assertTrue(any("step broke" in line for line in lines))

    def test_a_wait_that_times_out_fails_with_a_reason(self):
        lines = []
        run = self.make_run(lines)
        self.assertFalse(run.wait_for("never", lambda: False, limit=0.05, detail=lambda: "still waiting"))
        self.assertIn("timed out: still waiting", lines[-1])

    def test_the_dialogs_are_put_back_even_when_a_step_fails(self):
        before = (dialogs.confirm, dialogs.ask_stop, dialogs.inform)
        run = self.make_run([])
        for name in ("connect", "interval_floor", "rotation", "history", "privacy", "profiles", "settings", "stopping",
                     "lookup", "finish"):
            setattr(run, name, lambda: (_ for _ in ()).throw(RuntimeError("x")))
        run.run()
        self.assertEqual((dialogs.confirm, dialogs.ask_stop, dialogs.inform), before)


if __name__ == "__main__":
    unittest.main()
