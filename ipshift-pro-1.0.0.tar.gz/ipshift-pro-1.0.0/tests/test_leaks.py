"""Privacy checks, report scoring and the real network probes."""
from __future__ import annotations

import errno
import json
import socket
import struct
import threading
import unittest

from helpers import TmpRootCase
from simharness import SimStack

from ipshift.errors import VpnError
from ipshift.net.dnswire import build_query
from ipshift.privacy.checks import first_ip, same_network
from ipshift.privacy.leaks import FULL, QUICK
from ipshift.privacy.probes import DnsAnswer, NetProbes, _classify
from ipshift.privacy.report import Finding, Report, grade_for


class LeakCase(TmpRootCase):
    def setUp(self):
        super().setUp()
        self.s = SimStack(self.tmp)
        self.addCleanup(self.s.close)
        self.wg = self.s.profiles("wireguard")

    def connect(self, profile=None):
        self.s.mgr.activate((profile or self.wg[0]).id)

    def run_checks(self, **kw):
        return self.s.checker.run(**kw)

    def status(self, report, check):
        return report.get(check).status


class HealthyTests(LeakCase):
    def test_everything_in_order(self):
        self.connect()
        self.s.hardening.store.put("mac", {"wlan0": "3c:52:82:aa:bb:01"})       # randomisation recorded
        rep = self.run_checks()
        self.assertEqual([f.id for f in rep.findings], list(FULL))
        self.assertEqual({f.status for f in rep.findings}, {"pass"}, [(f.id, f.status, f.detail) for f in rep.findings])
        self.assertEqual((rep.verdict, rep.score, rep.grade), ("protected", 100, "A"))
        self.assertIn("PROTECTED", rep.headline())
        self.assertIn("exit address", rep.get("tunnel").detail)
        self.assertIn("independent services agree", rep.get("public_ip").detail)

    def test_the_mac_warning_is_the_only_blemish_by_default(self):
        self.connect()
        rep = self.run_checks()
        self.assertEqual([f.id for f in rep.findings if f.status != "pass"], ["mac"])
        self.assertEqual(rep.verdict, "protected-with-warnings")
        self.assertEqual(rep.score, 97)
        self.assertEqual(rep.get("mac").hint, "ipshift harden mac enable")

    def test_quick_mode_and_selection(self):
        self.connect()
        self.assertEqual([f.id for f in self.run_checks(mode="quick").findings], list(QUICK))
        rep = self.run_checks(only=["ipv6", "escape", "ipv6"])
        self.assertEqual([f.id for f in rep.findings], ["ipv6", "escape"])
        self.assertEqual(rep.mode, "custom")
        with self.assertRaises(ValueError):
            self.run_checks(only=["nope"])

    def test_report_is_json_serialisable_and_states_its_limits(self):
        self.connect()
        d = self.run_checks().to_dict()
        json.dumps(d)
        self.assertGreaterEqual(len(d["not_covered"]), 4)
        self.assertTrue(any("WebRTC" in x for x in d["not_covered"]))
        self.assertTrue(any("provider" in x for x in d["not_covered"]))


class OfflineStateTests(LeakCase):
    def test_vpn_down_with_the_kill_switch_armed_is_blocked_not_exposed(self):
        self.connect()
        self.s.mgr.disconnect(release=False)
        rep = self.run_checks()
        self.assertEqual(rep.verdict, "blocked")
        self.assertEqual(self.status(rep, "tunnel"), "fail")
        self.assertEqual(self.status(rep, "killswitch"), "pass")
        for skipped in ("public_ip", "dns_path"):
            self.assertEqual(self.status(rep, skipped), "skip")
        self.assertEqual(rep.leaks, [])
        self.assertEqual(self.status(rep, "escape"), "pass")                 # nothing gets out

    def test_no_vpn_and_no_firewall_is_unprotected_and_not_reported_as_a_leak(self):
        rep = self.run_checks()
        self.assertEqual(rep.verdict, "unprotected")
        self.assertEqual(rep.leaks, [])
        for fid in ("escape", "dns_escape", "ipv6", "dns_config"):
            self.assertEqual(self.status(rep, fid), "skip", fid)
            self.assertIn("real network", rep.get(fid).detail)
        self.assertEqual(self.status(rep, "tunnel"), "fail")
        self.assertEqual(self.status(rep, "killswitch"), "fail")
        self.assertEqual(rep.grade, "F")

    def test_a_failed_connection_whose_firewall_vanished_is_a_real_leak(self):
        a = self.s.profiles("wireguard")[0]
        self.s.world.fail[a.id] = "boom"
        with self.assertRaises(VpnError):
            self.s.mgr.activate(a.id)
        self.assertEqual(self.run_checks().verdict, "blocked")
        self.s.ks.disarm()                                                   # the person still expects protection
        rep = self.run_checks()
        self.assertEqual(rep.verdict, "exposed")
        self.assertEqual(self.status(rep, "escape"), "fail")


class LeakDetectionTests(LeakCase):
    def test_firewall_removed_behind_our_back(self):
        self.connect()
        self.s.ks.disarm()                                                   # e.g. somebody ran nft flush ruleset
        rep = self.run_checks()
        self.assertEqual(rep.verdict, "exposed")
        self.assertEqual(self.status(rep, "killswitch"), "fail")
        self.assertEqual(self.status(rep, "escape"), "fail")
        self.assertEqual(self.status(rep, "dns_escape"), "fail")
        self.assertIn("wlan0", rep.get("escape").detail)
        self.assertEqual(rep.get("killswitch").hint, "re-arm it with: ipshift killswitch on")

    def test_dns_leak_is_caught_by_the_resolver_identity_when_the_real_ip_is_known(self):
        self.connect()
        self.s.world.leaks.add("dns")
        self.s.mgr.baseline_ip = self.s.world.real_ip
        rep = self.run_checks()
        f = rep.get("dns_path")
        self.assertEqual(f.status, "fail")
        self.assertTrue(f.leak)
        self.assertIn(self.s.world.isp_resolver, f.detail)
        self.assertEqual(rep.verdict, "exposed")

    def test_dns_leak_is_caught_without_a_baseline_by_the_escape_probe(self):
        self.connect()
        self.s.world.leaks.add("dns")
        rep = self.run_checks()
        self.assertEqual(self.status(rep, "dns_path"), "pass")               # identity alone cannot tell...
        self.assertEqual(self.status(rep, "dns_escape"), "fail")             # ...but a DNS query via the real NIC can
        self.assertEqual(rep.verdict, "exposed")

    def test_resolver_that_was_the_original_isp_resolver_is_flagged(self):
        self.s.resolv.write_text("nameserver 192.0.2.53\n")                  # the network handed us this one
        self.connect()
        self.s.world.vpn_resolver = "192.0.2.53"                             # and the tunnel's queries end up there
        rep = self.run_checks(only=["dns_path"])
        self.assertEqual(rep.get("dns_path").status, "fail")

    def test_ipv6_leak_on_an_ipv4_only_tunnel(self):
        self.s.world.server_for(self.wg[0]).exit_ipv6 = None
        self.connect()
        self.s.world.leaks.add("ipv6")
        rep = self.run_checks()
        f = rep.get("ipv6")
        self.assertEqual((f.status, f.leak), ("fail", True))
        self.assertEqual(rep.verdict, "exposed")

    def test_ipv4_only_tunnel_without_a_leak_passes(self):
        self.s.world.server_for(self.wg[0]).exit_ipv6 = None
        self.connect()
        f = self.run_checks(only=["ipv6"]).get("ipv6")
        self.assertEqual(f.status, "pass")
        self.assertIn("No IPv6", f.detail)

    def test_ipv6_tunnel_that_passes_no_ipv6_traffic_warns(self):
        self.connect()
        self.s.world.server_for(self.wg[0]).exit_ipv6 = None                 # the tunnel stops carrying v6 ...
        self.s.mgr.conn.tunnel.ipv6 = True                                   # ... but still advertises it
        self.assertEqual(self.run_checks(only=["ipv6"]).get("ipv6").status, "warn")

    def test_public_ip_equal_to_the_real_ip(self):
        self.connect()
        self.s.mgr.baseline_ip = self.s.mgr.conn.exit_ip
        rep = self.run_checks()
        f = rep.get("public_ip")
        self.assertEqual((f.status, f.leak), ("fail", True))
        self.assertIn("REAL address", f.detail)

    def test_public_ip_that_changed_since_connecting_only_warns(self):
        self.connect()
        self.s.world.server_for(self.wg[0]).exit_ip = "198.51.100.222"
        f = self.run_checks(only=["public_ip"]).get("public_ip")
        self.assertEqual(f.status, "warn")
        self.assertIn("198.51.100.222", f.detail)

    def test_tunnel_up_but_no_traffic_passes_it(self):
        self.connect()
        self.s.world.dead = True
        rep = self.run_checks()
        self.assertEqual(self.status(rep, "tunnel"), "fail")


class DnsConfigTests(LeakCase):
    def test_lan_router_as_resolver_is_reported_and_blocked_by_the_firewall(self):
        self.connect()
        self.s.resolv.write_text("nameserver 192.168.1.1\n")
        f = self.run_checks(only=["dns_config"]).get("dns_config")
        self.assertEqual(f.status, "fail")
        self.assertFalse(f.leak)                                             # the kill switch blocks it
        self.assertIn("blocked by the kill switch", f.detail)
        self.assertIn("192.168.1.1 (via wlan0)", f.detail)

    def test_the_same_setup_without_a_firewall_is_a_real_leak(self):
        self.connect()
        self.s.ks.disarm()
        self.s.resolv.write_text("nameserver 192.168.1.1\n")
        f = self.run_checks(only=["dns_config"]).get("dns_config")
        self.assertTrue(f.leak)

    def test_local_stub_resolver_warns(self):
        self.connect()
        self.s.resolv.write_text("nameserver 127.0.0.53\n")
        f = self.run_checks(only=["dns_config"]).get("dns_config")
        self.assertEqual(f.status, "warn")
        self.assertIn("127.0.0.53", f.detail)

    def test_rewritten_resolv_conf_is_noticed(self):
        self.connect()
        self.s.resolv.write_text("nameserver 10.8.0.1\n")                    # right server, but not our file any more
        f = self.run_checks(only=["dns_config"]).get("dns_config")
        self.assertEqual(f.status, "warn")
        self.assertIn("rewritten", f.detail)

    def test_no_nameserver_at_all(self):
        self.s.ks.arm()                                                      # something is supposed to be protecting us
        self.s.resolv.write_text("# empty\n")
        self.assertEqual(self.run_checks(only=["dns_config"]).get("dns_config").status, "fail")


class SkippedProbeTests(LeakCase):
    def test_without_root_the_pinned_probes_are_skipped_with_a_hint(self):
        self.connect()

        class NoRoot:
            def __init__(self, inner):
                self.inner = inner

            def dns(self, *a, device=None, **kw):
                return DnsAnswer("unavailable") if device else self.inner.dns(*a, **kw)

            def resolver_identity(self, server, *, device=None):
                return DnsAnswer("unavailable") if device else self.inner.resolver_identity(server)

            def tcp(self, ip, port, *, device=None):
                return "unavailable" if device else self.inner.tcp(ip, port)
        self.s.checker.probes = NoRoot(self.s.probes)
        rep = self.run_checks()
        for cid in ("escape", "dns_escape"):
            self.assertEqual(self.status(rep, cid), "skip")
            self.assertEqual(rep.get(cid).hint, "run: sudo ipshift privacy-check")
        self.assertEqual(self.status(rep, "ipv6"), "warn")                  # no v6 seen, but the probe could not run
        self.assertEqual(rep.counts["fail"], 0)

    def test_a_broken_check_becomes_a_skip_and_the_rest_still_run(self):
        self.connect()

        def boom():
            raise RuntimeError("probe exploded")
        self.s.checker.mac = boom
        with self.assertLogs("ipshift.privacy.leaks", "ERROR"):
            rep = self.run_checks()
        f = rep.get("mac")
        self.assertEqual(f.status, "skip")
        self.assertIn("probe exploded", f.detail)
        self.assertEqual(self.status(rep, "tunnel"), "pass")


class LocalNetworkTests(LeakCase):
    def test_deliberate_openings_are_flagged(self):
        self.connect()
        self.s.cfg.killswitch.allow_lan = True
        self.s.cfg.killswitch.allow_ifaces = ["virbr*"]
        self.s.cfg.killswitch.allow_forward = True
        f = self.run_checks(only=["lan"]).get("lan")
        self.assertEqual(f.status, "warn")
        for word in ("LAN access", "virbr*", "forwarding"):
            self.assertIn(word, f.detail)

    def test_closed_by_default(self):
        self.assertEqual(self.run_checks(only=["lan"]).get("lan").status, "pass")


class ScoringTests(unittest.TestCase):
    def rep(self, *items):
        return Report([Finding(i, i, st, weight=w, leak=lk) for i, st, w, lk in items])

    def test_arithmetic(self):
        r = self.rep(("a", "pass", 10, False), ("b", "warn", 10, False), ("c", "fail", 20, False), ("d", "skip", 50, False))
        self.assertEqual(r.score, 100 - 5 - 20)
        self.assertEqual(r.verdict, "at-risk")
        self.assertEqual(r.counts, {"pass": 1, "warn": 1, "fail": 1, "skip": 1})

    def test_a_leak_caps_the_score_whatever_else_passed(self):
        r = self.rep(("a", "pass", 10, False), ("leak", "fail", 5, True))
        self.assertEqual(r.score, 39)
        self.assertEqual((r.grade, r.verdict), ("F", "exposed"))

    def test_grades(self):
        self.assertEqual([grade_for(n) for n in (100, 95, 94, 85, 84, 70, 69, 50, 49, 0)],
                         ["A", "A", "B", "B", "C", "C", "D", "D", "F", "F"])

    def test_nothing_to_lose_never_goes_negative(self):
        self.assertEqual(self.rep(("a", "fail", 80, False), ("b", "fail", 80, False)).score, 0)

    def test_verdicts(self):
        self.assertEqual(self.rep(("a", "pass", 1, False)).verdict, "protected")
        self.assertEqual(self.rep(("a", "warn", 1, False)).verdict, "protected-with-warnings")
        self.assertEqual(self.rep(("tunnel", "fail", 1, False), ("killswitch", "pass", 1, False)).verdict, "blocked")
        self.assertEqual(self.rep(("tunnel", "fail", 1, False), ("killswitch", "fail", 1, False)).verdict, "unprotected")


class HelperTests(unittest.TestCase):
    def test_first_ip(self):
        self.assertEqual(first_ip(["74.125.46.12"]), "74.125.46.12")
        self.assertEqual(first_ip(['edns0-client-subnet 203.0.113.0/24', "74.125.46.12"]), "203.0.113.0")
        self.assertEqual(first_ip(["2620:fe::fe"]), "2620:fe::fe")
        self.assertIsNone(first_ip(["no address here", ""]))

    def test_same_network(self):
        self.assertTrue(same_network("192.0.2.53", "192.0.2.77"))
        self.assertFalse(same_network("192.0.2.53", "192.0.3.77"))
        self.assertTrue(same_network("2001:db8:1::1", "2001:db8:1:ffff::2"))
        self.assertFalse(same_network("2001:db8:1::1", "2001:db8:2::1"))
        self.assertFalse(same_network("192.0.2.1", "2001:db8::1"))
        self.assertFalse(same_network("junk", "192.0.2.1"))


class NetProbeTests(unittest.TestCase):
    """The real probes, against sockets on loopback."""

    def test_classification(self):
        self.assertEqual(_classify(OSError(errno.EPERM, "Operation not permitted")), "blocked")
        self.assertEqual(_classify(OSError(errno.ENETUNREACH, "unreachable")), "unreachable")
        self.assertEqual(_classify(socket.timeout("timed out")), "timeout")
        self.assertEqual(_classify(OSError(errno.EIO, "io")), "error")

    def test_tcp(self):
        srv = socket.socket()
        srv.bind(("127.0.0.1", 0))
        srv.listen(1)
        port = srv.getsockname()[1]
        self.addCleanup(srv.close)
        self.assertEqual(NetProbes(timeout=1).tcp("127.0.0.1", port), "connected")
        srv.close()
        self.assertEqual(NetProbes(timeout=1).tcp("127.0.0.1", port), "connected")     # refused still proves a path
        self.assertEqual(NetProbes(timeout=1).tcp("127.0.0.1", port, device="no-such-if0"), "unavailable")

    def serve_dns(self, answer_ip="203.0.113.99", respond=True):
        srv = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        srv.bind(("127.0.0.1", 0))
        srv.settimeout(3)
        self.addCleanup(srv.close)

        def loop():
            try:
                data, addr = srv.recvfrom(512)
            except OSError:
                return
            if not respond:
                return
            name_end = data.index(b"\0", 12) + 1
            question = data[12:name_end + 4]
            resp = data[:2] + struct.pack("!HHHHH", 0x8180, 1, 1, 0, 0) + question
            resp += b"\xc0\x0c" + struct.pack("!HHIH", 1, 1, 30, 4) + socket.inet_aton(answer_ip)
            srv.sendto(resp, addr)
        t = threading.Thread(target=loop, daemon=True)
        t.start()
        return srv.getsockname()[1]

    def test_dns_probe_parses_the_answer(self):
        port = self.serve_dns()
        ans = NetProbes(timeout=2).dns("127.0.0.1", "whoami.akamai.net", "A", port=port)
        self.assertEqual((ans.status, ans.values), ("ok", ["203.0.113.99"]))
        self.assertTrue(ans.answered)

    def test_dns_probe_times_out(self):
        port = self.serve_dns(respond=False)
        ans = NetProbes(timeout=0.5).dns("127.0.0.1", "whoami.akamai.net", "A", port=port)
        self.assertEqual(ans.status, "timeout")

    def test_dns_probe_pinned_to_a_missing_device_is_unavailable(self):
        self.assertEqual(NetProbes(timeout=0.5).dns("127.0.0.1", "x.example", device="no-such-if0").status, "unavailable")

    def test_query_builder_roundtrip_sanity(self):
        q = build_query("whoami.akamai.net", "A", txid=7)
        self.assertEqual(struct.unpack("!H", q[:2])[0], 7)


if __name__ == "__main__":
    unittest.main()
