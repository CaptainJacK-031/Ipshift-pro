"""Packaging, part 3: the shell scripts, the Debian package and the source tarball (all built in temporary
directories), and the real installer and uninstaller run end-to-end inside throw-away mount and network namespaces."""
from __future__ import annotations

import hashlib
import os
import re
import shutil
import stat
import subprocess
import sys
import tarfile
import tempfile
import unittest
from pathlib import Path

import helpers  # noqa: F401  (puts src/ on sys.path)

ROOT = Path(__file__).resolve().parents[1]
PK = ROOT / "packaging"
if str(PK) not in sys.path:
    sys.path.insert(0, str(PK))

from tools import version as version_tool  # noqa: E402
from ipshift import __version__  # noqa: E402

BASH = shutil.which("bash")
HAVE_DPKG = shutil.which("dpkg-deb") is not None
SCRIPTS = ["install.sh", "uninstall.sh", "build_deb.sh", "build_tarball.sh"]
MAINTAINER_SCRIPTS = ["postinst", "prerm", "postrm"]


def run(cmd, **kw):
    kw.setdefault("capture_output", True)
    kw.setdefault("text", True)
    kw.setdefault("timeout", 300)
    return subprocess.run(cmd, **kw)


def as_nobody(cmd: list[str]) -> list[str]:
    """Run as an unprivileged user even when the tests run as root (when that is possible)."""
    if os.geteuid() == 0 and shutil.which("setpriv"):
        return ["setpriv", "--reuid=65534", "--regid=65534", "--clear-groups", *cmd]
    return cmd


@unittest.skipUnless(BASH, "bash is not installed")
class ScriptTests(unittest.TestCase):
    def text(self, name: str) -> str:
        return (PK / name).read_text()

    def test_the_scripts_are_executable(self):
        for path in [PK / n for n in SCRIPTS] + [PK / "stage.py", PK / "unstage.py"] + [PK / "debian" / n for n in MAINTAINER_SCRIPTS]:
            self.assertEqual(stat.S_IMODE(path.stat().st_mode) & 0o111, 0o111, path)

    def test_the_syntax_is_valid(self):
        for name in SCRIPTS:
            r = run(["bash", "-n", str(PK / name)])
            self.assertEqual(r.returncode, 0, (name, r.stderr))
        if shutil.which("sh"):
            for name in MAINTAINER_SCRIPTS:
                r = run(["sh", "-n", str(PK / "debian" / name)])
                self.assertEqual(r.returncode, 0, (name, r.stderr))

    def test_every_script_stops_at_the_first_error(self):
        for name in SCRIPTS:
            self.assertIn("set -euo pipefail", self.text(name), name)
        for name in MAINTAINER_SCRIPTS:
            text = (PK / "debian" / name).read_text()
            self.assertIn("set -e\n", text, name)
            self.assertTrue(text.rstrip().endswith("exit 0"), name)

    def test_help_exits_cleanly_and_changes_nothing(self):
        for name in ("install.sh", "uninstall.sh"):
            r = run(["bash", str(PK / name), "--help"])
            self.assertEqual(r.returncode, 0, r.stderr)
            self.assertIn("--prefix", r.stdout)
            self.assertIn("usage:", r.stdout)

    def test_unknown_and_incomplete_options_are_refused_before_anything_happens(self):
        for name in ("install.sh", "uninstall.sh"):
            r = run(["bash", str(PK / name), "--bogus"])
            self.assertEqual(r.returncode, 1)
            self.assertIn("unknown option", r.stderr)
            r = run(["bash", str(PK / name), "--prefix"])
            self.assertEqual(r.returncode, 1)
            self.assertIn("needs a directory", r.stderr)

    def test_without_root_nothing_happens(self):
        for name in ("install.sh", "uninstall.sh"):
            r = run(as_nobody(["bash", str(PK / name)]))
            self.assertEqual(r.returncode, 1, (name, r.stdout))
            self.assertIn("has to run as root", r.stderr)

    @unittest.skipUnless(os.geteuid() == 0, "needs root to get past the root check")
    def test_uninstall_stops_at_a_missing_manifest_before_touching_anything(self):
        with tempfile.TemporaryDirectory() as tmp:
            r = run(["bash", str(PK / "uninstall.sh"), "--prefix", tmp])
        self.assertEqual(r.returncode, 1)
        self.assertIn("no install manifest", r.stderr)
        self.assertNotIn("restore", r.stdout)

    def test_uninstall_stops_the_daemon_and_restores_the_network_before_it_removes_anything(self):
        text = self.text("uninstall.sh")
        stop, restore, remove = (text.index(s) for s in ('systemctl disable --now ipshiftd', '" restore', "unstage.py"))
        self.assertLess(stop, restore)
        self.assertLess(restore, remove)
        self.assertRegex(text, r'elif \[ "\$FORCE" -eq 1 \]; then\n\s+warn "could not restore everything; going on because of --force"')
        self.assertIn("so nothing was removed", text)                       # without --force a failed restore stops it

    def test_the_installer_enables_the_service_and_adds_a_user_only_when_asked(self):
        lines = self.text("install.sh").splitlines()
        enable = next(i for i, line in enumerate(lines) if "systemctl enable --now ipshiftd" in line)
        self.assertIn('"$ENABLE" -eq 1', lines[enable - 1])
        usermod = next(i for i, line in enumerate(lines) if line.strip().startswith("usermod -aG ipshift"))
        self.assertTrue(any('-n "$ADD_USER"' in line for line in lines[usermod - 4:usermod]))

    def test_the_installer_installs_only_through_the_staging_script(self):
        text = self.text("install.sh")
        self.assertIn('stage.py" --destdir / --prefix "$PREFIX"', text)
        self.assertIn("compileall", text)
        self.assertNotIn("cp -r", text)

    def test_the_maintainer_scripts_do_what_the_package_promises(self):
        post, pre, postrm = ((PK / "debian" / n).read_text() for n in MAINTAINER_SCRIPTS)
        self.assertNotRegex(post, r"(?m)^\s*systemctl\s+(enable|start|restart|reload)")       # never starts the daemon by itself
        self.assertIn("groupadd --system ipshift", post)
        self.assertIn("py3compile", post)
        remove_branch = pre[pre.index("remove)"):]
        self.assertLess(remove_branch.index("disable --now ipshiftd"), remove_branch.index("/usr/bin/ipshift restore"))
        self.assertIn("nft delete table inet ipshift", pre)                                  # the last resort is spelled out
        self.assertRegex(postrm, r'(?m)^    rm -rf /etc/ipshift /var/lib/ipshift /var/log/ipshift /run/ipshift$')
        self.assertIn('[ "$1" = "purge" ]', postrm)                                          # and only on purge


class VersionTests(unittest.TestCase):
    def test_the_version_comes_from_the_one_place_it_is_defined(self):
        self.assertEqual(version_tool.version(), __version__)
        self.assertIn(f'version = "{__version__}"', (ROOT / "pyproject.toml").read_text())


@unittest.skipUnless(HAVE_DPKG and BASH, "dpkg-deb is not installed")
class DebPackageTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.dir = Path(cls.tmp.name)
        env = dict(os.environ, IPSHIFT_MAINTAINER="Test Builder <builder@example.org>", SOURCE_DATE_EPOCH="1700000000")
        r = run(["bash", str(PK / "build_deb.sh"), str(cls.dir / "out")], env=env)
        assert r.returncode == 0, r.stderr
        cls.deb = Path(r.stdout.strip())
        cls.listing = run(["dpkg-deb", "-c", str(cls.deb)]).stdout.splitlines()
        cls.data = cls.dir / "data"
        cls.control = cls.dir / "control"
        assert run(["dpkg-deb", "-x", str(cls.deb), str(cls.data)]).returncode == 0
        assert run(["dpkg-deb", "-e", str(cls.deb), str(cls.control)]).returncode == 0

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def field(self, name: str) -> str:
        return run(["dpkg-deb", "-f", str(self.deb), name]).stdout.strip()

    def test_the_name_and_the_fields(self):
        self.assertEqual(self.deb.name, f"ipshift-pro_{__version__}_all.deb")
        self.assertEqual(self.field("Package"), "ipshift-pro")
        self.assertEqual(self.field("Version"), __version__)
        self.assertEqual(self.field("Architecture"), "all")
        self.assertEqual(self.field("Maintainer"), "Test Builder <builder@example.org>")
        self.assertEqual(self.field("Section"), "net")
        self.assertGreater(int(self.field("Installed-Size")), 100)

    def test_it_depends_on_what_the_daemon_needs_and_recommends_the_rest(self):
        depends, recommends = self.field("Depends"), self.field("Recommends")
        for need in ("python3 (>= 3.10)", "nftables", "iproute2", "wireguard-tools | openvpn"):
            self.assertIn(need, depends)
        for want in ("wireguard-tools", "openvpn", "python3-pyside6.qtwidgets", "ca-certificates"):
            self.assertIn(want, recommends)
        self.assertNotIn("pyside6", depends.lower())                 # the command line works without the window's toolkit

    def test_everything_is_owned_by_root_and_nothing_is_writable_by_others(self):
        self.assertGreater(len(self.listing), 60)
        for line in self.listing:
            mode, owner = line.split()[:2]
            self.assertEqual(owner, "root/root", line)
            self.assertNotIn(mode[5], "w", line)
            self.assertNotIn(mode[8], "w", line)

    def test_the_expected_files_are_in_the_package(self):
        paths = {line.split()[-1]: line.split()[0] for line in self.listing}
        for path, mode in (("./usr/bin/ipshift", "-rwxr-xr-x"), ("./usr/bin/ipshiftd", "-rwxr-xr-x"),
                           ("./usr/bin/ipshift-gui", "-rwxr-xr-x"), ("./usr/lib/systemd/system/ipshiftd.service", "-rw-r--r--"),
                           ("./usr/share/applications/ipshift-pro.desktop", "-rw-r--r--"),
                           ("./usr/share/icons/hicolor/scalable/apps/ipshift-pro.svg", "-rw-r--r--"),
                           ("./usr/share/bash-completion/completions/ipshift", "-rw-r--r--"),
                           ("./usr/share/man/man1/ipshift.1.gz", "-rw-r--r--"), ("./usr/share/man/man8/ipshiftd.8.gz", "-rw-r--r--"),
                           ("./usr/share/doc/ipshift-pro/copyright", "-rw-r--r--"),
                           ("./usr/share/doc/ipshift-pro/changelog.Debian.gz", "-rw-r--r--"),
                           ("./usr/share/doc/ipshift-pro/README.md", "-rw-r--r--"),
                           ("./usr/lib/python3/dist-packages/ipshift/daemon.py", "-rw-r--r--")):
            self.assertEqual(paths.get(path), mode, path)
        self.assertEqual([p for p in paths if "__pycache__" in p or p.endswith(".pyc")], [])
        self.assertEqual([p for p in paths if p.startswith(("./etc", "./var", "./run"))], [])      # the daemon makes its own

    def test_the_maintainer_scripts_are_there_and_executable(self):
        for name in MAINTAINER_SCRIPTS:
            mode = stat.S_IMODE((self.control / name).stat().st_mode)
            self.assertEqual(mode, 0o755, name)
        self.assertEqual(stat.S_IMODE((self.control / "control").stat().st_mode), 0o644)

    def test_the_checksums_match_and_cover_every_file(self):
        listed = {}
        for line in (self.control / "md5sums").read_text().splitlines():
            digest, _, name = line.partition("  ")
            listed[name] = digest
        on_disk = {str(p.relative_to(self.data)): p for p in self.data.rglob("*") if p.is_file()}
        self.assertEqual(set(listed), set(on_disk))
        for name, path in on_disk.items():
            self.assertEqual(hashlib.md5(path.read_bytes()).hexdigest(), listed[name], name)

    def test_the_unit_and_the_launchers_use_the_debian_paths(self):
        unit = (self.data / "usr/lib/systemd/system/ipshiftd.service").read_text()
        self.assertIn("ExecStart=/usr/bin/ipshiftd\n", unit)
        for name, shebang in (("ipshift", "#!/usr/bin/python3 -I"), ("ipshiftd", "#!/usr/bin/python3 -I"), ("ipshift-gui", "#!/usr/bin/python3")):
            text = (self.data / "usr/bin" / name).read_text()
            self.assertEqual(text.splitlines()[0], shebang)
            self.assertIn("sys.path.insert(0, '/usr/lib/python3/dist-packages')", text)
        self.assertIn("Exec=/usr/bin/ipshift-gui\n", (self.data / "usr/share/applications/ipshift-pro.desktop").read_text())

    def test_the_changelog_names_the_version_and_the_maintainer(self):
        import gzip
        text = gzip.decompress((self.data / "usr/share/doc/ipshift-pro/changelog.Debian.gz").read_bytes()).decode()
        self.assertTrue(text.startswith(f"ipshift-pro ({__version__}) unstable; urgency=medium"))
        self.assertIn(" -- Test Builder <builder@example.org>  Tue, 14 Nov 2023 22:13:20 +0000", text)      # SOURCE_DATE_EPOCH

    def test_every_module_of_the_package_is_in_it_and_imports(self):
        """The unpacked package is complete: each module imports (the window's own modules need PySide6, so those may not)."""
        code = (
            "import importlib, importlib.util, pkgutil, sys\n"
            "sys.path.insert(0, sys.argv[1])\n"
            "import ipshift\n"
            "failed = []\n"
            "for m in pkgutil.walk_packages(ipshift.__path__, 'ipshift.'):\n"
            "    try:\n"
            "        if m.name.endswith('.__main__'):\n"           # running one of these starts the program: it only has to be there
            "            if importlib.util.find_spec(m.name) is None:\n"
            "                failed.append((m.name, 'missing'))\n"
            "            continue\n"
            "        importlib.import_module(m.name)\n"
            "    except ModuleNotFoundError as e:\n"
            "        if e.name != 'PySide6':\n"
            "            failed.append((m.name, str(e)))\n"
            "print(failed)\n"
            "print(ipshift.__file__)\n"
        )
        # -B: importing must not leave .pyc files behind in the unpacked package (the checksum test compares every file)
        r = run([sys.executable, "-I", "-B", "-c", code, str(self.data / "usr/lib/python3/dist-packages")])
        self.assertEqual(r.returncode, 0, r.stderr)
        failed, where = r.stdout.splitlines()[:2]
        self.assertEqual(failed, "[]")
        self.assertTrue(where.startswith(str(self.data)), where)

    def test_a_maintainer_that_could_inject_a_field_is_refused(self):
        for bad in ("no angle brackets", "A <a@example.org>\nDepends: evil", "<only@example.org>", "A <a@example.org> trailing"):
            r = run(["bash", str(PK / "build_deb.sh"), str(self.dir / "refused")], env=dict(os.environ, IPSHIFT_MAINTAINER=bad))
            self.assertEqual(r.returncode, 1, repr(bad))
            self.assertIn("IPSHIFT_MAINTAINER must look like", r.stderr)
        self.assertFalse((self.dir / "refused").exists())

    def test_building_twice_gives_the_same_bytes(self):
        env = dict(os.environ, IPSHIFT_MAINTAINER="Test Builder <builder@example.org>", SOURCE_DATE_EPOCH="1700000000")
        again = run(["bash", str(PK / "build_deb.sh"), str(self.dir / "again")], env=env)
        self.assertEqual(again.returncode, 0, again.stderr)
        self.assertEqual(hashlib.sha256(Path(again.stdout.strip()).read_bytes()).hexdigest(),
                         hashlib.sha256(self.deb.read_bytes()).hexdigest())


@unittest.skipUnless(BASH, "bash is not installed")
class TarballTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.dir = Path(cls.tmp.name)
        r = run(["bash", str(PK / "build_tarball.sh"), str(cls.dir / "out")])
        assert r.returncode == 0, r.stderr
        cls.tar = Path(r.stdout.strip())
        with tarfile.open(cls.tar) as t:
            cls.members = {m.name: m for m in t.getmembers()}
            t.extractall(cls.dir / "x", filter="data")
        cls.top = cls.dir / "x" / f"ipshift-pro-{__version__}"

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def test_everything_sits_in_one_folder_named_after_the_version(self):
        self.assertEqual(self.tar.name, f"ipshift-pro-{__version__}.tar.gz")
        top = f"ipshift-pro-{__version__}"
        self.assertTrue(all(n == top or n.startswith(top + "/") for n in self.members), [n for n in self.members if not n.startswith(top)][:5])

    def test_it_holds_what_is_needed_and_nothing_that_is_built(self):
        top = f"ipshift-pro-{__version__}/"
        for name in ("README.md", "pyproject.toml", "src/ipshift/__init__.py", "src/ipshift/daemon.py", "packaging/install.sh",
                     "packaging/uninstall.sh", "packaging/stage.py", "packaging/systemd/ipshiftd.service.in",
                     "tests/test_packaging.py", "tests/netns_killswitch.py"):
            self.assertIn(top + name, self.members, name)
        self.assertEqual([n for n in self.members if "__pycache__" in n or n.endswith(".pyc") or "/dist/" in n or n.endswith("/dist")], [])
        self.assertEqual({(m.uid, m.gid) for m in self.members.values()}, {(0, 0)})
        self.assertEqual(self.members[top + "packaging/install.sh"].mode & 0o777, 0o755)

    def test_the_unpacked_copy_can_stage_an_install_by_itself(self):
        dest = self.dir / "stage"
        r = run([sys.executable, "-I", str(self.top / "packaging/stage.py"), "--destdir", str(dest), "--python", sys.executable]
                if re.match(r"^/[A-Za-z0-9._+/-]*\Z", sys.executable) else ["true"])
        if r.args == ["true"]:
            self.skipTest("the test interpreter's path is not a plain path")
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertTrue((dest / "usr/local/lib/ipshift/ipshift/daemon.py").is_file())
        self.assertTrue((dest / "usr/local/bin/ipshiftd").is_file())

    def test_the_unpacked_scripts_run(self):
        for name in ("install.sh", "uninstall.sh"):
            r = run(["bash", str(self.top / "packaging" / name), "--help"])
            self.assertEqual(r.returncode, 0, r.stderr)

    def test_the_unpacked_tree_builds_the_same_package(self):
        if not HAVE_DPKG:
            self.skipTest("dpkg-deb is not installed")
        r = run(["bash", str(self.top / "packaging/build_deb.sh"), str(self.dir / "deb")])
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertTrue(Path(r.stdout.strip()).is_file())


IN_NAMESPACE = r'''
set -uo pipefail
ROOT=$1; WORK=$2; VERSION=$3
FAILED=0
check() {                       # check "what" command...: runs the command and reports
    local what=$1; shift
    if "$@" >/dev/null 2>&1; then echo "ok   $what"; else echo "FAIL $what"; FAILED=1; fi
}
absent() { [ ! -e "$1" ]; }
has() { grep -q -- "$2" "$1"; }
not() { ! "$@"; }

mount -t tmpfs -o mode=0755 tmpfs /usr/local || exit 90
mount -t tmpfs -o mode=0755 tmpfs /var/lib   || exit 90
mount -t tmpfs -o mode=0755 tmpfs /var/log   || exit 90
mount -t tmpfs -o mode=0755 tmpfs /run       || exit 90
cp -a /etc "$WORK/etc" || exit 91
mount --bind "$WORK/etc" /etc || exit 91

# --- install
bash "$ROOT/packaging/install.sh" >"$WORK/install.out" 2>&1; rc=$?
check "install succeeds" test $rc -eq 0
check "install says where it put things" has "$WORK/install.out" "is installed under /usr/local"
check "install shows the next steps" has "$WORK/install.out" "usermod -aG ipshift"
check "install does not start the daemon" not has "$WORK/install.out" "the daemon is running"
check "the group exists" getent group ipshift
check "ipshift runs" test "$(/usr/local/bin/ipshift --version)" = "ipshift $VERSION"
check "ipshiftd runs" test "$(/usr/local/bin/ipshiftd --version)" = "ipshiftd $VERSION"
check "ipshift-gui runs" test "$(/usr/local/bin/ipshift-gui --version)" = "ipshift-gui $VERSION"
check "the daemon refuses a normal user it cannot serve" test "$(setpriv --reuid=65534 --regid=65534 --clear-groups /usr/local/bin/ipshiftd 2>&1 >/dev/null | grep -c -- --simulate)" -eq 1
check "the manifest exists" test -s /usr/local/share/ipshift-pro/MANIFEST
check "every file in the manifest is there" bash -c 'grep "^F " /usr/local/share/ipshift-pro/MANIFEST | cut -c3- | while read -r f; do [ -f "$f" ] || exit 1; done'
check "nothing is writable by others" test -z "$(find /usr/local -perm /022 -not -type l)"
check "everything is owned by root" test -z "$(find /usr/local -not -user root)"
check "the python files are compiled" test -d /usr/local/lib/ipshift/ipshift/__pycache__
check "doctor works without the daemon" bash -c '/usr/local/bin/ipshift doctor | grep -q "IPShift doctor"'
check "the man page is installed" test -s /usr/local/share/man/man1/ipshift.1.gz

# --- install again (an upgrade)
cp /usr/local/share/ipshift-pro/MANIFEST "$WORK/manifest.1"
touch /usr/local/lib/ipshift/ipshift/stale_module.py
bash "$ROOT/packaging/install.sh" >"$WORK/upgrade.out" 2>&1; rc=$?
check "the upgrade succeeds" test $rc -eq 0
check "the upgrade keeps the manifest the same" cmp /usr/local/share/ipshift-pro/MANIFEST "$WORK/manifest.1"
check "the upgrade removes a module that is gone" absent /usr/local/lib/ipshift/ipshift/stale_module.py

# --- options of the installer
bash "$ROOT/packaging/install.sh" --add-user no_such_user_x >"$WORK/baduser.out" 2>&1; rc=$?
check "an unknown user is refused" test $rc -eq 1
check "and says so" has "$WORK/baduser.out" "no such user"
bash "$ROOT/packaging/install.sh" --add-user nobody >"$WORK/adduser.out" 2>&1; rc=$?
check "--add-user adds the user to the group" bash -c 'id -nG nobody | tr " " "\n" | grep -qx ipshift'
check "and then does not repeat the advice to do it" not has "$WORK/adduser.out" "Let your user control it"

# --- uninstall that cannot restore the network stops, unless forced
cp /usr/local/bin/ipshift "$WORK/ipshift.real"
printf '#!/bin/sh\necho "restore went wrong" >&2\nexit 1\n' >/usr/local/bin/ipshift
bash "$ROOT/packaging/uninstall.sh" >"$WORK/stuck.out" 2>&1; rc=$?
check "a failed restore stops the uninstall" test $rc -eq 1
check "and nothing was removed" test -f /usr/local/lib/ipshift/ipshift/daemon.py
check "and it says what to do" has "$WORK/stuck.out" "nft delete table inet ipshift"
cp "$WORK/ipshift.real" /usr/local/bin/ipshift; chmod 755 /usr/local/bin/ipshift

# --- normal uninstall
mkdir -p /etc/ipshift /var/lib/ipshift
echo '{}' >/etc/ipshift/config.json; echo x >/var/lib/ipshift/history.db
bash "$ROOT/packaging/uninstall.sh" >"$WORK/uninstall.out" 2>&1; rc=$?
check "uninstall succeeds" test $rc -eq 0
check "it gave the network back first" has "$WORK/uninstall.out" "the normal network is back"
check "it says it is done" has "$WORK/uninstall.out" "IPShift Pro is removed."
check "the launchers are gone" absent /usr/local/bin/ipshift
check "the package is gone" absent /usr/local/lib/ipshift
check "no file of ours is left" test -z "$(find /usr/local -type f)"
check "the settings and history are kept" test -f /var/lib/ipshift/history.db
check "the group is kept" getent group ipshift
bash "$ROOT/packaging/uninstall.sh" >"$WORK/again.out" 2>&1; rc=$?
check "a second uninstall finds nothing to do" test $rc -eq 1
check "and says so" has "$WORK/again.out" "no install manifest"

# --- purge
bash "$ROOT/packaging/install.sh" >/dev/null 2>&1
bash "$ROOT/packaging/uninstall.sh" --purge >"$WORK/purge.out" 2>&1; rc=$?
check "uninstall --purge succeeds" test $rc -eq 0
check "purge deletes the settings" absent /etc/ipshift
check "purge deletes the state" absent /var/lib/ipshift
check "purge removes the group" not getent group ipshift
check "purge leaves other files alone" test -f /etc/hostname -o -f /etc/passwd

echo "DONE failed=$FAILED"
exit $FAILED
'''


def namespaces_work() -> bool:
    if os.geteuid() != 0 or not shutil.which("unshare") or not os.path.isdir("/usr/local") or not os.path.isdir("/var/lib"):
        return False
    try:
        return run(["unshare", "-m", "-n", "true"], timeout=30).returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


@unittest.skipUnless(namespaces_work() and BASH and shutil.which("setpriv"), "needs root and mount + network namespaces")
class InstallEndToEndTests(unittest.TestCase):
    """The real install.sh and uninstall.sh, on the real file system layout, inside namespaces that discard
    every change: /usr/local, /var/lib, /var/log and /run are fresh tmpfs mounts and /etc is a private copy."""

    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        work = Path(cls.tmp.name)
        script = work / "inside.sh"
        script.write_text(IN_NAMESPACE)
        cls.result = run(["unshare", "-m", "-n", "bash", str(script), str(ROOT), str(work), __version__])
        cls.lines = [line for line in cls.result.stdout.splitlines() if line.startswith(("ok ", "FAIL", "DONE"))]

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def test_every_check_inside_the_namespace_passed(self):
        failures = [line for line in self.lines if line.startswith("FAIL")]
        self.assertEqual(failures, [], self.result.stdout[-3000:] + self.result.stderr[-1500:])
        self.assertEqual(self.result.returncode, 0, self.result.stderr[-1500:])
        self.assertIn("DONE failed=0", self.lines)

    def test_the_run_really_covered_install_upgrade_options_uninstall_and_purge(self):
        ok = [line[5:] for line in self.lines if line.startswith("ok   ")]
        self.assertGreaterEqual(len(ok), 40)
        for wanted in ("install succeeds", "the upgrade removes a module that is gone", "--add-user adds the user to the group",
                       "a failed restore stops the uninstall", "no file of ours is left", "purge removes the group"):
            self.assertIn(wanted, ok)

    def test_the_real_system_was_not_changed(self):
        # the group was created inside the namespace's private copy of /etc only
        self.assertEqual(run(["getent", "group", "ipshift"]).returncode, 2)
        self.assertFalse(Path("/usr/local/bin/ipshift").exists())
        self.assertFalse(Path("/usr/local/lib/ipshift").exists())


if __name__ == "__main__":
    unittest.main()
