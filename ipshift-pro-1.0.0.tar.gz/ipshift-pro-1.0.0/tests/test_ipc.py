"""The socket protocol, the server's access control, the client, and the daemon as a real process."""
from __future__ import annotations

import contextlib
import inspect
import io
import json
import os
import signal
import socket
import stat
import subprocess
import sys
import threading
import time
import unittest
from pathlib import Path
from unittest import mock

from helpers import TmpRootCase

from ipshift.config import Config
from ipshift.daemon import Daemon, PidLock, main
from ipshift.engine import Engine
from ipshift.errors import (AuthError, ConfigError, DaemonUnavailable, IPShiftError, NotFound, PrivilegeError,
                            ProfileError, ProtocolError)
from ipshift.ipc import protocol
from ipshift.ipc.client import Client, diagnose, find_socket
from ipshift.ipc.server import IpcServer
from ipshift.paths import default_paths

ROOT = Path(__file__).resolve().parents[1]


def wait_for(pred, timeout=8.0, step=0.02):
    end = time.time() + timeout
    while time.time() < end:
        v = pred()
        if v:
            return v
        time.sleep(step)
    return pred()


class ProtocolTests(unittest.TestCase):
    def cmd(self, name):
        return protocol.COMMANDS[name]

    def test_every_command_maps_to_an_engine_method_with_matching_arguments(self):
        for name, cmd in protocol.COMMANDS.items():
            if not cmd.method:
                self.assertIn(name, ("ping", "subscribe"))
                continue
            fn = getattr(Engine, cmd.method, None)
            self.assertIsNotNone(fn, f"{name}: Engine.{cmd.method} is missing")
            params = inspect.signature(fn).parameters
            takes_kwargs = any(p.kind is inspect.Parameter.VAR_KEYWORD for p in params.values())
            for arg in cmd.args:
                self.assertTrue(arg in params or takes_kwargs, f"{name}: Engine.{cmd.method} has no parameter {arg!r}")
            for pname, p in params.items():
                if pname == "self" or p.kind in (p.VAR_KEYWORD, p.VAR_POSITIONAL):
                    continue
                if p.default is p.empty:
                    self.assertIn(pname, cmd.args, f"{name}: required parameter {pname!r} cannot be supplied")
                    self.assertFalse(cmd.args[pname].endswith("?"), f"{name}: {pname!r} is required by the engine")

    def test_levels_and_types_are_declared_correctly(self):
        for name, cmd in protocol.COMMANDS.items():
            self.assertIn(cmd.level, (protocol.READ, protocol.WRITE, protocol.ADMIN), name)
            for arg, tag in cmd.args.items():
                self.assertIn(tag.rstrip("?"), protocol.TYPES, f"{name}.{arg}")
        for name in ("config.set", "config.reload", "killswitch.on", "killswitch.off", "killswitch.lockdown",
                     "harden.mac", "restore"):
            self.assertEqual(self.cmd(name).level, protocol.ADMIN, name)
        for name in ("status", "ip", "profiles", "history", "events", "config.get"):
            self.assertEqual(self.cmd(name).level, protocol.READ, name)

    def test_validate_accepts_good_arguments_and_drops_nulls(self):
        out = protocol.validate(self.cmd("rotate.start"), {"interval": 1, "immediate": None})
        self.assertEqual(out, {"interval": 1})
        self.assertEqual(protocol.validate(self.cmd("status"), None), {})
        self.assertEqual(protocol.validate(self.cmd("config.set"), {"key": "a.b", "value": ["x", "y"]}),
                         {"key": "a.b", "value": ["x", "y"]})

    def test_validate_refuses_bad_arguments(self):
        v = protocol.validate
        bad = [
            ("rotate.start", {"interval": "fast"}), ("rotate.start", {"interval": True}),
            ("rotate.start", {"interval": float("nan")}), ("rotate.start", {"interval": float("inf")}),
            ("rotate.start", {"nope": 1}), ("rotate.start", [1]), ("rotate.interval", {}),
            ("history", {"limit": 1.5}), ("history", {"limit": True}), ("history", {"limit": 10 ** 15}),
            ("connect", {"profile": 5}), ("connect", {"profile": "x" * 5000}), ("connect", {"keep_rotation": 1}),
            ("privacy.check", {"only": "ipv6"}), ("privacy.check", {"only": ["a"] * 65}),
            ("privacy.check", {"only": [1]}),
            ("profile.import", {"text": "x"}), ("profile.import", {"text": "x" * (2 << 20), "name": "n"}),
            ("profile.import", {"text": "x", "name": "bad\nname"}),
            ("profile.import", {"text": "x", "name": "n", "files": {"a": 1}}),
            ("profile.import", {"text": "x", "name": "n", "files": {str(i): "x" for i in range(21)}}),
            ("config.set", {"key": "a.b", "value": {"x": 1}}), ("config.set", {"key": "a.b"}),
            ("config.set", {"key": "a.b", "value": float("nan")}),
            ("profile.update", {"ref": "x", "enabled": "yes"}), ("profile.update", {"ref": "x", "id": "new"}),
        ]
        for name, args in bad:
            with self.assertRaises(ProtocolError, msg=f"{name} {str(args)[:60]}"):
                v(self.cmd(name), args)

    def test_encode_decode(self):
        msg = {"id": 3, "cmd": "status", "args": {"fresh": True}, "text": "héllo ☃"}
        raw = protocol.encode(msg)
        self.assertTrue(raw.endswith(b"\n"))
        self.assertEqual(raw.count(b"\n"), 1)
        self.assertEqual(protocol.decode(raw), msg)
        for junk in (b"not json\n", b"[1,2]\n", b"\xff\xfe\n", b"\n", b'"str"\n'):
            with self.assertRaises(ProtocolError):
                protocol.decode(junk)

    def test_unserialisable_values_do_not_break_encoding(self):
        self.assertEqual(json.loads(protocol.encode({"p": Path("/x/y")})), {"p": "/x/y"})


class SocketCase(TmpRootCase):
    """A real daemon (simulated network) on a real Unix socket, in this process."""

    def setUp(self):
        super().setUp()
        self.cfg = Config()
        self.cfg.vpn.connect_timeout = 5.0
        self.cfg.vpn.verify_timeout = 3.0
        self.paths = default_paths()
        self.sock = self.tmp / "run" / "ipshift.sock"
        self.daemon = Daemon(self.cfg, self.paths, simulate=True, sim_speed=0.0, socket_path=self.sock)
        self.daemon.start()
        self.addCleanup(self.daemon.stop)
        self.engine = self.daemon.engine
        self.server = self.daemon.server
        self.client = Client(self.sock)
        self.wg = self.engine.store.list(protocol="wireguard")

    def raw(self) -> socket.socket:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(5)
        s.connect(str(self.sock))
        self.addCleanup(s.close)
        return s

    @staticmethod
    def rpc(s: socket.socket, obj) -> dict:
        s.sendall(obj if isinstance(obj, bytes) else protocol.encode(obj))
        return json.loads(s.makefile("rb").readline())


class RoundTripTests(SocketCase):
    def test_ping_and_status(self):
        pong = self.client.ping()
        self.assertIn("version", pong)
        st = self.client.status()
        self.assertEqual(st["protection"]["level"], "unprotected")
        self.assertTrue(st["daemon"]["simulated"])
        self.assertEqual(st["profiles"]["total"], 8)

    def test_connect_check_rotate_stop_over_the_socket(self):
        res = self.client.connect(self.wg[0].name)
        self.assertTrue(res["exit_ip"])
        self.assertEqual(self.client.status()["protection"]["level"], "protected")
        self.assertEqual(self.client.ip(refresh=True)["public"]["v4"], res["exit_ip"])
        rep = self.client.privacy_check("quick")
        self.assertEqual(len(rep["findings"]), 4)
        self.assertEqual(self.client.report()["ts"], rep["ts"])
        out = self.client.rotate_start(1.0)
        self.assertTrue(out["running"])
        self.assertTrue(wait_for(lambda: self.client.status()["rotation"]["ok"] >= 2, 10))
        self.assertEqual(self.client.set_interval(2)["interval"], 2.0)
        self.assertEqual(self.client.rotate_stop()["running"], False)
        self.assertEqual(self.client.stop()["released"], True)
        self.assertEqual(self.client.status()["protection"]["level"], "unprotected")
        h = self.client.history(5)
        self.assertGreaterEqual(h["stats"]["success"], 2)
        self.assertIn("csv", self.client.history_export())

    def test_profiles_config_killswitch_harden_restore(self):
        self.assertEqual(len(self.client.profiles()["profiles"]), 8)
        self.assertEqual(self.client.config_get("rotation.interval")["value"], 30.0)
        self.assertEqual(self.client.config_set("rotation.interval", 9)["value"], 9.0)
        self.assertTrue(self.client.killswitch_on()["armed"])
        self.assertTrue(self.client.killswitch_status()["armed"])
        self.assertFalse(self.client.killswitch_off()["armed"])
        self.assertIn("dns_locked", self.client.harden_status())
        self.assertEqual(self.client.mac("randomize", "wlan0")["iface"], "wlan0")
        self.assertEqual(self.client.restore()["killswitch"], "removed")

    def test_doctor_over_the_socket(self):
        rep = self.client.doctor()
        self.assertTrue(rep["simulated"])
        self.assertTrue(rep["ready"])
        self.assertEqual(sum(rep["summary"].values()), len(rep["checks"]))
        ids = {c["id"] for c in rep["checks"]}
        self.assertTrue({"simulation", "profiles"} <= ids)
        for c in rep["checks"]:
            self.assertIn(c["status"], ("ok", "info", "warn", "fail"))
            self.assertTrue(c["title"] and c["detail"])

    def test_profile_import_with_credentials_over_the_socket(self):
        text = "client\ndev tun\nproto udp\nremote 192.0.2.8 1194\nauth-user-pass\n"
        out = self.client.profile_import(text=text, name="from socket", tier="free", username="u", password="pw")
        pid = out["profile"]["id"]
        self.assertTrue(out["profile"]["has_auth"])
        self.assertNotIn("pw", json.dumps(out))
        self.assertEqual(self.client.profile_update(pid, notes="hello")["profile"]["notes"], "hello")
        self.assertEqual(self.client.profile_clear_quarantine(pid), {"cleared": 0})
        self.assertEqual(self.client.profile_remove(pid)["removed"], pid)

    def test_errors_keep_their_class_message_and_hint(self):
        with self.assertRaises(NotFound) as cm:
            self.client.connect("does-not-exist")
        self.assertIn("does-not-exist", str(cm.exception))
        self.assertTrue(cm.exception.hint)
        with self.assertRaises(ConfigError):
            self.client.set_interval(0.5)
        with self.assertRaises(PrivilegeError):
            self.client.config_set("vpn.openvpn_bin", "/tmp/evil")
        with self.assertRaises(ConfigError):
            self.client.config_set("rotation.interval", 0.5)
        self.assertEqual(self.client.config_get("rotation.interval")["value"], 30.0)

    def test_bad_requests_are_refused_before_reaching_the_engine(self):
        for cmd, args in (("nope", {}), ("connect", {"profile": 5}), ("status", {"x": 1}), ("history", {"limit": "a"})):
            with self.assertRaises(ProtocolError, msg=cmd):
                self.client.call(cmd, args)

    def test_internal_errors_do_not_leak_details(self):
        def boom(**kw):
            raise RuntimeError("secret internal detail /etc/shadow")
        self.engine.profiles = boom
        with self.assertLogs("ipshift.ipc.server", level="ERROR"):
            with self.assertRaises(IPShiftError) as cm:
                self.client.profiles()
        self.assertEqual(cm.exception.to_dict()["code"], "internal")
        self.assertNotIn("shadow", str(cm.exception))
        self.assertTrue(self.client.ping())                                    # still serving

    def test_concurrent_clients(self):
        results, errors = [], []

        def worker():
            try:
                for _ in range(10):
                    results.append(Client(self.sock).status()["daemon"]["pid"])
            except Exception as e:                                   # pragma: no cover
                errors.append(e)
        threads = [threading.Thread(target=worker) for _ in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(20)
        self.assertEqual(errors, [])
        self.assertEqual(len(results), 80)


class WireLevelTests(SocketCase):
    def test_a_malformed_line_gets_an_error_and_the_connection_stays_usable(self):
        s = self.raw()
        f = s.makefile("rb")
        s.sendall(b"this is not json\n")
        bad = json.loads(f.readline())
        self.assertFalse(bad["ok"])
        self.assertEqual(bad["error"]["code"], "protocol")
        s.sendall(protocol.encode({"id": "abc", "cmd": "ping"}))
        good = json.loads(f.readline())
        self.assertTrue(good["ok"])
        self.assertEqual(good["id"], "abc")

    def test_several_requests_on_one_connection_are_answered_in_order(self):
        s = self.raw()
        f = s.makefile("rb")
        s.sendall(b"".join(protocol.encode({"id": i, "cmd": "ping"}) for i in range(5)))
        self.assertEqual([json.loads(f.readline())["id"] for _ in range(5)], [0, 1, 2, 3, 4])

    def test_an_oversized_request_is_refused_and_the_connection_closed(self):
        s = self.raw()
        f = s.makefile("rb")
        try:
            s.sendall(b'{"cmd":"ping","pad":"' + b"x" * (protocol.MAX_REQUEST + 100) + b'"}\n')
        except OSError:
            pass
        reply = json.loads(f.readline())
        self.assertEqual(reply["error"]["code"], "protocol")
        self.assertEqual(f.readline(), b"")
        self.assertTrue(self.client.ping())                                    # the daemon is fine

    def test_hostile_ids_are_not_echoed_unsafely(self):
        s = self.raw()
        reply = self.rpc(s, {"id": {"a": [1]}, "cmd": "ping"})
        self.assertIsNone(reply["id"])

    def test_idle_connections_are_closed(self):
        self.server.idle_timeout = 0.3
        s = self.raw()
        s.settimeout(3)
        self.rpc(s, {"id": 1, "cmd": "ping"})
        time.sleep(0.6)
        self.assertEqual(s.recv(10), b"")

    def test_too_many_connections(self):
        self.server.max_clients = 2
        held = [self.raw(), self.raw()]
        for h in held:
            self.rpc(h, {"id": 1, "cmd": "ping"})
        third = self.raw()
        reply = json.loads(third.makefile("rb").readline())
        self.assertEqual(reply["error"]["code"], "busy")
        for h in held:                                                # the existing ones still work
            self.assertTrue(self.rpc(h, {"id": 2, "cmd": "ping"})["ok"])

    def test_arguments_are_never_logged_but_the_caller_is(self):
        with self.assertLogs("ipshift.ipc.server", level="INFO") as cm:
            try:
                self.client.profile_auth(self.engine.store.list()[0].id, "alice", "s3cret-pw-123")
            except IPShiftError:
                pass
            self.client.connect(self.wg[0].id)
            self.client.status()
        text = "\n".join(cm.output)
        self.assertNotIn("s3cret-pw-123", text)
        self.assertNotIn("alice", text)
        self.assertRegex(text, r"profile\.auth requested by uid \d+ \(pid \d+\)")
        self.assertRegex(text, r"connect requested by uid \d+")
        self.assertNotIn("status requested", text)                    # reads are not logged


class EventStreamTests(SocketCase):
    def test_events_arrive_as_things_happen(self):
        got = []
        stop = threading.Event()

        def reader():
            for ev in self.client.events(min_level="info"):
                got.append(ev["kind"])
                if "connected" in got or stop.is_set():
                    return
        t = threading.Thread(target=reader, daemon=True)
        t.start()
        time.sleep(0.2)
        self.client.connect(self.wg[0].id)
        t.join(8)
        self.assertIn("connecting", got)
        self.assertIn("connected", got)

    def test_replay_and_level_filter(self):
        self.engine.bus.publish("noise", "info", message="x")
        self.engine.bus.publish("important", "critical", message="y")
        s = self.raw()
        f = s.makefile("rb")
        s.sendall(protocol.encode({"id": 1, "cmd": "subscribe", "args": {"min_level": "warning", "replay": 10}}))
        self.assertTrue(json.loads(f.readline())["ok"])
        ev = json.loads(f.readline())["event"]
        self.assertEqual(ev["kind"], "important")
        self.assertEqual(ev["level"], "critical")

    def test_heartbeats_keep_the_stream_alive(self):
        self.server.heartbeat = 0.2
        s = self.raw()
        f = s.makefile("rb")
        s.sendall(protocol.encode({"id": 1, "cmd": "subscribe"}))
        f.readline()
        self.assertIn("hb", json.loads(f.readline()))

    def test_a_bad_subscribe_is_refused(self):
        s = self.raw()
        reply = self.rpc(s, {"id": 1, "cmd": "subscribe", "args": {"min_level": 5}})
        self.assertFalse(reply["ok"])

    def test_subscribers_are_cleaned_up_when_the_client_leaves(self):
        before = len(self.engine.bus._subs)
        s = self.raw()
        s.sendall(protocol.encode({"id": 1, "cmd": "subscribe"}))
        s.makefile("rb").readline()
        self.assertEqual(len(self.engine.bus._subs), before + 1)
        s.close()
        self.server.heartbeat = 0.1
        self.engine.bus.publish("x", "info")
        self.assertTrue(wait_for(lambda: len(self.engine.bus._subs) == before, 5))

    def test_a_slow_subscriber_cannot_block_the_engine(self):
        s = self.raw()
        s.sendall(protocol.encode({"id": 1, "cmd": "subscribe"}))
        s.makefile("rb").readline()
        t0 = time.monotonic()
        for i in range(3000):                                         # nobody reads: the queue overflows, publish never blocks
            self.engine.bus.publish("spam", "info", n=i)
        self.assertLess(time.monotonic() - t0, 5)


class AccessControlTests(SocketCase):
    def test_socket_and_directory_modes(self):
        st = os.stat(self.sock)
        self.assertTrue(stat.S_ISSOCK(st.st_mode))
        self.assertEqual(st.st_mode & 0o777, 0o600)                   # no 'ipshift' group here: owner only
        self.assertEqual(os.stat(self.sock.parent).st_mode & 0o777, 0o700)

    @unittest.skipUnless(os.geteuid() == 0, "needs root to chown")
    def test_group_access_when_the_group_exists(self):
        import grp
        name = next((g.gr_name for g in grp.getgrall() if g.gr_gid not in (0,) and g.gr_name.isidentifier()), None)
        if name is None:
            self.skipTest("no spare group")
        sock = self.tmp / "grp" / "s.sock"
        srv = IpcServer(self.engine, sock, group=name)
        srv.start()
        self.addCleanup(srv.stop)
        self.assertEqual(os.stat(sock).st_mode & 0o777, 0o660)
        self.assertEqual(os.stat(sock).st_gid, grp.getgrnam(name).gr_gid)
        self.assertEqual(os.stat(sock.parent).st_mode & 0o777, 0o750)

    def test_authorized(self):
        srv = IpcServer(self.engine, self.tmp / "x.sock", group="ipshift")
        srv._gid = 4242
        me = os.geteuid()
        self.assertTrue(srv.authorized(0, 0))
        self.assertTrue(srv.authorized(me, 99999))
        self.assertTrue(srv.authorized(me + 1, 4242))                 # primary group matches
        with mock.patch("ipshift.ipc.server.pwd.getpwuid") as pw, mock.patch("ipshift.ipc.server.os.getgrouplist") as gl:
            pw.return_value.pw_name = "someone"
            gl.return_value = [100, 4242]
            self.assertTrue(srv.authorized(me + 1, 100))              # supplementary group matches
            gl.return_value = [100, 200]
            self.assertFalse(srv.authorized(me + 1, 100))
            pw.side_effect = KeyError
            self.assertFalse(srv.authorized(me + 1, 100))
        srv._gid = None                                               # the group does not exist: only root and us
        self.assertFalse(srv.authorized(me + 1, 4242))

    def test_allowed_uids_narrow_access_further(self):
        srv = IpcServer(self.engine, self.tmp / "x.sock", group="ipshift", allowed_uids=[1234])
        srv._gid = 4242
        self.assertTrue(srv.authorized(0, 0))
        self.assertTrue(srv.authorized(1234, 1))
        self.assertFalse(srv.authorized(1235, 4242))                  # in the group, but not on the list

    @unittest.skipUnless(os.geteuid() == 0, "needs root to switch users")
    def test_the_kernel_identity_of_the_peer_is_checked_even_if_the_socket_is_world_writable(self):
        """Layer 2: the file permissions are 'forgotten' (chmod 666) and a different user connects."""
        os.chmod(self.sock.parent, 0o755)
        os.chmod(self.tmp, 0o755)
        os.chmod(self.sock, 0o666)
        code = ("import json,socket,sys\n"
                "s=socket.socket(socket.AF_UNIX);s.settimeout(5);s.connect(sys.argv[1])\n"
                "try:\n"
                " s.sendall(b'{\"id\":1,\"cmd\":\"status\"}\\n')\n"
                "except OSError:\n"
                " pass\n"
                "print(s.makefile('rb').readline().decode())\n")
        out = subprocess.run([sys.executable, "-c", code, str(self.sock)], user=65534, group=65534,
                             capture_output=True, text=True, timeout=20)
        self.assertEqual(out.returncode, 0, out.stderr)
        reply = json.loads(out.stdout)
        self.assertFalse(reply["ok"])
        self.assertEqual(reply["error"]["code"], "auth")
        self.assertTrue(self.client.ping())                           # the daemon itself is unaffected

    @unittest.skipUnless(os.geteuid() == 0, "needs root to switch users")
    def test_a_refused_user_is_told_why_by_the_real_client(self):
        os.chmod(self.sock.parent, 0o755)
        os.chmod(self.tmp, 0o755)
        os.chmod(self.sock, 0o666)
        code = ("import sys\n"
                "from ipshift.ipc.client import Client\n"
                "from ipshift.errors import IPShiftError\n"
                "try:\n Client(sys.argv[1]).status()\n"
                "except IPShiftError as e:\n print(e.code, '|', e, '|', e.hint)\n")
        env = dict(os.environ, PYTHONPATH=str(ROOT / "src"))
        out = subprocess.run([sys.executable, "-c", code, str(self.sock)], user=65534, group=65534, env=env,
                             capture_output=True, text=True, timeout=20)
        self.assertEqual(out.returncode, 0, out.stderr)
        self.assertTrue(out.stdout.startswith("auth |"), out.stdout)
        self.assertIn("ipshift", out.stdout)

    @unittest.skipUnless(os.geteuid() == 0, "needs root to switch users")
    def test_another_user_cannot_even_open_the_socket(self):
        code = ("import socket,sys\n"
                "s=socket.socket(socket.AF_UNIX)\n"
                "try:\n s.connect(sys.argv[1]); print('CONNECTED')\n"
                "except PermissionError: print('DENIED')\n")
        os.chmod(self.tmp, 0o755)
        out = subprocess.run([sys.executable, "-c", code, str(self.sock)], user=65534, group=65534,
                             capture_output=True, text=True, timeout=20)
        self.assertEqual(out.stdout.strip(), "DENIED", out.stderr)


class LifecycleTests(SocketCase):
    def test_stop_closes_clients_and_removes_the_socket(self):
        s = self.raw()
        self.rpc(s, {"id": 1, "cmd": "ping"})
        sub = self.raw()
        sub.sendall(protocol.encode({"id": 1, "cmd": "subscribe"}))
        sub.makefile("rb").readline()
        self.daemon.stop()
        self.assertFalse(self.sock.exists())
        self.assertEqual(s.makefile("rb").readline(), b"")
        sub.settimeout(5)
        rest = b""
        try:
            while True:
                chunk = sub.recv(4096)
                if not chunk:
                    break
                rest += chunk
        except OSError:
            pass
        with self.assertRaises(DaemonUnavailable) as cm:
            Client(self.sock).status()
        self.assertIn("not running", str(cm.exception))
        self.assertIn("systemctl start ipshiftd", cm.exception.hint)
        self.assertFalse(self.paths.pidfile.exists())

    def test_stopping_does_not_wait_for_an_event_subscriber_to_wake_up(self):
        sub = self.raw()
        sub.sendall(protocol.encode({"id": 1, "cmd": "subscribe"}))
        sub.makefile("rb").readline()
        t0 = time.monotonic()
        self.server.stop()
        self.assertLess(time.monotonic() - t0, 1.5, "stop() waited for the subscriber's next heartbeat")

    def test_a_second_server_on_the_same_socket_is_refused_and_leaves_the_first_alone(self):
        other = IpcServer(self.engine, self.sock)
        with self.assertRaises(IPShiftError) as cm:
            other.start()
        self.assertIn("already listening", str(cm.exception))
        other.stop()                                                  # must not remove somebody else's socket
        self.assertTrue(self.sock.exists())
        self.assertTrue(self.client.ping())

    def test_a_second_daemon_is_refused_by_the_pid_lock(self):
        second = Daemon(Config(), self.paths, simulate=True, sim_speed=0.0, socket_path=self.tmp / "other.sock")
        with self.assertRaises(IPShiftError) as cm:
            second.start()
        self.assertIn("already running", str(cm.exception))
        self.assertTrue(self.client.ping())
        self.assertTrue(self.paths.pidfile.exists())                  # the first daemon's lock is untouched

    def test_a_stale_socket_file_is_replaced(self):
        self.daemon.stop()
        s = socket.socket(socket.AF_UNIX)
        s.bind(str(self.sock))
        s.close()                                                     # leaves a dead socket file behind
        d = Daemon(Config(), self.paths, simulate=True, sim_speed=0.0, socket_path=self.sock)
        d.start()
        self.addCleanup(d.stop)
        self.assertTrue(Client(self.sock).ping())

    def test_a_reload_signal_that_arrives_before_the_engine_exists_is_ignored(self):
        early = Daemon(Config(), self.paths, simulate=True, sim_speed=0.0, socket_path=self.tmp / "early.sock")
        early.reload()                                                # no engine yet: nothing to reload, nothing raised
        self.assertIsNone(early.engine)

    def test_a_stop_requested_during_start_up_ends_the_wait_at_once(self):
        d = Daemon(Config(), self.paths, simulate=True, sim_speed=0.0, socket_path=self.tmp / "early2.sock")
        d.request_stop()                                              # what the SIGTERM handler does
        t0 = time.monotonic()
        d.wait()
        self.assertLess(time.monotonic() - t0, 1.0)

    def test_pid_lock(self):
        a, b = PidLock(self.tmp / "p.pid"), PidLock(self.tmp / "p.pid")
        a.acquire()
        self.assertEqual((self.tmp / "p.pid").read_text().strip(), str(os.getpid()))
        with self.assertRaises(IPShiftError):
            b.acquire()
        a.release()
        b.acquire()
        b.release()
        self.assertFalse((self.tmp / "p.pid").exists())


class ClientTests(TmpRootCase):
    def test_nothing_listening(self):
        with self.assertRaises(DaemonUnavailable) as cm:
            Client(self.tmp / "nope.sock").status()
        self.assertIn("not running", str(cm.exception))
        self.assertIn("--simulate", cm.exception.hint)

    def test_autodiscovery_uses_the_environment(self):
        os.environ["IPSHIFT_SOCKET"] = str(self.tmp / "custom.sock")
        with self.assertRaises(DaemonUnavailable) as cm:
            find_socket()
        self.assertIn("custom.sock", str(cm.exception))

    def test_stale_socket_is_explained(self):
        path = self.tmp / "stale.sock"
        s = socket.socket(socket.AF_UNIX)
        s.bind(str(path))
        s.close()
        with self.assertRaises(DaemonUnavailable) as cm:
            Client(path).status()
        self.assertIn("does not answer", str(cm.exception))
        self.assertIn("restart ipshiftd", cm.exception.hint)

    def test_permission_denied_is_explained(self):
        err = diagnose([Path("/run/ipshift/ipshift.sock")], {Path("/run/ipshift/ipshift.sock"): PermissionError(13, "x")})
        self.assertIn("permission denied", str(err))
        self.assertIn("usermod -aG ipshift", err.hint)

    def test_a_daemon_that_never_answers_times_out_with_a_hint(self):
        path = self.tmp / "mute.sock"
        srv = socket.socket(socket.AF_UNIX)
        srv.bind(str(path))
        srv.listen(1)
        self.addCleanup(srv.close)
        with self.assertRaises(DaemonUnavailable) as cm:
            Client(path).call("status", timeout=0.3)
        self.assertIn("did not answer", str(cm.exception))
        self.assertIn("may still be running", cm.exception.hint)

    def test_a_daemon_that_hangs_up(self):
        path = self.tmp / "hangup.sock"
        srv = socket.socket(socket.AF_UNIX)
        srv.bind(str(path))
        srv.listen(1)
        self.addCleanup(srv.close)
        srv.settimeout(5)

        def hang_up_on_everyone():
            try:
                while True:
                    srv.accept()[0].close()
            except OSError:
                pass
        threading.Thread(target=hang_up_on_everyone, daemon=True).start()
        with self.assertRaises(DaemonUnavailable) as cm:
            Client(path).status()
        self.assertRegex(str(cm.exception), "closed the connection|lost the connection")


class DaemonProcessTests(TmpRootCase):
    """ipshiftd as a real process: start, talk to it, reload, stop with a signal."""

    def start(self, *extra):
        env = dict(os.environ, PYTHONPATH=str(ROOT / "src"), IPSHIFT_ROOT=str(self.tmp))
        env.pop("NOTIFY_SOCKET", None)
        proc = subprocess.Popen([sys.executable, "-m", "ipshift.daemon", "--simulate", "--sim-speed", "0", *extra],
                                env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        def reap():
            if proc.poll() is None:
                proc.kill()
            proc.communicate()
        self.addCleanup(reap)
        sock = self.tmp / "run" / "ipshift.sock"
        if not wait_for(lambda: sock.exists() and proc.poll() is None, 15):
            proc.kill()
            self.fail("the daemon did not start:\n" + proc.communicate()[0])
        return proc, sock

    def test_start_serve_reload_and_stop_on_sigterm(self):
        proc, sock = self.start()
        c = Client(sock)
        self.assertEqual(c.status()["daemon"]["pid"], proc.pid)
        self.assertTrue(c.connect()["exit_ip"])
        cfg = self.tmp / "etc" / "config.json"
        cfg.parent.mkdir(parents=True, exist_ok=True)
        cfg.write_text(json.dumps({"rotation": {"interval": 11}}))
        proc.send_signal(signal.SIGHUP)
        self.assertTrue(wait_for(lambda: c.config_get("rotation.interval")["value"] == 11.0, 5))
        proc.send_signal(signal.SIGTERM)
        out = proc.communicate(timeout=20)[0]
        self.assertEqual(proc.returncode, 0, out)
        self.assertFalse(sock.exists())
        self.assertFalse((self.tmp / "run" / "ipshiftd.pid").exists())
        self.assertIn("SIMULATION", out)

    def test_sigint_also_stops_it(self):
        proc, _ = self.start()
        proc.send_signal(signal.SIGINT)
        proc.communicate(timeout=20)
        self.assertEqual(proc.returncode, 0)

    def test_a_second_process_refuses_to_start(self):
        proc, sock = self.start()
        env = dict(os.environ, PYTHONPATH=str(ROOT / "src"), IPSHIFT_ROOT=str(self.tmp))
        second = subprocess.run([sys.executable, "-m", "ipshift.daemon", "--simulate"], env=env,
                                capture_output=True, text=True, timeout=30)
        self.assertEqual(second.returncode, 1)
        self.assertIn("already running", second.stderr)
        self.assertTrue(Client(sock).ping())

    def test_invalid_config_is_a_clear_error(self):
        cfg = self.tmp / "etc" / "config.json"
        cfg.parent.mkdir(parents=True, exist_ok=True)
        cfg.write_text(json.dumps({"rotation": {"interval": 0.1}}))
        env = dict(os.environ, PYTHONPATH=str(ROOT / "src"), IPSHIFT_ROOT=str(self.tmp))
        out = subprocess.run([sys.executable, "-m", "ipshift.daemon", "--simulate"], env=env,
                             capture_output=True, text=True, timeout=30)
        self.assertEqual(out.returncode, 2)
        self.assertIn("rotation.interval", out.stderr)

    def test_main_checks(self):
        out, err = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            self.assertEqual(main(["--version"]), 0)
            self.assertEqual(main(["--simulate", "--sim-speed", "-1"]), 2)
            with mock.patch("ipshift.daemon.is_root", return_value=False):
                self.assertEqual(main([]), 2)
        self.assertIn("ipshiftd 1.0.0", out.getvalue())
        self.assertIn("--sim-speed must be between 0 and 100", err.getvalue())
        self.assertIn("must run as root", err.getvalue())


if __name__ == "__main__":
    unittest.main()
