from __future__ import annotations

import http.server
import json
import os
import random
import shutil
import socket
import ssl
import subprocess
import tempfile
import threading
import unittest
from pathlib import Path

from helpers import FakeRunner, TmpRootCase

from ipshift.config import PrivacyConfig
from ipshift.net.echo import EchoResolver, parse_echo_body
from ipshift.net.http import HttpError, HttpResponse, http_get, http_post
from ipshift.net.local import NetInfo, scope_of


class _Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):  # keep test output clean
        pass

    def do_GET(self):
        if self.path == "/ip":
            body = b"203.0.113.7\n"
        elif self.path == "/big":
            body = b"x" * 200_000
        elif self.path == "/v6":
            body = b"2001:db8::7\n"
        else:
            self.send_error(404)
            return
        self.send_response(200)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        data = self.rfile.read(n)
        self.send_response(200)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("X-Ctype", self.headers.get("Content-Type", ""))
        self.end_headers()
        self.wfile.write(data)


def serve(tls: tuple[str, str] | None = None):
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
    if tls:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(*tls)
        srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    return srv, srv.server_address[1]


class HttpTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv, cls.port = serve()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()
        cls.srv.server_close()

    def test_get_post_and_family(self):
        r = http_get(f"http://127.0.0.1:{self.port}/ip", family=socket.AF_INET)
        self.assertEqual((r.status, r.text.strip()), (200, "203.0.113.7"))
        p = http_post(f"http://127.0.0.1:{self.port}/echo", b"abc", "application/dns-message")
        self.assertEqual((p.body, p.headers["x-ctype"]), (b"abc", "application/dns-message"))

    def test_size_cap(self):
        with self.assertRaises(HttpError):
            http_get(f"http://127.0.0.1:{self.port}/big", max_bytes=1000)

    def test_plain_http_only_for_loopback(self):
        with self.assertRaises(HttpError):
            http_get("http://example.com/")
        with self.assertRaises(HttpError):
            http_get("ftp://127.0.0.1/")

    def test_connection_refused_is_httperror(self):
        s = socket.socket()
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]
        s.close()
        with self.assertRaises(HttpError):
            http_get(f"http://127.0.0.1:{port}/", timeout=2)


@unittest.skipUnless(shutil.which("openssl"), "openssl not installed")
class TlsTests(unittest.TestCase):
    def test_verification_is_enforced(self):
        d = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, d, True)
        crt, key = os.path.join(d, "c.pem"), os.path.join(d, "k.pem")
        subprocess.run(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-keyout", key,
                        "-out", crt, "-days", "2", "-subj", "/CN=localhost",
                        "-addext", "subjectAltName=DNS:localhost,IP:127.0.0.1"],
                       check=True, capture_output=True)
        srv, port = serve((crt, key))
        self.addCleanup(srv.server_close)
        self.addCleanup(srv.shutdown)
        ok = http_get(f"https://127.0.0.1:{port}/ip", cafile=crt)       # trusted + IP SAN matches
        self.assertEqual(ok.text.strip(), "203.0.113.7")
        with self.assertRaises(HttpError):                              # not in the system trust store
            http_get(f"https://127.0.0.1:{port}/ip")


class EchoTests(unittest.TestCase):
    def make(self, answers: dict, rng=None, **cfg):
        priv = PrivacyConfig(ip_echo_v4=[f"https://{h}/" for h in answers], quorum=cfg.pop("quorum", 2), **cfg)
        calls = []

        def fetch(url, **kw):
            calls.append(url)
            host = url.split("/")[2]
            v = answers[host]
            if isinstance(v, Exception):
                raise v
            return v if isinstance(v, HttpResponse) else HttpResponse(200, {}, v.encode())

        return EchoResolver(priv, fetch=fetch, rng=rng or random.Random(1)), calls

    def test_parse_body(self):
        self.assertEqual(parse_echo_body("  203.0.113.9\n", 4), "203.0.113.9")
        self.assertEqual(parse_echo_body("2001:DB8::1", 6), "2001:db8::1")
        self.assertIsNone(parse_echo_body("2001:db8::1", 4))     # wrong family
        self.assertIsNone(parse_echo_body("<html>blocked</html>", 4))
        self.assertIsNone(parse_echo_body("", 4))

    def test_quorum_asks_only_what_it_needs(self):
        r, calls = self.make({"a": "203.0.113.1", "b": "203.0.113.1", "c": "203.0.113.1", "d": "203.0.113.1"})
        res = r.lookup(4)
        self.assertEqual((res.ip, res.agree), ("203.0.113.1", 2))
        self.assertEqual(len(calls), 2)                          # did not bother the other two

    def test_widens_when_first_batch_disagrees(self):
        class InOrder:                      # no shuffling: first batch is exactly a, b
            def shuffle(self, x):
                pass

        r, calls = self.make({"a": "203.0.113.1", "b": "198.51.100.2", "c": "203.0.113.1", "d": "203.0.113.1"},
                             rng=InOrder())
        res = r.lookup(4)
        self.assertEqual((res.ip, res.agree), ("203.0.113.1", 3))
        self.assertEqual(len(calls), 4)

    def test_failures_and_no_consensus(self):
        r, _ = self.make({"a": HttpError("boom"), "b": HttpError("boom"), "c": HttpError("down")})
        res = r.lookup(4)
        self.assertFalse(res.ok)
        self.assertIn("no echo service answered", res.error)
        r, _ = self.make({"a": "203.0.113.1", "b": "198.51.100.2", "c": "192.0.2.3"})
        res = r.lookup(4)
        self.assertIsNone(res.ip)
        self.assertIsNotNone(res.candidate)                      # shown as "unverified" by UIs
        self.assertIn("no consensus", res.error)

    def test_one_liar_cannot_win(self):
        r, _ = self.make({"a": "198.51.100.66", "b": "203.0.113.1", "c": "203.0.113.1"})
        self.assertEqual(r.lookup(4).ip, "203.0.113.1")

    def test_http_error_status_and_garbage(self):
        r, _ = self.make({"a": HttpResponse(503, {}, b"nope"), "b": "not an ip"}, quorum=1)
        res = r.lookup(4)
        self.assertFalse(res.ok)
        self.assertTrue(all(v.startswith("error") for v in res.answers.values()))

    def test_single_service_with_default_quorum(self):
        r, _ = self.make({"only": "203.0.113.5"})
        self.assertEqual(r.lookup(4).ip, "203.0.113.5")          # quorum is capped at what exists

    def test_no_services(self):
        res = EchoResolver(PrivacyConfig(ip_echo_v4=[]), fetch=None).lookup(4)
        self.assertEqual(res.error, "no echo services configured")

    def test_real_http_roundtrip(self):
        srv, port = serve()
        self.addCleanup(srv.server_close)
        self.addCleanup(srv.shutdown)
        priv = PrivacyConfig(ip_echo_v4=[f"http://127.0.0.1:{port}/ip"], quorum=1)
        res = EchoResolver(priv).lookup(4)
        self.assertEqual(res.ip, "203.0.113.7")
        self.assertEqual(res.to_dict()["agree"], 1)


IP_ADDR_JSON = json.dumps([
    {"ifname": "lo", "flags": ["LOOPBACK", "UP", "LOWER_UP"], "operstate": "UNKNOWN", "address": "00:00:00:00:00:00",
     "addr_info": [{"family": "inet", "local": "127.0.0.1", "prefixlen": 8}]},
    {"ifname": "wlan0", "flags": ["BROADCAST", "UP", "LOWER_UP"], "operstate": "UP", "address": "aa:bb:cc:dd:ee:ff",
     "addr_info": [{"family": "inet", "local": "172.20.10.4", "prefixlen": 28},
                   {"family": "inet6", "local": "2001:db8::4", "prefixlen": 64},
                   {"family": "inet6", "local": "fe80::1", "prefixlen": 64}]},
    {"ifname": "ipshift0", "flags": ["POINTOPOINT", "UP", "LOWER_UP"], "operstate": "UNKNOWN",
     "addr_info": [{"family": "inet", "local": "10.8.0.2", "prefixlen": 24}]},
    {"ifname": "eth1", "flags": ["BROADCAST"], "operstate": "DOWN", "address": "11:22:33:44:55:66", "addr_info": []},
])


class LocalTests(TmpRootCase):
    def sysfs(self) -> Path:
        s = self.tmp / "sys"
        for n in ("lo", "wlan0", "ipshift0", "eth1", "usb0", "br0", "veth9"):
            (s / n).mkdir(parents=True)
        (s / "wlan0" / "wireless").mkdir()
        (s / "wlan0" / "device").mkdir()
        (s / "ipshift0" / "tun_flags").write_text("0x1002")
        (s / "eth1" / "device").mkdir()
        (s / "br0" / "bridge").mkdir()
        (s / "usb0" / "device").mkdir()
        drv = self.tmp / "drivers" / "rndis_host"
        drv.mkdir(parents=True)
        os.symlink(drv, s / "usb0" / "device" / "driver")
        return s

    def net(self, runner=None, **kw):
        return NetInfo(runner or FakeRunner(), sysroot=self.sysfs(), procroot=self.tmp / "proc", **kw)

    def test_classification(self):
        n = self.net()
        self.assertEqual(n.classify("lo"), ("loopback", False))
        self.assertEqual(n.classify("wlan0"), ("wifi", True))
        self.assertEqual(n.classify("ipshift0"), ("tunnel", False))
        self.assertEqual(n.classify("eth1"), ("ethernet", True))
        self.assertEqual(n.classify("usb0"), ("usb-tether", True))
        self.assertEqual(n.classify("br0"), ("bridge", False))
        self.assertEqual(n.classify("veth9"), ("virtual", False))
        self.assertEqual(n.classify("wg0")[0], "tunnel")
        self.assertEqual(n.classify("wwan0")[0], "mobile")

    def test_ip_json_parsing_and_private_ips(self):
        r = FakeRunner([("ip -j addr show", (0, IP_ADDR_JSON)),
                        ("ip -4 -j route show default" if False else "ip -j -4 route show default",
                         (0, json.dumps([{"dst": "default", "gateway": "172.20.10.1", "dev": "wlan0",
                                          "prefsrc": "172.20.10.4", "metric": 600}])))])
        n = self.net(r)
        ifs = {i.name: i for i in n.interfaces()}
        self.assertTrue(ifs["wlan0"].up)
        self.assertFalse(ifs["eth1"].up)
        self.assertEqual(ifs["wlan0"].ipv4, ["172.20.10.4/28"])
        self.assertEqual(ifs["ipshift0"].kind, "tunnel")
        ips = n.private_ips()
        got = {(p["iface"], p["ip"]): p for p in ips}
        self.assertNotIn(("lo", "127.0.0.1"), got)                # loopback hidden
        self.assertNotIn(("wlan0", "fe80::1"), got)               # link-local hidden
        self.assertTrue(got[("wlan0", "172.20.10.4")]["primary"])
        self.assertEqual(got[("wlan0", "2001:db8::4")]["family"], 6)
        s = n.summary()
        self.assertEqual((s["default_iface"], s["kind"], s["hotspot"]), ("wlan0", "wifi", "iPhone hotspot"))

    def test_change_key_ignores_tunnel_but_sees_network_change(self):
        a = {"default_iface": "wlan0", "gateway": "1.1.1.1",
             "private_ips": [{"iface": "wlan0", "ip": "192.168.1.5", "kind": "wifi"},
                             {"iface": "ipshift0", "ip": "10.8.0.2", "kind": "tunnel"}]}
        b = json.loads(json.dumps(a))
        b["private_ips"][1]["ip"] = "10.9.0.2"
        self.assertEqual(NetInfo.change_key(a), NetInfo.change_key(b))
        b["private_ips"][0]["ip"] = "192.168.43.9"
        self.assertNotEqual(NetInfo.change_key(a), NetInfo.change_key(b))

    def test_route_get_json(self):
        r = FakeRunner([("ip -j -4 route get 9.9.9.9", (0, json.dumps([{"dst": "9.9.9.9", "gateway": "10.8.0.1", "dev": "ipshift0"}])))])
        self.assertEqual(self.net(r).route_get("9.9.9.9").iface, "ipshift0")

    def test_procfs_fallback_when_ip_is_missing(self):
        proc = self.tmp / "proc"
        proc.mkdir()
        # default via 192.168.1.1 on wlan0 (metric 600); 10.0.0.0/8 via ipshift0
        (proc / "route").write_text(
            "Iface\tDestination\tGateway\tFlags\tRefCnt\tUse\tMetric\tMask\tMTU\tWindow\tIRTT\n"
            "wlan0\t00000000\t0101A8C0\t0003\t0\t0\t600\t00000000\t0\t0\t0\n"
            "wlan0\t0001A8C0\t00000000\t0001\t0\t0\t600\t00FFFFFF\t0\t0\t0\n"
            "ipshift0\t0000000A\t0100000A\t0003\t0\t0\t50\t000000FF\t0\t0\t0\n")
        r = FakeRunner(default_rc=127)
        n = self.net(r)
        d = n.default_route(4)
        self.assertEqual((d.iface, d.gateway, d.metric), ("wlan0", "192.168.1.1", 600))
        self.assertEqual(n.route_get("10.1.2.3").iface, "ipshift0")      # longest prefix wins
        self.assertEqual(n.route_get("192.168.1.77").iface, "wlan0")
        self.assertEqual(n.route_get("8.8.8.8").iface, "wlan0")

    def test_scope_and_hotspot_hints(self):
        self.assertEqual(scope_of("192.168.0.4"), "private")
        self.assertEqual(scope_of("100.72.1.1"), "cgnat")
        self.assertEqual(scope_of("169.254.3.3"), "link-local")
        self.assertEqual(scope_of("fd00::1"), "private")
        self.assertEqual(scope_of("8.8.8.8"), "global")
        self.assertEqual(scope_of("nonsense"), "unknown")
        self.assertEqual(NetInfo.hotspot_hint("usb-tether", "192.168.42.129"), "USB tethering")
        self.assertEqual(NetInfo.hotspot_hint("wifi", "192.168.43.1"), "Android hotspot")
        self.assertIsNone(NetInfo.hotspot_hint("ethernet", "192.168.1.1"))


if __name__ == "__main__":
    unittest.main()
