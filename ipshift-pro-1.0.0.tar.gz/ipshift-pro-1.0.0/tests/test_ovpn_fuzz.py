"""A fixed-seed fuzz of the OpenVPN profile cleaner.

Whatever hostile text goes in, nothing but ProfileError may come out as an error, every line of the cleaned
profile must start with an allow-listed option, nothing may switch the encryption off, and no value may
carry shell metacharacters, control characters or a path.
"""
from __future__ import annotations

import random
import re
import unittest

from ipshift.errors import ProfileError
from ipshift.vpn import ovpn

CERT = "-----BEGIN CERTIFICATE-----\nMIIBkTCB+wIJAK\nAAAAAAAAAAA=\n-----END CERTIFICATE-----"
ALLOWED_FIRST = set(ovpn._PASS) | {"pull-filter", "verify-x509-name", "key-direction"}
NAMES = sorted(set(ovpn._PASS) | ovpn._HANDLED | ovpn._DANGEROUS) + [
    "up", "script-security", "plugin", "setenv", "push-peer-info", "UP", "Plugin", "--up", "-up", "up\x0b", "\u00a0up",
    "u\\p", "\"up\"", "'up'", "up;", "#up", ";up", "remote", "proto", "pull-filter", "verify-x509-name", "auth-user-pass",
    "cipher", "auth", "tls-auth", "ca", "cert", "key",
]
ARGS = ["/tmp/x.sh", "none", "AES-256-GCM", "tcp", "udp", "1194", "vpn.example.net", "ignore", "\"redirect-gateway\"",
        "a;b", "a\\nup /bin/sh", "$(id)", "`id`", "../../etc/shadow", "C:\\x", "[inline]", "1", "0", "server", "-x",
        "x" * 300, "\u2028", "\u00a0", "\t", "''", "\"", "'", "AES:none", "SHA256", "\x0b", "\x0c", "\x1c", "\x85"]
SEPS = [" ", "\t", "  ", " \t ", "\u00a0", "\x0b", "\x0c", "\u2028", "\x1c", "\x85", "\r", ""]
EOLS = ["\n", "\r\n", "\r", "\n\n", "\u2028", "\x85", "\x0b", "\x0c"]
TAGS = ["ca", "cert", "key", "tls-auth", "tls-crypt", "connection", "auth-user-pass", "dh", "UP", "up", "plugin"]
BODIES = [CERT, "up /bin/sh", "remote a.example.net 1194\nup /x", "alice\nsecret", "junk", "", CERT + "\nup /x"]
BAD_CHARS = re.compile(r"[;`$\\\x00-\x08\x0b-\x1f\x7f\u2028\u00a0\x85]|/tmp|/etc|\.\./")


def hostile_line(rnd: random.Random) -> str:
    parts = [rnd.choice(NAMES)] + [rnd.choice(ARGS) for _ in range(rnd.randint(0, 3))]
    text = (rnd.choice(SEPS) or " ").join(parts)
    return text.upper() if rnd.random() < 0.1 else text


def hostile_block(rnd: random.Random) -> str:
    tag = rnd.choice(TAGS)
    return f"<{tag}>\n{rnd.choice(BODIES)}\n</{tag}>"


class CleanerFuzz(unittest.TestCase):
    CASES = 4000

    def test_nothing_hostile_survives(self):
        rnd = random.Random(20261024)
        accepted = 0
        for _ in range(self.CASES):
            chunks = ["client", "remote vpn.example.net 1194"]
            for _ in range(rnd.randint(1, 12)):
                chunks.append(hostile_block(rnd) if rnd.random() < 0.2 else hostile_line(rnd))
            text = rnd.choice(EOLS).join(chunks)
            try:
                cleaned = ovpn.sanitize(text, files={"x.sh": "alice\nsecret"})
            except ProfileError:
                continue
            accepted += 1
            self.assertNotIn("push-peer-info", cleaned.body, repr(text[:300]))
            in_block = None
            for line in cleaned.body.split("\n"):
                if not line or line.startswith("#"):
                    continue
                opened = re.fullmatch(r"<([a-z0-9-]+)>", line)
                if opened:
                    in_block = opened.group(1)
                    continue
                if line == f"</{in_block}>":
                    in_block = None
                    continue
                if in_block:                                        # certificate and key data only
                    self.assertRegex(line.replace("-----", ""), r"^[A-Za-z0-9+/= -]*$", repr(line))
                    continue
                first = line.split(" ")[0]
                self.assertIn(first, ALLOWED_FIRST, f"{line!r} from {text[:300]!r}")
                if first != "verify-x509-name":
                    self.assertIsNone(BAD_CHARS.search(line), repr(line))
                if first in ("cipher", "data-ciphers", "data-ciphers-fallback", "ncp-ciphers", "auth"):
                    values = [p.lower() for a in line.split(" ")[1:] for p in a.strip('"').split(":")]
                    self.assertNotIn("none", values, repr(line))
        self.assertGreater(accepted, self.CASES // 10)              # the generator produces usable profiles too


if __name__ == "__main__":
    unittest.main()
