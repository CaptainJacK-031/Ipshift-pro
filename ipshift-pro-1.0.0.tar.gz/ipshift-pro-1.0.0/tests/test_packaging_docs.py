"""Packaging, part 2: the completion script and the manual pages (both generated from the real command line
grammar) and the documentation that names commands and settings."""
from __future__ import annotations

import argparse
import dataclasses
import gzip
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import helpers  # noqa: F401  (puts src/ on sys.path)

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "packaging") not in sys.path:
    sys.path.insert(0, str(ROOT / "packaging"))

from tools import completion, docs, grammar, manpages, render  # noqa: E402
from ipshift import __version__  # noqa: E402
from ipshift import config as config_module  # noqa: E402
from ipshift.cli import manage  # noqa: E402
from ipshift.cli.parser import EPILOG, build_parser  # noqa: E402
from ipshift.daemon import build_parser as daemon_parser  # noqa: E402
from ipshift.gui.app import build_parser as gui_parser  # noqa: E402

HAVE_BASH = shutil.which("bash") is not None


class GrammarTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tree = grammar.read(build_parser())
        cls.by_key = {k: n for n in grammar.flatten(cls.tree) for k in n.keys()}

    def test_commands_aliases_and_nesting(self):
        names = [c.path[-1] for c in self.tree.children]
        for name in ("status", "ip", "vpn", "rotate", "stop", "privacy-check", "killswitch", "config", "history",
                     "harden", "restore", "doctor", "events", "version"):
            self.assertIn(name, names)
        self.assertNotIn("check", names)                              # an alias is not a command of its own
        self.assertEqual(self.by_key["privacy-check"].aliases, ["check"])
        self.assertIs(self.by_key["check"], self.by_key["privacy-check"])
        self.assertEqual(self.by_key["vpn list"].keys(), ["vpn list", "vpn ls"])
        self.assertIn("import", [c.path[-1] for c in self.by_key["vpn"].children])

    def test_flags_values_and_choices(self):
        rotate = {n: o for o in self.by_key["rotate"].options for n in o.names}
        self.assertTrue(rotate["--interval"].required_value)
        self.assertEqual(rotate["-i"].metavar, "SECONDS")
        self.assertIsNone(rotate["--now"].metavar)
        self.assertFalse(rotate["--now"].required_value)
        watch = {n: o for o in self.by_key["status"].options for n in o.names}["--watch"]
        self.assertFalse(watch.required_value)                         # nargs="?": the value is optional
        self.assertEqual(watch.metavar, "SECONDS")
        imp = {n: o for o in self.by_key["vpn import"].options for n in o.names}
        self.assertEqual(imp["--tier"].choices, list(manage.TIERS))
        self.assertEqual(imp["--protocol"].choices, ["openvpn", "wireguard"])
        self.assertTrue({n: o for o in self.by_key["history"].options for n in o.names}["--export"].file)
        self.assertTrue(imp["--password-stdin"].metavar is None)

    def test_positional_words(self):
        imp = self.by_key["vpn import"].positionals[0]
        self.assertTrue(imp.many and imp.file)
        remove = self.by_key["vpn remove"].positionals[0]
        self.assertTrue(remove.many)
        self.assertFalse(remove.file, "PROFILE merely contains the letters FILE")
        ks = self.by_key["killswitch"].positionals[0]
        self.assertEqual((ks.choices, ks.optional), (["status", "on", "off", "lockdown"], True))
        self.assertEqual([p.metavar for p in self.by_key["harden"].positionals], ["action", "mac_action", "iface", "mac"])

    def test_what_counts_as_a_path(self):
        for yes in ("FILE", "PATH", "DIR", "FOLDER", "FILE_OR_FOLDER", "SOURCE_FILE"):
            self.assertTrue(grammar.FILE_LIKE.search(yes), yes)
        for no in ("PROFILE", "PROFILES", "SECONDS", "N", "TIER", "profile"):
            self.assertFalse(grammar.FILE_LIKE.search(no), no)


@unittest.skipUnless(HAVE_BASH, "bash is not installed")
class CompletionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.dir = Path(cls.tmp.name)
        cls.script = cls.dir / "ipshift.bash"
        cls.script.write_text(completion.bash_completion(build_parser(), "ipshift"))
        cls.tree = grammar.read(build_parser())

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def bash(self, code: str) -> str:
        r = subprocess.run(["bash", "-c", code], capture_output=True, text=True, timeout=60)
        self.assertEqual(r.returncode, 0, r.stderr)
        return r.stdout

    def complete(self, line: str, script: Path | None = None, prog: str = "ipshift") -> list[str]:
        words = line.split()
        if line.endswith(" "):
            words.append("")
        code = (f"source {shlex.quote(str(script or self.script))}\n"
                f"COMP_WORDS=({' '.join(shlex.quote(w) for w in words)})\n"
                f"COMP_CWORD={len(words) - 1}\n"
                f"_{prog}\n"
                'printf "%s\\n" "${COMPREPLY[@]}"\n')
        return self.bash(code).split()

    def test_the_script_is_valid_bash_and_needs_no_helper_package(self):
        self.bash(f"bash -n {shlex.quote(str(self.script))}")
        text = self.script.read_text()
        for helper in ("_init_completion", "_get_comp_words_by_ref", "__ltrim_colon_completions"):
            self.assertNotIn(helper, text)
        self.assertIn("complete -F _ipshift ipshift", text)

    def test_every_command_option_and_value_of_the_real_parser_is_offered(self):
        keys = {k: n for n in grammar.flatten(self.tree) for k in n.keys()}
        code = f"source {shlex.quote(str(self.script))}\n"
        for key in keys:
            q = shlex.quote(key)
            code += (f'echo "children|"{q}"|$(_ipshift_children {q})"\n'
                     f'echo "options|"{q}"|$(_ipshift_options {q})"\n'
                     f'echo "valued|"{q}"|$(_ipshift_valued {q})"\n')
        got: dict[tuple[str, str], list[str]] = {}
        for line in self.bash(code).splitlines():
            kind, key, words = line.split("|", 2)
            got[(kind, key)] = words.split()
        for key, node in keys.items():
            self.assertEqual(sorted(got[("children", key)]),
                             sorted(n for c in node.children for n in [c.path[-1], *c.aliases]), key)
            self.assertEqual(sorted(got[("options", key)]), sorted(n for o in node.options for n in o.names), key)
            self.assertEqual(sorted(got[("valued", key)]),
                             sorted(n for o in node.options if o.required_value for n in o.names), key)

    def test_what_a_person_would_type(self):
        c = self.complete
        self.assertEqual(c("ipshift sta"), ["status"])
        self.assertIn("rotate", c("ipshift "))
        self.assertIn("privacy-check", c("ipshift "))
        self.assertEqual(sorted(c("ipshift vpn imp")), ["import"])
        self.assertIn("connect", c("ipshift vpn "))
        self.assertIn("--watch", c("ipshift status --"))
        self.assertEqual(c("ipshift killswitch "), ["status", "on", "off", "lockdown"])
        self.assertEqual(c("ipshift harden "), ["status", "mac"])
        self.assertEqual(c("ipshift harden mac "), ["enable", "disable", "randomize", "restore"])
        self.assertEqual(c("ipshift config "), ["show", "get", "set", "reload"])

    def test_option_values(self):
        c = self.complete
        self.assertEqual(c("ipshift vpn import --tier "), list(manage.TIERS))
        self.assertEqual(c("ipshift vpn import --tier fr"), ["free"])
        self.assertEqual(c("ipshift vpn set myprofile --tier p"), ["paid"])
        self.assertEqual(c("ipshift vpn import --protocol "), ["openvpn", "wireguard"])
        self.assertEqual(c("ipshift events --level w"), ["warning"])
        self.assertEqual(c("ipshift rotate --interval "), [])         # a free number: nothing to suggest
        self.assertEqual(c("ipshift vpn remove "), [])                # profile names are not known to the script

    def test_global_options_before_the_command_are_stepped_over(self):
        c = self.complete
        self.assertIn("connect", c("ipshift --socket /run/x.sock vpn "))
        self.assertIn("connect", c("ipshift --json --no-color vpn "))
        self.assertEqual(c("ipshift --config /etc/x.json killswitch "), ["status", "on", "off", "lockdown"])

    def test_the_words_after_an_option_with_a_value_are_not_taken_for_commands(self):
        c = self.complete("ipshift vpn import --tier free --")       # "free" is the value of --tier; still inside "vpn import"
        self.assertIn("--protocol", c)
        self.assertNotIn("--watch", c)

    def test_paths_are_completed_where_a_path_is_expected(self):
        files = self.dir / "profiles"
        files.mkdir()
        (files / "a.ovpn").write_text("x")
        (files / "b.conf").write_text("x")
        self.assertEqual(sorted(self.complete(f"ipshift vpn import {files}/")), [f"{files}/a.ovpn", f"{files}/b.conf"])
        self.assertEqual(self.complete(f"ipshift history --export {files}/a"), [f"{files}/a.ovpn"])
        self.assertEqual(self.complete(f"ipshift --socket {files}/b"), [f"{files}/b.conf"])

    def test_a_word_that_takes_any_number_of_values_keeps_answering_but_not_for_the_words_before_it(self):
        parser = argparse.ArgumentParser(prog="demo")
        sub = parser.add_subparsers(dest="command")
        p = sub.add_parser("copy")
        p.add_argument("source")                                      # free text
        p.add_argument("targets", nargs="+", choices=("x", "y"))
        script = self.dir / "demo.bash"
        script.write_text(completion.bash_completion(parser, "demo"))
        self.assertEqual(self.complete("demo copy ", script, "demo"), [])                 # the free word: nothing to offer
        self.assertEqual(self.complete("demo copy here ", script, "demo"), ["x", "y"])
        self.assertEqual(self.complete("demo copy here x ", script, "demo"), ["x", "y"])  # and every later one

    def test_nothing_that_could_break_out_of_the_script_is_accepted(self):
        for bad in ("a b", "x;y", "$(id)", "a'b", 'a"b', "a`b", "a|b", "a\nb", "a\n", ""):
            with self.assertRaises(ValueError, msg=repr(bad)):
                completion._safe(bad)
        parser = argparse.ArgumentParser(prog="demo")
        parser.add_argument("--mode", choices=("ok", "x; rm -rf /"))
        with self.assertRaises(ValueError):
            completion.bash_completion(parser, "demo")


class RoffTests(unittest.TestCase):
    def test_escaping(self):
        self.assertEqual(manpages.esc("a-b"), "a\\-b")
        self.assertEqual(manpages.esc("a\\b"), "a\\\\b")
        self.assertEqual(manpages.esc(".hidden"), "\\&.hidden")
        self.assertEqual(manpages.esc("'quoted'"), "\\&'quoted'")
        self.assertEqual(manpages.esc("x\n.y\n'z"), "x\n\\&.y\n\\&'z")

    def test_paragraphs_are_reflowed_and_split_on_blank_lines(self):
        self.assertEqual(manpages.paragraphs("one\ntwo\n\n  three   four \n\n\n"), ["one two", "three four"])


class ManPageTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pages = {}
        for prog, section, parser, page in (("ipshift", 1, build_parser(), docs.IPSHIFT),
                                            ("ipshiftd", 8, daemon_parser(), docs.IPSHIFTD),
                                            ("ipshift-gui", 1, gui_parser(), docs.IPSHIFT_GUI)):
            cls.pages[prog] = manpages.page(prog, section, page["summary"], parser, __version__,
                                            description=page["description"], examples=page.get("examples", []),
                                            extra=page.get("extra", []), see_also=page.get("see_also", []))

    def test_the_structure_is_plain_man_macros(self):
        for prog, text in self.pages.items():
            lines = text.splitlines()
            self.assertTrue(lines[0].startswith(".TH "), prog)
            self.assertNotIn("", lines, f"{prog}: a blank line ends a paragraph in the middle of a man page")
            for n, line in enumerate(lines):
                if line.startswith("."):
                    self.assertRegex(line, r"^\.(TH|SH|SS|PP|TP)( |$)", (prog, n, line))
                if not line.startswith(".TH"):
                    self.assertNotRegex(line, r"(?<!\\)-", (prog, n, line))       # every hyphen printed as a minus sign
                self.assertEqual(line.count("\\fB") + line.count("\\fI"), line.count("\\fR"), (prog, n, line))
            for n, line in enumerate(lines):
                if line == ".TP":
                    self.assertFalse(lines[n + 1].startswith("."), (prog, n))      # the tag
                    self.assertFalse(lines[n + 2].startswith("."), (prog, n))      # the text

    def test_the_sections_are_there(self):
        for prog, text in self.pages.items():
            for section in (".SH NAME", ".SH SYNOPSIS", ".SH DESCRIPTION", ".SH OPTIONS", ".SH LIMITS", ".SH SEE ALSO"):
                self.assertIn(section, text, (prog, section))
        self.assertIn(".SH COMMANDS", self.pages["ipshift"])
        self.assertNotIn(".SH COMMANDS", self.pages["ipshiftd"])
        self.assertIn(".SH EXIT STATUS", self.pages["ipshift"])
        self.assertIn(".SH EXAMPLES", self.pages["ipshift"])
        self.assertIn(".SH SIGNALS", self.pages["ipshiftd"])

    def test_every_command_and_option_of_the_command_line_is_in_the_page(self):
        text = self.pages["ipshift"]
        tree = grammar.read(build_parser())
        for node in grammar.flatten(tree):
            if not node.path:
                continue
            self.assertIn(f'.SS "{manpages.esc(" ".join(node.path))}', text, node.path)
            for alias in node.aliases:
                self.assertIn(manpages.esc(alias), text)
            for opt in node.options:
                for name in opt.names:
                    if name not in ("-h", "--help"):
                        self.assertIn(f"\\fB{manpages.esc(name)}\\fR", text, (node.path, name))

    def test_the_page_of_the_daemon_and_the_window_list_their_options(self):
        for prog, parser in (("ipshiftd", daemon_parser()), ("ipshift-gui", gui_parser())):
            for opt in grammar.read(parser).options:
                for name in opt.names:
                    if name not in ("-h", "--help"):
                        self.assertIn(f"\\fB{manpages.esc(name)}\\fR", self.pages[prog], (prog, name))
        self.assertNotRegex(self.pages["ipshift-gui"], r"\\fB\\-\\-version\\fR\n[.]")     # --version has a description

    def test_the_limits_are_in_every_page_and_say_what_they_must(self):
        for prog, text in self.pages.items():
            flat = " ".join(text.split())
            self.assertIn("does not make you anonymous", flat, prog)
            self.assertIn("moves trust", flat, prog)
            self.assertIn("ipshift restore", flat, prog)

    def test_the_options_that_have_a_fixed_set_of_values_list_them(self):
        text = self.pages["ipshift"]
        self.assertIn("One of: free, paid, self\\-hosted, unknown.", text)
        self.assertIn("One of: debug, info, warning, error, critical.", text)

    def test_a_page_is_the_same_every_time_it_is_made(self):
        import stage
        self.assertEqual(stage.gz("x\n"), stage.gz("x\n"))
        self.assertEqual(stage.gz("x\n")[4:8], b"\0\0\0\0")                   # no timestamp in the gzip header
        self.assertEqual(gzip.decompress(stage.gz("hello\n")), b"hello\n")


class DocumentationNamesRealThingsTests(unittest.TestCase):
    """README.md and the manual pages must not mention commands, options or settings that do not exist."""

    @classmethod
    def setUpClass(cls):
        cls.readme = (ROOT / "README.md").read_text()
        tree = grammar.read(build_parser())
        cls.top = {n for c in tree.children for n in [c.path[-1], *c.aliases]}
        cls.vpn = {n for c in tree.children if c.path == ("vpn",) for v in c.children for n in [v.path[-1], *v.aliases]}
        options = {n for p in (build_parser(), daemon_parser(), gui_parser()) for node in grammar.flatten(grammar.read(p))
                   for o in node.options for n in o.names}
        script_options = {m for name in ("install.sh", "uninstall.sh", "build_deb.sh")
                          for m in re.findall(r"(--[a-z][a-z-]*)", (ROOT / "packaging" / name).read_text())}
        cls.options = options | script_options | {"--root-owner-group"}
        cls.settings = {f"{sec}.{f.name}": getattr(config_module.Config(), sec) for sec, c in config_module._SECTIONS.items()
                        for f in dataclasses.fields(c)}

    def code_snippets(self, text: str) -> list[str]:
        snippets = re.findall(r"`([^`\n]+)`", text)
        for block in re.findall(r"```[a-z]*\n(.*?)```", text, re.S):
            snippets += [line.split("#")[0] for line in block.splitlines()]
        return snippets

    def commands_in(self, snippets: list[str]) -> list[tuple[str, ...]]:
        found = []
        for snippet in snippets:
            tokens = snippet.split()
            for i, token in enumerate(tokens):
                if token != "ipshift":
                    continue
                rest = [t for t in tokens[i + 1:] if not t.startswith("-")]
                if rest and re.match(r"^[a-z]", rest[0]):
                    found.append(tuple(rest[:2]))
        return found

    def test_every_command_in_the_readme_exists(self):
        found = self.commands_in(self.code_snippets(self.readme))
        self.assertGreater(len(found), 15)
        for words in found:
            self.assertIn(words[0], self.top, f"README mentions 'ipshift {' '.join(words)}'")
            if words[0] == "vpn" and len(words) > 1 and re.match(r"^[a-z]+$", words[1]):
                self.assertIn(words[1], self.vpn, f"README mentions 'ipshift {' '.join(words)}'")

    def test_every_command_in_the_manual_pages_exists(self):
        text = "\n".join(str(v) for page in (docs.IPSHIFT, docs.IPSHIFTD, docs.IPSHIFT_GUI) for v in page.values()) + docs.LIMITS
        for words in self.commands_in(re.findall(r'"(ipshift [^"]+)"', text) + [c for c, _ in docs.IPSHIFT["examples"]]):
            self.assertIn(words[0], self.top, words)

    def test_every_option_in_backticks_exists(self):
        for snippet in self.code_snippets(self.readme):
            for option in re.findall(r"(?<![\w-])(--[a-z][a-z-]*)", snippet):
                self.assertIn(option, self.options, f"README mentions {option} in `{snippet}`")

    def test_every_setting_the_documents_name_exists(self):
        names = set(re.findall(r"`((?:rotation|vpn|killswitch|dns|privacy|daemon)\.[a-z_0-9]+)`", self.readme))
        names |= set(re.findall(r"\b((?:rotation|vpn|killswitch|dns|privacy|daemon)\.[a-z_0-9]+)\b",
                                " ".join(str(v) for page in (docs.IPSHIFT, docs.IPSHIFTD, docs.IPSHIFT_GUI) for v in page.values())))
        self.assertGreater(len(names), 20)
        for name in names:
            self.assertIn(name, self.settings, f"{name} is not a setting")

    def test_the_defaults_in_the_settings_table_are_the_real_defaults(self):
        checked = 0
        for row in re.findall(r"^\| `([a-z_.0-9]+)` \| ([^|]+) \|", self.readme, re.M):
            key, shown = row[0], row[1].strip()
            if key not in self.settings:
                continue
            section, _, name = key.partition(".")
            actual = getattr(getattr(config_module.Config(), section), name)
            if isinstance(actual, bool):
                expected = "on" if actual else "off"
            elif isinstance(actual, (int, float)):
                expected = str(int(actual)) if float(actual).is_integer() else str(actual)
            elif isinstance(actual, str):
                expected = f"`{actual}`"
            else:
                continue
            checked += 1
            self.assertEqual(shown, expected, key)
        self.assertGreaterEqual(checked, 8)

    def test_the_exit_codes_and_the_floor_in_the_readme_are_the_real_ones(self):
        flat = " ".join(self.readme.split())
        for phrase in ("0 success", "1 failed", "2 wrong usage", "3 daemon not reachable", "4 privacy check found problems",
                       "130 interrupted"):
            self.assertIn(phrase, flat)
            self.assertIn(phrase, " ".join(EPILOG.split()))
        self.assertEqual(config_module.MIN_INTERVAL, 1.0)
        self.assertIn("minimum 1", self.readme)

    def test_the_install_instructions_name_a_package_that_provides_the_window(self):
        for text in (self.readme, (ROOT / "packaging/debian/control.in").read_text(), docs.IPSHIFT_GUI["description"]):
            self.assertIn("python3-pyside6.qtwidgets", text)

    def test_the_readme_is_honest_about_what_it_cannot_promise(self):
        flat = " ".join(self.readme.split())
        for claim in ("No program can promise maximum anonymity", "moves trust", "Every reconnect shows your real address",
                      "Not tested", "PySide6 could not be installed", "ipshift-gui --selftest", "sudo ipshift restore"):
            self.assertIn(claim, flat)


if __name__ == "__main__":
    unittest.main()
