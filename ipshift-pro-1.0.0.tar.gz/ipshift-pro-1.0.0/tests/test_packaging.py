"""Packaging, part 1: templates and launchers, the staged tree, upgrades, and the manifest-driven uninstall.

Nothing here touches the real system: every tree is built in a temporary directory."""
from __future__ import annotations

import os
import re
import stat
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import helpers  # noqa: F401  (puts src/ on sys.path)

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(ROOT / "packaging") not in sys.path:
    sys.path.insert(0, str(ROOT / "packaging"))

import stage as stage_mod  # noqa: E402
import unstage  # noqa: E402
from tools import render  # noqa: E402
from ipshift import __version__  # noqa: E402

PYTHON = sys.executable


def python_ok() -> bool:
    return bool(render.SAFE_PATH.match(PYTHON))


class TempCase(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.tmp = Path(tmp.name)

    def files_under(self, base: Path) -> set[str]:
        return {"/" + str(p.relative_to(base)) for p in base.rglob("*") if p.is_file() or p.is_symlink()}


class RenderTests(unittest.TestCase):
    def test_fill_replaces_every_token_and_leaves_other_text_alone(self):
        text = "ExecStart=@BINDIR@/ipshiftd\nExecReload=/bin/kill -HUP $MAINPID\nAgain @BINDIR@\n"
        self.assertEqual(render.fill(text, {"BINDIR": "/usr/bin"}),
                         "ExecStart=/usr/bin/ipshiftd\nExecReload=/bin/kill -HUP $MAINPID\nAgain /usr/bin\n")

    def test_a_token_without_a_value_is_an_error_not_a_half_filled_file(self):
        with self.assertRaises(KeyError) as cm:
            render.fill("a @ONE@ b @TWO@", {"ONE": "1"})
        self.assertIn("@TWO@", str(cm.exception))

    def test_only_plain_absolute_paths_are_accepted(self):
        self.assertEqual(render.check_path("p", "/usr/local/lib/ipshift"), "/usr/local/lib/ipshift")
        self.assertEqual(render.check_path("p", "/usr/local/"), "/usr/local")
        for bad in ("usr/local", "", "/a b", "/a;b", "/a$(x)", "/a'b", "/a\nb", "/a\n", "/a/../b", "/a//b", "/..", "/a/.."):
            with self.assertRaises(ValueError, msg=repr(bad)):
                render.check_path("p", bad)

    def test_the_launchers_are_python_that_compiles(self):
        for name in render.LAUNCHERS:
            text = render.launcher(name, "/usr/local/lib/ipshift", "/usr/bin/python3")
            compile(text, name, "exec")

    def test_what_root_may_run_starts_python_in_isolated_mode_and_the_window_does_not(self):
        first = lambda name: render.launcher(name, "/opt/x", "/usr/bin/python3").splitlines()[0]
        self.assertEqual(first("ipshiftd"), "#!/usr/bin/python3 -I")
        self.assertEqual(first("ipshift"), "#!/usr/bin/python3 -I")
        self.assertEqual(first("ipshift-gui"), "#!/usr/bin/python3")           # PySide6 from pip --user must stay visible

    def test_the_launcher_checks_the_python_version_before_importing_anything_of_ours(self):
        text = render.launcher("ipshiftd", "/opt/x", "/usr/bin/python3")
        self.assertLess(text.index("version_info"), text.index("from ipshift"))
        self.assertLess(text.index("sys.path.insert"), text.index("from ipshift"))
        with mock.patch.object(sys, "version_info", (3, 9, 18)):
            with self.assertRaises(SystemExit) as cm:
                exec(compile(text, "ipshiftd", "exec"), {"__name__": "__main__"})
        self.assertIn("Python 3.10 or newer", str(cm.exception))

    def test_a_launcher_is_never_written_for_an_unsafe_path(self):
        for pylib, python in (("/a b", "/usr/bin/python3"), ("/opt/x", "/usr/bin/python3; rm -rf /"), ("rel", "/usr/bin/python3")):
            with self.assertRaises(ValueError):
                render.launcher("ipshift", pylib, python)


@unittest.skipUnless(python_ok(), "the test interpreter's path is not a plain path")
class StagedTreeTests(TempCase):
    def stage(self, **kw):
        kw.setdefault("python", PYTHON)
        kw.setdefault("owner_root", False)
        return stage_mod.stage(self.tmp, **kw)

    def read(self, target: str) -> str:
        return (self.tmp / target.lstrip("/")).read_text()

    def mode(self, target: str) -> int:
        return stat.S_IMODE((self.tmp / target.lstrip("/")).stat().st_mode)

    def test_every_file_is_there_with_the_right_mode(self):
        self.stage()
        for name in ("ipshift", "ipshiftd", "ipshift-gui"):
            self.assertEqual(self.mode(f"/usr/local/bin/{name}"), 0o755, name)
        for target in ("/usr/local/lib/systemd/system/ipshiftd.service", "/usr/local/share/applications/ipshift-pro.desktop",
                       "/usr/local/share/icons/hicolor/scalable/apps/ipshift-pro.svg",
                       "/usr/local/share/bash-completion/completions/ipshift",
                       "/usr/local/share/man/man1/ipshift.1.gz", "/usr/local/share/man/man1/ipshift-gui.1.gz",
                       "/usr/local/share/man/man8/ipshiftd.8.gz", "/usr/local/share/ipshift-pro/MANIFEST",
                       "/usr/local/share/doc/ipshift-pro/README.md"):
            self.assertEqual(self.mode(target), 0o644, target)

    def test_nothing_is_writable_by_anyone_but_the_owner(self):
        self.stage()
        for p in self.tmp.rglob("*"):
            self.assertFalse(p.lstat().st_mode & (stat.S_IWGRP | stat.S_IWOTH), p)

    def test_the_python_package_is_a_clean_copy_of_the_sources(self):
        self.stage()
        staged = self.tmp / "usr/local/lib/ipshift/ipshift"
        wanted = {p.relative_to(SRC / "ipshift") for p in (SRC / "ipshift").rglob("*")
                  if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc"}
        got = {p.relative_to(staged) for p in staged.rglob("*") if p.is_file()}
        self.assertEqual(got, wanted)
        self.assertEqual((staged / "daemon.py").read_bytes(), (SRC / "ipshift/daemon.py").read_bytes())
        self.assertEqual([p for p in staged.rglob("*") if "__pycache__" in p.parts], [])

    def test_the_unit_file_is_filled_in_and_asks_for_nothing_that_would_break_the_daemon(self):
        self.stage()
        unit = self.read("/usr/local/lib/systemd/system/ipshiftd.service")
        self.assertNotIn("@", unit)
        self.assertIn("ExecStart=/usr/local/bin/ipshiftd\n", unit)
        for line in ("Type=notify", "WatchdogSec=", "Restart=on-failure", "RestartPreventExitStatus=2",
                     "WantedBy=multi-user.target", "Before=network-pre.target", "After=nftables.service", "UMask=0077"):
            self.assertIn(line, unit)
        directives = {line.split("=", 1)[0] for line in unit.splitlines() if "=" in line and not line.startswith("#")}
        # the daemon manages nftables, routes, /etc/resolv.conf, /proc/sys and /dev/net/tun: these would break it
        for option in ("ProtectSystem", "PrivateDevices", "ProtectKernelTunables", "ProtectKernelModules",
                       "MemoryDenyWriteExecute", "SystemCallFilter", "CapabilityBoundingSet", "PrivateNetwork",
                       "RuntimeDirectory", "StateDirectory", "ReadOnlyPaths", "InaccessiblePaths"):
            self.assertNotIn(option, directives, option)
        for option in ("NoNewPrivileges", "PrivateTmp", "ProtectHome"):
            self.assertIn(option, directives, option)

    def test_the_desktop_entry_matches_what_the_window_tells_the_desktop(self):
        self.stage()
        entry = self.read("/usr/local/share/applications/ipshift-pro.desktop")
        self.assertIn("Exec=/usr/local/bin/ipshift-gui\n", entry)
        self.assertIn("Icon=ipshift-pro\n", entry)
        self.assertRegex(entry, r"(?m)^Categories=.*;$")
        self.assertNotIn("@", entry)
        self.assertIn('app.setDesktopFileName("ipshift-pro")', (SRC / "ipshift/gui/app.py").read_text())
        self.assertTrue((self.tmp / "usr/local/share/icons/hicolor/scalable/apps/ipshift-pro.svg").is_file())

    def test_the_manifest_lists_exactly_what_was_installed(self):
        st = self.stage()
        entries = unstage.parse(self.read("/usr/local/share/ipshift-pro/MANIFEST"))
        listed_files = {p for k, p in entries if k == "F"}
        trees = [p for k, p in entries if k == "T"]
        self.assertEqual(trees, ["/usr/local/lib/ipshift/ipshift"])
        on_disk = {p for p in self.files_under(self.tmp) if not p.startswith(trees[0] + "/")}
        self.assertEqual(listed_files, on_disk)
        self.assertIn("/usr/local/share/ipshift-pro/MANIFEST", listed_files)             # it lists itself
        for kind, path in entries:
            if kind == "D":
                self.assertTrue((self.tmp / path.lstrip("/")).is_dir(), path)
        self.assertEqual(st.manifest(), [f"{k} {p}" for k, p in entries])

    def test_staging_twice_gives_the_same_tree(self):
        self.stage()
        first = self.read("/usr/local/share/ipshift-pro/MANIFEST")
        before = {p: (self.tmp / p.lstrip("/")).read_bytes() for p in self.files_under(self.tmp)}
        self.stage()
        self.assertEqual(self.read("/usr/local/share/ipshift-pro/MANIFEST"), first)
        after = {p: (self.tmp / p.lstrip("/")).read_bytes() for p in self.files_under(self.tmp)}
        self.assertEqual(before, after)
        self.assertEqual([p for p in self.tmp.rglob("*") if p.name.endswith((".new", ".tmp"))], [])
        self.assertFalse(any(p.name.startswith(".ipshift-") for p in self.tmp.rglob("*")))

    def test_an_upgrade_leaves_no_stale_module_behind(self):
        self.stage()
        stale = self.tmp / "usr/local/lib/ipshift/ipshift/removed_in_this_version.py"
        stale.write_text("x = 1\n")
        self.stage()
        self.assertFalse(stale.exists())

    def test_an_upgrade_remembers_the_directories_the_first_install_made(self):
        self.stage()
        first = [line for line in self.read("/usr/local/share/ipshift-pro/MANIFEST").splitlines() if line.startswith("D ")]
        self.assertTrue(first)
        self.stage()                                           # every directory exists now, yet the manifest keeps them
        second = [line for line in self.read("/usr/local/share/ipshift-pro/MANIFEST").splitlines() if line.startswith("D ")]
        self.assertEqual(sorted(second), sorted(first))

    def test_the_debian_layout_has_no_manifest_and_puts_the_program_in_dist_packages(self):
        self.stage(prefix="/usr", pylib="/usr/lib/python3/dist-packages", with_manifest=False)
        self.assertTrue((self.tmp / "usr/lib/python3/dist-packages/ipshift/__init__.py").is_file())
        self.assertTrue((self.tmp / "usr/lib/systemd/system/ipshiftd.service").is_file())
        self.assertFalse((self.tmp / "usr/share/ipshift-pro").exists())
        self.assertIn("sys.path.insert(0, '/usr/lib/python3/dist-packages')", self.read("/usr/bin/ipshiftd"))

    def test_a_pylib_of_slash_and_unsafe_paths_are_refused(self):
        with self.assertRaises(stage_mod.StageError):
            self.stage(pylib="/")
        for kw in ({"prefix": "/usr/local; x"}, {"python": "/usr/bin/python3 -c x"}, {"pylib": "/a/../b"}):
            with self.assertRaises(ValueError):
                self.stage(**kw)
        self.assertEqual(list(self.tmp.iterdir()), [])         # nothing was written

    def test_the_command_line_of_the_staging_script_prints_the_manifest(self):
        out = subprocess.run([PYTHON, "-I", str(ROOT / "packaging/stage.py"), "--destdir", str(self.tmp), "--prefix", "/usr",
                              "--pylib", "/usr/lib/python3/dist-packages", "--python", PYTHON],
                             capture_output=True, text=True, check=True).stdout
        entries = unstage.parse(out)
        self.assertIn(("F", "/usr/bin/ipshift"), entries)
        self.assertIn(("T", "/usr/lib/python3/dist-packages/ipshift"), entries)
        bad = subprocess.run([PYTHON, "-I", str(ROOT / "packaging/stage.py"), "--destdir", str(self.tmp), "--prefix", "usr"],
                             capture_output=True, text=True)
        self.assertEqual(bad.returncode, 1)
        self.assertIn("plain absolute path", bad.stderr)


@unittest.skipUnless(python_ok(), "the test interpreter's path is not a plain path")
class InstalledLaunchersRunTests(TempCase):
    """The launchers really start the program: written next to a copy of the package, then executed."""

    def setUp(self):
        super().setUp()
        pylib = self.tmp / "lib"
        st = stage_mod.Stage("/", owner_root=False)
        stage_mod.copy_package(st, SRC / "ipshift", str(pylib))
        self.bin = self.tmp / "bin"
        self.bin.mkdir()
        for name in render.LAUNCHERS:
            path = self.bin / name
            path.write_text(render.launcher(name, str(pylib), PYTHON))
            path.chmod(0o755)

    def run_launcher(self, name, *args):
        env = {"PATH": os.environ.get("PATH", ""), "HOME": str(self.tmp), "PYTHONPATH": str(self.tmp / "nope")}
        return subprocess.run([str(self.bin / name), *args], capture_output=True, text=True, env=env, cwd=self.tmp, timeout=60)

    def test_each_launcher_reports_its_version(self):
        for name in render.LAUNCHERS:
            r = self.run_launcher(name, "--version")
            self.assertEqual((r.returncode, r.stdout.strip()), (0, f"{name} {__version__}"), r.stderr)

    def test_the_command_line_runs_through_its_launcher(self):
        r = self.run_launcher("ipshift", "--help")
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("privacy-check", r.stdout)
        bad = self.run_launcher("ipshift", "rotate", "--interval", "0.5")
        self.assertEqual(bad.returncode, 2)                      # the 1-second floor reaches the launcher too
        self.assertIn("shortest interval is 1 second", bad.stderr)

    def test_the_daemon_refuses_to_run_without_root_and_says_how_to_try_it(self):
        if os.geteuid() == 0:
            self.skipTest("this check is for an unprivileged user")
        r = self.run_launcher("ipshiftd")
        self.assertEqual(r.returncode, 2)
        self.assertIn("--simulate", r.stderr)

    def test_isolated_mode_keeps_a_planted_module_out_of_the_root_daemon(self):
        """PYTHONPATH and the current directory must not be able to shadow the program's own modules."""
        evil = self.tmp / "evil"
        evil.mkdir()
        (evil / "json.py").write_text("raise SystemExit('PLANTED MODULE RAN')\n")
        for where in ("PYTHONPATH", "cwd"):
            env = {"PATH": os.environ.get("PATH", ""), "HOME": str(self.tmp)}
            if where == "PYTHONPATH":
                env["PYTHONPATH"] = str(evil)
            r = subprocess.run([str(self.bin / "ipshiftd"), "--version"], capture_output=True, text=True, env=env,
                               cwd=evil if where == "cwd" else self.tmp, timeout=60)
            self.assertEqual((r.returncode, r.stdout.strip()), (0, f"ipshiftd {__version__}"), (where, r.stderr))
            self.assertNotIn("PLANTED", r.stdout + r.stderr)


class UnstageParseTests(unittest.TestCase):
    def test_a_good_manifest_is_read(self):
        text = "F /usr/local/bin/ipshift\nT /usr/local/lib/ipshift/ipshift\nD /usr/local/lib/ipshift\n\n"
        self.assertEqual(unstage.parse(text), [("F", "/usr/local/bin/ipshift"), ("T", "/usr/local/lib/ipshift/ipshift"),
                                               ("D", "/usr/local/lib/ipshift")])

    def test_a_line_that_is_not_understood_stops_everything(self):
        for bad in ("X /usr/local/bin/ipshift",                  # unknown kind
                    "F usr/local/bin/ipshift",                   # relative
                    "F /usr/local/../etc/passwd/x",              # parent reference
                    "F /usr/local/bin/",                         # trailing slash
                    "F /",                                       # the root itself
                    "F /etc/x",                                  # too close to the root
                    "T /usr/local/lib/ipshift/other",            # only a tree called ipshift goes as a whole
                    "T /usr/lib",                                # shallow and not ipshift
                    "F /usr/local/bin/a b",                      # a space
                    "F /usr//local/bin/ipshift",                 # a doubled slash
                    "F /usr/local/bin/ipshift\n/etc/passwd"):    # a second line that is not a line at all
            with self.assertRaises(ValueError, msg=repr(bad)):
                unstage.parse(bad)


@unittest.skipUnless(python_ok(), "the test interpreter's path is not a plain path")
class UnstageRemoveTests(TempCase):
    def install(self):
        stage_mod.stage(self.tmp, python=PYTHON, owner_root=False)

    def manifest(self):
        return unstage.parse((self.tmp / "usr/local/share/ipshift-pro/MANIFEST").read_text())

    def test_stage_then_unstage_leaves_nothing_of_ours(self):
        self.install()
        messages = []
        count = unstage.remove(self.tmp, self.manifest(), log=messages.append)
        self.assertGreater(count, 10)
        self.assertEqual(messages, [])
        self.assertEqual(self.files_under(self.tmp), set())
        remaining = {"/" + str(p.relative_to(self.tmp)) for p in self.tmp.rglob("*")}
        self.assertLessEqual(remaining, unstage.PROTECTED)       # only the system's own directories are left

    def test_files_that_are_not_ours_stay(self):
        self.install()
        other = self.tmp / "usr/local/bin/someone-elses-tool"
        other.write_text("#!/bin/sh\n")
        foreign = self.tmp / "usr/local/share/man/man1/other.1.gz"
        foreign.write_text("x")
        unstage.remove(self.tmp, self.manifest())
        self.assertTrue(other.exists())
        self.assertTrue(foreign.exists())
        self.assertTrue(foreign.parent.is_dir())                 # a directory with something else in it is kept

    def test_a_protected_directory_is_never_removed_even_when_listed_and_empty(self):
        (self.tmp / "usr/local/bin").mkdir(parents=True)
        unstage.remove(self.tmp, [("D", "/usr/local/bin"), ("D", "/usr/local")])
        self.assertTrue((self.tmp / "usr/local/bin").is_dir())

    def test_a_directory_listed_as_a_file_is_not_deleted(self):
        victim = self.tmp / "usr/local/share/precious"
        victim.mkdir(parents=True)
        (victim / "data").write_text("keep")
        messages = []
        unstage.remove(self.tmp, [("F", "/usr/local/share/precious")], log=messages.append)
        self.assertTrue((victim / "data").exists())
        self.assertTrue(any("is a directory" in m for m in messages))

    def test_a_symlink_listed_as_a_file_is_unlinked_not_followed(self):
        target = self.tmp / "keep.txt"
        target.write_text("keep")
        link = self.tmp / "usr/local/bin/ipshift"
        link.parent.mkdir(parents=True)
        link.symlink_to(target)
        unstage.remove(self.tmp, [("F", "/usr/local/bin/ipshift")])
        self.assertFalse(link.is_symlink())
        self.assertEqual(target.read_text(), "keep")

    def test_a_symlinked_tree_is_not_removed(self):
        real = self.tmp / "elsewhere"
        (real / "ipshift").mkdir(parents=True)
        (real / "ipshift" / "x.py").write_text("x")
        lib = self.tmp / "usr/local/lib/ipshift"
        lib.mkdir(parents=True)
        (lib / "ipshift").symlink_to(real / "ipshift")
        messages = []
        unstage.remove(self.tmp, [("T", "/usr/local/lib/ipshift/ipshift")], log=messages.append)
        self.assertTrue((real / "ipshift" / "x.py").exists())
        self.assertTrue(any("not a plain directory" in m for m in messages))

    def test_a_symlinked_parent_stops_the_removal_of_a_tree(self):
        real = self.tmp / "elsewhere/lib/ipshift/ipshift"
        real.mkdir(parents=True)
        (real / "x.py").write_text("x")
        (self.tmp / "usr/local").mkdir(parents=True)
        (self.tmp / "usr/local/lib").symlink_to(self.tmp / "elsewhere/lib")
        messages = []
        unstage.remove(self.tmp, [("T", "/usr/local/lib/ipshift/ipshift")], log=messages.append)
        self.assertTrue((real / "x.py").exists())
        self.assertTrue(any("symbolic link" in m for m in messages))

    def test_removing_what_is_already_gone_is_fine(self):
        self.install()
        entries = self.manifest()
        unstage.remove(self.tmp, entries)
        self.assertEqual(unstage.remove(self.tmp, entries), 0)

    def test_the_command_line_removes_and_reports(self):
        self.install()
        r = subprocess.run([PYTHON, "-I", str(ROOT / "packaging/unstage.py"), "--destdir", str(self.tmp),
                            "--manifest", "/usr/local/share/ipshift-pro/MANIFEST"], capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertRegex(r.stdout, r"removed \d+ item")
        self.assertEqual(self.files_under(self.tmp), set())

    def test_an_unusable_manifest_removes_nothing_and_fails(self):
        self.install()
        manifest = self.tmp / "usr/local/share/ipshift-pro/MANIFEST"
        manifest.write_text(manifest.read_text() + "F /etc/passwd\n")
        before = self.files_under(self.tmp)
        r = subprocess.run([PYTHON, "-I", str(ROOT / "packaging/unstage.py"), "--destdir", str(self.tmp),
                            "--manifest", "/usr/local/share/ipshift-pro/MANIFEST"], capture_output=True, text=True)
        self.assertEqual(r.returncode, 1)
        self.assertIn("nothing was removed", r.stderr)
        self.assertEqual(self.files_under(self.tmp), before)

    def test_a_missing_manifest_fails_cleanly(self):
        r = subprocess.run([PYTHON, "-I", str(ROOT / "packaging/unstage.py"), "--destdir", str(self.tmp),
                            "--manifest", "/usr/local/share/ipshift-pro/MANIFEST"], capture_output=True, text=True)
        self.assertEqual(r.returncode, 1)
        self.assertIn("cannot read the manifest", r.stderr)


class RootOwnedTests(TempCase):
    """A real install refuses to put code that root runs where somebody else can change it."""

    def test_a_directory_others_can_write_is_refused(self):
        d = self.tmp / "open"
        d.mkdir()
        d.chmod(0o777)
        with self.assertRaises(stage_mod.StageError) as cm:
            stage_mod.require_root_owned(str(d / "lib"), "pylib")
        self.assertIn("refusing", str(cm.exception))

    def test_a_directory_owned_by_somebody_else_is_refused(self):
        if os.geteuid() == 0:
            self.skipTest("everything here belongs to root")
        with self.assertRaises(stage_mod.StageError):
            stage_mod.require_root_owned(str(self.tmp / "mine"), "pylib")

    def test_system_directories_pass(self):
        if os.geteuid() != 0 and not Path("/usr/bin/python3").exists():
            self.skipTest("no system python here")
        stage_mod.require_root_owned("/usr/bin/python3", "python")


if __name__ == "__main__":
    unittest.main()
