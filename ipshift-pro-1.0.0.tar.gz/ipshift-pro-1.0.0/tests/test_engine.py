"""The engine, assembled from the simulated world (and, for a few wiring checks, the real parts)."""
from __future__ import annotations

import dataclasses
import json
import threading
import time
import unittest

from helpers import TmpRootCase, FakeRunner
from test_vpnconf import wgkey

from ipshift.config import Config
from ipshift.engine import Engine, IPC_SETTABLE_KEYS, ipc_settable
from ipshift.errors import (BusyError, ConfigError, IPShiftError, NotFound, PrivilegeError, ProfileError, VpnError)
from ipshift.paths import default_paths


def wait_for(pred, timeout: float = 8.0, step: float = 0.02):
    end = time.time() + timeout
    while time.time() < end:
        v = pred()
        if v:
            return v
        time.sleep(step)
    return pred()


class EngineCase(TmpRootCase):
    SIM = True

    def setUp(self):
        super().setUp()
        self.cfg = Config()
        self.cfg.vpn.connect_timeout = 5.0
        self.cfg.vpn.verify_timeout = 3.0
        self.paths = default_paths()
        self.eng = Engine(self.cfg, self.paths, simulate=self.SIM, sim_speed=0.0)
        self.addCleanup(self.eng.shutdown)
        self.world = self.eng.world
        self.kinds = lambda: [e.kind for e in self.eng.bus.recent(300)]
        if self.SIM:
            self.wg = self.eng.store.list(protocol="wireguard")
            self.ov = self.eng.store.list(protocol="openvpn")

    def exit_of(self, p):
        return self.world.server_for(p).exit_ip


class ConstructionTests(EngineCase):
    def test_demo_profiles_and_isolated_state(self):
        self.assertEqual(len(self.eng.store.list()), 8)
        self.assertIn("sim", self.eng.paths.state_dir.parts)
        self.assertTrue(str(self.eng.hardening.dns.resolv).startswith(str(self.tmp)))
        self.assertTrue(self.eng.ks.dry_run)

    def test_no_demo_profiles_when_disabled(self):
        other = dataclasses.replace(self.paths, state_dir=self.tmp / "elsewhere")
        eng = Engine(Config(), other, simulate=True, sim_speed=0.0, demo=False)
        self.addCleanup(eng.shutdown)
        self.assertEqual(eng.store.list(), [])

    def test_initial_status(self):
        st = self.eng.status()
        self.assertEqual(st["protection"]["level"], "unprotected")
        self.assertEqual(st["vpn"]["state"], "disconnected")
        self.assertIsNone(st["public"]["v4"])
        self.assertTrue(st["daemon"]["simulated"])
        self.assertEqual(st["wanted"], {"vpn": False, "protect": False})
        self.assertEqual(st["profiles"], {"total": 8, "usable": 8})
        self.assertTrue(any(p["primary"] for p in st["network"]["private_ips"]))
        self.assertEqual(st["rotation"]["minimum_interval"], 1.0)
        json.dumps(st)                                         # everything must be JSON-serialisable


class ConnectTests(EngineCase):
    def test_connect_named_profile(self):
        a = self.wg[0]
        res = self.eng.connect(a.name)
        self.assertEqual(res["exit_ip"], self.exit_of(a))
        self.assertFalse(res["rotation_stopped"])
        st = self.eng.status()
        self.assertEqual(st["protection"]["level"], "protected")
        self.assertEqual(st["public"]["v4"], self.exit_of(a))
        self.assertEqual(st["public"]["source"], "tunnel")
        self.assertEqual(st["wanted"], {"vpn": True, "protect": True})
        self.assertTrue(st["killswitch"]["armed"])
        json.dumps(res)

    def test_connect_without_a_name_picks_one(self):
        res = self.eng.connect()
        self.assertTrue(res["exit_ip"])
        again = self.eng.connect()
        self.assertEqual(again["profile_id"], res["profile_id"])   # reuses the last one

    def test_unknown_profile(self):
        with self.assertRaises(NotFound):
            self.eng.connect("does-not-exist")
        self.assertFalse(self.eng.protect_wanted())

    def test_failure_stays_blocked_and_is_not_retried_automatically(self):
        a = self.wg[0]
        self.world.fail[a.id] = "simulated handshake failure"
        with self.assertRaises(VpnError):
            self.eng.connect(a.id)
        st = self.eng.status()
        self.assertEqual(st["protection"]["level"], "blocked")
        self.assertTrue(self.eng.protect_wanted())
        self.assertFalse(self.eng.vpn_wanted())
        self.assertEqual(st["vpn"]["state"], "failed")

    def test_connect_pauses_the_rotation(self):
        self.eng.rotate_start(5.0)
        self.assertTrue(wait_for(lambda: self.eng.scheduler.ok >= 1))
        res = self.eng.connect(self.wg[1].id)
        self.assertTrue(res["rotation_stopped"])
        self.assertFalse(self.eng.scheduler.running)
        self.assertIn("rotation_stopped", self.kinds())

    def test_keep_rotation(self):
        self.eng.rotate_start(30.0)
        self.assertTrue(wait_for(lambda: self.eng.scheduler.ok >= 1))
        res = self.eng.connect(self.wg[1].id, keep_rotation=True)
        self.assertFalse(res["rotation_stopped"])
        self.assertTrue(self.eng.scheduler.running)

    def test_second_control_operation_gets_a_clear_busy_error(self):
        gate = threading.Event()
        started = threading.Event()
        real = self.eng.mgr.activate

        def slow(ref, **kw):
            started.set()
            gate.wait(5)
            return real(ref, **kw)
        self.eng.mgr.activate = slow
        t = threading.Thread(target=lambda: self.eng.connect(self.wg[0].id), daemon=True)
        t.start()
        self.assertTrue(started.wait(5))
        with self.assertRaises(BusyError) as cm:
            self.eng.rotate_start(5.0)
        self.assertIn("connect", str(cm.exception))
        gate.set()
        t.join(5)

    def test_baseline_is_measured_only_when_enabled_and_before_arming(self):
        self.eng.connect(self.wg[0].id)
        self.assertIsNone(self.eng.mgr.baseline_ip)
        self.eng.stop()
        self.cfg.privacy.baseline = True
        calls = []
        orig = self.eng.echo.lookup

        def spy(*a, **kw):
            calls.append(self.eng.ks.armed)
            return orig(*a, **kw)
        self.eng.echo.lookup = spy
        self.eng.connect(self.wg[0].id)
        self.assertEqual(self.eng.mgr.baseline_ip, self.world.real_ip)
        self.assertEqual(calls[0], False)                      # looked up while no firewall was up

    def test_baseline_is_forgotten_when_the_network_changes(self):
        self.eng.mgr.baseline_ip = "192.0.2.77"
        self.eng.bus.publish("network_changed", "warning", network="x")
        self.assertIsNone(self.eng.mgr.baseline_ip)


class StopTests(EngineCase):
    def test_stop_gives_the_normal_network_back(self):
        self.eng.connect(self.wg[0].id)
        self.assertNotEqual(self.eng.hardening.dns.resolv.read_text(), "nameserver 192.168.1.1\n")
        out = self.eng.stop()
        self.assertEqual(out, {"stopped": "all", "released": True})
        st = self.eng.status()
        self.assertEqual(st["protection"]["level"], "unprotected")
        self.assertFalse(st["killswitch"]["armed"])
        self.assertEqual(st["wanted"], {"vpn": False, "protect": False})
        self.assertEqual(self.eng.hardening.dns.resolv.read_text(), "nameserver 192.168.1.1\n")
        knob = self.eng._sim_system["sysctl_root"] / "net" / "ipv6" / "conf" / "wlan0" / "disable_ipv6"
        self.assertEqual(knob.read_text().strip(), "0")
        self.assertIn("stopped", self.kinds())

    def test_stop_can_keep_blocking(self):
        self.eng.connect(self.wg[0].id)
        out = self.eng.stop(keep_blocking=True)
        self.assertFalse(out["released"])
        st = self.eng.status()
        self.assertEqual(st["protection"]["level"], "blocked")
        self.assertTrue(st["killswitch"]["armed"])
        self.assertTrue(self.eng.protect_wanted())
        self.assertFalse(self.eng.vpn_wanted())

    def test_keep_blocking_arms_the_firewall_even_if_it_was_never_up(self):
        self.eng.stop(keep_blocking=True)
        self.assertTrue(self.eng.ks.armed)

    def test_stop_can_leave_the_vpn_connected(self):
        self.eng.rotate_start(5.0)
        self.assertTrue(wait_for(lambda: self.eng.scheduler.ok >= 1))
        out = self.eng.stop(keep_vpn=True)
        self.assertEqual(out["stopped"], "rotation")
        self.assertTrue(out["connected"])
        self.assertFalse(self.eng.scheduler.running)
        self.assertEqual(self.eng.status()["protection"]["level"], "protected")

    def test_stop_when_nothing_is_running(self):
        self.assertEqual(self.eng.stop()["stopped"], "all")
        self.assertEqual(self.eng.stop()["stopped"], "all")

    def test_stop_aborts_a_connection_in_progress(self):
        a = self.wg[0]
        self.world.stuck.add(a.id)
        errors = []

        def run():
            try:
                self.eng.connect(a.id)
            except IPShiftError as e:
                errors.append(e)
        t = threading.Thread(target=run, daemon=True)
        t.start()
        self.assertTrue(wait_for(lambda: self.eng.mgr.state == "connecting"))
        t0 = time.monotonic()
        self.eng.stop()
        t.join(5)
        self.assertLess(time.monotonic() - t0, 4)
        self.assertEqual(len(errors), 1)
        self.assertFalse(self.eng.ks.armed)
        self.assertEqual(self.eng.mgr.state, "disconnected")

    def test_stop_ends_a_running_rotation(self):
        self.eng.rotate_start(1.0)
        self.assertTrue(wait_for(lambda: self.eng.scheduler.ok >= 1))
        self.eng.stop()
        self.assertFalse(self.eng.scheduler.running)
        self.assertIsNone(self.eng.mgr.conn)
        n = self.eng.scheduler.ok
        time.sleep(1.3)
        self.assertEqual(self.eng.scheduler.ok, n)               # nothing keeps rotating after stop


class RotationTests(EngineCase):
    def test_interval_below_one_second_is_refused_before_anything_changes(self):
        for bad in (0.5, 0, -3, float("nan")):
            with self.assertRaises(ConfigError):
                self.eng.rotate_start(bad)
        self.assertFalse(self.eng.scheduler.running)
        self.assertFalse(self.eng.vpn_wanted())
        self.assertFalse(self.eng.ks.armed)

    def test_one_second_rotation_rotates_and_is_recorded(self):
        out = self.eng.rotate_start(1.0)
        self.assertTrue(out["running"])
        self.assertEqual(out["interval"], 1.0)
        self.assertEqual(out["profiles_in_rotation"], 8)
        self.assertTrue(wait_for(lambda: self.eng.scheduler.ok >= 3, timeout=10))
        st = self.eng.status()
        self.assertTrue(st["rotation"]["running"])
        self.assertEqual(st["protection"]["level"], "protected")
        rows = self.eng.history_get(10)["rotations"]
        self.assertGreaterEqual(len([r for r in rows if r["status"] == "success"]), 3)
        ips = [r["new_ip"] for r in rows if r["status"] == "success"]
        self.assertGreaterEqual(len(set(ips)), 2)
        self.assertTrue(self.eng.vpn_wanted() and self.eng.protect_wanted())

    def test_needs_profiles(self):
        for p in self.eng.store.list():
            self.eng.store.remove(p.id)
        with self.assertRaises(ProfileError):
            self.eng.rotate_start(5.0)
        with self.assertRaises(ProfileError):
            self.eng.rotate_now()
        self.assertFalse(self.eng.vpn_wanted() and self.eng.scheduler.running)

    def test_a_single_profile_is_allowed_with_a_warning(self):
        for p in self.eng.store.list()[1:]:
            self.eng.store.remove(p.id)
        out = self.eng.rotate_start(5.0)
        self.assertIn("only one usable profile", out["warning"])

    def test_rotate_now_changes_the_address(self):
        a = self.eng.connect(self.wg[0].id)
        b = self.eng.rotate_now()
        self.assertNotEqual(b["exit_ip"], a["exit_ip"])
        self.assertEqual(b["previous_ip"], a["exit_ip"])

    def test_rotate_stop_keeps_the_vpn(self):
        self.eng.rotate_start(5.0)
        self.assertTrue(wait_for(lambda: self.eng.scheduler.ok >= 1))
        out = self.eng.rotate_stop()
        self.assertFalse(out["running"])
        self.assertTrue(self.eng.mgr.conn)

    def test_stopping_only_the_rotation_lets_a_switch_in_flight_finish(self):
        cfg = Config()
        cfg.vpn.connect_timeout, cfg.vpn.verify_timeout = 5.0, 3.0
        slow = Engine(cfg, dataclasses.replace(self.paths, state_dir=self.tmp / "slow"), simulate=True, sim_speed=1.0)
        self.addCleanup(slow.shutdown)
        for p in slow.store.list(protocol="openvpn"):
            slow.store.update(p.id, enabled=False)           # WireGuard connects in a fraction of a second
        for stop in (lambda: slow.rotate_stop(), lambda: slow.stop(keep_vpn=True)):
            slow.rotate_start(30.0)
            self.assertTrue(wait_for(lambda: slow.mgr.state in ("connecting", "switching"), 3), "no attempt started")
            stop()
            self.assertFalse(slow.scheduler.running)
            self.assertTrue(slow.mgr.conn, "the connection that was being made was cancelled")
            self.assertEqual(slow.status()["protection"]["level"], "protected")

    def test_set_interval(self):
        self.assertEqual(self.eng.set_interval(2)["interval"], 2.0)
        self.assertEqual(self.cfg.rotation.interval, 2.0)
        for bad in (0.99, 0, -1, float("inf")):
            with self.assertRaises(ConfigError):
                self.eng.set_interval(bad)
        self.assertEqual(self.cfg.rotation.interval, 2.0)

    def test_set_interval_while_running_rearms_the_timer(self):
        self.eng.rotate_start(30.0)
        self.assertTrue(wait_for(lambda: self.eng.scheduler.ok >= 1))
        self.eng.set_interval(1.0)
        self.assertTrue(wait_for(lambda: self.eng.scheduler.ok >= 3, timeout=10))
        self.assertIn("interval_changed", self.kinds())


class IpInfoTests(EngineCase):
    def test_unprotected_does_not_probe_the_internet(self):
        calls = []
        orig = self.eng.echo.lookup
        self.eng.echo.lookup = lambda *a, **kw: calls.append(1) or orig(*a, **kw)
        info = self.eng.ip_info(refresh=True)
        self.assertEqual(calls, [])
        self.assertIsNone(info["public"]["v4"])
        self.assertEqual(info["protection"], "unprotected")
        self.assertIn("not looked up", info["note"])
        self.assertTrue(info["private"])

    def test_direct_lookup_is_explicit_and_flagged(self):
        info = self.eng.ip_info(direct=True)
        self.assertEqual(info["public"]["v4"], self.world.real_ip)
        self.assertEqual(info["public"]["source"], "direct")
        self.assertIn("real, unprotected", info["note"])

    def test_blocked_by_the_kill_switch(self):
        self.eng.killswitch_on()
        info = self.eng.ip_info(direct=True)
        self.assertIsNone(info["public"]["v4"])
        self.assertIn("blocking all traffic", info["note"])

    def test_connected_shows_the_tunnel_address_and_refresh_notices_changes(self):
        a = self.wg[0]
        self.eng.connect(a.id)
        info = self.eng.ip_info()
        self.assertEqual(info["public"]["v4"], self.exit_of(a))
        self.assertEqual(info["protection"], "protected")
        self.world.servers[a.id].exit_ip = "198.51.100.222"
        info = self.eng.ip_info(refresh=True)
        self.assertEqual(info["public"]["v4"], "198.51.100.222")
        self.assertIn("ip_changed", self.kinds())

    def test_refresh_failure_keeps_the_last_known_address_and_says_so(self):
        a = self.wg[0]
        self.eng.connect(a.id)
        self.world.dead = True
        info = self.eng.ip_info(refresh=True)
        self.assertEqual(info["public"]["v4"], self.exit_of(a))
        self.assertIn("could not be confirmed", info["note"])

    def test_private_addresses_follow_the_network(self):
        before = {p["ip"] for p in self.eng.ip_info()["private"]}
        self.world.switch_network("hotspot")
        after = {p["ip"] for p in self.eng.ip_info()["private"]}
        self.assertNotEqual(before, after)


class PrivacyCheckTests(EngineCase):
    def test_protected_connection(self):
        self.eng.connect(self.wg[0].id)
        rep = self.eng.privacy_check()
        self.assertIn(rep["verdict"], ("protected", "protected-with-warnings"))
        self.assertGreaterEqual(rep["score"], 85)
        self.assertTrue(rep["simulated"])
        self.assertTrue(rep["not_covered"])
        self.assertEqual(self.eng.status()["privacy"]["verdict"], rep["verdict"])
        self.assertEqual(self.eng.last_report()["ts"], rep["ts"])
        json.dumps(rep)

    def test_a_leak_is_reported_and_raises_a_critical_event(self):
        self.eng.connect(self.wg[0].id)
        self.world.leaks.add("dns")
        rep = self.eng.privacy_check()
        self.assertEqual(rep["verdict"], "exposed")
        self.assertLessEqual(rep["score"], 39)
        ev = [e for e in self.eng.bus.recent(50) if e.kind == "leak_detected"]
        self.assertEqual(len(ev), 1)
        self.assertEqual(ev[0].level, "critical")

    def test_quick_mode_and_selection(self):
        self.eng.connect(self.wg[0].id)
        self.assertEqual(len(self.eng.privacy_check("quick")["findings"]), 4)
        only = self.eng.privacy_check(only=["ipv6", "dns_escape"])
        self.assertEqual([f["id"] for f in only["findings"]], ["ipv6", "dns_escape"])

    def test_bad_arguments(self):
        with self.assertRaises(IPShiftError):
            self.eng.privacy_check(only=["nope"])
        with self.assertRaises(ConfigError):
            self.eng.privacy_check("deep")

    def test_not_connected_is_reported_as_unprotected_or_blocked(self):
        self.assertEqual(self.eng.privacy_check()["verdict"], "unprotected")
        self.eng.killswitch_on()
        self.assertEqual(self.eng.privacy_check()["verdict"], "blocked")


class ProfileTests(EngineCase):
    def wg_text(self):
        return (f"[Interface]\nPrivateKey = {wgkey()}\nAddress = 10.7.0.2/32\nDNS = 10.7.0.1\n"
                f"[Peer]\nPublicKey = {wgkey()}\nAllowedIPs = 0.0.0.0/0, ::/0\nEndpoint = 192.0.2.44:51820\n")

    def test_import_list_update_remove(self):
        out = self.eng.profile_import(text=self.wg_text(), name="my home server", tier="self-hosted", country="de")
        pid = out["profile"]["id"]
        self.assertEqual(out["profile"]["protocol"], "wireguard")
        self.assertEqual(out["profile"]["country"], "DE")
        self.assertNotIn("PrivateKey", json.dumps(out))
        listing = self.eng.profiles()
        self.assertIn(pid, [p["id"] for p in listing["profiles"]])
        self.assertIn(pid, listing["in_rotation"])
        self.assertEqual(self.eng.profile_update(pid, enabled=False)["profile"]["enabled"], False)
        self.assertNotIn(pid, self.eng.profiles()["in_rotation"])
        self.eng.profile_remove(pid)
        self.assertNotIn(pid, [p["id"] for p in self.eng.profiles()["profiles"]])
        self.assertIn("profile_imported", self.kinds())

    def test_bad_import(self):
        with self.assertRaises(ProfileError):
            self.eng.profile_import(text="hello world", name="x")
        with self.assertRaises(ProfileError):
            self.eng.profile_import(text=self.wg_text(), name="x", files={f"f{i}": "a" for i in range(21)})
        with self.assertRaises(ProfileError):
            self.eng.profile_import(text=self.wg_text(), name="x", files={"a": "x" * 70000})

    def test_cannot_remove_the_active_profile(self):
        a = self.wg[0]
        self.eng.connect(a.id)
        with self.assertRaises(ProfileError):
            self.eng.profile_remove(a.id)

    def test_auth_and_quarantine(self):
        a = self.ov[0]
        self.assertTrue(self.eng.profile_auth(a.id, "user", "pw")["profile"]["has_auth"])
        for _ in range(3):
            self.eng.store.record_result(a.id, False, error="x")
        self.assertTrue(self.eng.store.get(a.id).quarantined)
        self.assertEqual(self.eng.profile_clear_quarantine(a.id), {"cleared": 1})
        self.assertFalse(self.eng.store.get(a.id).quarantined)

    def test_names_are_not_resolved_while_the_firewall_is_up(self):
        calls = []
        self.eng.resolver.resolve = lambda host, *a, **kw: calls.append(host) or ["203.0.113.9"]
        text = self.wg_text().replace("192.0.2.44", "vpn.example.net")
        self.eng.killswitch_on()
        out = self.eng.profile_import(text=text, name="armed import")
        self.assertEqual(calls, [])
        self.assertEqual(out["profile"]["endpoints"][0]["ips"], [])
        self.eng.killswitch_off()
        self.eng.profile_import(text=text, name="open import")
        self.assertEqual(calls, ["vpn.example.net"])


class HistoryTests(EngineCase):
    def test_rotations_and_alerts_are_stored(self):
        self.eng.connect(self.wg[0].id)
        self.eng.bus.publish("tunnel_lost", "critical", message="The VPN connection dropped")
        self.eng.bus.publish("chatter", "info", message="not stored")
        h = self.eng.history_get()
        self.assertEqual(h["stats"]["success"], 1)
        self.assertEqual([e["kind"] for e in h["events"]], ["tunnel_lost"])

    def test_export_and_clear(self):
        self.eng.connect(self.wg[0].id)
        self.eng.rotate_now()
        out = self.eng.history_export()
        lines = out["csv"].strip().splitlines()
        self.assertEqual(out["rows"], 2)
        self.assertTrue(lines[0].startswith("id,ts,profile_id"))
        self.assertEqual(len(lines), 3)
        self.assertFalse(out["truncated"])
        self.eng.history_clear()
        self.assertEqual(self.eng.history_get()["stats"]["total"], 0)

    def test_limits_are_clamped(self):
        self.assertEqual(self.eng.history_get(0)["rotations"], [])
        self.eng.history_get(10 ** 9)
        self.assertEqual(self.eng.history_export(0)["rows"], 0)


class ConfigTests(EngineCase):
    def test_get(self):
        full = self.eng.config_get()
        self.assertEqual(full["config"]["rotation"]["interval"], 30.0)
        one = self.eng.config_get("rotation.interval")
        self.assertEqual(one, {"key": "rotation.interval", "value": 30.0, "settable": True})
        self.assertFalse(self.eng.config_get("vpn.ip_bin")["settable"])
        with self.assertRaises(ConfigError):
            self.eng.config_get("nope.nope")

    def test_set_and_apply(self):
        out = self.eng.config_set("rotation.interval", "5")
        self.assertEqual((out["old"], out["value"], out["applies"]), (30.0, 5.0, "now"))
        self.assertFalse(out["saved"])                           # simulation never rewrites the real settings
        self.assertFalse(self.paths.config_file.exists())
        self.assertEqual(self.eng.config_set("dns.manage", "false")["applies"], "next_connect")
        self.assertEqual(self.eng.config_set("privacy.history", "false")["applies"], "restart")

    def test_the_one_second_floor_cannot_be_bypassed(self):
        for bad in ("0.5", "0", "-1", "nan", "inf", "abc", ""):
            with self.assertRaises(ConfigError):
                self.eng.config_set("rotation.interval", bad)
        self.assertEqual(self.cfg.rotation.interval, 30.0)

    def test_dangerous_keys_cannot_be_set_over_the_socket(self):
        for key in ("vpn.openvpn_bin", "vpn.wg_bin", "vpn.ip_bin", "vpn.openvpn_user", "vpn.interface",
                    "vpn.bootstrap_doh", "killswitch.nft_bin", "daemon.group", "daemon.allowed_uids",
                    "daemon.monitor_interval", "daemon.log_level"):
            before = self.cfg.get(key)
            with self.assertRaises(PrivilegeError, msg=key):
                self.eng.config_set(key, "/tmp/evil" if key.endswith("_bin") else "x")
            self.assertEqual(self.cfg.get(key), before)
        self.assertFalse(ipc_settable("vpn.openvpn_bin"))
        self.assertTrue(ipc_settable("rotation.strategy"))

    def test_allowlist_only_names_real_keys(self):
        for key in IPC_SETTABLE_KEYS:
            self.cfg.get(key)                                    # raises ConfigError for a typo

    def test_unknown_and_invalid(self):
        with self.assertRaises(ConfigError):
            self.eng.config_set("rotation.nonsense", "1")
        with self.assertRaises(ConfigError):
            self.eng.config_set("rotation.strategy", "chaos")
        self.assertEqual(self.cfg.rotation.strategy, "diverse")

    def test_settings_take_effect_immediately(self):
        self.eng.config_set("privacy.mask_ips_in_history", "true")
        self.assertTrue(self.eng.history.mask_ips)
        self.eng.config_set("privacy.history_retention_days", "7")
        self.assertEqual(self.eng.history.retention_days, 7)
        self.eng.config_set("privacy.history_max_rows", "5000")
        self.assertEqual(self.eng.history.max_rows, 5000)
        with self.assertRaises(ConfigError):
            self.eng.config_set("privacy.history_max_rows", "10")
        self.assertEqual(self.eng.history.max_rows, 5000)
        self.eng.connect(self.wg[0].id)
        before = self.eng.ks.last_ruleset
        self.eng.config_set("killswitch.allow_lan", "true")
        self.assertNotEqual(self.eng.ks.last_ruleset, before)

    def test_disabling_the_kill_switch_releases_it_and_warns(self):
        self.eng.connect(self.wg[0].id)
        self.eng.config_set("killswitch.enabled", "false")
        self.assertFalse(self.eng.ks.armed)
        self.assertFalse(self.eng.protect_wanted())
        self.assertIn("killswitch_disabled", self.kinds())
        self.eng.config_set("killswitch.enabled", "true")
        self.assertTrue(self.eng.ks.armed)

    def test_interval_change_reaches_the_running_scheduler(self):
        self.eng.rotate_start(30.0)
        self.assertTrue(wait_for(lambda: self.eng.scheduler.ok >= 1))
        self.eng.config_set("rotation.interval", "2")
        self.assertEqual(self.eng.scheduler.interval, 2.0)
        self.assertIn("interval_changed", self.kinds())

    def test_reload_applies_changes_in_place_and_flags_restarts(self):
        self.paths.config_file.parent.mkdir(parents=True, exist_ok=True)
        self.paths.config_file.write_text(json.dumps({
            "rotation": {"interval": 7, "strategy": "random"},
            "vpn": {"interface": "wg-other"}, "killswitch": {"allow_lan": True}}))
        section = self.cfg.rotation                              # components hold this very object
        out = self.eng.config_reload()
        self.assertIs(self.cfg.rotation, section)
        self.assertEqual((section.interval, section.strategy), (7.0, "random"))
        self.assertTrue(self.cfg.killswitch.allow_lan)
        self.assertEqual(self.cfg.vpn.interface, "ipshift0")     # the tunnel name never changes while running
        self.assertEqual(out["restart_required"], ["vpn.interface"])
        self.assertIn("rotation.interval", out["changed"])
        self.assertIn("restart_required", self.kinds())

    def test_reload_of_a_broken_file_changes_nothing(self):
        self.paths.config_file.parent.mkdir(parents=True, exist_ok=True)
        self.paths.config_file.write_text(json.dumps({"rotation": {"interval": 0.2}}))
        with self.assertRaises(ConfigError):
            self.eng.config_reload()
        self.assertEqual(self.cfg.rotation.interval, 30.0)
        self.paths.config_file.write_text("{not json")
        with self.assertRaises(ConfigError):
            self.eng.config_reload()


class FirewallAndRecoveryTests(EngineCase):
    def test_kill_switch_on_off(self):
        self.assertTrue(self.eng.killswitch_on()["armed"])
        self.assertTrue(self.eng.protect_wanted())
        self.assertFalse(self.eng.killswitch_off()["armed"])
        self.assertFalse(self.eng.protect_wanted())
        self.assertIn("killswitch_released", self.kinds())

    def test_lockdown_drops_the_tunnel_and_blocks_everything(self):
        self.eng.rotate_start(5.0)
        self.assertTrue(wait_for(lambda: self.eng.scheduler.ok >= 1))
        st = self.eng.lockdown()
        self.assertTrue(st["armed"] and st["lockdown"])
        self.assertIsNone(self.eng.mgr.conn)
        self.assertFalse(self.eng.scheduler.running)
        self.assertFalse(self.eng.vpn_wanted())
        self.assertTrue(self.eng.protect_wanted())
        crit = [e for e in self.eng.bus.recent(50, "critical") if e.kind == "lockdown"]
        self.assertEqual(len(crit), 1)
        res = self.eng.connect(self.wg[0].id)                    # an explicit connect leaves lockdown
        self.assertTrue(res["exit_ip"])
        self.assertFalse(self.eng.killswitch_status()["lockdown"])

    def test_mac_policy(self):
        self.assertTrue(self.eng.mac_policy("enable")["nm_policy"])
        self.assertTrue(self.eng.harden_status()["mac_nm_policy"])
        self.assertTrue(self.eng.mac_policy("disable")["was_enabled"])
        out = self.eng.mac_policy("randomize", "wlan0")
        self.assertRegex(out["mac"], r"^([0-9a-f]{2}:){5}[0-9a-f]{2}$")
        self.assertEqual(self.eng.mac_policy("restore")["restored"], ["wlan0"])
        with self.assertRaises(ConfigError):
            self.eng.mac_policy("randomize")
        with self.assertRaises(ConfigError):
            self.eng.mac_policy("explode")

    def test_restore_network(self):
        self.eng.connect(self.wg[0].id)
        report = self.eng.restore_network()
        self.assertEqual(report["killswitch"], "removed")
        self.assertFalse(self.eng.ks.is_armed())
        self.assertEqual(self.eng.mgr.state, "disconnected")
        self.assertEqual(self.eng.hardening.dns.resolv.read_text(), "nameserver 192.168.1.1\n")
        self.assertEqual(self.eng.status()["wanted"], {"vpn": False, "protect": False})

    def test_recover_tunnel_tries_the_same_profile_first(self):
        a = self.wg[0]
        self.eng.connect(a.id)
        self.world.dead = True
        res = self.eng.recover_tunnel()
        self.assertEqual(res.profile_id, a.id)
        self.assertTrue(self.eng.mgr.tunnel_alive())

    def test_recover_tunnel_falls_back_to_another_profile(self):
        a = self.wg[0]
        self.eng.connect(a.id)
        self.world.dead = True
        self.world.fail[a.id] = "gone"
        res = self.eng.recover_tunnel()
        self.assertNotEqual(res.profile_id, a.id)
        self.assertTrue(self.eng.mgr.tunnel_alive())

    def test_recover_tunnel_gives_up_with_the_last_error(self):
        self.eng.connect(self.wg[0].id)
        self.world.dead = True
        for p in self.eng.store.list():
            self.world.fail[p.id] = "everything is down"
        with self.assertRaises(VpnError) as cm:
            self.eng.recover_tunnel()
        self.assertIn("everything is down", str(cm.exception))
        self.assertTrue(self.eng.ks.armed)                       # and traffic stays blocked meanwhile

    def test_recover_tunnel_busy_is_propagated(self):
        self.eng.connect(self.wg[0].id)
        gate, started = threading.Event(), threading.Event()
        real = self.eng.mgr._activate

        def slow(ref, reason):
            started.set()
            gate.wait(5)
            return real(ref, reason)
        self.eng.mgr._activate = slow
        t = threading.Thread(target=lambda: self.eng.mgr.activate(self.wg[1].id), daemon=True)
        t.start()
        self.assertTrue(started.wait(5))
        with self.assertRaises(BusyError):
            self.eng.recover_tunnel()
        gate.set()
        t.join(5)


class LifecycleTests(EngineCase):
    def test_start_adopts_rules_left_by_an_earlier_run(self):
        self.eng.ks.arm()
        self.eng.start()
        self.assertTrue(self.eng.protect_wanted())
        ev = [e for e in self.eng.bus.recent(50) if e.kind == "killswitch_adopted"]
        self.assertEqual(len(ev), 1)
        self.assertEqual(ev[0].level, "warning")
        self.assertEqual(self.eng.status()["protection"]["level"], "blocked")

    def test_always_on_kill_switch(self):
        self.cfg.killswitch.arm_on_start = True
        self.eng.start()
        self.assertTrue(self.eng.ks.armed)
        self.assertEqual(self.eng.status()["protection"]["level"], "blocked")
        self.assertIn("killswitch_armed", self.kinds())

    def test_normal_start_touches_nothing(self):
        self.eng.start()
        self.assertFalse(self.eng.ks.armed)
        self.assertIn("daemon_started", self.kinds())

    def test_shutdown_stays_fail_closed_by_default(self):
        self.eng.connect(self.wg[0].id)
        self.eng.shutdown()
        self.assertIsNone(self.eng.mgr.conn)
        self.assertTrue(self.eng.ks.armed)
        self.eng.shutdown()                                      # idempotent

    def test_shutdown_can_release(self):
        self.cfg.killswitch.release_on_exit = True
        self.eng.connect(self.wg[0].id)
        self.eng.shutdown()
        self.assertFalse(self.eng.ks.armed)

    def test_shutdown_interrupts_a_rotation_promptly(self):
        self.eng.start()
        self.eng.rotate_start(1.0)
        self.assertTrue(wait_for(lambda: self.eng.scheduler.ok >= 1))
        t0 = time.monotonic()
        self.eng.shutdown()
        self.assertLess(time.monotonic() - t0, 5)
        self.assertFalse(self.eng.scheduler.running)

    def test_the_monitor_reconnects_a_dropped_tunnel_end_to_end(self):
        self.cfg.daemon.monitor_interval = 1.0
        self.eng.start()
        a = self.wg[0]
        self.eng.connect(a.id)
        self.world.dead = True
        self.assertTrue(wait_for(lambda: "tunnel_restored" in self.kinds(), timeout=15), self.kinds())
        self.assertIn("tunnel_lost", self.kinds())
        self.assertTrue(self.eng.mgr.tunnel_alive())
        self.assertEqual(self.eng.status()["protection"]["level"], "protected")

    def test_the_monitor_puts_removed_firewall_rules_back(self):
        self.cfg.daemon.monitor_interval = 1.0
        self.eng.start()
        self.eng.connect(self.wg[0].id)
        self.eng.ks.disarm()                                     # "someone" flushed the rules
        self.assertTrue(wait_for(lambda: self.eng.ks.armed, timeout=10))
        self.assertIn("killswitch_tampered", self.kinds())

    def test_the_monitor_does_not_resurrect_a_stopped_vpn(self):
        self.cfg.daemon.monitor_interval = 1.0
        self.eng.start()
        self.eng.connect(self.wg[0].id)
        self.eng.stop()
        self.world.dead = True
        self.eng.monitor.tick()
        time.sleep(0.3)
        self.assertIsNone(self.eng.mgr.conn)
        self.assertFalse(self.eng.ks.armed)
        self.assertNotIn("tunnel_lost", self.kinds())


class RealModeWiringTests(EngineCase):
    """The real parts (not the simulator) assemble and answer read-only questions; nothing is started."""
    SIM = False

    def test_status_and_config_with_real_components(self):
        self.assertFalse(self.eng.simulate)
        self.assertIsNone(self.eng.world)
        self.assertEqual(sorted(self.eng.backends), ["openvpn", "wireguard"])
        st = self.eng.status()
        self.assertEqual(st["vpn"]["state"], "disconnected")
        self.assertFalse(st["daemon"]["simulated"])
        json.dumps(st)
        self.assertEqual(self.eng.profiles()["profiles"], [])

    def test_changes_are_saved_to_the_config_file(self):
        out = self.eng.config_set("rotation.interval", "12")
        self.assertTrue(out["saved"])
        self.assertEqual(json.loads(self.paths.config_file.read_text())["rotation"]["interval"], 12.0)
        self.assertEqual(Config.load(self.paths.config_file).rotation.interval, 12.0)

    def test_history_lives_in_a_private_file(self):
        self.eng.history.add_rotation(status="success", new_ip="203.0.113.5")
        self.assertTrue(self.paths.history_db.exists())
        self.assertEqual(self.paths.history_db.stat().st_mode & 0o777, 0o600)

    def test_history_stays_in_memory_when_disabled(self):
        cfg = Config()
        cfg.privacy.history = False
        eng = Engine(cfg, default_paths(), simulate=False)
        self.addCleanup(eng.shutdown)
        eng.history.add_rotation(status="success")
        self.assertEqual(len(eng.history.recent_rotations()), 1)
        self.assertFalse(self.paths.history_db.exists() and self.paths.history_db.stat().st_size > 0 and
                         b"success" in self.paths.history_db.read_bytes())


if __name__ == "__main__":
    unittest.main()
