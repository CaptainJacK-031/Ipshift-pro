"""Hand-made daemon answers for the GUI tests (shaped exactly like the real ones)."""
from __future__ import annotations

import copy

from ipshift.privacy.report import Finding, Report


def status(**over) -> dict:
    """A connected, rotating, protected status; ``over`` replaces whole top-level sections."""
    st = {
        "daemon": {"version": "1.0.0", "pid": 42, "uptime": 125, "simulated": False, "root": True},
        "protection": {"level": "protected", "message": "Traffic goes through the VPN; the kill switch is armed"},
        "vpn": {"state": "connected", "connected": True, "busy": None, "last_error": None,
                "profile": {"id": "nl-1", "name": "NL 1", "tier": "paid", "protocol": "wireguard", "country": "NL"},
                "server": "203.0.113.9:51820/udp", "backend": "wireguard", "iface": "ipshift0",
                "exit_ip": "198.51.100.7", "exit_ipv6": None, "since": 1000.0, "uptime": 95, "via": "full",
                "dns": ["10.0.0.1"], "health": {"handshake_age": 12, "uptime": 95}},
        "rotation": {"running": True, "interval": 1.0, "strategy": "diverse", "next_in": 0.6, "ticks": 10, "ok": 8,
                     "failed": 1, "unchanged": 1, "skipped": 0, "consecutive_failures": 0, "stalled": False,
                     "last": {"status": "success", "profile": "NL 1", "ip": "198.51.100.7", "ms": 850},
                     "minimum_interval": 1.0},
        "killswitch": {"armed": True, "lockdown": False, "dry_run": False, "endpoints": ["203.0.113.9:51820/udp"],
                       "allow_lan": False, "enabled": True, "blocked_packets": 12, "blocked_bytes": 1000},
        "network": {"default_iface": "wlan0", "gateway": "192.168.1.1", "kind": "wifi", "hotspot": None,
                    "description": "Wi-Fi on wlan0",
                    "private_ips": [
                        {"iface": "wlan0", "ip": "192.168.1.23", "prefix": 24, "family": 4, "scope": "private",
                         "kind": "wifi", "primary": True},
                        {"iface": "ipshift0", "ip": "10.2.0.2", "prefix": 32, "family": 4, "scope": "private",
                         "kind": "tunnel", "primary": False},
                        {"iface": "wlan0", "ip": "fd00::23", "prefix": 64, "family": 6, "scope": "private",
                         "kind": "wifi", "primary": False}]},
        "public": {"v4": "198.51.100.7", "v6": None, "source": "tunnel", "verified_at": 990.0},
        "hardening": {"dns_locked": True, "dns_servers": ["10.0.0.1"], "dns_intact": True, "ipv6_guard": True,
                      "ipv6_intact": True, "mac_nm_policy": False, "mac_overrides": []},
        "alerts": [], "privacy": None, "wanted": {"vpn": True, "protect": True},
        "profiles": {"total": 8, "usable": 8},
    }
    st.update(copy.deepcopy(over))
    return st


def idle(level: str = "unprotected", **over) -> dict:
    """Not connected: ``unprotected`` (no firewall) or ``blocked`` (kill switch up)."""
    armed = level == "blocked"
    msg = ("Not connected - the kill switch is blocking all traffic" if armed
           else "Not connected - your real IP address is exposed")
    base = dict(
        protection={"level": level, "message": msg},
        vpn={"state": "disconnected", "connected": False, "busy": None, "last_error": None, "profile": None,
             "server": None, "backend": None, "iface": "ipshift0", "exit_ip": None, "exit_ipv6": None,
             "since": None, "uptime": None, "via": None, "dns": [], "health": {}},
        rotation={"running": False, "interval": 30.0, "strategy": "diverse", "next_in": None, "ticks": 0, "ok": 0,
                  "failed": 0, "unchanged": 0, "skipped": 0, "consecutive_failures": 0, "stalled": False,
                  "last": {}, "minimum_interval": 1.0},
        killswitch={"armed": armed, "lockdown": False, "dry_run": False, "endpoints": [], "allow_lan": False,
                    "enabled": True, "blocked_packets": 0, "blocked_bytes": 0},
        public={"v4": None, "v6": None, "source": None, "verified_at": None},
        hardening={"dns_locked": False, "dns_servers": [], "dns_intact": None, "ipv6_guard": False,
                   "ipv6_intact": None, "mac_nm_policy": False, "mac_overrides": []})
    base.update(over)
    return status(**base)


def finding(id_: str, status_: str, detail: str = "", *, leak: bool = False, hint: str | None = None,
            title: str | None = None) -> Finding:
    from ipshift.privacy.leaks import TITLES
    return Finding(id_, title or TITLES[id_], status_, detail or f"{id_} {status_}", hint=hint, leak=leak)


def report(**statuses) -> dict:
    """A full report as the daemon sends it; ``statuses`` maps a check id to pass|warn|fail|skip."""
    from ipshift.privacy.leaks import FULL
    leaky = {"dns_path", "dns_escape", "ipv6", "escape", "public_ip"}
    findings = [finding(i, statuses.get(i, "pass"), leak=(i in leaky and statuses.get(i) == "fail"),
                        hint="fix it" if statuses.get(i) in ("fail", "warn") else None) for i in FULL]
    return Report(findings, mode="full", ts=2000.0, duration_ms=3200).to_dict()


def history(n: int = 3) -> dict:
    rows = []
    for i in range(n, 0, -1):                                   # newest first, like the daemon
        rows.append({"id": i, "ts": 1_700_000_000.0 + i, "profile_id": f"p{i}", "profile_name": f"Server {i}",
                     "kind": "wireguard", "tier": "paid", "old_ip": f"198.51.100.{i}", "new_ip": f"198.51.100.{i + 1}",
                     "duration_ms": 800 + i, "status": "success", "reason": "rotate", "error": None})
    return {"rotations": rows, "stats": {"total": n, "success": n, "failed": 0, "unchanged": 0, "unique_ips": n,
                                         "avg_duration_ms": 801},
            "events": []}


def profiles(**extra) -> dict:
    base = [
        {"id": "wg-nl", "name": "WG NL", "protocol": "wireguard", "tier": "paid", "country": "NL", "enabled": True,
         "needs_auth": False, "has_auth": False, "quarantined": False, "quarantined_until": 0.0, "usable": True,
         "ok_count": 5, "fail_count": 1, "last_ip": "198.51.100.5", "endpoints": [{"host": "a", "port": 1}],
         "last_error": None},
        {"id": "ovpn-us", "name": "OVPN US", "protocol": "openvpn", "tier": "free", "country": "US", "enabled": True,
         "needs_auth": True, "has_auth": False, "quarantined": False, "quarantined_until": 0.0, "usable": False,
         "ok_count": 0, "fail_count": 0, "last_ip": None, "endpoints": [{"host": "b", "port": 2}],
         "last_error": None},
    ]
    return {"profiles": base, "current": None, "in_rotation": ["wg-nl"], **extra}


def config(over: dict | None = None) -> dict:
    """What ``config.get`` returns for the settings the Settings page knows: ``{section: {key: value}}``.

    Every value is a valid one (the smallest number, the first choice, nothing ticked); ``over`` maps
    ``"section.key"`` to the value to use instead."""
    from ipshift.gui.settings_schema import all_settings
    cfg: dict = {}
    for s in all_settings():
        section, _, name = s.key.partition(".")
        if s.kind == "bool":
            value = False
        elif s.kind == "int":
            value = int(s.minimum)
        elif s.kind == "float":
            value = float(s.minimum)
        elif s.kind == "choice":
            value = s.choices[0][0]
        else:
            value = []
        cfg.setdefault(section, {})[name] = value
    for key, value in (over or {}).items():
        section, _, name = key.partition(".")
        cfg[section][name] = value
    return cfg


def config_get(over: dict | None = None, *, file: str = "/etc/ipshift/config.toml", simulated: bool = False) -> dict:
    """The whole answer of ``config.get``."""
    return {"config": config(over), "file": file, "warnings": [], "simulated": simulated}
