"""A main window wired to a ``FakeLink`` instead of a daemon, for the window tests.

The window, the model and the actions are the real ones; only the link (threads and sockets) is replaced,
so a test feeds the window by emitting the bridge's signals, exactly as the link's threads would, and
reads what the window asked the daemon to do from ``link.calls``.
"""
from __future__ import annotations

import fakeqt
import guifix
import qtcase


class WindowCase(qtcase.QtCase):
    NOW = 1_700_000_000.0
    demo = False

    def prepare(self) -> None:
        """Called after the QApplication exists and before the window is built."""

    def setUp(self):
        super().setUp()
        self.prepare()
        from ipshift.gui import qtbridge, window
        from ipshift.gui.actions import Actions
        from ipshift.gui.model import AppModel
        self.now, self.mono = self.NOW, 100.0
        self.link = qtcase.FakeLink()
        self.model = AppModel(clock=lambda: self.now, mono=lambda: self.mono)
        self.bridge = qtbridge.Bridge()
        self.bridge.link = self.link
        self.commands = Actions(self.link, self.model)
        self.win = window.MainWindow(self.bridge, self.model, self.commands, demo=self.demo)

    # ---- feeding the window ---------------------------------------------------------------------------------------
    def feed(self, signal: str, *args) -> None:
        """Emit one of the bridge's signals and let Qt deliver it (it is a queued connection)."""
        getattr(self.bridge, signal).emit(*args)
        self.app.processEvents()

    def connect_daemon(self, st=None, *, page=None, **data) -> None:
        """Show the window, report the daemon as reachable with a status, and optionally more data."""
        self.win.show()
        self.feed("link_changed", True, "", "")
        self.feed("status_received", guifix.status() if st is None else st)
        for name, payload in data.items():
            self.feed("data_received", name, payload)
        if page:
            self.win.select_page(page)
            self.app.processEvents()
        self.link.clear()                       # what the set-up asked for is not what the test is about

    # ---- scripting the questions ----------------------------------------------------------------------------------
    @property
    def hooks(self):
        return fakeqt.state.hooks

    def confirms(self, answer: bool) -> list:
        """Answer every confirmation with yes (True) or no; returns the message boxes that were shown."""
        shown: list = []

        def hook(box):
            shown.append(box)
            return box._buttons[0 if answer else 1][0]

        self.hooks.message_box = hook
        return shown

    def script(self, fn) -> None:
        """Run ``fn(dialog)`` whenever a dialog is opened."""
        self.hooks.dialog = fn

    def press(self, dialog, which: str) -> None:
        from PySide6.QtWidgets import QDialogButtonBox
        flag = {"ok": QDialogButtonBox.StandardButton.Ok, "cancel": QDialogButtonBox.StandardButton.Cancel}[which]
        dialog.buttons.button(flag).click()

    def unscripted(self) -> list:
        return list(self.hooks.unscripted)
