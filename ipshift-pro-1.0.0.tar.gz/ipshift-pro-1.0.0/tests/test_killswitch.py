"""Kill switch tests: ruleset generation, controller behaviour, and - when the
machine allows it (root, nft, unshare, /dev/net/tun) - a packet-level check that
runs the real ruleset in a throw-away network namespace."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import unittest
from pathlib import Path

from helpers import FakeRunner

from ipshift.config import KillSwitchConfig, VpnConfig
from ipshift.errors import DependencyError, KillSwitchError
from ipshift.firewall.killswitch import KillSwitch
from ipshift.firewall.rules import COMMENT_BLOCKED, RuleSpec, render
from ipshift.sysutil import CmdResult
from ipshift.vpn.backend import Target

HERE = Path(__file__).resolve().parent


class FakeNet:
    def __init__(self, phys=("wlan0",)):
        self.phys = list(phys)

    def physical_ifaces(self):
        return list(self.phys)


def lines(text: str, needle: str) -> list[str]:
    return [l.strip() for l in text.splitlines() if needle in l]


class RuleRenderTests(unittest.TestCase):
    def test_default_is_drop_everywhere_it_matters(self):
        text = render(RuleSpec())
        self.assertIn("type filter hook output priority -150; policy drop;", text)
        self.assertIn("type filter hook input priority -150; policy drop;", text)
        self.assertTrue(text.startswith("add table inet ipshift\ndelete table inet ipshift\ntable inet ipshift {"))
        self.assertTrue(text.endswith("}\n"))
        # no endpoint, no bootstrap, no LAN: nothing but lo/tunnel/DHCP may leave
        out = text.split("chain output")[1].split("chain input")[0]
        accepts = [l.strip() for l in out.splitlines() if l.strip().endswith("accept") or " accept " in l]
        self.assertTrue(any('oifname "lo" accept' in l for l in accepts))
        self.assertTrue(any('oifname "ipshift0" accept' in l for l in accepts))
        self.assertFalse(any("192.168" in l or "10.0.0.0" in l for l in accepts))

    def test_endpoint_is_matched_on_ip_protocol_and_port(self):
        text = render(RuleSpec(endpoints=[Target("203.0.113.7", 51820, "udp"), Target("2001:db8::1", 443, "tcp")]))
        self.assertIn("203.0.113.7 . udp . 51820", text)
        self.assertIn("2001:db8::1 . tcp . 443", text)
        self.assertIn("ip daddr . meta l4proto . th dport @servers4 accept", text)
        self.assertIn("ip6 daddr . meta l4proto . th dport @servers6 accept", text)
        self.assertIn("nd-neighbor-solicit", text)                 # needed to reach a v6 server

    def test_no_ndp_rule_without_ipv6_server(self):
        self.assertNotIn("nd-neighbor", render(RuleSpec(endpoints=[Target("203.0.113.7", 1194, "udp")])))

    def test_bootstrap_hosts_only_on_443(self):
        text = render(RuleSpec(bootstrap_hosts=["9.9.9.9", "149.112.112.112", "2620:fe::fe"]))
        self.assertEqual(len(lines(text, "DoH bootstrap")), 2)
        for l in lines(text, "DoH bootstrap"):
            self.assertIn("tcp dport 443", l)
        self.assertIn("9.9.9.9", text)

    def test_lan_never_gets_dns(self):
        text = render(RuleSpec(allow_lan=True))
        out = text.split("chain output")[1].split("chain input")[0].splitlines()
        drop4 = next(i for i, l in enumerate(out) if "th dport { 53, 853 } drop" in l and "ip daddr" in l)
        accept4 = next(i for i, l in enumerate(out) if l.strip().startswith("ip daddr {") and l.strip().endswith("accept"))
        self.assertLess(drop4, accept4, "the DNS drop must precede the LAN accept")
        self.assertIn("fe80::/10", text)

    def test_lan_off_by_default(self):
        self.assertNotIn("192.168.0.0/16", render(RuleSpec()))

    def test_dhcp_optional(self):
        self.assertIn("udp sport 68 udp dport 67 accept", render(RuleSpec(allow_dhcp=True)))
        self.assertNotIn("dport 67", render(RuleSpec(allow_dhcp=False)))
        self.assertNotIn("dport 68", render(RuleSpec(allow_dhcp=False)))

    def test_lockdown_is_loopback_only(self):
        text = render(RuleSpec(lockdown=True, endpoints=[Target("203.0.113.7", 51820)], bootstrap_hosts=["9.9.9.9"],
                               allow_lan=True, allow_ifaces=["tap0"]))
        self.assertNotIn("203.0.113.7", text)
        self.assertNotIn("9.9.9.9", text)
        self.assertNotIn("dport 67", text)
        self.assertNotIn("192.168", text)
        self.assertNotIn("tap0", text)
        self.assertNotIn("established", text)
        self.assertIn('oifname "lo" accept', text)

    def test_forward_cannot_leave_by_physical_interface(self):
        text = render(RuleSpec(physical_ifaces=["wlan0", "eth0", "ipshift0"]))
        fwd = text.split("chain forward")[1]
        self.assertIn('oifname { "wlan0", "eth0" } counter drop', fwd)
        self.assertNotIn('"ipshift0" }', fwd)
        self.assertNotIn("chain forward", render(RuleSpec(allow_forward=True)))

    def test_allow_ifaces_are_mirrored_on_input(self):
        text = render(RuleSpec(allow_ifaces=["vboxnet0", "virbr*"]))
        self.assertIn('oifname "vboxnet0" accept', text)
        self.assertIn('iifname "virbr*" accept', text)

    def test_blocked_counter_present_on_both_chains(self):
        self.assertEqual(render(RuleSpec()).count(f'counter drop comment "{COMMENT_BLOCKED}"'), 2)

    def test_log_rule_is_rate_limited(self):
        self.assertIn("limit rate 5/second log prefix", render(RuleSpec(log_drops=True)))
        self.assertNotIn("log prefix", render(RuleSpec()))

    def test_rejects_hostile_values(self):
        for bad in ('x"; drop', "a b", "", "x" * 20, "wl{an}", "e;th"):
            with self.assertRaises(ValueError, msg=bad):
                render(RuleSpec(allow_ifaces=[bad]))
        with self.assertRaises(ValueError):
            render(RuleSpec(tunnel_iface='ipshift0" accept; #'))
        with self.assertRaises(ValueError):
            render(RuleSpec(endpoints=[Target("203.0.113.7", 70000, "udp")]))
        with self.assertRaises(ValueError):
            render(RuleSpec(endpoints=[Target("203.0.113.7", 53, "icmp")]))
        with self.assertRaises(ValueError):
            render(RuleSpec(endpoints=[Target("not-an-ip", 53, "udp")]))
        with self.assertRaises(ValueError):
            render(RuleSpec(bootstrap_hosts=["dns.example.org"]))

    def test_output_is_deterministic(self):
        a = render(RuleSpec(endpoints=[Target("203.0.113.9", 1, "udp"), Target("203.0.113.7", 2, "tcp")],
                            bootstrap_hosts=["9.9.9.9", "149.112.112.112"]))
        b = render(RuleSpec(endpoints=[Target("203.0.113.7", 2, "tcp"), Target("203.0.113.9", 1, "udp")],
                            bootstrap_hosts=["149.112.112.112", "9.9.9.9"]))
        self.assertEqual(a, b)


class ControllerTests(unittest.TestCase):
    def make(self, *, dry=False, runner=None, phys=("wlan0",), **ks):
        self.runner = runner or FakeRunner()
        cfg = KillSwitchConfig(**ks)
        return KillSwitch(cfg, VpnConfig(), self.runner, FakeNet(phys), dry_run=dry)

    def nft_inputs(self):
        return [i for c, i in zip(self.runner.calls, self.runner.inputs) if c[:3] == ("nft", "-f", "-")]

    def setUp(self):
        # make 'nft' look installed regardless of the machine running the tests
        import ipshift.firewall.killswitch as mod
        self._mod = mod
        self._orig = mod.which
        mod.which = lambda name: "/usr/sbin/nft"
        self.addCleanup(setattr, mod, "which", self._orig)

    def test_arm_applies_one_transaction(self):
        ks = self.make()
        ks.arm()
        sent = self.nft_inputs()
        self.assertEqual(len(sent), 1)
        self.assertIn("delete table inet ipshift", sent[0])
        self.assertIn('"wlan0"', sent[0])                       # forward protection learned the NIC
        self.assertEqual(ks.last_ruleset, sent[0])

    def test_arm_failure_raises_and_is_not_armed(self):
        runner = FakeRunner([(lambda a: a[:3] == ("nft", "-f", "-"), CmdResult(("nft",), 1, "", "Error: boom"))])
        ks = self.make(runner=runner)
        with self.assertRaises(KillSwitchError) as cm:
            ks.arm()
        self.assertIn("boom", str(cm.exception))
        self.assertFalse(ks._armed)

    def test_missing_nft_is_a_dependency_error(self):
        self._mod.which = lambda name: None
        with self.assertRaises(DependencyError):
            self.make().arm()

    def test_set_endpoints_before_arm_does_not_touch_the_firewall(self):
        ks = self.make()
        ks.set_endpoints([Target("203.0.113.7", 51820)])
        self.assertEqual(self.nft_inputs(), [])
        ks.arm()
        self.assertIn("203.0.113.7 . udp . 51820", self.nft_inputs()[-1])

    def test_server_switch_replaces_the_whole_table(self):
        ks = self.make()
        ks.arm()
        ks.set_endpoints([Target("203.0.113.7", 51820)])
        ks.set_endpoints([Target("203.0.113.9", 51820)])
        last = self.nft_inputs()[-1]
        self.assertIn("203.0.113.9", last)
        self.assertNotIn("203.0.113.7", last)
        self.assertTrue(last.startswith("add table inet ipshift\ndelete table inet ipshift\n"))

    def test_bootstrap_window_opens_and_closes(self):
        ks = self.make()
        ks.arm()
        n = len(self.nft_inputs())
        ks.close_bootstrap()                                    # nothing open: no churn
        self.assertEqual(len(self.nft_inputs()), n)
        ks.open_bootstrap(["9.9.9.9"])
        self.assertIn("DoH bootstrap", self.nft_inputs()[-1])
        ks.close_bootstrap()
        self.assertNotIn("DoH bootstrap", self.nft_inputs()[-1])

    def test_lockdown_then_arm_restores_normal_policy(self):
        ks = self.make()
        ks.set_endpoints([Target("203.0.113.7", 51820)])
        ks.arm()
        ks.lockdown()
        self.assertNotIn("203.0.113.7", self.nft_inputs()[-1])
        self.assertTrue(ks.status()["lockdown"])
        ks.arm()
        self.assertIn("203.0.113.7", self.nft_inputs()[-1])
        self.assertFalse(ks.status()["lockdown"])

    def test_forward_rule_tracks_physical_interfaces_on_refresh(self):
        net = FakeNet(["wlan0"])
        runner = FakeRunner()
        ks = KillSwitch(KillSwitchConfig(), VpnConfig(), runner, net)
        ks.arm()
        net.phys = ["wlan0", "usb0"]                            # a hotspot was plugged in
        ks.refresh()
        self.assertIn('"usb0"', [i for c, i in zip(runner.calls, runner.inputs) if c[:3] == ("nft", "-f", "-")][-1])

    def test_allow_forward_config_removes_forward_chain(self):
        ks = self.make(allow_forward=True)
        ks.arm()
        self.assertNotIn("chain forward", self.nft_inputs()[-1])

    def test_disarm_deletes_the_table_and_tolerates_absence(self):
        ks = self.make()
        ks.arm()
        ks.disarm()
        self.assertTrue(self.runner.ran("nft delete table inet ipshift"))
        runner = FakeRunner([("nft delete", CmdResult(("nft",), 1, "", "Error: No such file or directory"))])
        ks2 = self.make(runner=runner)
        ks2.disarm()                                            # must not raise
        runner = FakeRunner([("nft delete", CmdResult(("nft",), 1, "", "Error: Operation not permitted"))])
        with self.assertRaises(KillSwitchError):
            self.make(runner=runner).disarm()

    def test_dry_run_never_calls_nft(self):
        ks = self.make(dry=True)
        ks.arm()
        ks.set_endpoints([Target("203.0.113.7", 51820)])
        ks.disarm()
        self.assertEqual(self.runner.calls, [])
        self.assertIn("203.0.113.7", ks.last_ruleset)
        self.assertFalse(ks.is_armed())

    def test_status_and_counters_parse_nft_json(self):
        doc = {"nftables": [{"rule": {"comment": COMMENT_BLOCKED, "expr": [{"counter": {"packets": 7, "bytes": 900}}]}},
                            {"rule": {"comment": COMMENT_BLOCKED, "expr": [{"counter": {"packets": 3, "bytes": 100}}]}},
                            {"rule": {"comment": "other", "expr": [{"counter": {"packets": 99, "bytes": 99}}]}}]}
        runner = FakeRunner([("nft -j", CmdResult(("nft",), 0, json.dumps(doc), "")),
                             ("nft list", CmdResult(("nft",), 0, "table inet ipshift {}", ""))])
        ks = self.make(runner=runner)
        ks.set_endpoints([Target("203.0.113.7", 51820, "udp")])
        st = ks.status()
        self.assertTrue(st["armed"])
        self.assertEqual((st["blocked_packets"], st["blocked_bytes"]), (10, 1000))
        self.assertEqual(st["endpoints"], ["203.0.113.7:51820/udp"])

    def test_garbage_counter_output_is_ignored(self):
        runner = FakeRunner([("nft -j", CmdResult(("nft",), 0, "not json", "")),
                             ("nft list", CmdResult(("nft",), 0, "", ""))])
        self.assertEqual(self.make(runner=runner).counters(), {"blocked_packets": 0, "blocked_bytes": 0})

    def test_not_armed_when_table_missing(self):
        runner = FakeRunner([("nft list", CmdResult(("nft",), 1, "", "No such file"))])
        ks = self.make(runner=runner)
        self.assertFalse(ks.is_armed())
        self.assertEqual(ks.status()["blocked_packets"], 0)


def _kernel_test_possible() -> str | None:
    if os.name != "posix" or os.geteuid() != 0:
        return "needs root"
    for tool in ("unshare", "nft"):
        if not shutil.which(tool):
            return f"{tool} not installed"
    if not os.path.exists("/dev/net/tun"):
        return "no /dev/net/tun"
    try:
        probe = subprocess.run(["unshare", "-n", "nft", "list", "ruleset"], capture_output=True, timeout=20)
    except (OSError, subprocess.TimeoutExpired):
        return "cannot create a network namespace"
    if probe.returncode != 0:
        return "cannot use nftables inside a network namespace"
    return None


class KernelLevelTests(unittest.TestCase):
    """Applies the real ruleset in a private namespace and watches which packets
    actually come out of the (fake) physical and tunnel interfaces."""

    reason = _kernel_test_possible()

    @unittest.skipIf(reason is not None, reason or "")
    def test_packets_follow_the_policy(self):
        env = dict(os.environ, PYTHONPATH=os.pathsep.join([str(HERE.parent / "src"), str(HERE)]))
        proc = subprocess.run(["unshare", "-n", sys.executable, str(HERE / "netns_killswitch.py")],
                              capture_output=True, text=True, timeout=240, env=env)
        self.assertEqual(proc.returncode, 0, proc.stderr[-2000:])
        report = json.loads(proc.stdout.strip().splitlines()[-1])
        failed = {k: v["detail"] for k, v in report.items() if not v["ok"]}
        self.assertEqual(failed, {}, "kernel-level checks failed")
        self.assertGreaterEqual(len(report), 35)
        self.assertEqual(report["no_leak_during_150_ruleset_replacements"]["ok"], True)


if __name__ == "__main__":
    unittest.main()
