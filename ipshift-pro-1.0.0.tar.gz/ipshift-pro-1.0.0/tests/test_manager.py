"""VpnManager against the simulated world."""
from __future__ import annotations

import threading
import time
import unittest

from helpers import TmpRootCase
from simharness import SimStack

from ipshift.errors import (BusyError, DependencyError, IPUnchanged, KillSwitchError, LeakDetected, NotFound,
                            ProfileError, VerificationError, VpnError, VpnTimeout)
from ipshift.vpn.profile import Endpoint, Profile, make_id
from ipshift.vpn.sim import SimBackend


def spy_endpoints(stack):
    calls = []
    orig = stack.ks.set_endpoints

    def spy(targets):
        calls.append([f"{t.ip}:{t.port}" for t in targets])
        return orig(targets)
    stack.ks.set_endpoints = spy
    return calls


class ManagerCase(TmpRootCase):
    def setUp(self):
        super().setUp()
        self.s = SimStack(self.tmp)
        self.addCleanup(self.s.close)
        self.wg = self.s.profiles("wireguard")
        self.ov = self.s.profiles("openvpn")

    def exit_of(self, profile):
        return self.s.world.server_for(profile).exit_ip


class ConnectTests(ManagerCase):
    def test_happy_path(self):
        a = self.wg[0]
        res = self.s.mgr.activate(a.id)
        self.assertEqual(res.exit_ip, self.exit_of(a))
        self.assertEqual(res.via, "connect")
        self.assertTrue(res.changed)
        self.assertEqual(res.dns, ["10.8.0.1"])
        st = self.s.mgr.status()
        self.assertTrue(st["connected"])
        self.assertEqual(st["state"], "connected")
        self.assertEqual(st["profile"]["id"], a.id)
        self.assertEqual(st["exit_ip"], self.exit_of(a))
        self.assertTrue(self.s.ks.armed)
        self.assertIn(res.server.split(":")[0], self.s.ks.last_ruleset)
        self.assertEqual(self.s.store.get(a.id).ok_count, 1)
        self.assertEqual(self.s.kinds(), ["connecting", "connected"])
        rows = self.s.history.recent_rotations()
        self.assertEqual((len(rows), rows[0]["status"], rows[0]["new_ip"]), (1, "success", self.exit_of(a)))

    def test_firewall_is_armed_and_server_allowed_before_the_tunnel_starts(self):
        seen = []
        stack = self.s

        class Probe(SimBackend):
            def connect(self, req):
                seen.append((stack.ks.armed, req.target.ip in stack.ks.last_ruleset))
                return super().connect(req)
        stack.backends["wireguard"] = Probe(stack.world, "wireguard", stack.cfg.vpn, stack.runner, stack.paths, stack.net)
        stack.mgr.activate(self.wg[0].id)
        self.assertEqual(seen, [(True, True)])

    def test_dns_and_ipv6_are_locked_before_the_ip_is_verified(self):
        stack, seen = self.s, []
        orig = stack.echo.lookup

        def spy(*a, **kw):
            seen.append((stack.hardening.dns.active(), stack.knob.read_text().strip(), kw.get("device")))
            return orig(*a, **kw)
        stack.echo.lookup = spy
        stack.mgr.activate(self.wg[0].id)
        self.assertEqual(seen[0], (True, "1", "ipshift0"))             # bound to the tunnel interface
        self.assertEqual(stack.hardening.dns.current(), ["10.8.0.1"])

    def test_unknown_profile(self):
        with self.assertRaises(NotFound):
            self.s.mgr.activate("nope")
        self.assertEqual(self.s.mgr.state, "disconnected")

    def test_disabled_and_quarantined_profiles_are_refused_without_penalty(self):
        p = self.wg[0]
        self.s.store.update(p.id, enabled=False)
        with self.assertRaises(ProfileError):
            self.s.mgr.activate(p.id)
        self.assertEqual(self.s.store.get(p.id).fail_count, 0)

    def test_kill_switch_failure_means_no_tunnel(self):
        calls = []
        self.s.ks.arm = lambda: (_ for _ in ()).throw(KillSwitchError("nft exploded"))
        orig = self.s.backends["wireguard"].connect
        self.s.backends["wireguard"].connect = lambda req: calls.append(req) or orig(req)
        with self.assertRaises(KillSwitchError):
            self.s.mgr.activate(self.wg[0].id)
        self.assertEqual(calls, [])
        self.assertIsNone(self.s.world.tunnel_profile)
        self.assertEqual(self.s.store.get(self.wg[0].id).fail_count, 0)       # not the profile's fault

    def test_missing_backend_tool_is_a_dependency_error(self):
        stack = self.s

        class Missing(SimBackend):
            def available(self):
                return "WireGuard tools are not installed"
        stack.backends["wireguard"] = Missing(stack.world, "wireguard", stack.cfg.vpn, stack.runner, stack.paths, stack.net)
        with self.assertRaises(DependencyError):
            stack.mgr.activate(self.wg[0].id)
        self.assertEqual(stack.store.get(self.wg[0].id).fail_count, 0)

    def test_firewall_disabled_by_config_is_announced_once(self):
        self.s.cfg.killswitch.enabled = False
        self.s.mgr.activate(self.wg[0].id)
        self.s.mgr.activate(self.wg[1].id)
        self.assertEqual(self.s.kinds().count("killswitch_disabled"), 1)
        self.assertFalse(self.s.ks.armed)
        self.assertEqual(self.s.ks.last_ruleset, "")


class FailureTests(ManagerCase):
    def test_failed_connect_stays_blocked_and_is_recorded(self):
        p = self.ov[0]
        self.s.world.fail[p.id] = "simulated auth failure"
        with self.assertRaises(VpnError):
            self.s.mgr.activate(p.id)
        st = self.s.mgr.status()
        self.assertEqual((st["state"], st["connected"]), ("failed", False))
        self.assertIn("auth failure", st["last_error"])
        self.assertTrue(self.s.ks.armed)                               # fail closed
        self.assertNotIn(self.s.world.server_for(p).server_ip, self.s.ks.last_ruleset)   # and nobody is allowed
        self.assertIsNone(self.s.world.tunnel_profile)
        prof = self.s.store.get(p.id)
        self.assertEqual((prof.fail_count, prof.consecutive_failures), (1, 1))
        self.assertEqual(self.s.history.recent_rotations()[0]["status"], "failed")
        ev = self.s.last_event("connect_failed")
        self.assertEqual((ev.level, ev.data["code"]), ("warning", "vpn"))

    def test_three_failures_quarantine_the_profile(self):
        p = self.wg[0]
        self.s.world.fail[p.id] = "simulated outage"
        for _ in range(3):
            with self.assertRaises(VpnError):
                self.s.mgr.activate(p.id)
        self.assertTrue(self.s.store.get(p.id).quarantined)
        with self.assertRaises(ProfileError):
            self.s.mgr.activate(p.id)
        self.assertEqual(self.s.store.get(p.id).fail_count, 3)

    def test_timeout(self):
        self.s.cfg.vpn.connect_timeout = 1.0
        p = self.ov[0]
        self.s.world.stuck.add(p.id)
        t0 = time.monotonic()
        with self.assertRaises(VpnTimeout):
            self.s.mgr.activate(p.id)
        self.assertLess(time.monotonic() - t0, 4)
        self.assertTrue(self.s.ks.armed)

    def test_tunnel_that_passes_no_traffic_is_a_failure(self):
        stack = self.s
        stack.cfg.vpn.verify_timeout = 1.0

        class Dead(SimBackend):
            def connect(self, req):
                info = super().connect(req)
                self.world.dead = True
                return info
        stack.backends["wireguard"] = Dead(stack.world, "wireguard", stack.cfg.vpn, stack.runner, stack.paths, stack.net)
        with self.assertRaises(VerificationError):
            stack.mgr.activate(self.wg[0].id)
        self.assertIsNone(stack.world.tunnel_profile)                  # torn down, not left half-open
        self.assertTrue(stack.ks.armed)
        self.assertEqual(stack.store.get(self.wg[0].id).fail_count, 1)

    def test_exit_address_equal_to_the_real_ip_is_a_critical_leak(self):
        p = self.wg[0]
        self.s.mgr.baseline_ip = self.exit_of(p)
        with self.assertRaises(LeakDetected):
            self.s.mgr.activate(p.id)
        self.assertEqual(self.s.last_event("connect_failed").level, "critical")
        self.assertIsNone(self.s.world.tunnel_profile)

    def test_private_exit_address_is_rejected_on_a_real_network(self):
        self.s.mgr.require_global_exit = True                          # the sim uses documentation addresses
        with self.assertRaises(VerificationError):
            self.s.mgr.activate(self.wg[0].id)

    def test_cancel_aborts_a_hanging_connect_without_blaming_the_profile(self):
        p = self.ov[0]
        self.s.world.stuck.add(p.id)
        out = {}

        def work():
            try:
                self.s.mgr.activate(p.id)
            except VpnError as e:
                out["err"] = e
        t = threading.Thread(target=work)
        t.start()
        time.sleep(0.3)
        t0 = time.monotonic()
        self.s.mgr.cancel()
        t.join(5)
        self.assertFalse(t.is_alive())
        self.assertLess(time.monotonic() - t0, 2)
        self.assertEqual(str(out["err"]), "cancelled")
        self.assertEqual(self.s.mgr.state, "disconnected")
        self.assertEqual(self.s.store.get(p.id).fail_count, 0)
        self.assertEqual(self.s.history.recent_rotations()[0]["status"], "cancelled")


class OverlapTests(ManagerCase):
    def test_a_second_request_during_a_connect_is_refused(self):
        stack = self.s
        gate, started = threading.Event(), threading.Event()

        class Slow(SimBackend):
            def connect(self, req):
                started.set()
                gate.wait(5)
                return super().connect(req)
        stack.backends["wireguard"] = Slow(stack.world, "wireguard", stack.cfg.vpn, stack.runner, stack.paths, stack.net)
        t = threading.Thread(target=lambda: stack.mgr.activate(self.wg[0].id))
        t.start()
        self.assertTrue(started.wait(5))
        try:
            with self.assertRaises(BusyError) as cm:
                stack.mgr.activate(self.wg[1].id)
            self.assertIn("activate", str(cm.exception))
            self.assertEqual(stack.mgr.status()["busy"], "activate")
        finally:
            gate.set()
            t.join(5)
        self.assertEqual(stack.mgr.state, "connected")
        self.assertIsNone(stack.mgr.status()["busy"])
        self.assertEqual(stack.store.get(self.wg[1].id).ok_count, 0)    # the refused request never ran


class SwitchTests(ManagerCase):
    def test_wireguard_to_wireguard_is_a_hot_swap_with_both_servers_allowed_meanwhile(self):
        a, b = self.wg[0], self.wg[1]
        self.s.mgr.activate(a.id)
        calls = spy_endpoints(self.s)
        res = self.s.mgr.activate(b.id, reason="rotate")
        self.assertEqual(res.via, "hot-swap")
        self.assertEqual(res.exit_ip, self.exit_of(b))
        self.assertEqual(res.previous_ip, self.exit_of(a))
        sa, sb = (f"{self.s.world.server_for(x).server_ip}:51820" for x in (a, b))
        self.assertEqual(calls[0], [sa, sb])                       # old + new while switching
        self.assertEqual(calls[-1], [sb])                          # then only the new one
        self.assertTrue(self.s.ks.armed)
        self.assertEqual(self.s.history.recent_rotations()[0]["reason"], "rotate")

    def test_wireguard_to_openvpn_is_a_full_reconnect_behind_the_firewall(self):
        a, b = self.wg[0], self.ov[0]
        self.s.mgr.activate(a.id)
        order = []
        for name, be in self.s.backends.items():
            od, oc = be.disconnect, be.connect
            be.disconnect = (lambda od=od, name=name: (order.append(f"down:{name}"), od())[1])
            be.connect = (lambda req, oc=oc, name=name: (order.append(f"up:{name}"), oc(req))[1])
        res = self.s.mgr.activate(b.id, reason="rotate")
        self.assertEqual(res.via, "connect")
        self.assertLess(order.index("down:wireguard"), order.index("up:openvpn"))
        self.assertTrue(self.s.ks.armed)

    def test_fast_switch_can_be_turned_off(self):
        self.s.cfg.vpn.fast_switch = False
        self.s.mgr.activate(self.wg[0].id)
        self.assertEqual(self.s.mgr.activate(self.wg[1].id).via, "connect")

    def test_failed_hot_swap_leaves_nothing_open(self):
        a, b = self.wg[0], self.wg[1]
        self.s.mgr.activate(a.id)
        self.s.world.fail[b.id] = "handshake failed"
        with self.assertRaises(VpnError):
            self.s.mgr.activate(b.id, reason="rotate")
        self.assertEqual(self.s.mgr.state, "failed")
        self.assertIsNone(self.s.world.tunnel_profile)
        self.assertNotIn(self.s.world.server_for(a).server_ip, self.s.ks.last_ruleset)
        self.assertTrue(self.s.ks.armed)

    def test_same_exit_address_counts_as_failed_rotation_but_keeps_the_tunnel(self):
        a, b = self.wg[0], self.wg[1]
        self.s.mgr.activate(a.id)
        self.s.world.server_for(b).exit_ip = self.exit_of(a)
        with self.assertRaises(IPUnchanged):
            self.s.mgr.activate(b.id, reason="rotate")
        self.assertEqual(self.s.mgr.state, "connected")                 # still protected, still working
        self.assertEqual(self.s.mgr.status()["profile"]["id"], b.id)
        self.assertEqual(self.s.history.recent_rotations()[0]["status"], "unchanged")
        self.assertEqual(self.s.store.get(b.id).fail_count, 0)
        self.assertEqual(self.s.last_event("unchanged").level, "warning")

    def test_same_exit_address_is_fine_for_a_manual_connect(self):
        a, b = self.wg[0], self.wg[1]
        self.s.mgr.activate(a.id)
        self.s.world.server_for(b).exit_ip = self.exit_of(a)
        res = self.s.mgr.activate(b.id, reason="manual")
        self.assertFalse(res.changed)


class EndpointTests(ManagerCase):
    def make_profile(self, name, endpoints, protocol="openvpn"):
        p = Profile(make_id(name, "x"), name, protocol, endpoints=endpoints)
        self.s.store.add(p, "x")
        return p

    def test_names_are_resolved_inside_a_firewall_window_and_cached(self):
        p = self.make_profile("Named", [Endpoint("vpn.example.org", 1194, "udp", [])])
        self.s.resolver.answers["vpn.example.org"] = ["203.0.113.44"]
        res = self.s.mgr.activate(p.id)
        self.assertTrue(res.server.startswith("203.0.113.44:1194"))
        self.assertEqual(self.s.resolver.calls, [("vpn.example.org", 4)])
        self.assertEqual(self.s.resolver.window_open_during_call, [True])
        self.assertEqual(self.s.ks._bootstrap, [])                       # window closed again
        self.assertNotIn("DoH bootstrap", self.s.ks.last_ruleset)
        self.assertEqual(self.s.store.get(p.id).endpoints[0].ips, ["203.0.113.44"])
        self.s.mgr.activate(p.id)
        self.assertEqual(len(self.s.resolver.calls), 1)                  # cached now: no second lookup

    def test_unresolvable_server_is_an_error_not_a_hang(self):
        p = self.make_profile("Gone", [Endpoint("gone.example.org", 1194, "udp", [])])
        with self.assertRaises(VpnError) as cm:
            self.s.mgr.activate(p.id)
        self.assertIn("address", str(cm.exception))
        self.assertEqual(self.s.ks._bootstrap, [])

    def test_second_server_is_tried_when_the_first_does_not_answer(self):
        p = self.make_profile("Multi", [Endpoint("m.example.org", 1194, "udp", ["203.0.113.50", "203.0.113.51"])])
        self.s.world.bad_servers = {"203.0.113.50"}
        res = self.s.mgr.activate(p.id)
        self.assertTrue(res.server.startswith("203.0.113.51"))
        self.assertEqual(self.s.store.get(p.id).endpoints[0].ips, ["203.0.113.50", "203.0.113.51"])   # cache kept

    def test_all_servers_failing_clears_the_cached_addresses(self):
        p = self.make_profile("Multi2", [Endpoint("m2.example.org", 1194, "udp", ["203.0.113.50", "203.0.113.51"])])
        self.s.world.bad_servers = {"203.0.113.50", "203.0.113.51"}
        with self.assertRaises(VpnError):
            self.s.mgr.activate(p.id)
        self.assertEqual(self.s.store.get(p.id).endpoints[0].ips, [])


class LifecycleTests(ManagerCase):
    def test_disconnect_with_release_gives_the_network_back(self):
        self.s.mgr.activate(self.wg[0].id)
        self.s.mgr.disconnect(release=True)
        self.assertEqual(self.s.mgr.state, "disconnected")
        self.assertFalse(self.s.ks.armed)
        self.assertEqual(self.s.resolv.read_text(), "nameserver 192.168.1.1\n")
        self.assertEqual(self.s.knob.read_text().strip(), "0")
        self.assertIsNone(self.s.world.tunnel_profile)
        self.assertEqual(self.s.last_event("disconnected").data["released"], True)

    def test_disconnect_without_release_keeps_blocking(self):
        self.s.mgr.activate(self.wg[0].id)
        self.s.mgr.disconnect(release=False)
        self.assertTrue(self.s.ks.armed)
        self.assertTrue(self.s.hardening.dns.active())
        self.assertNotIn(self.s.world.server_for(self.wg[0]).server_ip, self.s.ks.last_ruleset)
        self.assertFalse(self.s.echo.lookup(4).ok)                      # nothing gets out: the world sees a firewall
        self.assertFalse(self.s.echo.lookup(4, device="wlan0").ok)

    def test_connecting_leaves_lockdown_so_the_server_can_be_reached(self):
        self.s.ks.lockdown()
        self.assertTrue(self.s.ks.in_lockdown)
        a = self.wg[0]
        res = self.s.mgr.activate(a.id)
        self.assertFalse(self.s.ks.in_lockdown)
        self.assertIn(res.server.split(":")[0], self.s.ks.last_ruleset)
        self.assertTrue(self.s.echo.lookup(4, device="ipshift0").ok)

    def test_disconnect_when_idle_is_harmless(self):
        self.s.mgr.disconnect(release=True)
        self.assertEqual(self.s.mgr.state, "disconnected")

    def test_recover_after_the_tunnel_dies(self):
        a = self.wg[0]
        self.s.mgr.activate(a.id)
        self.assertTrue(self.s.mgr.tunnel_alive())
        self.s.world.dead = True
        self.assertFalse(self.s.mgr.tunnel_alive())
        res = self.s.mgr.recover()
        self.assertEqual(res.profile_id, a.id)
        self.assertEqual(res.via, "connect")                            # a dead tunnel cannot be hot-swapped
        self.assertTrue(self.s.mgr.tunnel_alive())
        self.assertEqual(self.s.history.recent_rotations()[0]["reason"], "recover")
        self.assertEqual(self.s.last_event("recovering").level, "warning")

    def test_recover_without_history_is_an_error(self):
        with self.assertRaises(VpnError):
            self.s.mgr.recover()

    def test_network_change_reactions(self):
        self.assertEqual(self.s.mgr.on_network_change(), "idle")
        self.s.mgr.activate(self.wg[0].id)
        refreshed = []
        orig = self.s.ks.refresh
        self.s.ks.refresh = lambda: (refreshed.append(1), orig())[1]
        self.assertEqual(self.s.mgr.on_network_change(), "reconnect")   # the sim backend cannot roam
        self.assertEqual(refreshed, [1])                                # the firewall learned the new interfaces
        self.s.cfg.vpn.reconnect_on_network_change = False
        self.assertEqual(self.s.mgr.on_network_change(), "ignored")


if __name__ == "__main__":
    unittest.main()
