"""Shared set-up for the tests that run the Qt layer against the stand-in (``fakeqt``).

A test module calls ``qtcase.install()`` in ``setUpModule`` and ``qtcase.uninstall()`` in
``tearDownModule``, and imports the ``ipshift.gui`` Qt modules only after that (inside functions), because
they bind to whichever PySide6 exists when they are first imported.
"""
from __future__ import annotations

import unittest

import helpers  # noqa: F401  (puts src/ on the path)
import fakeqt


def install() -> None:
    fakeqt.install()


def uninstall() -> None:
    fakeqt.uninstall()


class FakeLink:
    """Stands in for ``DaemonLink`` so button presses can be checked without threads or a daemon."""

    def __init__(self):
        self.calls: list[tuple[str, dict]] = []
        self.refreshes: list[bool] = []
        self.history_wanted = None
        self.poll = None
        self.closed = False
        self.started = False
        self.busy = frozenset()

    def run(self, name, **kwargs):
        self.calls.append((name, kwargs))

    def submit(self, name, job):
        self.calls.append((name, {"job": job}))

    def refresh(self, *, everything=False):
        self.refreshes.append(everything)

    def want_history(self, wanted):
        self.history_wanted = wanted

    def set_poll(self, seconds):
        self.poll = seconds

    def start(self):
        self.started = True

    def close(self):
        self.closed = True

    # ---- helpers for the assertions ------------------------------------------------------------------------------
    @property
    def names(self) -> list[str]:
        return [n for n, _ in self.calls]

    def last(self, name: str) -> dict:
        for n, kw in reversed(self.calls):
            if n == name:
                return kw
        raise AssertionError(f"no {name!r} command was sent; sent: {self.names}")

    def clear(self) -> None:
        self.calls.clear()


class QtCase(unittest.TestCase):
    """A fresh QApplication and event queue for each test; leaves nothing behind."""

    def setUp(self):
        fakeqt.reset()
        from PySide6.QtWidgets import QApplication
        self.app = QApplication([])
        self.addCleanup(self._cleanup)

    def _cleanup(self):
        try:
            self.app.processEvents()
        finally:
            violations = list(fakeqt.state.violations)
            fakeqt.reset()
            from PySide6.QtWidgets import QApplication
            QApplication._instance = None
        self.assertEqual(violations, [], "a widget was touched from a thread other than the GUI thread")

    def pump(self, seconds: float = 0.0) -> None:
        """Deliver queued signals; with ``seconds`` also move the clock so that timers fire."""
        if seconds:
            fakeqt.advance(seconds)
        else:
            self.app.processEvents()

    # ---- widgets ------------------------------------------------------------------------------------------------------
    @staticmethod
    def texts(layout_or_widget, kind=None):
        """The text of every label below a widget, in creation order."""
        from PySide6.QtWidgets import QLabel
        return [w.text() for w in layout_or_widget.findChildren(kind or QLabel)]
