"""Stand-ins for the basic widgets and layouts (see core.py for the rules they follow)."""
from __future__ import annotations

import enum

from .core import QEvent, QObject, Qt, Signal, gui, state


def _need_int(value, what):
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError(f"{what} needs an int, got {type(value).__name__}")
    return value


def _need_number(value, what):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{what} needs a number, got {type(value).__name__}")
    return value


class QSizePolicy:
    class Policy(enum.Enum):
        Fixed = 0
        Minimum = 1
        Maximum = 4
        Preferred = 5
        Expanding = 7


class _Style:
    def unpolish(self, widget):
        widget._polish_log.append("unpolish")

    def polish(self, widget):
        widget._polish_log.append("polish")


class _CloseEvent(QEvent):
    def __init__(self):
        super().__init__(QEvent.Type.Close)


# ---- widgets ---------------------------------------------------------------------------------------------------
class QWidget(QObject):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._layout = None
        self._hidden = False                 # hidden on purpose (hide() / setVisible(False))
        self._shown = False                  # a top-level widget that has been shown
        self._enabled = True
        self._focus = False
        self._tooltip = ""
        self._polish_log: list[str] = []
        self._size_policy = None
        self._window_title = ""
        self._window_icon = None
        self._minimized = False
        self._closed = False
        self.sizes: dict = {}

    # ---- visibility, as in Qt: visible = shown, not hidden, and every ancestor visible ----------------------------
    def _shows_child(self, child) -> bool:
        return True

    def isVisible(self):
        if self._hidden:
            return False
        parent = self._parent
        if parent is None:
            return self._shown
        if isinstance(parent, QWidget):
            return parent._shows_child(self) and parent.isVisible()
        return self._shown

    def isHidden(self):
        return self._hidden or (self._parent is None and not self._shown)

    @gui
    def setVisible(self, visible):
        if not isinstance(visible, bool):
            raise TypeError("setVisible needs a bool")
        was = self.isVisible()
        # As in Qt, hide() is remembered: a widget hidden before it is put into a layout stays hidden there.
        self._hidden = not visible
        if self._parent is None:
            self._shown = visible
        if self._parent is None:
            if visible and not was:
                self.showEvent(QEvent(QEvent.Type.Show))
            elif not visible and was:
                self.hideEvent(QEvent(QEvent.Type.Hide))

    def show(self):
        self.setVisible(True)

    def hide(self):
        self.setVisible(False)

    def showEvent(self, event):
        pass

    def hideEvent(self, event):
        pass

    def changeEvent(self, event):
        pass

    def closeEvent(self, event):
        pass

    @gui
    def close(self):
        event = _CloseEvent()
        self.closeEvent(event)
        if event.isAccepted():
            self._closed = True
            if self._parent is None:
                self._shown = False
        return event.isAccepted()

    # ---- enabling and focus ------------------------------------------------------------------------------------------
    @gui
    def setEnabled(self, enabled):
        if not isinstance(enabled, bool):
            raise TypeError(f"setEnabled needs a bool, got {type(enabled).__name__}")
        self._enabled = enabled

    def isEnabled(self):
        parent = self._parent
        return self._enabled and (not isinstance(parent, QWidget) or parent.isEnabled())

    @gui
    def setFocus(self):
        if state.focused is not None:
            state.focused._focus = False
        state.focused, self._focus = self, True

    def hasFocus(self):
        return self._focus

    # ---- looks (recorded, so tests can look at them) ---------------------------------------------------------------------
    @gui
    def setToolTip(self, text):
        self._tooltip = str(text)

    def toolTip(self):
        return self._tooltip

    def style(self):
        return _Style()

    @gui
    def update(self):
        pass

    @gui
    def setSizePolicy(self, horizontal, vertical):
        if not isinstance(horizontal, QSizePolicy.Policy) or not isinstance(vertical, QSizePolicy.Policy):
            raise TypeError("setSizePolicy needs QSizePolicy.Policy values")
        self._size_policy = (horizontal, vertical)

    @gui
    def setFixedWidth(self, w):
        self.sizes["fixed_width"] = _need_int(w, "setFixedWidth")

    @gui
    def setFixedHeight(self, h):
        self.sizes["fixed_height"] = _need_int(h, "setFixedHeight")

    @gui
    def setMinimumWidth(self, w):
        self.sizes["min_width"] = _need_int(w, "setMinimumWidth")

    @gui
    def setMaximumHeight(self, h):
        self.sizes["max_height"] = _need_int(h, "setMaximumHeight")

    @gui
    def setMinimumSize(self, w, h):
        self.sizes["min_size"] = (_need_int(w, "setMinimumSize"), _need_int(h, "setMinimumSize"))

    @gui
    def resize(self, w, h):
        self.sizes["size"] = (_need_int(w, "resize"), _need_int(h, "resize"))

    @gui
    def setWindowTitle(self, title):
        if not isinstance(title, str):
            raise TypeError("setWindowTitle needs a str")
        self._window_title = title

    def windowTitle(self):
        return self._window_title

    @gui
    def setWindowIcon(self, icon):
        self._window_icon = icon

    def windowIcon(self):
        return self._window_icon

    def grab(self):
        from .gui import QPixmap
        return QPixmap(10, 10)

    # ---- window state -----------------------------------------------------------------------------------------------
    def isMinimized(self):
        return self._minimized

    @gui
    def showNormal(self):
        self._minimized = False
        self.setVisible(True)
        self.changeEvent(QEvent(QEvent.Type.WindowStateChange))

    @gui
    def showMinimized(self):
        self._minimized = True
        self.setVisible(True)
        self.changeEvent(QEvent(QEvent.Type.WindowStateChange))

    @gui
    def raise_(self):
        pass

    @gui
    def activateWindow(self):
        pass

    # ---- layouts ------------------------------------------------------------------------------------------------------
    @gui
    def setLayout(self, layout):
        if not isinstance(layout, QLayout):
            raise TypeError("setLayout needs a QLayout")
        if self._layout is not None:
            raise RuntimeError("the widget already has a layout")
        self._layout = layout
        layout._install(self)

    def layout(self):
        return self._layout


class QFrame(QWidget):
    class Shape(enum.Enum):
        NoFrame = 0
        Box = 1
        Panel = 2
        StyledPanel = 6
        HLine = 4
        VLine = 5

    @gui
    def setFrameShape(self, shape):
        if not isinstance(shape, QFrame.Shape):
            raise TypeError("setFrameShape needs a QFrame.Shape")
        self._shape = shape


class QLabel(QFrame):
    def __init__(self, text="", parent=None):
        super().__init__(parent)
        self._text = _need_str(text)
        self._wrap = False
        self._format = Qt.TextFormat.AutoText          # what the real one does: it guesses rich text
        self._flags = Qt.TextInteractionFlag.NoTextInteraction
        self._alignment = Qt.AlignmentFlag.AlignLeft

    def text(self):
        return self._text

    @gui
    def setText(self, text):
        self._text = _need_str(text)

    @gui
    def setWordWrap(self, wrap):
        self._wrap = bool(wrap)

    def wordWrap(self):
        return self._wrap

    @gui
    def setTextFormat(self, fmt):
        if not isinstance(fmt, Qt.TextFormat):
            raise TypeError("setTextFormat needs a Qt.TextFormat")
        self._format = fmt

    def textFormat(self):
        return self._format

    @gui
    def setTextInteractionFlags(self, flags):
        self._flags = flags

    def textInteractionFlags(self):
        return self._flags

    @gui
    def setAlignment(self, alignment):
        self._alignment = alignment

    def alignment(self):
        return self._alignment


def _need_str(value):
    if not isinstance(value, str):
        raise TypeError(f"expected a str, got {type(value).__name__}")
    return value


class QAbstractButton(QWidget):
    clicked = Signal(bool)
    toggled = Signal(bool)
    _checkable = False

    def __init__(self, text="", parent=None):
        super().__init__(parent)
        self._text = _need_str(text)
        self._checked = False

    def text(self):
        return self._text

    @gui
    def setText(self, text):
        self._text = _need_str(text)

    def isChecked(self):
        return self._checked

    @gui
    def setChecked(self, checked):
        if not isinstance(checked, bool):
            raise TypeError(f"setChecked needs a bool, got {type(checked).__name__}")
        if not self._checkable or checked == self._checked:
            return
        self._checked = checked
        self._after_check(checked)
        self.toggled.emit(checked)

    def _after_check(self, checked):
        pass

    @gui
    def click(self):
        if not self.isEnabled():
            return                                       # as in Qt: a disabled button does nothing
        if self._checkable:
            self.setChecked(not self._checked if self._toggles_off else True)
        self.clicked.emit(self._checked)

    _toggles_off = True


class QPushButton(QAbstractButton):
    pass


class QCheckBox(QAbstractButton):
    _checkable = True


class QRadioButton(QAbstractButton):
    _checkable = True
    _toggles_off = False

    def _after_check(self, checked):
        if checked and self._parent is not None:              # auto-exclusive among the siblings
            for sibling in self._parent._children:
                if isinstance(sibling, QRadioButton) and sibling is not self and sibling._checked:
                    sibling._checked = False
                    sibling.toggled.emit(False)


class _Spin(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._min, self._max, self._value, self._step = 0, 99, 0, 1
        self._suffix = ""
        self._tracking, self._accelerated = True, False

    def minimum(self):
        return self._min

    def maximum(self):
        return self._max

    def value(self):
        return self._value

    def singleStep(self):
        return self._step

    def suffix(self):
        return self._suffix

    @gui
    def setSuffix(self, suffix):
        self._suffix = _need_str(suffix)

    @gui
    def setKeyboardTracking(self, tracking):
        self._tracking = bool(tracking)

    def keyboardTracking(self):
        return self._tracking

    @gui
    def setAccelerated(self, accelerated):
        self._accelerated = bool(accelerated)

    def isAccelerated(self):
        return self._accelerated

    @gui
    def setRange(self, low, high):
        self._min, self._max = self._norm(low), self._norm(high)
        self._set(self._value)

    @gui
    def setSingleStep(self, step):
        self._step = self._norm(step)

    @gui
    def setValue(self, value):
        self._set(self._norm(value))

    def _set(self, value):
        value = min(self._max, max(self._min, value))
        if value != self._value:
            self._value = value
            self.valueChanged.emit(value)


class QSpinBox(_Spin):
    valueChanged = Signal(int)

    def _norm(self, value):
        return _need_int(value, "QSpinBox")


class QDoubleSpinBox(_Spin):
    valueChanged = Signal(float)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._decimals = 2
        self._min, self._max, self._value, self._step = 0.0, 99.99, 0.0, 1.0

    def _norm(self, value):
        return round(float(_need_number(value, "QDoubleSpinBox")), self._decimals)

    def decimals(self):
        return self._decimals

    @gui
    def setDecimals(self, decimals):
        self._decimals = _need_int(decimals, "setDecimals")


class QLineEdit(QWidget):
    class EchoMode(enum.Enum):
        Normal = 0
        NoEcho = 1
        Password = 2

    editingFinished = Signal()
    textChanged = Signal(str)

    def __init__(self, text="", parent=None):
        super().__init__(parent)
        self._text, self._placeholder, self._echo = _need_str(text), "", QLineEdit.EchoMode.Normal

    def text(self):
        return self._text

    @gui
    def setText(self, text):
        text = _need_str(text)
        if text != self._text:
            self._text = text
            self.textChanged.emit(text)

    @gui
    def setPlaceholderText(self, text):
        self._placeholder = _need_str(text)

    def placeholderText(self):
        return self._placeholder

    @gui
    def setEchoMode(self, mode):
        if not isinstance(mode, QLineEdit.EchoMode):
            raise TypeError("setEchoMode needs a QLineEdit.EchoMode")
        self._echo = mode

    def echoMode(self):
        return self._echo


class QComboBox(QWidget):
    currentIndexChanged = Signal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._items: list[tuple[str, object]] = []
        self._index = -1

    @gui
    def addItem(self, text, userData=None):
        self._items.append((_need_str(text), userData))
        if self._index < 0:
            self._index = 0
            self.currentIndexChanged.emit(0)

    def count(self):
        return len(self._items)

    def findData(self, value):
        for i, (_, data) in enumerate(self._items):
            if type(data) is type(value) and data == value:
                return i
        return -1

    def itemText(self, i):
        return self._items[i][0]

    def currentIndex(self):
        return self._index

    def currentData(self):
        return self._items[self._index][1] if 0 <= self._index < len(self._items) else None

    def currentText(self):
        return self._items[self._index][0] if 0 <= self._index < len(self._items) else ""

    @gui
    def setCurrentIndex(self, i):
        _need_int(i, "setCurrentIndex")
        if i != self._index and -1 <= i < len(self._items):
            self._index = i
            self.currentIndexChanged.emit(i)


# ---- layouts ----------------------------------------------------------------------------------------------------
class _Item:
    def __init__(self, widget=None, layout=None, spacer=None, pos=None):
        self._w, self._l, self._s = widget, layout, spacer
        self.pos = pos                           # (row, column) in a grid layout

    def widget(self):
        return self._w

    def layout(self):
        return self._l

    def spacerItem(self):
        return self._s


class QLayout(QObject):
    def __init__(self, parent=None):
        super().__init__()
        self._items: list[_Item] = []
        self._owner = None
        self.margins, self.spacing_value = (9, 9, 9, 9), -1
        if parent is not None:
            parent.setLayout(self)

    @gui
    def setContentsMargins(self, left, top, right, bottom):
        self.margins = tuple(_need_int(v, "setContentsMargins") for v in (left, top, right, bottom))

    @gui
    def setSpacing(self, spacing):
        self.spacing_value = _need_int(spacing, "setSpacing")

    def count(self):
        return len(self._items)

    def itemAt(self, i):
        return self._items[i] if 0 <= i < len(self._items) else None

    @gui
    def takeAt(self, i):
        return self._items.pop(i) if 0 <= i < len(self._items) else None

    def _install(self, owner):
        self._owner = owner
        for item in self._items:
            if item.widget() is not None:
                item.widget()._attach(owner)
            elif item.layout() is not None:
                item.layout()._install(owner)

    def _add_widget(self, widget, pos=None):
        if not isinstance(widget, QWidget):
            raise TypeError(f"addWidget needs a QWidget, got {type(widget).__name__}")
        self._items.append(_Item(widget=widget, pos=pos))
        if self._owner is not None:
            widget._attach(self._owner)

    def _add_layout(self, layout, pos=None):
        if not isinstance(layout, QLayout):
            raise TypeError(f"addLayout needs a QLayout, got {type(layout).__name__}")
        self._items.append(_Item(layout=layout, pos=pos))
        if self._owner is not None:
            layout._install(self._owner)


class QBoxLayout(QLayout):
    @gui
    def addWidget(self, widget, stretch=0, alignment=None):
        _need_int(stretch, "addWidget stretch")
        self._add_widget(widget)

    @gui
    def addLayout(self, layout, stretch=0):
        _need_int(stretch, "addLayout stretch")
        self._add_layout(layout)

    @gui
    def addStretch(self, stretch=0):
        _need_int(stretch, "addStretch")
        self._items.append(_Item(spacer="stretch"))

    @gui
    def addSpacing(self, size):
        _need_int(size, "addSpacing")
        self._items.append(_Item(spacer="spacing"))


class QVBoxLayout(QBoxLayout):
    pass


class QHBoxLayout(QBoxLayout):
    pass


class QGridLayout(QLayout):
    @gui
    def addWidget(self, widget, row, column, alignment=None):
        _need_int(row, "addWidget row")
        _need_int(column, "addWidget column")
        self._add_widget(widget, (row, column))

    @gui
    def addLayout(self, layout, row, column):
        _need_int(row, "addLayout row")
        _need_int(column, "addLayout column")
        self._add_layout(layout, (row, column))

    @gui
    def setColumnStretch(self, column, stretch):
        _need_int(column, "setColumnStretch")
        _need_int(stretch, "setColumnStretch")

    @gui
    def setHorizontalSpacing(self, spacing):
        _need_int(spacing, "setHorizontalSpacing")

    @gui
    def setVerticalSpacing(self, spacing):
        _need_int(spacing, "setVerticalSpacing")
