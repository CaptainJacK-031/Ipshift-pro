"""Stand-ins for the drawing classes in QtGui."""
from __future__ import annotations

import enum

from .basic import _need_int, _need_str
from .core import Qt, QObject, Signal, gui, state


class QColor:
    def __init__(self, value="#000000"):
        if not isinstance(value, (str, Qt.GlobalColor)):
            raise TypeError("QColor needs a colour name or a Qt.GlobalColor")
        self.value = value

    def name(self):
        return self.value if isinstance(self.value, str) else self.value.name


class QBrush:
    def __init__(self, color=None):
        if color is not None and not isinstance(color, (QColor, Qt.GlobalColor)):
            raise TypeError("QBrush needs a QColor")
        self.color = color


class QPixmap:
    def __init__(self, width=0, height=0):
        self.size = (_need_int(width, "QPixmap"), _need_int(height, "QPixmap"))
        self.filled = None

    def fill(self, color):
        self.filled = color

    def isNull(self):
        return self.size == (0, 0)

    def save(self, path):
        with open(path, "wb") as f:
            f.write(b"FAKEPNG")
        return True


class QIcon:
    def __init__(self, pixmap=None):
        if pixmap is not None and not isinstance(pixmap, QPixmap):
            raise TypeError("QIcon needs a QPixmap")
        self.pixmap = pixmap


class QPainter:
    class RenderHint(enum.Enum):
        Antialiasing = 1

    def __init__(self, device):
        if not isinstance(device, QPixmap):
            raise TypeError("QPainter needs something to paint on")
        self.device, self.active, self.calls = device, True, []

    def _need_active(self):
        if not self.active:
            raise RuntimeError("the painter is not active (end() was called)")

    def setRenderHint(self, hint):
        self._need_active()
        if not isinstance(hint, QPainter.RenderHint):
            raise TypeError("setRenderHint needs a QPainter.RenderHint")
        self.calls.append(("hint", hint))

    def setPen(self, pen):
        self._need_active()
        if not isinstance(pen, Qt.PenStyle):
            raise TypeError("setPen needs a pen")
        self.calls.append(("pen", pen))

    def setBrush(self, brush):
        self._need_active()
        if not isinstance(brush, QBrush):
            raise TypeError("setBrush needs a QBrush")
        self.calls.append(("brush", brush))

    def drawEllipse(self, x, y, w, h):
        self._need_active()
        self.calls.append(("ellipse", tuple(_need_int(v, "drawEllipse") for v in (x, y, w, h))))

    def end(self):
        self._need_active()
        self.active = False
        return True


class QAction(QObject):
    triggered = Signal(bool)

    def __init__(self, text="", parent=None):
        super().__init__(parent)
        self._text = _need_str(text)

    def text(self):
        return self._text

    @gui
    def trigger(self):
        self.triggered.emit(False)
