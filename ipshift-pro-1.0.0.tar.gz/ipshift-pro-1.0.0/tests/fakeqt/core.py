"""The heart of the stand-in for PySide6: objects, signals, timers and the event queue.

The real PySide6 cannot be installed in the sandbox this was built in, so the GUI tests run against
this.  It is deliberately STRICT, so that a mistake in the GUI code fails here instead of on a user's desktop:

* only names that exist in the real API are defined (a typo is an AttributeError);
* a signal emitted with the wrong number or kind of arguments is a TypeError, as in PySide;
* a slot is called with as many arguments as it accepts, as in PySide;
* a queued connection delivers during ``QApplication.processEvents()`` in the GUI thread, and an
  object touched from any other thread is recorded in ``state.violations`` and raises;
* ``deleteLater()`` takes effect at the next ``processEvents()``; a deleted object raises RuntimeError.
"""
from __future__ import annotations

import enum
import functools
import inspect
import queue
import threading
import time
import types

state = types.SimpleNamespace()


def reset() -> None:
    """A clean slate for the next test."""
    state.gui_thread = None
    state.app = None
    state.events = queue.Queue()
    state.violations = []                  # widgets touched from the wrong thread
    state.offset = 0.0                     # virtual time added to the real clock (see ``advance``)
    state.timers = []
    state.focused = None
    state.tray_available = True
    state.hooks = types.SimpleNamespace(dialog=None, message_box=None, open_files=[], directory="",
                                        save_path="", informs=[], unscripted=[], calls=[])


reset()


def now() -> float:
    return time.monotonic() + state.offset


def advance(seconds: float) -> None:
    """Jump the clock forward (timers become due) and deliver what is pending."""
    state.offset += seconds
    process_events()


# ---- enums ----------------------------------------------------------------------------------------------------
class Qt:
    class TextFormat(enum.Enum):
        PlainText = 0
        RichText = 1
        AutoText = 2
        MarkdownText = 3

    class TextInteractionFlag(enum.IntFlag):
        NoTextInteraction = 0
        TextSelectableByMouse = 1

    class AlignmentFlag(enum.IntFlag):
        AlignLeft = 1
        AlignRight = 2
        AlignHCenter = 4
        AlignTop = 32
        AlignBottom = 64
        AlignVCenter = 128
        AlignCenter = 132

    class ItemDataRole(enum.IntEnum):
        DisplayRole = 0
        ToolTipRole = 3
        ForegroundRole = 9
        UserRole = 256

    class Orientation(enum.Enum):
        Horizontal = 1
        Vertical = 2

    class ConnectionType(enum.Enum):
        AutoConnection = 0
        DirectConnection = 1
        QueuedConnection = 2

    class GlobalColor(enum.Enum):
        transparent = 19

    class PenStyle(enum.Enum):
        NoPen = 0


class QEvent:
    class Type(enum.Enum):
        WindowStateChange = 105
        Show = 17
        Hide = 18
        Close = 19

    def __init__(self, kind):
        self._type = kind
        self._accepted = True

    def type(self):
        return self._type

    def accept(self):
        self._accepted = True

    def ignore(self):
        self._accepted = False

    def isAccepted(self):
        return self._accepted


# ---- signals ----------------------------------------------------------------------------------------------------
def _coerce(types_, args, name):
    if len(args) != len(types_):
        raise TypeError(f"{name} needs {len(types_)} argument(s) but was emitted with {len(args)}")
    out = []
    for kind, value in zip(types_, args):
        if kind is object:
            out.append(value)
        elif kind is float and isinstance(value, (int, float)) and not isinstance(value, bool):
            out.append(float(value))
        elif kind is int and isinstance(value, int):
            out.append(value)
        elif kind is bool and isinstance(value, bool):
            out.append(value)
        elif kind is str and isinstance(value, str):
            out.append(value)
        else:
            raise TypeError(f"{name}: expected {kind.__name__}, got {type(value).__name__}")
    return tuple(out)


def _accepts(slot, available: int) -> int:
    """How many of the signal's arguments the slot takes (PySide drops the extra ones)."""
    try:
        sig = inspect.signature(slot)
    except (TypeError, ValueError):
        return available
    positional = [p for p in sig.parameters.values()
                  if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)]
    if any(p.kind == p.VAR_POSITIONAL for p in sig.parameters.values()):
        return available
    required = sum(1 for p in positional if p.default is p.empty)
    if required > available:
        raise TypeError(f"slot {getattr(slot, '__qualname__', slot)} needs {required} argument(s); "
                        f"the signal sends {available}")
    return min(len(positional), available)


def call_slot(slot, args) -> None:
    slot(*args[:_accepts(slot, len(args))])


def _receiver(slot):
    owner = getattr(slot, "__self__", None)
    return owner if isinstance(owner, QObject) else None


class SignalInstance:
    def __init__(self, owner, name, kinds):
        self.owner, self.name, self.kinds, self.conns = owner, name, kinds, []

    def connect(self, slot, type=Qt.ConnectionType.AutoConnection):
        if not callable(slot):
            raise TypeError(f"{self.name}.connect needs a callable")
        self.conns.append((slot, type))

    def disconnect(self, slot=None):
        self.conns = [] if slot is None else [c for c in self.conns if c[0] != slot]

    def emit(self, *args):
        args = _coerce(self.kinds, args, self.name)
        self.owner._touch_emit()
        if self.owner._signals_blocked:
            return
        for slot, ctype in list(self.conns):
            receiver = _receiver(slot)
            if ctype is Qt.ConnectionType.QueuedConnection:
                queued = True
            elif ctype is Qt.ConnectionType.DirectConnection:
                queued = False
            else:                                         # auto: queued when the receiver lives in another thread
                queued = receiver is not None and receiver._thread != threading.get_ident()
            if queued:
                state.events.put(("call", slot, args, receiver))
            else:
                call_slot(slot, args)


class Signal:
    def __init__(self, *kinds):
        self.kinds, self.name = kinds, None

    def __set_name__(self, owner, name):
        self.name = name

    def __get__(self, obj, owner=None):
        if obj is None:
            return self
        key = "_sig_" + self.name
        inst = obj.__dict__.get(key)
        if inst is None:
            inst = obj.__dict__[key] = SignalInstance(obj, self.name, self.kinds)
        return inst


# ---- objects ----------------------------------------------------------------------------------------------------
def gui(fn):
    """A method that changes an object: only from the GUI thread, never after deletion."""
    @functools.wraps(fn)
    def wrapper(self, *args, **kwargs):
        self._touch(fn.__name__)
        return fn(self, *args, **kwargs)
    return wrapper


class QObject:
    def __init__(self, parent=None):
        self._thread = threading.get_ident()
        self._deleted = False
        self._signals_blocked = False
        self._props: dict = {}
        self._name = ""
        self._parent = None
        self._children: list = []
        if parent is not None:
            self._attach(parent)

    # ---- guards ------------------------------------------------------------------------------------------------
    def _touch(self, what: str) -> None:
        if self._deleted:
            raise RuntimeError(f"Internal C++ object ({type(self).__name__}) already deleted [{what}]")
        if state.gui_thread is not None and threading.get_ident() != state.gui_thread:
            msg = f"{type(self).__name__}.{what} was called from a thread other than the GUI thread"
            state.violations.append(msg)
            raise AssertionError(msg)

    def _touch_emit(self) -> None:
        if self._deleted:
            raise RuntimeError(f"Internal C++ object ({type(self).__name__}) already deleted [emit]")

    # ---- tree --------------------------------------------------------------------------------------------------
    def _attach(self, parent) -> None:
        if self._parent is parent:
            return
        if self._parent is not None and self in self._parent._children:
            self._parent._children.remove(self)
        self._parent = parent
        if parent is not None:
            parent._children.append(self)

    def parent(self):
        return self._parent

    def children(self):
        return list(self._children)

    def findChildren(self, kind):
        out = []
        for child in self._children:
            if isinstance(child, kind):
                out.append(child)
            out.extend(child.findChildren(kind))
        return out

    def setParent(self, parent):
        self._touch("setParent")
        self._attach(parent)

    # ---- the QObject API ---------------------------------------------------------------------------------------
    @gui
    def setObjectName(self, name):
        self._name = str(name)

    def objectName(self):
        return self._name

    @gui
    def setProperty(self, name, value):
        self._props[str(name)] = value
        return True

    def property(self, name):
        return self._props.get(str(name))

    def blockSignals(self, block):
        previous, self._signals_blocked = self._signals_blocked, bool(block)
        return previous

    def signalsBlocked(self):
        return self._signals_blocked

    def deleteLater(self):
        self._touch("deleteLater")
        state.events.put(("delete", self))

    def _mark_deleted(self) -> None:
        if self._deleted:
            return
        self._deleted = True
        for child in list(self._children):
            child._mark_deleted()
        if self._parent is not None and self in self._parent._children:
            self._parent._children.remove(self)


# ---- timers and the event loop ----------------------------------------------------------------------------------
class QTimer(QObject):
    timeout = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._single = False
        self._interval = 0
        self._due = None

    @gui
    def setSingleShot(self, single):
        self._single = bool(single)

    @gui
    def setInterval(self, ms):
        if not isinstance(ms, int):
            raise TypeError("QTimer.setInterval needs an int")
        self._interval = ms

    def interval(self):
        return self._interval

    @gui
    def start(self, ms=None):
        if ms is not None:
            if not isinstance(ms, int):
                raise TypeError("QTimer.start needs an int number of milliseconds")
            self._interval = ms
        self._due = now() + self._interval / 1000.0
        if self not in state.timers:
            state.timers.append(self)

    @gui
    def stop(self):
        self._due = None
        if self in state.timers:
            state.timers.remove(self)

    def isActive(self):
        return self._due is not None

    def isSingleShot(self):
        return self._single

    def _fire(self) -> None:
        if self._single:
            self.stop()
        else:
            self._due = now() + self._interval / 1000.0
        self.timeout.emit()

    def fire(self) -> None:
        """For tests: make the timer time out right now."""
        if self._due is not None:
            self._fire()

    def _mark_deleted(self):
        if self in state.timers:
            state.timers.remove(self)
        super()._mark_deleted()


def process_events() -> None:
    if state.gui_thread is not None and threading.get_ident() != state.gui_thread:
        raise AssertionError("processEvents was called from a thread other than the GUI thread")
    _drain()
    t = now()
    for timer in list(state.timers):
        if timer._due is not None and timer._due <= t and not timer._deleted:
            timer._fire()
    _drain()


def _drain() -> None:
    for _ in range(100_000):
        try:
            item = state.events.get_nowait()
        except queue.Empty:
            return
        if item[0] == "call":
            _, slot, args, receiver = item
            if receiver is None or not receiver._deleted:
                call_slot(slot, args)
        elif item[0] == "delete":
            item[1]._mark_deleted()
    raise AssertionError("the event queue never emptied: a slot keeps posting events")


class QApplication(QObject):
    _instance = None

    def __init__(self, argv=None):
        super().__init__()
        QApplication._instance = self
        state.gui_thread = threading.get_ident()
        state.app = self
        self.stylesheet, self.style_name, self.app_name, self.desktop_file = "", None, "", ""
        self.quit_called = False
        self.exec_hook = None

    @staticmethod
    def instance():
        return QApplication._instance

    def processEvents(self):
        process_events()

    def setStyle(self, name):
        self.style_name = name

    def setStyleSheet(self, css):
        self.stylesheet = css

    def setApplicationName(self, name):
        self.app_name = name

    def setDesktopFileName(self, name):                  # a static method of QGuiApplication in Qt
        self.desktop_file = name

    @staticmethod
    def quit():
        if QApplication._instance is not None:
            QApplication._instance.quit_called = True

    def exec(self):
        """Without a hook this returns at once; a test can set ``exec_hook`` (called until it returns True)."""
        while not self.quit_called:
            process_events()
            if self.exec_hook is None or self.exec_hook():
                break
            time.sleep(0.005)
        return 0
