"""A strict stand-in for PySide6, so the GUI code can be exercised where Qt cannot be installed.

    import fakeqt
    fakeqt.install()            # PySide6 now means this; ipshift.gui.widgets etc. can be imported
    ...
    fakeqt.uninstall()          # and forgotten again, together with every module that imported it

See core.py for the rules it enforces.
"""
from __future__ import annotations

import importlib
import importlib.machinery
import sys
import types

from . import basic, containers, core, gui
from .core import advance, process_events, reset, state

GUI_MODULES = ("widgets", "dialogs", "qtbridge", "page_dashboard", "page_privacy", "page_history", "page_profiles",
               "page_settings", "window", "app", "selftest", "theme")
_installed = False


def _module(name: str, **attrs) -> types.ModuleType:
    mod = types.ModuleType(name)
    mod.__spec__ = importlib.machinery.ModuleSpec(name, None)       # so importlib.util.find_spec() works
    mod.__dict__.update(attrs)
    return mod


def install() -> None:
    global _installed
    if _installed:
        return
    reset()
    qtcore = _module("PySide6.QtCore", Qt=core.Qt, QObject=core.QObject, Signal=core.Signal, QTimer=core.QTimer,
                     QEvent=core.QEvent, QAbstractTableModel=containers.QAbstractTableModel,
                     QModelIndex=containers.QModelIndex)
    qtgui = _module("PySide6.QtGui", QColor=gui.QColor, QBrush=gui.QBrush, QIcon=gui.QIcon, QPixmap=gui.QPixmap,
                    QPainter=gui.QPainter, QAction=gui.QAction)
    not_widgets = {"QModelIndex", "QAbstractTableModel", "QItemSelectionModel"}      # those live in QtCore
    widgets = {n: getattr(m, n) for m in (basic, containers) for n in dir(m)
               if n.startswith("Q") and n not in not_widgets and isinstance(getattr(m, n), type)
               and getattr(m, n).__module__ == m.__name__}
    widgets["QApplication"] = core.QApplication
    qtwidgets = _module("PySide6.QtWidgets", **widgets)
    pkg = _module("PySide6", QtCore=qtcore, QtGui=qtgui, QtWidgets=qtwidgets)
    pkg.__path__ = []
    sys.modules.update({"PySide6": pkg, "PySide6.QtCore": qtcore, "PySide6.QtGui": qtgui,
                        "PySide6.QtWidgets": qtwidgets})
    _installed = True


def uninstall() -> None:
    """Forget the stand-in and every ipshift.gui module that was built on it."""
    global _installed
    for name in ("PySide6", "PySide6.QtCore", "PySide6.QtGui", "PySide6.QtWidgets"):
        sys.modules.pop(name, None)
    package = sys.modules.get("ipshift.gui")
    for name in GUI_MODULES:
        sys.modules.pop(f"ipshift.gui.{name}", None)
        if package is not None and hasattr(package, name):
            delattr(package, name)
    core.QApplication._instance = None
    reset()
    _installed = False
    importlib.invalidate_caches()
