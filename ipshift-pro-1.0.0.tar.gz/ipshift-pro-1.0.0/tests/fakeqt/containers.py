"""Stand-ins for lists, stacks, tables, dialogs, menus and the main window."""
from __future__ import annotations

import enum

from .basic import QFrame, QPushButton, QWidget, _need_int, _need_str
from .core import QEvent, QObject, Qt, Signal, gui, state


# ---- lists and stacks ---------------------------------------------------------------------------------------------
class QListWidgetItem:
    def __init__(self, text=""):
        self._text = text

    def text(self):
        return self._text


class QListWidget(QFrame):
    currentRowChanged = Signal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._items: list[QListWidgetItem] = []
        self._row = -1

    @gui
    def addItem(self, item):
        self._items.append(item if isinstance(item, QListWidgetItem) else QListWidgetItem(_need_str(item)))

    def count(self):
        return len(self._items)

    def item(self, i):
        return self._items[i] if 0 <= i < len(self._items) else None

    def currentRow(self):
        return self._row

    @gui
    def setCurrentRow(self, row):
        _need_int(row, "setCurrentRow")
        if row != self._row and -1 <= row < len(self._items):
            self._row = row
            self.currentRowChanged.emit(row)


class QStackedWidget(QFrame):
    currentChanged = Signal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._pages: list[QWidget] = []
        self._index = -1

    @gui
    def addWidget(self, widget):
        if not isinstance(widget, QWidget):
            raise TypeError("addWidget needs a QWidget")
        self._pages.append(widget)
        widget._attach(self)
        if self._index < 0:
            self._index = 0
            self.currentChanged.emit(0)
        return len(self._pages) - 1

    def count(self):
        return len(self._pages)

    def currentIndex(self):
        return self._index

    def currentWidget(self):
        return self._pages[self._index] if 0 <= self._index < len(self._pages) else None

    def widget(self, i):
        return self._pages[i] if 0 <= i < len(self._pages) else None

    @gui
    def setCurrentIndex(self, i):
        _need_int(i, "setCurrentIndex")
        if not 0 <= i < len(self._pages):
            return
        if i != self._index:
            self._index = i
            self.currentChanged.emit(i)

    def _shows_child(self, child):
        return child is self.currentWidget()


class QTabWidget(QWidget):
    currentChanged = Signal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._tabs: list[tuple[QWidget, str]] = []
        self._index = -1

    @gui
    def addTab(self, widget, text):
        if not isinstance(widget, QWidget):
            raise TypeError("addTab needs a QWidget")
        self._tabs.append((widget, _need_str(text)))
        widget._attach(self)
        if self._index < 0:
            self._index = 0
        return len(self._tabs) - 1

    def count(self):
        return len(self._tabs)

    def tabText(self, i):
        return self._tabs[i][1]

    def currentIndex(self):
        return self._index

    def currentWidget(self):
        return self._tabs[self._index][0] if 0 <= self._index < len(self._tabs) else None

    @gui
    def setCurrentIndex(self, i):
        _need_int(i, "setCurrentIndex")
        if i != self._index and 0 <= i < len(self._tabs):
            self._index = i
            self.currentChanged.emit(i)

    def _shows_child(self, child):
        return child is self.currentWidget()


class _ScrollBar:
    def __init__(self):
        self._value = 0

    def value(self):
        return self._value

    def setValue(self, value):
        self._value = max(0, _need_int(value, "setValue"))


class QScrollArea(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._widget = None
        self._vbar = _ScrollBar()
        self.resizable = False

    @gui
    def setWidgetResizable(self, resizable):
        self.resizable = bool(resizable)

    @gui
    def setWidget(self, widget):
        if not isinstance(widget, QWidget):
            raise TypeError("setWidget needs a QWidget")
        self._widget = widget
        widget._attach(self)

    def widget(self):
        return self._widget

    def verticalScrollBar(self):
        return self._vbar


class QProgressBar(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._range = (0, 100)
        self._text_visible = True

    @gui
    def setRange(self, low, high):
        self._range = (_need_int(low, "setRange"), _need_int(high, "setRange"))

    def minimum(self):
        return self._range[0]

    def maximum(self):
        return self._range[1]

    @gui
    def setTextVisible(self, visible):
        self._text_visible = bool(visible)


# ---- tables --------------------------------------------------------------------------------------------------------
class QModelIndex:
    def __init__(self, row=-1, column=-1, model=None):
        self._row, self._column, self._model = row, column, model

    def isValid(self):
        return self._row >= 0 and self._column >= 0 and self._model is not None

    def row(self):
        return self._row

    def column(self):
        return self._column


class QAbstractTableModel(QObject):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._views: list = []
        self.reset_count = 0
        self._resetting = False

    def index(self, row, column, parent=None):
        if 0 <= row < self.rowCount() and 0 <= column < self.columnCount():
            return QModelIndex(row, column, self)
        return QModelIndex()

    @gui
    def beginResetModel(self):
        if self._resetting:
            raise RuntimeError("beginResetModel was called twice")
        self._resetting = True

    @gui
    def endResetModel(self):
        if not self._resetting:
            raise RuntimeError("endResetModel without beginResetModel")
        self._resetting = False
        self.reset_count += 1
        for view in self._views:
            view._model_reset()


class QItemSelectionModel(QObject):
    selectionChanged = Signal(object, object)

    def __init__(self, model, parent=None):
        super().__init__(parent)
        self._model = model
        self._rows: list[int] = []

    def selectedIndexes(self):
        return [QModelIndex(r, c, self._model) for r in self._rows for c in range(self._model.columnCount())]

    def hasSelection(self):
        return bool(self._rows)

    def _select(self, row):
        self._rows = [row]
        self.selectionChanged.emit(None, None)

    def _clear_silently(self):
        self._rows = []


class QAbstractItemView(QFrame):
    class SelectionBehavior(enum.Enum):
        SelectItems = 0
        SelectRows = 1
        SelectColumns = 2

    class SelectionMode(enum.Enum):
        NoSelection = 0
        SingleSelection = 1
        MultiSelection = 2
        ExtendedSelection = 3

    class EditTrigger(enum.IntFlag):
        NoEditTriggers = 0
        DoubleClicked = 1


class QHeaderView(QWidget):
    class ResizeMode(enum.Enum):
        Interactive = 0
        Stretch = 1
        Fixed = 2
        ResizeToContents = 3

    def __init__(self, orientation, parent=None):
        super().__init__(parent)
        self.modes: dict = {}
        self.stretch_last = False

    @gui
    def setSectionResizeMode(self, *args):
        if len(args) == 1:
            mode, index = args[0], "all"
        elif len(args) == 2:
            index, mode = _need_int(args[0], "setSectionResizeMode"), args[1]
        else:
            raise TypeError("setSectionResizeMode takes (mode) or (index, mode)")
        if not isinstance(mode, QHeaderView.ResizeMode):
            raise TypeError("setSectionResizeMode needs a QHeaderView.ResizeMode")
        self.modes[index] = mode

    @gui
    def setStretchLastSection(self, stretch):
        self.stretch_last = bool(stretch)


class QTableView(QAbstractItemView):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._model = None
        self._selection = None
        self._vbar = _ScrollBar()
        self._hheader = QHeaderView(Qt.Orientation.Horizontal, self)
        self._vheader = QHeaderView(Qt.Orientation.Vertical, self)
        self.options: dict = {}

    @gui
    def setModel(self, model):
        if not isinstance(model, QAbstractTableModel):
            raise TypeError("setModel needs a model")
        self._model = model
        model._views.append(self)
        self._selection = QItemSelectionModel(model, self)

    def model(self):
        return self._model

    def selectionModel(self):
        return self._selection

    def verticalScrollBar(self):
        return self._vbar

    def horizontalHeader(self):
        return self._hheader

    def verticalHeader(self):
        return self._vheader

    @gui
    def setAlternatingRowColors(self, on):
        self.options["alternating"] = bool(on)

    @gui
    def setSelectionBehavior(self, behavior):
        if not isinstance(behavior, QAbstractItemView.SelectionBehavior):
            raise TypeError("setSelectionBehavior needs a QAbstractItemView.SelectionBehavior")
        self.options["behavior"] = behavior

    @gui
    def setSelectionMode(self, mode):
        if not isinstance(mode, QAbstractItemView.SelectionMode):
            raise TypeError("setSelectionMode needs a QAbstractItemView.SelectionMode")
        self.options["mode"] = mode

    @gui
    def setEditTriggers(self, triggers):
        self.options["edit"] = triggers

    @gui
    def setShowGrid(self, show):
        self.options["grid"] = bool(show)

    @gui
    def setWordWrap(self, wrap):
        self.options["wrap"] = bool(wrap)

    @gui
    def selectRow(self, row):
        _need_int(row, "selectRow")
        if self._model is not None and 0 <= row < self._model.rowCount():
            self._selection._select(row)

    def currentIndex(self):
        rows = self._selection._rows if self._selection else []
        return QModelIndex(rows[0], 0, self._model) if rows else QModelIndex()

    def _model_reset(self):
        """A model reset forgets the selection (silently) and, in the worst case, scrolls back to the top."""
        self._selection._clear_silently()
        self._vbar._value = 0


# ---- dialogs -----------------------------------------------------------------------------------------------------
class QDialog(QWidget):
    class DialogCode(enum.IntEnum):
        Rejected = 0
        Accepted = 1

    def __init__(self, parent=None):
        super().__init__(parent)
        self._result = 0
        self._modal = False

    @gui
    def setModal(self, modal):
        self._modal = bool(modal)

    @gui
    def accept(self):
        self._result = 1

    @gui
    def reject(self):
        self._result = 0

    def result(self):
        return self._result

    def exec(self):
        """Without a scripted answer (``state.hooks.dialog``) the dialog is cancelled and noted."""
        self._touch("exec")
        hook = state.hooks.dialog
        self._result = 0
        if hook is None:
            state.hooks.unscripted.append(type(self).__name__)
            return 0
        hook(self)
        return int(self._result)


class QDialogButtonBox(QWidget):
    class StandardButton(enum.IntFlag):
        NoButton = 0
        Ok = 0x400
        Cancel = 0x400000

    accepted = Signal()
    rejected = Signal()

    def __init__(self, buttons=StandardButton.NoButton, parent=None):
        super().__init__(parent)
        self._buttons = {}
        for flag, text, signal in ((QDialogButtonBox.StandardButton.Ok, "OK", self.accepted),
                                   (QDialogButtonBox.StandardButton.Cancel, "Cancel", self.rejected)):
            if buttons & flag:
                b = QPushButton(text, self)
                b.clicked.connect(lambda *_, signal=signal: signal.emit())
                self._buttons[flag] = b

    def button(self, which):
        return self._buttons.get(which)


class QFileDialog(QDialog):
    class Option(enum.IntFlag):
        ShowDirsOnly = 1
        DontConfirmOverwrite = 2

    @staticmethod
    def getOpenFileNames(parent=None, caption="", dir="", filter="", selectedFilter="", options=None):
        state.hooks.calls.append(("getOpenFileNames", caption))
        return (state.hooks.open_files.pop(0) if state.hooks.open_files else []), ""

    @staticmethod
    def getExistingDirectory(parent=None, caption="", dir="", options=None):
        state.hooks.calls.append(("getExistingDirectory", caption))
        return state.hooks.directory

    @staticmethod
    def getSaveFileName(parent=None, caption="", dir="", filter="", selectedFilter="", options=None):
        state.hooks.calls.append(("getSaveFileName", caption, dir, options))
        return state.hooks.save_path, ""


class QMessageBox(QDialog):
    class Icon(enum.Enum):
        NoIcon = 0
        Information = 1
        Warning = 2
        Critical = 3
        Question = 4

    class ButtonRole(enum.Enum):
        AcceptRole = 0
        RejectRole = 1

    def __init__(self, parent=None):
        super().__init__(parent)
        self._buttons: list[tuple[QPushButton, object]] = []
        self._clicked = None
        self._default = self._escape = None
        self.icon_value = None
        self.text_value = self.informative = ""

    @gui
    def setIcon(self, icon):
        if not isinstance(icon, QMessageBox.Icon):
            raise TypeError("setIcon needs a QMessageBox.Icon")
        self.icon_value = icon

    @gui
    def setText(self, text):
        self.text_value = _need_str(text)

    @gui
    def setInformativeText(self, text):
        self.informative = _need_str(text)

    @gui
    def addButton(self, text, role):
        if not isinstance(role, QMessageBox.ButtonRole):
            raise TypeError("addButton needs a QMessageBox.ButtonRole")
        b = QPushButton(_need_str(text), self)
        self._buttons.append((b, role))
        return b

    @gui
    def setDefaultButton(self, button):
        self._default = button

    @gui
    def setEscapeButton(self, button):
        self._escape = button

    def clickedButton(self):
        return self._clicked

    def exec(self):
        self._touch("exec")
        hook = state.hooks.message_box
        if hook is None:
            state.hooks.unscripted.append("QMessageBox: " + self.text_value)
            self._clicked = self._escape
        else:
            self._clicked = hook(self)
        return 0

    @staticmethod
    def information(parent, title, text, *args):
        state.hooks.informs.append((title, text))


# ---- menus, status bar, tray, main window ----------------------------------------------------------------------
class QMenu(QWidget):
    def __init__(self, title="", parent=None):
        super().__init__(parent)
        self.title_value = title
        self.actions_list: list = []

    @gui
    def addAction(self, text):
        from .gui import QAction
        action = QAction(_need_str(text), self)
        self.actions_list.append(action)
        return action

    def action(self, text):
        return next(a for a in self.actions_list if a.text() == text)


class QMenuBar(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.menus: list[QMenu] = []

    @gui
    def addMenu(self, title):
        menu = QMenu(_need_str(title), self)
        self.menus.append(menu)
        return menu

    def menu(self, title):
        return next(m for m in self.menus if m.title_value == title)


class QStatusBar(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.message = ""
        self.permanent: list = []

    @gui
    def showMessage(self, text, msecs=0):
        self.message = _need_str(text)

    @gui
    def addPermanentWidget(self, widget):
        if not isinstance(widget, QWidget):
            raise TypeError("addPermanentWidget needs a QWidget")
        widget._attach(self)
        self.permanent.append(widget)


class QSystemTrayIcon(QObject):
    class MessageIcon(enum.Enum):
        NoIcon = 0
        Information = 1
        Warning = 2
        Critical = 3

    activated = Signal(object)

    def __init__(self, icon=None, parent=None):
        super().__init__(parent)
        self._icon, self._tooltip, self._menu, self._visible = icon, "", None, False
        self.messages: list[tuple] = []

    @staticmethod
    def isSystemTrayAvailable():
        return state.tray_available

    @gui
    def setIcon(self, icon):
        self._icon = icon

    def icon(self):
        return self._icon

    @gui
    def setToolTip(self, text):
        self._tooltip = _need_str(text)

    def toolTip(self):
        return self._tooltip

    @gui
    def setContextMenu(self, menu):
        if not isinstance(menu, QMenu):
            raise TypeError("setContextMenu needs a QMenu")
        self._menu = menu

    @gui
    def show(self):
        self._visible = True

    @gui
    def hide(self):
        self._visible = False

    def isVisible(self):
        return self._visible

    @gui
    def showMessage(self, title, message, icon=MessageIcon.Information, msecs=10000):
        if not isinstance(icon, QSystemTrayIcon.MessageIcon):
            raise TypeError("showMessage needs a QSystemTrayIcon.MessageIcon")
        self.messages.append((title, message, icon, msecs))


class QMainWindow(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._central = None
        self._menubar = None
        self._statusbar = None

    @gui
    def setCentralWidget(self, widget):
        if not isinstance(widget, QWidget):
            raise TypeError("setCentralWidget needs a QWidget")
        self._central = widget
        widget._attach(self)

    def centralWidget(self):
        return self._central

    def menuBar(self):
        if self._menubar is None:
            self._menubar = QMenuBar(self)
        return self._menubar

    def statusBar(self):
        if self._statusbar is None:
            self._statusbar = QStatusBar(self)
        return self._statusbar
