from __future__ import annotations

import io
import json
import logging
import os
import stat
import time
import unittest

from helpers import TmpRootCase  # noqa: F401  (also puts src/ on sys.path)

from ipshift import config as cfgmod
from ipshift.errors import ConfigError, IPShiftError, VpnTimeout, from_dict
from ipshift.events import EventBus
from ipshift.history import History
from ipshift.logging_setup import mask_ip, redact_text, setup_logging
from ipshift.paths import default_paths
from ipshift.sysutil import atomic_write, is_ipv6, parse_ip


class ConfigTests(TmpRootCase):
    def test_defaults_validate_and_roundtrip(self):
        c = cfgmod.Config()
        c.validate()
        p = self.tmp / "etc" / "config.json"
        c.save(p)
        again = cfgmod.Config.load(p)
        self.assertEqual(c.to_dict(), again.to_dict())

    def test_privacy_first_defaults(self):
        c = cfgmod.Config()
        self.assertTrue(c.killswitch.enabled)
        self.assertFalse(c.killswitch.allow_lan)
        self.assertFalse(c.privacy.baseline)          # no real-IP probe unless opted in
        self.assertFalse(c.killswitch.arm_on_start)   # never lock out an SSH session by default
        self.assertFalse(c.killswitch.release_on_exit)

    def test_interval_floor_is_one_second(self):
        c = cfgmod.Config()
        self.assertEqual(c.set("rotation.interval", "1"), 1.0)
        with self.assertRaises(ConfigError):
            c.set("rotation.interval", "0.5")
        with self.assertRaises(ConfigError):
            c.set("rotation.interval", "0")
        with self.assertRaises(ConfigError):
            c.set("rotation.interval", "nan")
        with self.assertRaises(ConfigError):
            c.set("rotation.interval", "inf")
        self.assertEqual(c.rotation.interval, 1.0)  # failed sets roll back

    def test_file_cannot_bypass_floor(self):
        p = self.tmp / "c.json"
        p.write_text(json.dumps({"rotation": {"interval": 0.1}}))
        with self.assertRaises(ConfigError):
            cfgmod.Config.load(p)

    def test_unknown_keys_are_warned_not_fatal(self):
        c = cfgmod.Config.from_dict({"rotation": {"nope": 1}, "bogus": {}})
        self.assertEqual(len(c.warnings), 2)

    def test_coercion(self):
        c = cfgmod.Config()
        self.assertIs(c.set("killswitch.allow_lan", "yes"), True)
        self.assertEqual(c.set("dns.servers", "9.9.9.9, 1.1.1.1"), ["9.9.9.9", "1.1.1.1"])
        with self.assertRaises(ConfigError):
            c.set("dns.servers", "not-an-ip")
        with self.assertRaises(ConfigError):
            c.set("rotation.strategy", "chaos")
        with self.assertRaises(ConfigError):
            c.set("rotation", "x")
        with self.assertRaises(ConfigError):
            c.set("nope.key", "x")

    def test_echo_urls_must_be_https(self):
        c = cfgmod.Config()
        with self.assertRaises(ConfigError):
            c.set("privacy.ip_echo_v4", "http://example.com/ip")
        c.set("privacy.ip_echo_v4", "http://127.0.0.1:8080/ip")  # loopback is fine (tests)
        self.assertEqual(c.privacy.ip_echo_v4, ["http://127.0.0.1:8080/ip"])

    def test_interface_pattern_validation(self):
        c = cfgmod.Config()
        c.set("killswitch.allow_ifaces", "virbr*,docker0")
        with self.assertRaises(ConfigError):
            c.set("killswitch.allow_ifaces", 'eth0"; drop')

    def test_saved_file_is_world_readable_but_atomic(self):
        c = cfgmod.Config()
        p = self.tmp / "x" / "config.json"
        c.save(p)
        self.assertEqual(stat.S_IMODE(os.stat(p).st_mode), 0o644)
        self.assertEqual([f.name for f in p.parent.iterdir()], ["config.json"])


class PathsTests(TmpRootCase):
    def test_root_override(self):
        p = default_paths()
        self.assertEqual(p.state_dir, self.tmp / "var")
        self.assertEqual(p.socket, self.tmp / "run" / "ipshift.sock")
        self.assertEqual(p.profiles_dir, self.tmp / "var" / "profiles")

    def test_unprivileged_uses_xdg(self):
        env = {"HOME": "/home/u", "XDG_RUNTIME_DIR": "/run/user/1000"}
        p = default_paths(env, euid=1000)
        self.assertEqual(str(p.config_file), "/home/u/.config/ipshift/config.json")
        self.assertEqual(str(p.run_dir), "/run/user/1000/ipshift")

    def test_root_uses_system_dirs(self):
        p = default_paths({}, euid=0)
        self.assertEqual(str(p.config_file), "/etc/ipshift/config.json")
        self.assertEqual(str(p.socket), "/run/ipshift/ipshift.sock")


class ErrorTests(unittest.TestCase):
    def test_roundtrip_keeps_type_and_hint(self):
        e = VpnTimeout("slow", hint="try another server")
        e2 = from_dict(e.to_dict())
        self.assertIsInstance(e2, VpnTimeout)
        self.assertEqual(e2.hint, "try another server")
        self.assertIsInstance(from_dict({"code": "???"}), IPShiftError)


class EventTests(unittest.TestCase):
    def test_publish_subscribe_and_isolation(self):
        bus = EventBus()
        got = []
        un = bus.subscribe(got.append)
        bus.subscribe(lambda e: 1 / 0)          # a broken subscriber must not matter
        bus.publish("ip", level="info", ip="203.0.113.5")
        bus.publish("alert", level="critical", msg="x")
        self.assertEqual([e.kind for e in got], ["ip", "alert"])
        self.assertTrue(got[1].is_alert)
        self.assertFalse(got[0].is_alert)
        un()
        bus.publish("ip")
        self.assertEqual(len(got), 2)
        self.assertEqual(len(bus.recent(10)), 3)
        self.assertEqual([e.kind for e in bus.recent(10, min_level="warning")], ["alert"])


class LoggingTests(unittest.TestCase):
    def test_mask_ip(self):
        self.assertEqual(mask_ip("203.0.113.77"), "203.0.113.x")
        self.assertEqual(mask_ip("2001:db8:1234:5678::1"), "2001:0db8:1234::x")
        self.assertEqual(mask_ip("garbage"), "garbage")

    def test_redact_text(self):
        t = redact_text("exit 198.51.100.23 via 2001:db8:abcd::7 version 1.2.3 ok")
        self.assertIn("198.51.100.x", t)
        self.assertNotIn("198.51.100.23", t)
        self.assertNotIn("2001:db8:abcd::7", t)
        self.assertIn("version 1.2.3", t)

    def test_logger_redacts(self):
        saved = logging.getLogger("ipshift")
        before = (list(saved.handlers), saved.level, saved.propagate)

        def restore():                                          # leave the shared logger as we found it
            saved.handlers[:] = before[0]
            saved.setLevel(before[1])
            saved.propagate = before[2]
        self.addCleanup(restore)
        buf = io.StringIO()
        lg = setup_logging("INFO", None, redact=True, stream=buf)
        lg.info("connected, exit ip %s", "192.0.2.99")
        self.assertIn("192.0.2.x", buf.getvalue())
        self.assertNotIn("192.0.2.99", buf.getvalue())
        setup_logging("INFO", None, redact=False, stream=buf)
        lg.info("exit ip %s", "192.0.2.98")
        self.assertIn("192.0.2.98", buf.getvalue())


class SysutilTests(TmpRootCase):
    def test_atomic_write_mode_and_replace(self):
        p = self.tmp / "d" / "secret"
        atomic_write(p, "one", 0o600)
        atomic_write(p, b"two", 0o600)
        self.assertEqual(p.read_text(), "two")
        self.assertEqual(stat.S_IMODE(os.stat(p).st_mode), 0o600)
        self.assertEqual(len(list(p.parent.iterdir())), 1)

    def test_parse_ip(self):
        self.assertEqual(str(parse_ip(" 192.0.2.1 ")), "192.0.2.1")
        self.assertEqual(str(parse_ip("fe80::1%eth0")), "fe80::1")
        self.assertIsNone(parse_ip("example.com"))
        self.assertTrue(is_ipv6("::1"))
        self.assertFalse(is_ipv6("1.2.3.4"))


class HistoryTests(TmpRootCase):
    def make(self, **kw):
        h = History(self.tmp / "var" / "history.db", **kw)
        self.addCleanup(h.close)
        return h

    def test_file_is_private(self):
        h = self.make()
        self.assertEqual(stat.S_IMODE(os.stat(h.path).st_mode), 0o600)
        self.assertEqual(stat.S_IMODE(os.stat(h.path.parent).st_mode), 0o700)
        h.close()

    def test_add_and_query(self):
        h = self.make()
        h.add_rotation(status="success", profile_id="a", profile_name="A", kind="openvpn",
                       tier="paid", old_ip="1.1.1.1", new_ip="2.2.2.2", duration_ms=900,
                       reason="scheduled")
        h.add_rotation(status="failed", profile_id="b", error="timeout")
        h.add_rotation(status="unchanged", profile_id="c")
        rows = h.recent_rotations(10)
        self.assertEqual([r["status"] for r in rows], ["unchanged", "failed", "success"])
        st = h.stats()
        self.assertEqual((st["total"], st["success"], st["failed"], st["unchanged"], st["unique_ips"]),
                         (3, 1, 1, 1, 1))
        self.assertEqual(st["avg_duration_ms"], 900)

    def test_masking(self):
        h = self.make(mask_ips=True)
        h.add_rotation(status="success", old_ip="198.51.100.4", new_ip="203.0.113.9")
        r = h.recent_rotations(1)[0]
        self.assertEqual((r["old_ip"], r["new_ip"]), ("198.51.100.x", "203.0.113.x"))

    def test_retention_prunes(self):
        h = self.make(retention_days=1)
        h.add_rotation(status="success", ts=time.time() - 3 * 86400)
        h.add_rotation(status="success")
        h.add_event("warning", "x", "old", ts=time.time() - 3 * 86400)
        self.assertEqual(h.prune(), 2)
        self.assertEqual(len(h.recent_rotations()), 1)

    def test_row_cap_keeps_the_newest_rows(self):
        h = self.make(max_rows=1000)
        for i in range(1300):
            h.add_rotation(status="success", profile_id=f"p{i}", new_ip="2.2.2.2")
        self.assertEqual(h.stats()["total"], 1300)                      # trimmed at the next prune, not on every insert
        self.assertGreaterEqual(h.prune(), 300)
        rows = h.recent_rotations(5000)
        self.assertEqual(len(rows), 1000)
        self.assertEqual(rows[0]["profile_id"], "p1299")                # newest first
        self.assertEqual(rows[-1]["profile_id"], "p300")                # the oldest 300 are gone
        self.assertEqual(h.prune(), 0)                                  # nothing more to trim
        h.max_rows = 1000
        for i in range(1500):
            h.add_event("warning", "x", f"e{i}")
        h.prune()
        self.assertEqual(len(h.recent_events(5000)), 1000)             # events are capped too (max_rows // 10, at least 1000)

    def test_clear_and_csv(self):
        h = self.make()
        h.add_rotation(status="success", new_ip="2.2.2.2")
        buf = io.StringIO()
        self.assertEqual(h.export_csv(buf), 1)
        self.assertIn("new_ip", buf.getvalue().splitlines()[0])
        self.assertIn("2.2.2.2", buf.getvalue())
        h.add_event("info", "k", "m")
        h.clear()
        self.assertEqual(h.recent_rotations(), [])
        self.assertEqual(h.recent_events(), [])

    def test_in_memory_mode_touches_no_disk(self):
        h = History(None)
        self.addCleanup(h.close)
        h.add_rotation(status="success")
        self.assertEqual(len(h.recent_rotations()), 1)
        self.assertFalse((self.tmp / "var").exists())


if __name__ == "__main__":
    unittest.main()
