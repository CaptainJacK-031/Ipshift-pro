"""Tiny rtnetlink helper so the kernel-level kill-switch test can build a fake
network (two dummy interfaces and routes) in a throw-away namespace without
needing iproute2.  Test support only."""
from __future__ import annotations

import ipaddress
import socket
import struct

NETLINK_ROUTE = 0
RTM_NEWLINK, RTM_NEWADDR, RTM_NEWROUTE = 16, 20, 24
NLM_F_REQUEST, NLM_F_ACK, NLM_F_EXCL, NLM_F_CREATE, NLM_F_REPLACE = 1, 4, 0x200, 0x400, 0x100
IFLA_IFNAME, IFLA_LINKINFO, IFLA_INFO_KIND = 3, 18, 1
IFA_ADDRESS, IFA_LOCAL = 1, 2
RTA_DST, RTA_OIF, RTA_GATEWAY = 1, 4, 5
IFF_UP = 1


def _attr(kind: int, payload: bytes) -> bytes:
    raw = struct.pack("HH", len(payload) + 4, kind) + payload
    return raw + b"\0" * (-len(raw) % 4)


def _send(msg_type: int, flags: int, body: bytes) -> None:
    s = socket.socket(socket.AF_NETLINK, socket.SOCK_RAW, NETLINK_ROUTE)
    try:
        hdr = struct.pack("IHHII", 16 + len(body), msg_type, flags | NLM_F_REQUEST | NLM_F_ACK, 1, 0)
        s.send(hdr + body)
        resp = s.recv(4096)
        _, mtype, _, _, _ = struct.unpack("IHHII", resp[:16])
        if mtype == 2:                                   # NLMSG_ERROR
            err = struct.unpack("i", resp[16:20])[0]
            if err:
                raise OSError(-err, f"netlink error {-err}")
    finally:
        s.close()


def add_dummy(name: str) -> None:
    info = _attr(IFLA_LINKINFO, _attr(IFLA_INFO_KIND, b"dummy\0"))
    body = struct.pack("BBHiII", socket.AF_UNSPEC, 0, 0, 0, 0, 0) + _attr(IFLA_IFNAME, name.encode() + b"\0") + info
    _send(RTM_NEWLINK, NLM_F_CREATE | NLM_F_EXCL, body)


def set_up(name: str) -> None:
    idx = socket.if_nametoindex(name)
    _send(RTM_NEWLINK, 0, struct.pack("BBHiII", socket.AF_UNSPEC, 0, 0, idx, IFF_UP, IFF_UP))


def add_addr(name: str, cidr: str) -> None:
    iface = ipaddress.ip_interface(cidr)
    fam = socket.AF_INET if iface.version == 4 else socket.AF_INET6
    ip = iface.ip.packed
    body = struct.pack("BBBBI", fam, iface.network.prefixlen, 0, 0, socket.if_nametoindex(name)) \
        + _attr(IFA_LOCAL, ip) + _attr(IFA_ADDRESS, ip)
    _send(RTM_NEWADDR, NLM_F_CREATE | NLM_F_EXCL, body)


def add_route(dst: str, dev: str, gateway: str | None = None) -> None:
    net = ipaddress.ip_network(dst)
    fam = socket.AF_INET if net.version == 4 else socket.AF_INET6
    scope = 0 if gateway else 253                        # universe via gateway, else link
    body = struct.pack("BBBBBBBBI", fam, net.prefixlen, 0, 0, 254, 3, scope, 1, 0)
    if net.prefixlen:
        body += _attr(RTA_DST, net.network_address.packed)
    if gateway:
        body += _attr(RTA_GATEWAY, ipaddress.ip_address(gateway).packed)
    body += _attr(RTA_OIF, struct.pack("I", socket.if_nametoindex(dev)))
    _send(RTM_NEWROUTE, NLM_F_CREATE | NLM_F_REPLACE, body)


def lo_up() -> None:
    set_up("lo")


TUNSETIFF, IFF_TUN, IFF_NO_PI = 0x400454CA, 0x0001, 0x1000


def add_tun(name: str) -> int:
    """Create a TUN interface and return its fd (the interface lives while the fd is open).
    Packets the kernel routes out of the interface can be read from the fd."""
    import fcntl
    import os
    fd = os.open("/dev/net/tun", os.O_RDWR)
    fcntl.ioctl(fd, TUNSETIFF, struct.pack("16sH", name.encode(), IFF_TUN | IFF_NO_PI))
    os.set_blocking(fd, False)
    return fd
